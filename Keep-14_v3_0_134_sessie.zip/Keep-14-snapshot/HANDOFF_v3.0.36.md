# HANDOFF v3.0.36 — Invaarcalculator® publiek-release

**Datum:** Wo 6 mei 2026
**Versie:** v3.0.36
**Status:** Release-klaar voor publicatie op invaarcalculator.nl
**Werkdir:** `/home/claude/Keep-14/`
**Voorgaande sessie:** v3.0.7 → v3.0.36 (29 versies)

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip:
  unzip /mnt/user-data/outputs/Keep-14_v3.0.36_complete.zip -d /home/claude/

Build calculator naar /mnt/user-data/outputs/calculator.html:
  cd /home/claude/Keep-14 && npx tsx build.calc.ts

Volledige regression-suite:
  npx tsx test_browser_calc.ts       # 12 ✓-marks verwacht
  npx tsx src/test_engine.m2.ts      # M1+M2 sluitingscontroles
  npx tsx test_v3_cascade.ts         # 3 cascade-ankers
```

**Werkafspraken:**
- Stap-voor-stap, één wijziging per turn (Werkafspraak 12)
- Alle SSPF-parameter-wijzigingen voorzien van bron-citaat in `fondsdataset.ts`
- Engine-baseline ankers (M1 €543.096 / M2 €574.369 bij x0=67, DG=1.15, r=0.02, N=10) niet wijzigen
- "Persoonlijk pensioenvermogen" canonical in UI; geen "potje"
- UI fonds-agnostisch in publieke tekst; SSPF expliciet alleen in `fondsdataset.ts` comments

---

## 2. SSPF-parameterset (eind v3.0.36) — bron-compleet

**Bestand:** `src/fondsdataset.ts`

| Parameter | Waarde | Bron | Status |
|---|---|---|---|
| Rekenrente `r` | 0.025 (2,5%) | SSPF-presentatie 14-04-2026, DNB UFR-curve eind 2025 | SSPF ✓ |
| Fondsvermogen | 26.000 mln € | SSPF-presentatie 14-04-2026 (eind feb 2026) | SSPF ✓ |
| Dekkingsgraad | 1.35 | Website 31-03-2026 + presentatie eind 2025 (134,7-135,9%) | SSPF ✓ |
| `vpvAftrekPct` | 0.06 (6%) | Implementatieplan 15-07-2025 §5: 2% wettelijk + €500m RDR + €400m compensatie ÷ €26,5 mld ≈ 5,4-7,3% | SSPF ✓ |
| `spreidingN` | **1000** (oneindig) | Implementatieplan 15-07-2025 §5.6: SSPF heeft gekozen voor levenslange spreiding (afwijking van wet) | SSPF ✓ |
| `N_deelnemers` | 26.000 | Presentatie 14-04-2026 deelnemersbestand-grafiek | SSPF ✓ |
| Demografie | preset:'gesloten' (R9.30) | "Prima proxy" — Hans 06-05-2026 | Geaccepteerd |
| `compensatiedepot` | 0 | Bewust nul (in vpvAftrekPct verwerkt) | Numeriek inert |
| `compensatieMu/Sigma` | 55 / 8 | Default | Numeriek inert (compensatiedepot=0) |
| `ervaringsSterfte` | 1.0 | Default | Numeriek inert |

**Bronnen:**
- https://www.shellpensioen.nl/SSPF/onze-beleggingen/financiele-situatie (DG)
- SSPF-presentatie "Financiële Performance SSPF" 14-04-2026 (rekenrente + vermogen + DG-historie)
- SSPF-presentatie "Opbouw deelnemersbestand SSPF 2012-2025" (deelnemers)
- https://www.shellpensioen.nl/-/media/Files/Shellpensioen/Nieuwe-pensioenregeling-sspf/Implementatieplan-SSPF.pdf (aftrek + spreiding §5.6)

---

## 3. Numerieke ankers

### UI-default-ankers (bij default-load)

**Input:** x0=70, geslacht M, partner V x_partner=65, OP €30k, NP €21k

| KPI | Waarde |
|---|---|
| **KV M1** | € 490.091 |
| **PPV M2** | € 678.402 (bij DG=1.35, r=2,5%, aftrek=6%, spreiding=∞) |

### Engine-baseline-ankers (regression-baseline)

`test_engine.m2.ts` met **expliciete params** (x0=67, DG=1.15, r=0.02, aftrek=0.10, N=10):

| Anker | Waarde |
|---|---|
| M1 KV | € 543.096 |
| M2 ppkTotal v3.0 N=10 | € 574.369 |
| M2 ppkTotal v3.0 N=∞ | € 580.519 |
| M2 ppkTotal R9.30-legacy | € 572.166 |
| Onderdekking DG=0.85 | € 323.592 |

**Belangrijke discipline:** wijzig nooit deze regression-baseline. Bij toekomstige UI-default-aanpassingen alleen het anker-cijfer in `test_browser_calc.ts` updaten, niet de engine-tests.

---

## 4. UI-architectuur eind v3.0.36

### Layout van boven naar beneden

```
Invaarcalculator®                          [Uitleg]

┌─ Mijn pensioenfonds ──────────────────────────────┐
│  ⦿ SSPF        ◯ Fonds 2                          │
└───────────────────────────────────────────────────┘

┌─ Uw huidige aanspraak (rood) ─────────────────────┐
│  Leeftijd 70 jaar    Pensioen € 30.000            │
│  Geslacht: ⦿ Man   ◯ Vrouw                        │
│  Heeft u een partner? [✓]                         │
│  Partner-leeftijd 65    Partnerpensioen € 21.000  │
│  Geslacht partner: ◯ Man  ⦿ Vrouw                 │
│  Rekenrente 2,50%                                 │
│                                                   │
│  KV € 490.091 [bold]                              │
│    Eigen ouderdomspensioen € 375.231 [bold]       │
│    Partnerpensioen € 114.860 [bold]               │
│  Verwachte sterfleeftijd ...                      │
└───────────────────────────────────────────────────┘

┌─ Uw persoonlijk pensioenvermogen na invaren ──────┐
│  PPV € 678.402 [bold]                             │
│  + € 188.311 t.o.v. uw aanspraak (+38,4%) ⓘ       │
│    Aandeel ouderdomspensioen € 488.238 [bold]     │
│    Aandeel nabestaandenpensioen € 190.164 [bold]  │
│                                                   │
│  Dekkingsgraad: 135% [?]                          │
│  Aftrek: 6.0% [?]                                 │
│  Spreidingstermijn: Oneindig [?]                  │
│    ◯ 10 jaar (wettelijke standaard)               │
│    ⦿ Oneindig                                     │
└───────────────────────────────────────────────────┘

Vragen of opmerkingen: hans@invaarcalculator.nl · Disclaimer
Release 3.0.36 · 05-05-2026 · CC BY-NC 4.0 · Innovation Nestor
```

### Modal-systeem

**Twee toegankelijke modals via topline + footer:**

1. **Uitleg-modal** (knop "Uitleg" rechtsboven) — 9 secties, fonds-agnostisch:
   - WAAR GAAT DIT OVER? / WAT KUNT U HIER DOEN? / DE REKENRENTE / WAT U NODIG HEEFT / UW HUIDIGE AANSPRAAK / UW VERMOGEN NA INVAREN / WAT DEZE CALCULATOR NIET MEENEEMT / INTERPRETATIE-VALKUILEN / PROCENT VS PROCENTPUNT

2. **Disclaimer-modal** (link "Disclaimer" in footer) — 2 secties:
   - GEEN RECHTEN TE ONTLENEN / PRIVACY

**?-icoon-modals per parameter** (verspreid over UI):
- `r`, `pen`, `y0`, `dekkingsgraad`, `vpvAftrekPct`, `spreidingN`
- Spreidings-modal noemt expliciet SSPF's keuze voor levenslang vs wettelijke 10-jaars default

**Audit-pane** (verborgen, toegang via `?audit=innovation-nestor2026` URL of inline-codeveld onderaan):
- 15-cohort-tabel met sluitingscontroles
- v2.2.10/CRM-2026-34-disclosures

---

## 5. Modules-overzicht

| Bestand | Functie | Regels |
|---|---|---|
| `src/engine.m1.ts` | Joint-life NP, annuityWithQ, m2Context-cascade. v3.0.18: `q(x>120)=1.0` clip | ~770 |
| `src/engine.m2.ts` | Wet-canoniek v3.0, computeFondsXStar, cwStarProfile, computeCohortOutcomes | ~870 |
| `schema.v2.ts` | Zod-SCHEMA met FIELD_REGISTRY (M1/M2-Parametersets via `.pick()`) | ~800 |
| `src/ui.shared.ts` | Pure helpers: escapeHtml, renderInputField, FieldInfo, helpIcon, OPTION_LABELS | ~210 |
| `src/ui.m1.ts` | Standalone scherm 1 (legacy, niet actief in publiek-bundle) | ~520 |
| `src/ui.m2.ts` | renderM2KPI, renderM2Sliders, renderM2Audit, applyM2SliderInput | ~480 |
| `src/ui.app.ts` | Gebundelde calculator (~1200 regels): HELP_CONTENT, openHelpModal, attachGlobalHelpHandler, footer, audit-unlock, partner-block, fondskeuze-radios | ~1200 |
| `src/fondsdataset.ts` | SSPF_M1_PLACEHOLDER + SSPF_M2_PLACEHOLDER + FONDSEN-registry (sspf, fonds2) met bron-citaten | ~110 |
| `build.calc.ts` | HTML-template (topline + footer + js-error-display) + CSS (~700 regels design-tokens v3.0.8) | ~770 |

### Tests

| Bestand | Wat | Status |
|---|---|---|
| `src/test_engine.m2.ts` | M1+M2 sluitingscontroles | ✓ |
| `test_v3_cascade.ts` | 3 v3.0-ankers (N=10, N=∞, R9.30-legacy) | ✓ |
| `test_browser_calc.ts` | 12 UI-tests via JSDOM | 12/12 ✓ |
| `test_smoke.ts` | 17 SCHEMA-smoke | ✓ |
| `test_ui_spreidingN.ts` | 7 UI-spreidings-radio-tests | ✓ |
| `test_cw_star.ts` | 4 cw_star-tests | ✓ |

---

## 6. Belangrijke v3.0.x wijzigingen (samengevat)

### Engine
- **v3.0.18:** `q(x>120)=1.0` clip in engine.m1.ts → fix crash bij x0=83 met partner

### SSPF-parameterset (v3.0.28-32)
- **v3.0.28:** DG 1.15 → 1.35 (website 31-03-2026)
- **v3.0.29:** r 0.02 → 0.025, fondsvermogen 27.202 → 26.000 (presentatie 14-04-2026)
- **v3.0.30:** vpvAftrekPct 0.10 → 0.06 (implementatieplan 15-07-2025 §5)
- **v3.0.31:** N_deelnemers 12.500 → 26.000 (presentatie 14-04-2026)
- **v3.0.32:** spreidingN 10 → 1000 (implementatieplan 15-07-2025 §5.6 levenslang)

### UI-mechaniek (v3.0.8-36)
- **v3.0.8:** CSS design-overhaul (design-tokens, Shell-rood/groen accenten)
- **v3.0.11-12:** leeftijd/pensioen/partner-sliders side-by-side
- **v3.0.13:** help-modal-systeem met ?-knoppen per slider
- **v3.0.14:** tekst-volume drastisch ingekort (intro-paragrafen weg)
- **v3.0.16:** H1 → "Invaarcalculator®"
- **v3.0.17:** topline met ?-knop, modals gesplitst legal/uitleg
- **v3.0.20:** UPO-bewoording op slider-labels
- **v3.0.22-23:** Uitleg-knop, fonds-agnostische tekst
- **v3.0.27:** spreidingstermijn-h3 weg, "Oneindig" zonder educatief-suffix
- **v3.0.33:** M1 KPI sub-blok-structuur identiek aan M2 (bold bedragen)
- **v3.0.34:** fondskeuze-radios (SSPF + Fonds 2) bovenaan
- **v3.0.35:** stand-label "oneindig" → "Oneindig"
- **v3.0.36:** ?-knop weg, Disclaimer-link in footer

---

## 7. Open hoofdpunten / volgende sessie-prioriteiten

| # | Onderwerp | Status | Prioriteit |
|---|---|---|---|
| 1 | **Hosting-deployment naar invaarcalculator.nl** | Hans's keuze | **Hoog** |
| 2 | "Fonds 2" met echte data invullen (ABN-onderzoek) | UI-mechaniek staat, dataset placeholder | Middel |
| 3 | iPad-issue origineel (HTML opent niet) | Niet opgelost; werkt door in Claude side window | Onbekend |
| 4 | Print/deelbaarheid-knop | Niet gestart | Laag |
| 5 | M3 (uitkeringsfase, Monte Carlo, μproj/μ-rentes) | Latere release | Strategisch |
| 6 | M4 (DB vs WTP-regime-vergelijking) | Latere release | Strategisch |

### Voor Fonds 2 (mogelijke ABN-uitbreiding)

Bekend uit Hans's notitie 2 mei 2026 (Bijlage 1 sectie 5):
- Spreidingstermijn 10 jaar (wettelijke default)
- Vermogensaftrek ~10% (publicatie ABN)
- DG-uitkomsten gepubliceerd voor 115/125/135% scenario's

Onbekend voor ABN: actuele DG, fondsvermogen, deelnemersaantal, demografie

**Aanbevolen aanpak:** eerst ABN-website fetchen (abnamropensioenfonds.nl) voor actuele DG en vermogen voordat Fonds 2 met data wordt gevuld. Bij onvolledige bron: blijven bij placeholder-status.

---

## 8. Bekend cosmetisch ding

**Aftrek-stand toont "6.0%" met punt** ipv "6,0%" met komma (Nederlandse decimaal-conventie). Andere percentages doen het wel goed: r-stand toont "2,50%" met komma.

Locatie: `src/ui.app.ts` rond regel 898 (`updateOutputsInPlace`):
```typescript
aftrLabel.textContent = (state.parameters_m2.vpvAftrekPct * 100).toFixed(1) + '%'
```

Fix: gebruik `.replace('.', ',')` of `toLocaleString('nl-NL', { ... })`. Niet kritiek; cosmetic only.

---

## 9. Zip-completeness check

`Keep-14_v3.0.36_complete.zip`:
- 24 MB, 2041 entries
- Alle source-bestanden + tests + node_modules + ag2024.json + alle HANDOFF-docs
- Diff vs werkdir: 0 verschillen
- Bevat: package.json, tsconfig.json, schema.v2.ts (root + symlink), build.calc.ts, ag2024.json, src/* (engine.m1/m2, ui.app/m1/m2/shared, fondsdataset, tests), test_browser_calc.ts, test_v3_cascade.ts, alle HANDOFF_*.md

**Restore:**
```bash
unzip /mnt/user-data/outputs/Keep-14_v3.0.36_complete.zip -d /home/claude/
ln -sf /home/claude/Keep-14 /home/claude/keep9   # optioneel, voor compat met oudere scripts
cd /home/claude/Keep-14
npx tsx build.calc.ts
npx tsx test_browser_calc.ts | grep -c ✓   # → 12
```

---

## 10. Outputs in /mnt/user-data/outputs/

- `calculator.html` (235 KB) — single-file calculator, klaar voor upload naar invaarcalculator.nl
- `Keep-14_v3.0.36_complete.zip` (24 MB) — volledige werkdir-restore
- `HANDOFF_v3.0.36.md` (dit bestand) — handover-document
