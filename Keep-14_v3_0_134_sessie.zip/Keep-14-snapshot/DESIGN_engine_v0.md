# DESIGN — ENGINE V0 (impliciete specificatie R9.30)

Datum: 22-04-2026 21:15
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Bron: code-inspectie van `21-04-2026_2216.html` (Release 9.30)
Status: documentatie van de bestaande engine, niet normatief ontwerp

Dit document maakt **expliciet wat de code feitelijk doet**, in dezelfde vorm als `calculator_specificatie.docx` de ideaal-engine beschrijft. Doel: een gemeenschappelijke basis waarop we beslissingen kunnen nemen over waar code aangepast moet worden aan de specificatie, waar de specificatie aangepast moet worden aan werkelijke behoefte, en waar bewust uit elkaar gehouden moet worden.

De engine bestaat feitelijk uit **drie rekenmodules**, niet één. De specificatie dekt alleen module 1 (waardering). Modules 2 en 3 zijn in de specificatie afwezig maar zijn in de bestaande code hoofdbestanddeel.

---

## 0. Architectuuroverzicht

Drie rekenmodules die als pijplijn zijn gekoppeld via DOM-sliders:

```
  ┌───────────────────────────┐
  │ Module 1 — Waardering     │  Scherm 1 + basis-berekening
  │ annuityTo, lifeExp        │  → persoonlijke KV, levensverwachting
  │ kvProfile (benadering)    │
  └──────────┬────────────────┘
             │ (KV, VPV, levensverwachting)
             ▼
  ┌───────────────────────────┐
  │ Module 2 — Toedeling      │  Scherm 2 (PPK)
  │ ppkCalculate              │  → potje bij invaren
  │ DNB-spreiding, buffer,    │
  │ compensatie, demografie   │
  └──────────┬────────────────┘
             │ (potje, buffer-aandeel, KV, VPV)
             ▼
  ┌───────────────────────────┐
  │ Module 3 — Projectie      │  Scherm 3 (FPR)
  │ verwSimulate              │  → verdelingsbanden U_t, jaar t=0..T
  │ MC 2000 paden, buffer     │
  └───────────────────────────┘
```

Module 1 is puur wiskunde op AG2022-tafel. Module 2 is de fondstoedelingsberekening die meest lijkt op wat `calculator_specificatie.docx` beschrijft, maar radicaal anders gemodelleerd (empirische potje-berekening vs. deterministische annuïteit-waardering). Module 3 is Monte Carlo projectie van toekomstige uitkeringen — buiten de scope van de specificatie zoals die nu geschreven is (§11 noemt "stochastisch" als uitbreiding, §12.1 zegt expliciet dat puntwaardering is).

---

## 1. MODULE 1 — Actuariële primitieven

### 1.1 Sterftekansentabel `Q`

**Locatie:** regel 2896-2913
**Type:** eendimensionale map `{ leeftijd: q }`, leeftijden 25-100

**Wat het is:** een leeftijds-geïndexeerde tabel met één sterftekans per leeftijd. Geen kalenderjaar-dimensie, geen geslacht-dimensie.

**Impliciete aannames:**

1. **Geen gender-onderscheid.** Commentaar in code: *"Alle waarden benaderen AG2022 (gemengde populatie, geen gender-onderscheid)."* Dit is een bewuste simplificatie: AG2022 geeft aparte tafels voor M en V; deze code neemt de gemengde-populatie-waarden (weging op basis van populatie-samenstelling).
2. **Geen generatietafel.** AG2022 is strikt genomen een prognosetafel met kalenderjaar-dimensie (q_{x,t}): sterftekansen zakken over tijd door verwachte levensverwachting-toename. Deze code gebruikt één snapshot, geen tijd-verloop.
3. **Gemengde populatie geen fondsspecifieke overlevingsfactor.** Geen ervaringssterftefactor f; de codebase kent überhaupt geen `f`-veld.
4. **Leeftijd 25-100.** Commentaar: *"Leeftijden 70-100 gebruikt door scherm 1 (KV, levensverwachting) en scherm 3 (simulatie). Leeftijden 25-69 toegevoegd voor de DNB-spreidingsmethode op scherm 2, die over de volledige fondspopulatie (25-100) normaliseert."* De tabel werd pragmatisch uitgebreid toen demografie nodig was.
5. **Cap op leeftijd 100.** Helper `gQ(a) = Q[Math.min(a, 100)] ?? 0.5`. Alles boven 100 krijgt q=0.5 als fallback (50% sterftekans). Dit is een veiligheidsnet, geen actuarieel verantwoorde extrapolatie.
6. **Onregelmatigheid rond leeftijd 62-69.** Waarden 63 (0.00748), 64 (0.00852), 65 (0.00926), 66 (0.00917), 67 (0.00970), 68 (0.00960), 69 (0.00988) vormen geen gladde monotoon stijgende curve — 66 < 65, 68 < 67. Dit is gedoc als "benadering AG2022"; oorsprong van de specifieke waarden niet in codecommentaar teruggevonden. Mogelijk bewust om aan te sluiten op een specifieke publicatie (Implementatieplan?). **Actiepunt voor review.**

### 1.2 `annuityTo(a, r)`

**Locatie:** regel 2925-2933
**Inputs:** leeftijd a, rente r (decimaal)
**Output:** annuïteitsfactor (scalar)

**Formule zoals geïmplementeerd:**

```
af = Σ_{t=0}^{T_eff}  ℓ_{a+t} / (1+r)^t

waarbij ℓ_{a+t} = Π_{s=0}^{t-1} (1 − q_{a+s})
en T_eff = min( MAX_AGE − a,  55,  t zodat a+t > 115 of ℓ_{a+t} < 0.001 )
```

**Dit is een *annuity-due*** (begin-van-periode betaling): eerste term t=0 heeft ℓ_a=1 en discount (1+r)^0=1. Dat wijkt af van de conventie in `calculator_specificatie.docx` §5.4, waar `a_x₀^(m) = (1/m) · Σ_{k=1..m(ω−x₀)} k/m p_{x₀} · P(0, k/m)` expliciet vanaf k=1 start (achteraf-betaling, arrears).

**Impliciete aannames:**

1. **Jaarlijkse frequentie.** Geen betalingsfrequentie m; stappen zijn altijd hele jaren.
2. **Annuity-due, niet arrears.** Eerste betaling op tijd 0, niet op tijd 1/m.
3. **Geen indexatie.** Geen (1+π)^t-term in de som; de functie levert een kale annuïteitsfactor. Indexatie wordt elders geregeld (of niet, afhankelijk van gebruik).
4. **Drievoudige horizon-cap.** t < 55 jaar (hard); a+t ≤ 115 (hard); ℓ > 0.001 (soft — stopt als overleving te klein). De 55-jaar cap betekent dat voor deelnemers van 25 de berekening stopt op leeftijd 80, voor 45-jarigen op 100. Voor gepensioneerden (65+) is de ℓ<0.001-cap typisch eerder bindend.
5. **Geen gender of generatie.** Direct gevolg van Q-tabel.

**Gebruik in code:** `kvProfile`, `ppkCalculate` (persoonlijke KV), `verwSimulate` (startuitkering-berekening), en scherm 1 (huidige pensioen-waardering).

### 1.3 `lifeExp(a)`

**Locatie:** regel 2943-2952
**Input:** leeftijd a
**Output:** verwachte sterfleeftijd (niet de resterende levensverwachting)

**Formule:**

```
sum = Σ_{t=1}^{T_eff} ℓ_{a+t}     // curtate expectation e_a
  met ℓ_{a+t} = ℓ_{a+t-1} × (1 − q_{a+t-1})

return a + sum + 0.5
```

**Impliciete aannames:**

1. **Curtate + 0.5 correctie.** Code-commentaar legt dit expliciet uit: *"ë_a ≈ e_a + 0,5 … De +0,5 corrigeert voor het feit dat overlijden gemiddeld halverwege een jaar plaatsvindt; sluit aan bij hoe CBS en AG2022 levensverwachting rapporteren."* Dit is de standaard complete-expectation-of-life benadering.
2. **Horizon-cap identiek aan annuityTo:** t ≤ 55, a+t ≤ 115, ℓ < 0.001 soft-stop.
3. **Retourneert verwachte sterfleeftijd, geen levensverwachting sensu stricto.** `lifeExp(70)` geeft bijvoorbeeld een waarde rond 88-89, niet de resterende jaren (~18-19). Nuance van benaming.

---

## 2. MODULE 2 — PPK-toedeling (scherm 2)

Deze module is de kernmotor van scherm 2. Hij bevat:
- Persoonlijke kapitaalwaarde (KV) berekening
- Fondsbrede balans-decompositie
- Cohort-toedeling via DNB-spreidingsmethode
- Compensatie via demografisch genormaliseerde bell-curve
- Buffer-aftrek vóór verdeling

Dit is **de plek waar de grootste divergentie met `calculator_specificatie.docx` zit**. De specificatie beschrijft één deterministische actuariële contante waarde (met annuïteit, generatietafel, partner, indexatie). De code doet iets totaal anders: empirische toedeling van verdeelbaar fondsvermogen op basis van dekkingsgraad en fondsdemografie.

### 2.1 Persoonlijke KV — benaderende berekening

**Functie `kvProfile(age, pen, r)`** — regel 3431-3439

```js
if (age < 65) {
  const fractie = (age - 25) / 40;                         // lineaire opbouw 25→65
  const disc = Math.pow(1 + r, -(65 - age));
  return pen * fractie * annuityTo(65, r) * disc;          // opgebouwde aanspraak
}
return pen * annuityTo(Math.min(age, 99), r);              // gepensioneerd
```

Voor gepensioneerden reduceert het tot **KV = pen · ä_age(r)**, waar ä_age de annuity-due is uit §1.2.

**Impliciete aannames:**

1. **Actieven: lineaire opbouw van 0 op leeftijd 25 naar 1 op leeftijd 65.** Geen doorsneesystematiek, geen franchise, geen salariscurve. Commentaar in code: *"Dit is een benadering voor de normalisatie-doeleinden, geen exacte VPV."*
2. **Geen indexatie tijdens opbouw.** pen is het eindbedrag bij 65; discontering naar heden.
3. **Gebruik van fractie = (age - 25) / 40.** Impliciet: pensioenopbouw begint altijd op 25 en eindigt altijd op 65. In werkelijkheid variabel per fonds/baan.
4. **Voor gepensioneerden identiek aan `pen × annuityTo(age, r)`.** Zelfde formule als de KV-berekening op scherm 1 en in `ppkCalculate`.
5. **Alleen gebruikt als cohortgemiddelde-benadering** voor demografie-gewogen sommen. Niet voor de individuele eindberekening.

### 2.2 Fondsbalans-decompositie

Uit `ppkCalculate` (regel 3670-3676):

```js
kv          = pen × annuityTo(min(age, 99), r)
vpvTotal    = fonds / dg                           // totale technische voorziening
operRes     = operPct × fonds                      // operationele reserve als % van fonds
verdeelbaar = fonds − depot − buffer − overig − operRes + bijstort
```

**Impliciete aannames:**

1. **VPV = fonds / dg** is de definitie van dekkingsgraad teruggerekend. Gegeven dekkingsgraad dg en fondsvermogen, is de voorziening fonds/dg. Consistent.
2. **Bijstort wordt toegevoegd aan verdeelbaar.** In de dataset zit `fondsbalans.bijstort` (SSPF-context: werkgeversbijdrage van 500/650/850 mln voor transitie). Wordt direct verdeelbaar gemaakt — geen apart kanaal.
3. **Operationele reserve als percentage van fonds**, niet van voorziening. Dit is een tool-keuze; kan discutabel zijn.
4. **Depot (compensatiedepot) wordt apart behandeld:** eruit getrokken voor basis-verdeling, maar apart weer toegevoegd via de compensatie-curve.
5. **Buffer wordt vooraf afgezonderd.** Bufferveld is niet een fondsbuffer in boekhoudkundige zin, maar een "opzij zetten voor dempings-gebruik op scherm 3"-reservering. Deze keuze maakt dat scherm 2 en scherm 3 één gekoppeld systeem vormen.

### 2.3 Individuele toedeling — gebruikersconsistentie

Uit `ppkCalculate` (regel 3701-3720):

```js
spreidingN  = dnb-slider-waarde (0..15 jaar)
baseRatio   = min(1, verdeelbaar / vpvTotal)
surplus     = max(0, verdeelbaar − vpvTotal)
sFactor     = dnbShareFactor(age, spreidingN)
nFactor     = dnbNormFactor(spreidingN, pen, r)

ppkBase     = kv × baseRatio                                    // dekking-deel
ppkSurplus  = (kv / vpvTotal) × surplus × sFactor × nFactor     // overschot-deel
ppkComp     = (depot / N) × w_relatief(age)                      // compensatie-deel
ppkTotal    = ppkBase + ppkSurplus + ppkComp
```

**Dit is de kernformule van de toedeling.** Drie componenten, alle drie afhankelijk van persoonlijke KV en leeftijd.

**Impliciete aannames en ontwerp-keuzes:**

1. **Gebruikersconsistentie boven fondsconsistentie.** Expliciet in commentaar (regel 3690-3700, de R9.21-keuze): *"De tool simuleert één persoon met bekende KV, en kent de pensioen-verdeling binnen zijn cohort niet — dus een scaleNorm-normalisatie die probeert Σ PPK_i = verdeelbaar te garanderen zou een aanname nodig hebben ('iedereen heeft hetzelfde pensioen als de gebruiker') die vrijwel nooit klopt."*
   - Consequentie: Σ individuele toedelingen ≠ verdeelbaar op fondsniveau
   - Voor één gebruiker wel zuiver: potje = zuivere functie van eigen KV × dekkingsfactor + eigen aandeel in overschot
2. **Basis-deel: volledig proportioneel aan KV bij dekking ≤ 100%.** Onder onderdekking krijgt iedereen pro rata.
3. **Overschot-deel: via DNB-spreidingsmethode.** Ouderen (korte resterende levensduur binnen N-jaar venster) krijgen minder van het overschot; dat wordt herverdeeld naar jongeren via de normalisatie-factor. Bij N=0 (gelijk) reduceert het tot (kv/vpvTotal) × surplus = pure proportionele toedeling.
4. **Compensatie-deel: uitgesmeerd over hele populatie N.** Per-persoon basisbedrag = depot/N; vermenigvuldigd met w_relatief(age) dat piek heeft bij μ (typisch 55-65 jaar, rond moment DRS-afschaffing meest relevant).
5. **KV gebruikt leeftijd gecapt op 99.** `annuityTo(min(age, 99), r)` — voor 100-jarigen voorkomt dit dat de annuïteit op 0 uitkomt (wegens a+t>115 of MAX_AGE=100).

### 2.4 DNB-spreidingsmethode

**Functie `dnbShareFactor(age, N)`** — regel 3447-3456

```
s(a, N) = (1/N) × Σ_{t=0}^{N-1} ℓ_{a+t}     // E[jaren alive in venster] / N
```

Dit is de verwachte fractie van het N-jaars venster dat de deelnemer nog leeft. Bij N=0 (geen spreiding) wordt s(a,0)=1 gezet als speciaal geval. Bij N=∞: convergeert naar resterende-levensduur/N.

**Functie `dnbNormFactor(N, pen, r)`** — regel 3466-3491

```
ν(N) = Σ_cohort ( n_c · kv̄_c )  /  Σ_cohort ( n_c · kv̄_c · s(midage_c, N) )
```

Herverdeel-normalisatie op cohort-midage basis. Zorgt dat totale overschot wel herverdeeld wordt, maar op een aangepaste manier — ouderen krijgen minder, jongeren krijgen meer dan hun KV-aandeel zou suggereren.

**Impliciete aannames:**

1. **N is een keuze van de tool-gebruiker, niet een fondsparameter.** In een echte DNB-context is de spreidingsperiode door het fonds gekozen; hier is het een slider. Pragmatische keuze voor verkenner-positionering.
2. **Normalisatie exact.** Commentaar: *"ν(N) × Σ cohortSFact × cohortMass precies gelijk aan Σ cohortMass, wat de exacte normalisatie van het overschot garandeert."* Σ cohort-overschotten = surplus altijd.
3. **Cohort-midage als benadering.** Elk cohort wordt in de normalisatie vertegenwoordigd door één leeftijd (midden van het bereik), niet een gemiddelde over de leeftijden erin. Consistent met cohort-breakdown maar potentieel een kleine vertekening bij brede cohorten.
4. **Pen in de cache-key.** `kv̄_c` gebruikt pen en r; beide gaan de cache-key in. Bij elke wijziging van pen/r of demografie wordt de normalisatie-tabel opnieuw berekend.

### 2.5 Compensatie-curve

**Functie `ppkBell(a, μ, σ)`** — Gaussisch gewicht op leeftijd

```
w(a) = exp( −0.5 × ((a − μ) / σ)² )
```

**Functie `ppkCurveSum(μ, σ)`** — demografisch gewogen gemiddelde

```
w̄ = Σ_a (n_a · w(a)) / Σ_a n_a

waar n_a = fracties[cohort(a)] / cohortbreedte    (uniform verdeeld binnen cohort)
```

In `ppkCalculate`:

```
w_relatief(age) = w(age) / w̄
ppkComp = (depot / N) × w_relatief(age)
```

**Impliciete aannames:**

1. **Bell-curve is een modelkeuze, geen fondsfeit.** μ en σ zijn UI-sliders (typisch default μ=55, σ=8), representeren vermoeden dat DRS-afschaffings­compensatie rond moment van maximale schade (ruwweg midden-carrière, einde-loopbaan) gecentreerd is. Fondsen doen dit in werkelijkheid via gedetailleerde compensatie-tabellen; de bell-curve is de tool-benadering.
2. **Normalisatie op demografisch gewogen gemiddelde.** `w_relatief = 1.0` voor "gemiddelde deelnemer". Bij uniforme demografie reduceert dit tot de kale w-verdeling; bij grijzend fonds krijgt het gewogen gemiddelde een verschoven ankerpunt.
3. **Basis-bedrag depot/N is gelijk voor iedereen.** Alleen het w_relatief differentieert. Dat betekent: totale compensatie Σ ppkComp_i = depot × Σ(w_rel_i)/N. Bij perfecte cohort-som-normalisatie = depot. Maar met gebruikers-consistentie is de som voor losse individuen niet gebonden.
4. **N staat in de formule — niet N_compensatiedoelgroep.** Iedereen in de populatie (25-100) deelt in de compensatie, niet alleen de doelgroep (typisch 40-60-jarigen). Dat lijkt inconsistent met de wet (compensatie voor DRS-afschaffing geldt specifiek voor actieven die onder het oude systeem inkoop verloren); maar de bell-curve demped dit al door lage w(a) voor jongeren/ouderen.

---

## 3. MODULE 3 — FPR-projectie (scherm 3)

### 3.1 Startuitkering U₀

Uit `verwSimulate` (regel 5485-5513):

```
potje       = ppkCalculate().ppkTotal             // uit module 2
aFactor     = annuityTo(age, proj)                // actuariële annuïteit op projectierendement
baseUitkering = potje / aFactor                   // U₀
```

**Impliciete aannames:**

1. **Potje komt uit module 2.** Volledig afhankelijk van scherm 2-instellingen. Dit koppelt de twee schermen vast aan elkaar.
2. **Actuariële annuïteit, niet deterministische n-jarige.** Code-commentaar (regel 5505-5511): *"In tegenstelling tot een deterministische n-jarige annuïteit (die n=round(ë_x) jaar betalingen veronderstelt alsof zeker) weegt de actuariële ä_x elke toekomstige betaling met de overlevingskans. Dit is wiskundig zuiver FPR: het fonds hoeft alleen te betalen wanneer de deelnemer nog leeft. Voor 70-jarigen is het verschil klein (~0,2%) maar voor 80+ significant (−5 tot −7% U₀)."*
3. **`annuityYears` (regel 5682) bestaat maar wordt hier niet gebruikt.** Is de deterministische n-jarige variant: (1 − (1+r)^-n) / r. Mogelijk legacy of voor een andere context; niet in actieve berekening.
4. **Projectierendement proj is de conversiefactor.** Dit is de DNB-wettelijke rekenrente voor FPR-omzetting. U₀ hangt lineair af van 1/proj; lagere proj → hogere U₀ (meer jaren betalen uit zelfde potje).

### 3.2 Monte Carlo — log-normaal rendement

Configuratie (regel 5537-5552):

```
N_PATHS     = 2000
MASTER_SEED = 20260418

σ_log²      = ln(1 + σ² / (1+μ)²)
μ_log       = ln(1+μ) − σ_log²/2

r_t = exp(μ_log + σ_log · Z) − 1     met Z ~ N(0,1)
```

**Impliciete aannames:**

1. **Geometric Brownian Motion (GBM) voor fondsrendement.** Log-normaal verdeeld jaarlijks rendement. Garandeert (1+r) > 0 altijd.
2. **Arithmetische-naar-log conversie met E-behoud.** E[r_t] = μ en Var(r_t) ≈ σ² exact; dit is de standaard Itô-correctie voor log-normale momenten.
3. **Seed-per-pad, niet één globale stream.** `mulberry32(MASTER_SEED + p)` voor pad p. Voordeel: pad 17 is altijd hetzelfde, onafhankelijk van N_PATHS. Nadeel: correlatie tussen paden als seeds nauw gerelateerd zijn (in praktijk verwaarloosbaar).
4. **Onafhankelijke jaarlijkse rendementen.** Geen autocorrelatie, geen mean-reversion, geen regime-shifts. Eerste-orde Markov met stationaire verdeling.
5. **Geen correlatie met inflatie.** Inflatie is een deterministische slider-waarde; rendement en inflatie worden onafhankelijk behandeld. In realiteit positief gecorreleerd (via rente-route) maar dit model negeert dat.
6. **Geen leeftijd-afhankelijkheid.** Zelfde μ en σ voor alle leeftijden. Geen lifecycle-profiel, geen rente-afdekking-per-cohort. Voor FPR met collectieve toedelingskring (SSPF-context) is dat consistent; voor FPR met individuele lifecycles is het een simplificatie.

### 3.3 U-update — projectierendement-correctie

Regel 5612-5626:

```
U_{t+1} = U_t × (1 + effR_final) / (1 + proj)
```

Dit is de **FPR-kern-update**, en de enige plek waar de specifieke wiskunde van de flexibele premieregeling expliciet zichtbaar is.

**Impliciete aannames en rationale:**

1. **Deling door (1+proj) is essentieel.** Code-commentaar (regel 5612-5621): *"De startuitkering U₀ wordt bij invaren bepaald door het potje te delen door de annuïteitsfactor ä(n, μ_proj). Die formule veronderstelt dat het potje *zelf* met μ_proj groeit om n jaar lang U₀ te kunnen betalen. De uitkering moet daarom alleen meebewegen met het OVER-rendement t.o.v. projectie: als r_t = μ_proj, dan blijft U vlak (factor = 1). Zonder deze deling zou U automatisch met μ_proj per jaar groeien — een systematische overschatting."*
2. **Geen sterftewinsten-toedeling.** In een echte FPR met collectieve toedelingskring worden overlevingskanswinsten naar overlevenden verdeeld (mortality pooling). Deze update doet dat niet expliciet; de annuïteit-aan-het-begin heeft het wel ingebakken. Gevolg: de simulatie toont het verwachte pad voor iemand die in leven blijft.
3. **effR_final is het effectieve rendement na demping en buffer-onttrekking** (zie §3.4).
4. **Geen kosten-aftrek.** Geen ρ_Wtp of equivalent; alle rendement gaat 1-op-1 in U.
5. **Geen regime-schakelaar.** Deze formule is FPR-specifiek; voor SPR-clean/SPR-hybride moet een alternatieve inner loop geschreven worden. In R9.30 is dat niet voorzien — `verwSimulate` is eenduidig FPR.

### 3.4 Demping en buffer

**Demping** (regel 5583-5590):

```
if damp == 0:
    effR = r_t
else:
    window.push(r_t); if len > damp: window.shift()
    effR = mean(window)
```

Rollend gemiddelde over laatste `damp` rendementen. Bij damp=0 geen demping. Voor SSPF: 5-jaars demping is standaard.

**Buffer-mechaniek** (regel 5595-5610):

```
if effR < inf:                         // koopkracht-trigger
    shortfall++
    if buffer > 0:
        tekort      = prev × (inf − effR)
        trekking    = min(tekort, buffer)
        buffer     -= trekking
        effR_final  = effR + trekking / prev
        if trekking >= tekort:   fullyCov++
        else:                    partCov++
    else:
        notCov++
```

**Impliciete aannames:**

1. **Koopkracht-trigger.** Tekortjaar = reëel rendement onder nul (effR < inflatie). Commentaar in code (regel 5623-5625) vlagt dit als heroverweging-punt: *"Bij FPR met opt-in buffer (stap 'buffer-herontwerp') moet die trigger heroverwogen worden in lijn met deze correctie."* Voor pure FPR is `effR < proj + inf` zuiverder (tekort t.o.v. projectie + inflatie), maar huidige code gebruikt de oudere formulering.
2. **Tekort wordt volledig uit buffer betaald, zonder jaarlijkse staffel.** Geen maximum per jaar; eerste slechte jaren kunnen buffer leegtrekken.
3. **Drie categorieën tekortjaren exclusief.** shortfall = fullyCov + partCov + notCov altijd.
4. **Buffer wordt gemeten per pad — gemiddelde over paden in output.** bufEnd in output is gemiddeld, niet mediaan of percentiel.
5. **Start-buffer proportioneel aan KV-aandeel in VPV** (regel 5491-5492): `bufStart = fondsBuf × (kvInd / vpvTotal)`. Dus fondsbrede buffer wordt geallocated per KV-aandeel.

### 3.5 Benchmark (rode lijn)

Regel 5519-5526:

```
benchmarkNom  = pen × (1+inf)^t
benchmarkReel = pen  (constant)
```

**Impliciete aannames:**

1. **Benchmark = "oude situatie met volledige inflatie-indexatie".** Dat is een ideaal-benchmark, niet de werkelijke pre-Wtp-uitkering die voorwaardelijke indexatie kent. Historische SSPF heeft deze indexatie niet altijd volledig gegeven.
2. **Benchmark in reële termen constant.** Impliciet: in koopkracht blijft de oude uitkering gelijk. Vergelijking met FPR-pad toont dan zuiver het FPR-effect.
3. **Geen sterfteweging op benchmark.** Lijn gaat door tot einde plot-horizon ongeacht overleving. Asymmetrisch met de FPR-uitkeringslijnen die wel sterftegewogen zouden moeten zijn — maar in de huidige code is ook de FPR-lijn niet sterftegewogen (paths[p][t] is de uitkering *als* deelnemer nog leeft, niet de verwachte uitkering over alle toestanden).

### 3.6 Horizon en percentielen

Regel 5499-5500:

```
endAge = min(100, ceil(lifeExp(age)))
years  = max(1, endAge − age)
```

Plot-horizon is de verwachte sterfleeftijd (afgerond naar boven), gecapt op 100. Voor 70-jarigen komt dat neer op ongeveer jaar 88-89.

Percentielen (regel 5641-5652):

```
Voor elke t in 0..years:
    sort(paths[·][t])
    p10 = paths[floor(0.10 × N)]
    p50 = paths[floor(0.50 × N)]
    p90 = paths[floor(0.90 × N)]
```

**Impliciete aannames:**

1. **Plot tot verwachte sterfdatum, niet levenslang.** Grafiek is compacter, maar mist de tail van lang-leefde deelnemers.
2. **Percentielen per tijdstap onafhankelijk gesorteerd.** Het "pad p10" is geen coherent pad; het is voor elke t een ander pad. Dit is gangbare praktijk maar relevant om te weten bij interpretatie — de p10-lijn is geen plausibel pad.
3. **p10/p50/p90 hardcoded.** Geen slider voor "toon 5/95 confidence" of iets dergelijks.

---

## 4. DATA-DEPENDENCIES: WAT ENGINE LEEST

Samengevat de inputs die de engine direct uit de DOM leest (via slider-state), niet uit `FONDS_DATASET`:

### Scherm 1 (deelnemersinvoer + globale)
- `ss-age` — leeftijd
- `ss-pen` — jaarbedrag pensioen
- `ss-disc` — rekenrente voor waardering

### Scherm 2 (fonds-parameters + toedeling)
- `ppk-sl-fonds` — fondsvermogen
- `ppk-sl-dg` — dekkingsgraad
- `ppk-sl-depot` — compensatiedepot
- `ppk-sl-overig` — overige onttrekkingen
- `ppk-sl-oper` — operationele reserve %
- `ppk-sl-bijstort` — bijstort van werkgever
- `ppk-sl-n` — aantal deelnemers
- `ppk-sl-piek` — compensatie-curve μ
- `ppk-sl-breedte` — compensatie-curve σ
- `ppk-sl-dnb` — DNB-spreidings-N
- `ppk-sl-buffer` — extra buffer voor scherm 3
- `demografieState.preset` / `customCounts` — demografie

### Scherm 3 (simulatie-parameters)
- `verw-sl-proj` — projectierendement (DNB-regel)
- `verw-sl-rend` — verwacht rendement MC
- `verw-sl-vola` — volatiliteit rendement MC
- `verw-sl-inf` — inflatie
- `verw-sl-demp` — dempingjaren

Alle inputs zijn numerieke sliders met vaste ranges. Een groot deel is in R9.24-R9.30 gekoppeld aan `FONDS_DATASET` via `applyDatasetDefaults` (init + reset); andere zijn puur gebruikersinvoer (leeftijd, pen, disc, vola, demp).

### Hardcoded in engine, niet dataset-gedreven
- AG2022-tabel `Q` (geen `sterftekansTabelId`-dispatch geïmplementeerd)
- `MAX_AGE = 100` (hard-coded horizon-cap)
- `COHORT_BOUNDS` en `COHORT_LABELS` (5-jaars cohorten, 25-100)
- `DEMOGRAFIE_PRESETS` (5 preset-vormen)
- `N_PATHS = 2000` en `MASTER_SEED = 20260418`
- Buffer-trigger-formule `effR < inf`
- Conversie arithmetisch-naar-log voor GBM
- Percentiel-keuze (10/50/90)
- FPR U-update-formule met projectie-deling

---

## 5. EXPLICIETE AANNAMES-LIJST

Samengevat de aannames die het meest opvallen wanneer je deze engine naast `calculator_specificatie.docx` legt:

### A. Actuarieel
1. **Geen generatietafel** — Q is puur leeftijds-dimensie, geen kalenderjaar
2. **Geen geslacht-onderscheid** — gemengde populatie AG2022
3. **Geen ervaringssterftefactor** — geen f(x, g)
4. **Annuïteiten zijn annuity-due, jaarlijks, geen indexatie** — geen m ∈ {1,4,12}
5. **Geen partnerpensioen** — tool kent alleen één deelnemer
6. **Geen kostenopslagen** — geen ρ_DB of ρ_Wtp

### B. Waardering
7. **Geen expliciete V_DB / V_Wtp / Δ** — de tool toont potje en verwachte uitkering, geen waarde-vergelijking
8. **Potje-berekening is empirisch, niet actuarieel** — fondsbalans-decompositie + DNB + compensatie, niet φ × V^Wtp
9. **Impliciete toedelingsfactor** — φ wordt niet expliciet benoemd; in code zit hij als `(kv/vpvTotal) × surplus` versleuteld
10. **Gebruikersconsistentie boven fondsconsistentie** (R9.21-keuze) — individuele uitkomsten optellen niet tot fondstotaal

### C. Projectie
11. **Monte Carlo met log-normaal rendement** — 2000 paden, fixed seed
12. **Onafhankelijke jaren, geen autocorrelatie** — stationaire Markov eerste-orde
13. **Geen correlatie rente-inflatie** — beide onafhankelijk van elkaar en van rendement
14. **Eén regeling (FPR)** — SPR-clean/SPR-hybride niet in `verwSimulate`
15. **Buffer-trigger op koopkracht (effR < inf)** — oudere formulering, markeerd in code als heroverweegpunt
16. **Plot-horizon naar verwachte sterfdatum, gecapt op 100** — niet levenslang
17. **Percentielen per tijdstap onafhankelijk** — p50-lijn is geen coherent pad

### D. Infrastructuur
18. **Scherm 2 en scherm 3 zijn vast gekoppeld** — verwSimulate roept ppkCalculate
19. **Sliders zijn bron-van-waarheid voor engine** — dataset initialiseert ze, gebruiker kan ze overschrijven
20. **Dataset-velden zonder slider** (`RDR_initieel`, `invaardatum`, `minimaleInvaarDG`, `sterftekansTabelId`) **worden niet gelezen** door engine in Fase A

---

## 6. GAP-ANALYSE VERSUS `calculator_specificatie.docx`

Per spec-paragraaf ingedeeld: ✓ in-sync, ∼ gedeeltelijk, ✗ divergent.

| Spec-§ | Onderwerp | Status | Toelichting |
|---|---|---|---|
| §1 | Doel en scope | ∼ | Spec: deterministische puntwaardering. Code: puntwaardering + MC projectie + toedeling. Breder dan spec. |
| §2 | Architectuur (3 componenten) | ∼ | Spec: invoer / parameterset / rekenmodule. Code: heeft wel deelnemersinvoer en parameterset (dataset), maar drie aparte rekenmodules i.p.v. één. |
| §3 | Deelnemersinvoer | ✗ | Spec: x₀, g, t₀, B_OP, B_PP, y₀, g_y. Code: age, pen, r — geen geslacht, geen partner, geen t₀. |
| §4 | Fondsparameterset | ∼ | Overlap in principe (inwisselbaarheid). Velden divergent: zie tabel in vorige feedback. |
| §5.1 | Sterftekansen (generatietafel × f) | ✗ | Code: alleen leeftijdstafel Q. Geen t-dimensie, geen f. |
| §5.2 | Overlevingskansen | ✓ | Code: ℓ_{a+t} via cumulatieve product van (1−q). Identiek. |
| §5.3 | Disconteringsfactoren | ∼ | Code: vlakke rente (1+r)^-t. Spec: RTS prefer, fallback naar vlak. Code heeft alleen fallback. |
| §5.4 | Koopsomfactoren | ∼ | Code: annuityTo is due, geen m-frequentie, geen indexatie, geen reversionary. Spec: arrears, m ∈ {1,4,12}, indexatie inbouwbaar, PP via verschil. |
| §5.5 | V_DB / V_Wtp | ✗ | Spec: expliciete twee waarderingen met dezelfde grondslagen. Code: kent wel KV (= pen × annuityTo) maar geen π_DB / π_Wtp onderscheid, geen ρ-opslagen, geen twee-pass. |
| §5.6 | K_x = φ · V_Wtp | ✗ | Code: potje via DNB + compensatie + basis. Fundamenteel andere formule. |
| §6 | Indexatiescenario's | ✗ | Spec: tabel met π_DB × π_Wtp combinaties. Code: één inflatie-waarde, geen scenarioselector. |
| §7 | Fallbacks bij ontbrekende gegevens | ∼ | Code: SCHEMA v1 hard-fail, geen fallback-gedrag. Dataset moet compleet zijn. |
| §8 | Consistentievoorwaarde pre/post | ∼ | Code: geen pre/post-berekening, dus conditie niet van toepassing. Maar de achterliggende grondslagen-consistentie (zelfde Q, zelfde rente binnen één scherm) is wel gerespecteerd. |
| §9 | Validaties | ∼ | Code: SCHEMA v1 validator + slider-ranges. Raakt spec-punten maar is anders gestructureerd. |
| §10 | Toepassingsmodi (volledig/benadering/demonstratie) | ∼ | Code: kent alleen één modus (de huidige state). Fase B + SSPF-publiek-v1 kan naar "volledig" doorgroeien. |
| §11 | Stochastische uitbreidingen | ✓ (code gaat verder dan spec) | Code heeft Monte Carlo; spec noemt het alleen als toekomstige uitbreiding. |
| §12.1 | V_Wtp als waarde-equivalent | n.v.t. | Code berekent geen V_Wtp. |
| §12.2 | π_Wtp afleiding buiten engine | ∼ | Consistent principe met code (sliders = overschrijven dataset-defaults), maar invulling anders. |
| §12.3 | Onafhankelijkheid x/y | n.v.t. | Code heeft geen joint-life. |
| §12.4 | SPR/FPR via aparte parametersets | ∼ | Consistent qua principe (regeling in dataset), inconsistent qua implementatie (code heeft drie regeling-routes gepland, spec twee). |
| §12.5 | Toedeelbaar vs totaal vermogen | ∼ | Code behandelt reserves expliciet (depot, buffer, overig, operRes) — eerder rijker dan wat spec vraagt. Spec zegt: φ moet gecorrigeerd zijn. Code: dekkingsgraad × verdeelbaar. |
| §12.6 | π_DB als vereenvoudiging | ∼ | Code heeft geen π_DB per scenario; kent maar één inflatie-slider. |
| §13 | SPR/FPR-differentiatie | ∼ | Code heeft regeling-pill geïmplementeerd maar alleen FPR werkt. SPR is Fase B. |

**Kern van de divergentie:** de spec beschrijft een **waarderingsengine** (Δ, V_DB, V_Wtp, K_x) die in de code niet bestaat. De code heeft een **toedelingsengine** (potje-berekening op basis van fondsbalans) en een **projectiecalculator** (MC uitkeringsbanen), die in de spec niet bestaan of alleen als toekomstige uitbreiding worden genoemd. Er is een onderwerp-overlap in de actuariële primitieven (§5.1-§5.4) en een principe-overlap in de architectuur (§2, §4), maar de **semantiek van wat de engine oplevert** verschilt fundamenteel.

---

## 7. VIER BESLISSINGSPUNTEN

Uit deze gap-analyse komen vier duidelijke punten waar besluit nodig is voordat we verder bouwen:

### 7.1 Wat is de semantiek van "de engine"?

Twee opties:

**Optie X** — Engine = waarderingsengine volgens spec. Dan moeten ppkCalculate en verwSimulate herzien of naar een "module 2" status degraderen die bovenop de waardering staat. Concrete consequentie: Δ = V_Wtp − V_DB wordt het kerngetal, potje wordt een afgeleide (φ × V_Wtp), uitkeringsprojectie wordt expliciet als "wat-als-module" afgebakend.

**Optie Y** — Engine = huidige toedelings + projectie-engine; spec wordt uitgebreid om dat te beschrijven. Dan komen er §14 t/m §17 bij (toedelingsmodule, projectiemodule, bufferlogica, compensatiecurve) en wordt de spec een documentatie van wat is, niet een normatief voorstel van wat zou moeten.

Hybride mogelijk: spec-module waarderingsbasis (§5) wordt ingebouwd als **extra** output naast potje en projectie — "hier is uw Δ" als derde antwoord naast "hier is uw potje" en "hier is uw uitkeringsbaan".

### 7.2 Actuariële uitbreidingen

Drie uitbreidingen zijn in de spec wel, in de code niet:

1. **Generatietafel q_{x,t}.** Vereist uitbreiding van Q naar 2D en een engine-functie die op transitiejaar indexeert. Implementatietechnisch niet zwaar.
2. **Ervaringssterftefactor f(x, g).** Simpel veld in dataset, multiplicatief in sterftekans-berekening.
3. **Geslacht-dimensie.** Vereist uitbreiding van deelnemersinvoer en aparte Q_M / Q_V tafels. UI-impact beperkt (één extra veld); engine-impact significant (alle `gQ(a)` worden `gQ(a, g)`).

Welke van deze wil je binnen Fase B?

### 7.3 Partnerpensioen

De spec heeft reversionary annuity via joint-life overlevingskansen. De code heeft geen partner-concept. Toevoegen vereist:
- Extra deelnemersinvoer (B_PP, y₀, g_y)
- Joint-life overleving (1D kans × 1D kans onder onafhankelijkheid)
- Annuity-functie met twee lives
- UI-uitbreiding

Voor SSPF-gepensioneerden is partnerpensioen relevant — veel deelnemers hebben nabestaandendekking via OP. Toevoeging zou de tool materieel verrijken maar is substantieel werk.

### 7.4 Twee of drie regelingen?

Spec: **twee** (SPR, FPR), differentiatie via parametersets. Code: **drie** (FPR, SPR-clean, SPR-hybride) als regeling-selector.

Argument voor twee: dichter bij wettelijke realiteit, matcht terminologie Pensioenwet.
Argument voor drie: SPR-hybride is de SSPF-relevante variant (RTS-curve, AG-herzieningsperiode, rente-afdekking); SPR-clean is een idealisatie die zinvolle contrast toevoegt. Werkelijke fondsen kiezen nuances binnen SPR.

Dit is waarschijnlijk geen ofwel-ofwel: "regeling: SPR" in dataset kan via `reserveringenFaseB`-velden naar clean of hybride geïnterpreteerd worden. Maar de UI (pill vs. dropdown vs. nested) moet één lijn trekken.

---

## 8. HOE VERDER

Dit document dient als referentie naast `calculator_specificatie.docx`. Samen vormen ze de expliciete dubbele basis: de ideaal-versie (spec) en de werkelijke versie (DESIGN). Volgende beslissing ligt bij jou:

- **Route 1**: we kiezen per beslispunt (§7.1 t/m §7.4) en formuleren een **nieuwe calculator_specificatie v2** die de daadwerkelijke engine beschrijft — waarderingsmodule + toedelingsmodule + projectiemodule expliciet naast elkaar, met correcte scope-afbakening per module.
- **Route 2**: we bouwen de waarderingsmodule uit de spec **als aanvulling** — nieuwe deelnemersinvoer (geslacht, partner), nieuwe dataset-velden (generatietafel, π_DB/π_Wtp, ρ_DB/ρ_Wtp), nieuwe output (Δ, V_DB, V_Wtp). Laat scherm 2 en scherm 3 ongemoeid. Voeg eventueel een vierde scherm of alternatieve view toe.
- **Route 3**: we prioriteren de makkelijke uitbreidingen eerst (f, geslacht in Q) zonder grote architecturale beslissing, en laten de strategische vraag (engine-semantiek) als apart spoor lopen.

Ik heb een voorkeur voor **Route 1** — een herschreven specificatie dwingt ons om het hele beeld expliciet te maken, en levert een document op dat daadwerkelijk de engine vastlegt i.p.v. de engine die we in gedachten hadden. Maar dat is substantieel werk (één of twee sessies apart).
