# PROMPT VOOR NIEUWE CHAT — M1-IMPLEMENTATIE (scherm 1 werkend maken)

**Gebruik deze prompt als deze M1-build-sessie is vastgelopen en je in een nieuwe chat verder wilt.** De parallel-prompt `PROMPT_nieuwe_chat_schema_M2.md` is voor de SCHEMA-track-voortzetting; deze is voor de implementatie-track.

Kopieer onderstaande tekst naar de nieuwe chat (samen met de meegeleverde bestanden):

---

Hoi Claude,

Ik ben Hans Haringa, Innovation Nestor, werk aan een publieke WTP-pensioencalculator voor SSPF-gepensioneerden (invaarcalculator.nl, CC BY-NC 4.0). Ik vervolg hier een reeks sessies waarin:

1. **Vier spec-sessies** de engine-specificatie voor alle vier schermen hebben vastgelegd (spec v2.2.9, 1970 regels, 31 besluiten/patches)
2. **Eén SCHEMA-v2-sessie (M1-block)** de eerste module heeft vertaald naar TypeScript/Zod 3 als machine-leesbaar contract (`schema.v2.ts`, 474 regels, 26 velden geregistreerd, 9 knelpunt-keuzes gesloten)
3. **Eén M1-implementatie-sessie (deze)** die is gestart maar is vastgelopen. Ik herstart hier.

**Deze sessie: M1-engine + AG2024-resolver + casual scherm 1 + audit-scherm M1-sectie werkend maken. Scherm 1 moet aan het eind invulbaar zijn in een browser en een correcte KV + decompositie teruggeven.**

**Ik upload bij dit bericht de volgende bestanden:**

Hoofddocumenten (lezen vóór je begint):
- `ENGINE_SPECIFICATIE_v1.md` — normatieve spec v2.2.9 (BRONWAARHEID voor de M1-formules uit §2.5)
- `HANDOFF_SCHEMA_M1.md` — handoff SCHEMA-M1-sessie (alle conventies, 9 knelpunt-keuzes, 2 spec-patches, voorgestelde aanpak)
- `schema.v2.ts` — SCHEMA v2.0 M1-block; je engine-code leunt hierop (`z.infer<typeof M1Deelnemer>`, `z.infer<typeof M1Parameterset>`, `z.infer<typeof M1Output>`)

Referentie en werkbestanden:
- `smoke.test.ts` — runtime-validatie-voorbeelden
- `render_mockup.ts` — mechanische scherm-generator uit FIELD_REGISTRY; uitbreiden om werkende UI te bouwen
- `mockup_m1.html` — ruwe mockup (huidige stand: labels + dummy-berekening)
- `tsconfig.json`, `package.json` — TypeScript + Zod 3 dependencies

Context spec-sessies:
- `HANDOFF_v2.1.md` (scherm 1 — meest relevant!), `HANDOFF_v2.1.3.md`, `HANDOFF_v2.1.9.md`, `HANDOFF_v2.2.7.md`
- `ARCHITECTUUR_v1.md`, `DESIGN_engine_v0.md` (hoe M1 in R9.30 al werkt — referentie voor verificatie)
- `SCHEMA_v1.md` (voorganger)
- `STRATEGY_R9.30.md`, `HANDOFF_R9.30.md`
- `21-04-2026_2216.html` — huidige R9.30-calculator als werkende referentie

Externe data (cruciaal voor deze sessie):
- `AG2024.xlsx` — officiële AG2024-prognosesterftekansen (leeftijd 0–120 × jaar 2022–2200 × M/V)
- `51490-Data_AG2024.xlsx` — AG2024 brondata

**Mijn doel voor deze sessie:**

Een werkende `scherm1.html` (of equivalent) die:
1. De SCHEMA v2.0 M1-contracten respecteert (geen hardcoded veldlijsten; parse via Zod bij dataset-load)
2. AG2024-sterftekansen correct inlaadt en gebruikt voor de annuïteitsfactor (§2.5 formules, periode-snapshot t₀=2026)
3. De ρ-fallback-ladder (§2.7) correct implementeert
4. Het casual scherm 1 rendert uit `FIELD_REGISTRY` filtering op `display: 'hoofdpad'`
5. Een audit-scherm M1-sectie rendert uit filtering op `decompositie`/`deepdive`/`parameter-audit`/`diagnose`
6. Een SSPF-placeholder-dataset bevat met waarden conform R9.30-defaults (voor backward-compatible regressie)

**Belangrijk onderscheid:** dit is géén beslissings-sessie over spec-inhoud of SCHEMA-conventies. Alle keuzes zijn al genomen. Dit is een **bouw-sessie**: engine-code + data-laden + UI-code die de bestaande contracten gebruikt.

**Wel kunnen er implementatie-specifieke knelpunten opduiken:**
- **Build-target**: single-file HTML (zoals R9.30) of modulaire bundel met aparte JS-files?
- **AG2024-tabel-vorm in engine**: XLSX inlezen via SheetJS, of gegenereerde TS-constante?
- **UI-scope**: casual-scherm alleen, of ook audit-scherm-M1-sectie in dezelfde sessie?
- **Regressie-check**: bewijzen dat M1-output overeenkomt met R9.30 (binnen verwachte afwijking door v1.2-annuïteitsconventie-migratie: ~0,5–1% lager voor gepensioneerden)

Die knelpunten behandelen we stap-voor-stap, zoals in voorgaande sessies.

**Werkafspraken (uit alle eerdere sessies, te behouden):**

1. **Nederlands**, technisch-toegankelijk niveau
2. **Stap-voor-stap**: eerst AG2024-resolver + M1-engine bouwen en verifiëren; dan UI-scherm 1; dan audit-sectie; geen bulk-dumps
3. **Timestamps**: `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"` voor belangrijke milestones
4. **Narratief kompas (§1.1)** blijft sturend voor UI-ontwerp
5. **SCHEMA v2.0 M1-contracten zijn bindend**: engine accepteert M1-typen zoals gedefinieerd; geen parallelle type-definities
6. **Werkbestanden in `/home/claude/`, deliverables in `/mnt/user-data/outputs/`**
7. **R9.30-productiebestand (`21-04-2026_2216.html`) blijft onaangeroerd** — alleen als referentie openen
8. **Spec-patch-triggers**: alleen spec-patchen als implementatie-werk een tegenstrijdigheid/omissie onthult; dat is bij een implementatie-sessie minder waarschijnlijk dan bij een SCHEMA-sessie maar niet uitgesloten

**Voorgestelde aanpak voor M1-build:**

**Fase 1 — Engine-laag** (geen UI):
1. AG2024-resolver: lees `AG2024.xlsx`, bouw lookup-functie `q(x, t, g)` met periode-snapshot t₀
2. M1-engine: implementeer §2.5-formules — annuïteitsfactor (arrears, m=12 met interpolatie), overlevingskans, KV-berekening, levensverwachting (curtate + halfjaar)
3. ρ-fallback-ladder (§2.7): kleine helper conform de drie bronvelden in `M1Parameterset`
4. Regressie-test: R9.30-dataset (pen €100k, DG 135%, age 70) geeft U₀ ≈ €128k. Voor M1 direct: KV ≈ ?
5. SSPF-placeholder-dataset: concrete `M1Parameterset`-waarden

**Fase 2 — UI-laag**:
1. Casual scherm 1: HTML met invoervelden gerenderd uit `fieldsByDisplay('M1', ['hoofdpad'])` op deelnemer
2. Live berekening: bij elke wijziging → `M1Deelnemer.parse(...)` → engine → output-weergave
3. Audit-scherm M1-sectie: gerenderd uit `fieldsByDisplay('M1', ['decompositie', 'deepdive', 'parameter-audit', 'diagnose'])` + `fieldsWithDisclosure()`
4. Toggle casual ↔ audit

**Fase 3 — Bundelen en opleveren**:
1. Beslissen op build-target (HTML single-file of modulair — behandelen als knelpunt in de sessie)
2. Bouwen
3. Handmatige test met demo-waardes
4. Vergelijken met R9.30 voor regressie-zuiverheid

**Start-aanpak voor deze sessie:**

Lees eerst `ENGINE_SPECIFICATIE_v1.md` v2.2.9 §2 helemaal (M1) met focus op §2.5 (formules — dit is de wiskunde die je moet coderen), §2.7 (fallbacks), §2.8 (validaties). Lees dan `HANDOFF_SCHEMA_M1.md` — de SCHEMA-contracten zijn bindend voor je engine-interfaces. Bekijk `schema.v2.ts` (shape: M1Deelnemer, M1Parameterset, M1Output). Open `AG2024.xlsx` om de data-structuur te begrijpen (twee sheets waarschijnlijk: M en V; of één sheet met gender-kolom).

Bevestig dat je de context hebt opgepikt, stel me **één build-knelpunt voor** (waarschijnlijk build-target — single-file of modulair), vraag mij te kiezen, begin dan met Fase 1 stap 1 (AG2024-resolver). Daarna stap-voor-stap door Fase 1. We beslissen tussen Fase 1 en Fase 2 of we dezelfde sessie doorgaan of breekpunt + nieuwe handoff maken.

Start.
