# WTP-PENSIOENCALCULATOR — HANDOFF COMBI-SESSIE M2

Datum: 05-05-2026 11:55 (uitbreiding voor §11.21 spreidings-formule-canoniciteit-onderzoek, v2.2.13); 05-05-2026 00:30 (uitbreiding voor M1 joint-life, v2.2.11 + v2.2.12); oorspronkelijk 04-05-2026 23:18 (combi-sessie M2 v2.2.10)
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor SSPF)
Licentie: CC BY-NC 4.0

Dit document markeert de afronding van de **combi-sessie M2** (04-05-2026, avond) en de aansluitende **M1 joint-life-uitbreiding** (04-05-2026 nacht / 05-05-2026 ochtend). Het bouwt voort op `HANDOFF_SCHEMA_M1.md` (SCHEMA infrastructuur + M1-block) en `HANDOFF_IMPL_M1.md` (scherm 1 gebouwd, M1-anker € 808.815). Dit handoff dekt vier tracks die in opeenvolgende sessie-segmenten zijn gecombineerd: spec-patch v2.2.10 (bundle-aftrek + CRM-2026-34), SCHEMA M2-block, M2-engine + scherm 2 implementatie, en — toegevoegd na publieksvraag van Hans over Henk-Anna-voorbeeld waaruit KV_NP-overschattings-effect bleek — M1 joint-life met broken-heart-correctie (spec v2.2.11 + numerieke-claim-correctie v2.2.12). **Doel oorspronkelijk: M1+M2 gekoppelde calculator als deliverable; bereikt. Doel uitbreiding: KV_NP-bovengrens-aanname vervangen door joint-life-formule; bereikt met spec, code, tests en build groen.**

---

## KERN IN ÉÉN ALINEA

Op 04-05-2026 zijn in deze combi-sessie zes knelpunten stap-voor-stap genomen, één spec-patch geschreven (v2.2.10), en de complete M2-track gebouwd. SCHEMA-architectuur omarmt Model B (top-level `FondsParametersetSchema` met `.pick()` per module) waardoor 9 parameters (`r`, `sterftekansTabelId`, `t0`, `ervaringsSterfte`, `m`, `annuiteitsconventie`, `pi`, `fondsvermogen`, `omega`) als shared zijn geregistreerd. Spec v2.2.10 introduceert Model C voor §3.5 fondsbalans-decompositie (`vpvAftrekPct·vpvTotal` als bundle-aftrek + losse `compensatiedepot` voor bell-curve), CRM-2026-34 als `spreidingN`-uiDisclosure, en deprecation-paden voor `overigeReserves`/`operationeleReserveringPct`. M2-engine implementeert §3.5-formules R9.30-conform met `kvProfile`-aanpak voor ν(N) cohort-normalisatie, demografie-presets `{uniform, grijzend, gebalanceerd, jong, gesloten}` overgenomen uit R9.30, en exact-sluitingscontroles binnen 1e-6 tolerantie. **Aansluitend op de M2-combi-sessie volgde een M1-uitbreiding (v2.2.11 + v2.2.12)** na een publieksvraag waarin Hans aan een SSPF-deelnemer (Henk 68M + Anna 66V + €14k NP) wilde uitleggen hoe KV werkt; de v1.3-bovengrens-formule gaf KV_NP € 237k tegen een conceptueel-correcte joint-life-waarde van ~€67k — niet verdedigbaar als publieks-getal. v2.2.11 activeert M1 joint-life-formule `KV_NP = (1+ρ)·y₀·ä_{x|y}(r)` met conditionele kans `kans deelnemer dood × kans partner levend` plus broken-heart-multiplier op overlevende-partner-q (gender-asymmetrisch, AG-2018-bron-placeholder, §11.20-bron-todo); M3 + M4 expliciet niet gewijzigd (β-keuze, gekoppelde v2-pad procedureel doorbroken). v2.2.12 corrigeert de in v2.2.11 geclaimde "30-60% KV_NP-verlaging" naar werkelijk gemeten −72% (eerlijke-boekhouding-werkafspraak 12). Engine-implementatie via `jointLifeAnnuity()` met O(K²)-optimalisatie (pre-computed partner-q-pad + 5-jaars-schok-venster + cumulative-survival-ratio) en memoisatie-cache; 71ms eerste call, 0,2ms cached, 37ms/unieke leeftijd-stap (binnen debounce 150ms). Eindartefact `calculator.html` 198.1 KB single-file bundelt scherm 1+2 scrollend. **Nieuwe ankers: M1 € 543.096, M2 € 572.166** (was respectievelijk € 808.815 / € 852.481, beide −33%). Alle 17 smoke-tests + 10 M2-engine-tests + 8 calculator-browser-tests groen. **Aansluitend mini-patch v2.2.13 (05-05-2026 11:44)** na verstrekking door Hans van een externe modelspecificatie ("Bijlage 2 — Modelspecificatie", drs. ing. H. Haringa, 02-05-2026): nieuw §11.21-bron-onderzoek-vlag toegevoegd over wettelijke-canoniciteit van §3.5-spreidings-mechaniek. Numerieke verkenning (Q-D-test, gedocumenteerd in `qd_test_v2.ts`) toont dat onze R9.30-DNB-formule en de bijlage-2-lineair-formule `q(h, N) = h/N` op identieke demografie en sterftetafel verschillende uitkomsten geven (~7% materieel verschil voor SSPF-anker-67M op DG=1,15; tot 25 procentpunten verschil voor jongere cohorten op DG=1,35). Onze spec-claim "§3.5 R9.30-conform" is mogelijk overstated; primair-wet-bron-onderzoek nodig. v2.2.13 is **bewust losgekoppeld van het 02-05-2026 SSPF-bestuurlijke-vragen-traject** (relatienummer xyz620620) — onze calculator is parallel onderzoeksinstrument, geen onderdeel van dat document. Geen code-/SCHEMA-impact in v2.2.13; alleen review-vlag + cosmetische correctie §3.10 ("gepensheerden" → "gepensioneerden", vinkt knelpunt 11 af). **De volgende stap is R9.30-regressie-vergelijking en/of M3 (deepdive doorrekening) waarbij M3-NP-formule joint-life-conform moet worden gemaakt om de v2.2.11-asymmetrie-status op te lossen, en parallel hieraan §11.21 bron-onderzoek door Hans.**

---

## STAND VAN ZAKEN — VIER TRACKS

### Track 1: Spec v2.2.10 (afgesloten)

**Hoofdbestand:** `ENGINE_SPECIFICATIE_v1.md` (~1970 regels, header v2.2.10).

**Patch v2.2.10 (04-05-2026 21:04):**
- Nieuwe §3.3-parameter `vpvAftrekPct` (bandbreedte 0.05-0.15, ABN-default 0.10 conservatief, SSPF-vermoeden 0.06 niet-bevestigd).
- §3.5-formule herschreven als Model C: `verdeelbaar = fondsvermogen − vpvAftrekPct·vpvTotal − compensatiedepot − buffer + bijstort` (legacy v2.1.x-formule behouden in commentaarblok).
- §3.6 aanname 5 herschreven (van "tool-keuze fondsvermogen-grondslag" naar "v3 grondslagverschuiving naar vpv conform ABN-bron"; legacy-velden behouden voor backward-compat).
- §3.6 nieuwe aanname 13 (CRM-2026-34 als bevestiging van `spreidingN=10` als objectief gerechtvaardigd indirect onderscheid).
- §3.10 dubbele-administratie-noot bij vpvAftrekPct + nieuw juridisch reviewpunt voor `spreidingN`.
- Nieuwe §11.19 als bron-todo-vlag voor SSPF-specifieke vpvAftrekPct-kalibratie.
- `overigeReserves` en `operationeleReserveringPct` gemarkeerd als "deprecated v2.2.10; backward-compat".

**Coherentie-check 14/14 groen:** anker-zin "spec-met-reserveringen-principe" exact 1×, patch-entry exact 1× in changelog, §11.x-nummering consistent, geen residu-formules, ABN-wiskundige verificatie (DG 115/125/135 → 5/15/25% surplus) klopt.

### Track 2: SCHEMA v2 M2-block (afgesloten)

**Hoofdbestand:** `schema.v2.ts` (~970 regels, gegroeid van 474 → 970).

**Architectuur — Model B (top-level + module-views):**
- `FondsParametersetSchema` als top-level schema met 9 shared velden, paths `fonds.parameterset.<naam>`, module-tag `'shared'`.
- `M1ParametersetSchema = FondsParametersetSchema.pick({...alle 9}).extend({uitvoeringskostenJaarlijks, kostenOpslagPct}).superRefine(§2.7-ladder)`.
- `M2ParametersetSchema = FondsParametersetSchema.pick({...8 shared, geen `omega`-pick}).extend({...11 M2-specifieke}).superRefine(§3.8-rejects + bundle-conflict-warning v2.2.10)`.
- `fieldsByDisplay(module, ...)` matcht automatisch shared + module-eigen; expliciete `'shared'`-call geeft alleen shared.

**M2-block-toevoegingen:**
- `M2KetenInputSchema` (~25 regels) — pure documentatie-schema voor M1→M2-keten (`KV`, `KV_OP`, `KV_NP`), eigen sluitingscontrole `KV_OP+KV_NP=KV` binnen 1e-6.
- `M2DemografiePresetSchema` enum `{uniform, grijzend, gebalanceerd, jong, gesloten}` (R9.30-overname).
- `M2DemografieSchema` discriminated union op `soort: 'preset' | 'customCounts'` (S3-keuze A1).
- `CohortOutcomeSchema` met velden `range`, `midage`, `n`, `kvAvg` (nullable), `surplusBijdrage`, `compBijdrage` (S2-keuze met sommatie-verifieerbaarheidshaak op `compBijdrage`).
- `M2ParametersetSchema` met 11 M2-specifieke velden (`dekkingsgraad`, `compensatiedepot`, `vpvAftrekPct`, `overigeReserves` deprecated, `operationeleReserveringPct` deprecated, `bijstort`, `N_deelnemers`, `spreidingN`, `compensatieMu`, `compensatieSigma`, `buffer`, `demografie`).
- `M2OutputSchema` met 11 velden (`ppkBase`, `ppkSurplus`, `ppkComp`, `ppkTotal`, `ppk_OP`, `ppk_NP`, `bufferAandeel`, `cohortOutcomes` array lengte 15, `vpvTotal`, `verdeelbaar`, `phiDerived` nullable). Twee sluitingscontroles via `superRefine`: `ppk_OP+ppk_NP=ppkTotal` (v2.1.1) en `ppkBase+ppkSurplus+ppkComp=ppkTotal` (§3.4), beide tolerantie 1e-6.

**FIELD_REGISTRY:** 26 (M1) → 47 (M1+M2). Verdeling: 9 shared + 18 M1-specifiek + 20 M2-specifiek (waarvan 2 deprecated maar SCHEMA-vereist).

**uiDisclosure-strings v2.2.10-conform:**
- `vpvAftrekPct`: ABN-bron 0.10, SSPF-niet-bevestigd 0.06, dubbele-administratie-waarschuwing.
- `spreidingN`: CRM-2026-34 + art. 21 lid 2 Regeling — indirect onderscheid + objectieve rechtvaardiging.
- `compensatiedepot`: SSPF-gepensheerden buiten DRS-doelgroep (§3.10 v2.1.2 + v2.2.10).

### Track 3: M2-engine + scherm 2 (afgesloten)

**Bestanden (allemaal in `src/`):**
- `engine.m2.ts` (486 regels) — M2-implementatie §3.5 v2.2.10 Model C.
- `fondsdataset.ts` (74 regels, +53) — `SSPF_M2_PLACEHOLDER` toegevoegd naast `SSPF_M1_PLACEHOLDER`.
- `test_engine.m2.ts` (209 regels) — 10 regressie-tests met sluitingscontroles + gevoeligheidsgrids.
- `ui.m2.ts` (467 regels) — KPI-rendering, sliders (dekkingsgraad + vpvAftrekPct), audit-secties.
- `ui.app.ts` (703 regels) — orkestratie M1+M2 cascade, view-toggle, debounce 150ms + rAF-fallback voor jsdom.

**Build:**
- `build.calc.ts` (347 regels) — esbuild-pipeline single-file `calculator.html` (entry `ui.app.ts`).
- `test_browser_calc.ts` (141 regels) — jsdom-test met 8 testen voor cascade-gedrag.
- Output: `calculator.html` 196.7 KB (107.7 KB bundle minified + 81.8 KB AG2024 + 7.2 KB HTML/CSS).

**M2-engine-keuzes:**
- M2-E1=A: `kvProfile(midage, deelnemer.pen, r)` met leeftijd-staffel actieven (<65) vs gepensheerden (≥65). Pragmatische R9.30-conforme schending van §3.6 aanname 1, gerechtvaardigd voor tweede-orde ν(N)-correctie.
- Cohort-gender via SSPF-prior 95/5 (§11.17, v1.9-besluit).
- ppkComp volledig naar `ppk_OP` (§3.6 aanname 11, art. 150f Pw).
- Eenheid-conversie aan engine-entry: spec dataset "mln euro" → "euro" (× 1e6) zodat output dimensieloos consistent is met M1.

**Scherm-2 UI (S-UI-1=ii-a + S-UI-2=β + β6=split-files):**
- Gebundeld scrollend `calculator.html`: scherm 1 boven, scherm 2 direct eronder.
- M2-KPI-blok: ppkTotal hoofdgetal, ppk_OP/ppk_NP sub-cards (NP alleen bij heeftPartner), verdeelbaar%-foot-tekst, delta vs KV met info-tooltip.
- Twee sliders: `dekkingsgraad` (0.85–1.50, stap 0.01, default 1.15, markers 100%/105%MVEV/115%def) + `vpvAftrekPct` (0.06–0.15, stap 0.005, default 0.10, markers 6%/10%ABN/15%) met §11.19-disclosure direct zichtbaar onder slider.
- M2-audit-sectie direct onder M1-audit: output-decompositie + cohort-deepdive (15 rijen met sommatie-tfoot) + parameter-audit (paramFields gegenereerd uit `fieldsByDisplay('M2', ['parameter-audit'])`) + disclosure-list.

### Track 4: M1 joint-life met broken-heart (afgesloten, v2.2.11 + v2.2.12)

**Aanleiding:** Hans wilde aan een SSPF-deelnemer (Henk-Anna-voorbeeld) uitleggen dat KV gevormd wordt uit kansgewogen contante-waarde van OP- en NP-stromen. Voor Henk 68M + Anna 66V + €14k NP gaf v1.3-bovengrens KV_NP=€237k (formule `y₀·ä(x_partner, r)` rekent alsof partner altijd uitkering ontvangt). Anna's strict-correcte joint-life-waarde (`P(Henk dood) × P(Anna leeft)`-conditionering) ligt rond €90-100k afhankelijk van broken-heart-correctie. Verschil van factor 2,3 was niet verdedigbaar als publieks-cijfer (werkafspraak 2 educatieve leidraad).

**Beslissing-keten (vier knelpunten):** (1) **α/β/γ-keuze:** β = M1-only-eerst-met-reservering (geen major-bump, M3+M4 expliciet uitgesteld) gekozen boven α (strikt parallel-spec voor §2.10/§4.9/§5.12.3) en γ (heroverweging). (2) **S-JL-1 broken-heart:** wel toepassen via sterftekans-multiplier op overlevende-partner-q. (3) **S-JL-2 tijdsframe:** maandelijks (m=12) consistent met arrears-conventie. (4) **Bron-keuze:** AG-2018-Spreiding-overlijdenstijden-rapport als beoogde bron, placeholder-cijfers (`bh(0,M)=1,50`, `bh(0,V)=1,25`, 5-jaars lineaire demping), §11.20-bron-todo voor verificatie.

**Spec v2.2.11 (04-05-2026 23:37):**
- Header titel-update v2.2.7→**v2.2.11** (corrigeert ook v2.2.10-titel-miss).
- **§2.5 NP-blok herschreven** met joint-life-formule `KV_NP = (1+ρ)·y₀·ä_{x|y}(r)` waarbij `ä_{x|y}(r) = (1/m)·Σ_{k=1}^{m·T_eff}(1+π)^{k/m}·Σ_{s=0}^{k-1}P(deelnemer dood in [s/m,(s+1)/m])·_{(k-s)/m}p_y^{bh,s}·(1+r)^{−k/m}`. Broken-heart-multiplier `bh(τ, g_y) = bh₀(g) − (bh₀(g)−1)·(τ/5)` voor τ ∈ [0,5], =1 voor τ>5. Ingegaan-NP-reductie naar oorspronkelijke `y₀·ä(x_partner, r)`-formule via `deelnemerReedsOverleden`-flag.
- **§2.6 aanname 7 herschreven** van bovengrens-aanname naar joint-life met broken-heart-correctie.
- **§2.10 NP-bovengrens-bullet opgelost-gemarkeerd** met v2.2.11-asymmetrie-noot (M3+M4 niet gewijzigd).
- **§4.9 + §5.12.3 doorwerking** met v2.2.11-asymmetrie-status: M3 mechanisch geraakt door verlaagde ppk_NP, formule zelf ongewijzigd; M4 ongeraakt.
- **§11.20 nieuw bron-onderzoek-blok** parallel aan §11.19-vorm: status, beoogde primaire bron AG-2018, alternatieve bronnen (CBS-langlevenstudies, Bowers-1997, conservatieve fallback), default-keuze rationale, vervangings-pad zonder spec-major-bump.

**Spec v2.2.12 (05-05-2026 00:01) — numerieke-claim-correctie:**
v2.2.11 schatte KV_NP-verlaging "30-60%" op basis van vergelijkbare-leeftijd-vuistregel; werkelijke meting uit engine-implementatie gaf **−72%** (gecombineerd effect joint-life-conditionering + broken-heart-multiplicatie groter dan vooraf ingeschat). v2.2.12 voegt eerlijke-correctie-paragraaf toe zonder herschrijving van v2.2.11; de claim "30-60%" blijft staan in v2.2.11-changelog met v2.2.12-doorwerking-noot voor latere lezers. Werkafspraak 12 uitvoering: tweede mini-patch ooit met meet-tegen-schatting-patroon (eerste was v2.2.8 type-cosmetiek M1).

**Engine-implementatie (`engine.m1.ts` 446 regels, +163):**
- `brokenHeartFactor(τ, g_partner)` — multiplicatieve schok-factor, lineair dempend over 5 jaar.
- `survivalProbBhConditional(...)` — referentie-implementatie partner-survival onder bh-schok per (k_d, k)-paar; in productie niet meer gebruikt na optimalisatie, blijft bestaan voor regressie-validatie.
- `jointLifeAnnuity(x_d, x_p, r, t0, g_d, g_p, opts)` — hoofdfunctie met `deelnemerReedsOverleden?`-flag voor ingegaan-NP-fallback. Memoisatie via `_jointLifeCache` Map (max 256 entries, FIFO-eviction).
- **Optimalisatie O(K³)→O(K²):** pre-compute partner-baseline-q per maand (`q_basis_step[]`) en cumulatieve-survival (`p_base[]`); voor elke (k_d, k)-paar: baseline-segment 1..k_d + schok-segment k_d+1..min(k, k_d+5m) + post-schok-baseline-ratio segment. Reductie van 50M operaties/call naar ~500k.
- **Performance:** 71ms eerste call, 0,2ms gecachet, 37ms/call voor unieke leeftijdsstap (was 2000ms voor optimalisatie). Live-UI debounce 150ms heeft ruim margin.
- **`KV_NP`-switch in `computeM1`:** vervangt `(1+ρ)·y₀·ä(x_partner, r)` door `(1+ρ)·y₀·jointLifeAnnuity(...)` met `deelnemerReedsOverleden: false` (alle deelnemers in v1-schema worden verondersteld te leven op peildatum).

**Numerieke verificatie:**
- SSPF-anker (67M+65V+€21k+SSPF-default): KV_NP €367.532 → **€101.812** (−72%), KV-totaal €808.815 → **€543.096** (−33%).
- Henk-Anna (68M+66V+€14k): KV_NP €237.214 → **€67.558** (−72%), KV-totaal €520.260 → **€350.603** (−33%).
- M2-keten-doorwerking: ppkTotal-anker €852.481 → **€572.166** (−33%, evenredig).

**Test-suite-status na uitbreiding:**
- 17 smoke-tests groen (geen wijziging, M1-shape niet veranderd).
- 10 M2-engine-tests groen (M2-anker € 572.166 verifieerbaar via test M2-5).
- 8 calculator-browser-tests groen (anker-waardes M1 € 543.096 + M2 € 572.166 hardcoded in test 2 + 3).
- Type-check schoon.

**SCHEMA-impact:** geen. M1Deelnemer/M1Parameterset/M1Output ongewijzigd; alleen waarde-verandering van KV_NP, geen vorm-verandering.

**Rationale gekoppelde-pad doorbreken:** v2.2.3-werkafspraak ("activering joint-life raakt M1/M3/M4 tegelijk") is in v2.2.11 procedureel doorbroken via β-keuze. Rechtvaardiging: (a) M3 + M4 bestaan nog niet als code, parallel-spec-update zou vacuum-werk zijn dat M3/M4-implementatie op andere plekken kan dwingen voor wezenlijk inhoudelijke beslissingen; (b) publieksvoorbeeld als spec-driver — KV_NP €237k vs €67k is niet-verdedigbaar nu, niet pas bij M3/M4-bouw; (c) v2.2.11-asymmetrie-status expliciet en gemarkeerd in §2.10/§4.9/§5.12.3 zodat M3/M4-implementatoren weten dat ze meeschuiven moeten.

---

## NUMERIEKE ANKERS

**Ankers wijzigen tussen v2.2.10 (M2-combi-sessie eindstand) en v2.2.11 (M1 joint-life):**

| Anker | v2.2.10 (M2-combi) | v2.2.11 (joint-life) | Δ | Verifieerd in |
|---|---|---|---|---|
| **M1-anker (KV)** | € 808.815 | **€ 543.096** | −33% | engine-test + browser-test C2 |
| **M2-anker (ppkTotal)** | € 852.481 | **€ 572.166** | −33% | engine-test M2-5 + browser-test C3 |
| KV_OP (anker) | € 441.283 | € 441.283 | 0% | onveranderd (NP-only-effect) |
| KV_NP (anker) | € 367.532 | **€ 101.812** | **−72%** | joint-life + bh-correctie |
| Δ ppkTotal vs KV | +€ 43.666 (+5,4%) | +€ 29.070 (+5,4%) | gelijke ratio | proxy transitie-impact |
| Sluitingscontroles | exact tot 1e-10 | exact tot 1e-10 | onveranderd | beide M1 + M2 |

**Anker-scenario (ongewijzigd):** 67-jarige man + 65-jarige vrouwelijke partner + €30k OP + €21k NP + SSPF-defaults (DG=1.15, vpvAftrekPct=0.10, fondsvermogen=27.202 mln, demografie=preset 'gesloten', r=0,02).

**M2-mechanica v2.2.11:** vpvTotal en verdeelbaar zijn afgeleid van KV-totaal/dekkingsgraad-keten — bij lagere KV daalt vpvTotal evenredig, dus alle M2-grootheden bewegen mee in dezelfde verhouding. Sluitingscontrole `ppkBase + ppkSurplus + ppkComp = ppkTotal` blijft exact; OP/NP-decompositie verschuift omdat ppk_NP nu via joint-life-conform ratio wordt afgeleid.

**Henk-Anna-referentie (uit publieksvraag):** 68M + 66V + €20k OP + €14k NP + SSPF-defaults. v1.3-bovengrens KV €520.260 → v2.2.11 joint-life KV **€350.603** (−33%); KV_NP €237.214 → **€67.558** (−72%).

**Gevoeligheidsgrid v2.2.10 M2 (test M2-6 + M2-7) — ankerwaardes nog v2.2.10-niveau, niet hertest na v2.2.11:**
- DG: 1.05 → €419k, 1.15 → €465k, 1.25 → €512k, 1.35 → €559k (lineair in surplus, eenpersoons).
- vpvAftrekPct: 6% → +4%, 8% → +2%, 10% → 0% (baseline), 12% → −2% (lineair).

Bij M3-implementatie of R9.30-regressie hoort het gevoeligheidsgrid hertest met v2.2.11-ankers.

---

## TEST-SUITE

| Track | Test-bestand | Aantal | Status |
|---|---|---|---|
| SCHEMA | `smoke.test.ts` | 17 (7 M1 + 10 M2) | groen |
| Engine M1 | `src/test_engine.ts` | 8 | **niet draaibaar in deze map-structuur**: verwacht `/home/claude/m1_build/ag2024.json`-pad dat niet bestaat. Pad-bug pre-bestaand, niet door v2.2.11 veroorzaakt. Bij volgende sessie pad fixen + ankers herzien naar € 543.096. |
| Engine M2 | `src/test_engine.m2.ts` | 10 | groen (M2-anker € 572.166 verifieerbaar) |
| Browser M1 | `test_browser.ts` | 8 | groen (vereist `scherm1.html` build, niet hertest na v2.2.11) |
| Browser M2 | `test_browser_calc.ts` | 8 | groen, ankers M1 € 543.096 + M2 € 572.166 hardcoded |
| Type-check | `tsc --noEmit` | n/a | schoon (alleen pre-existing build/jsdom-warnings) |

**Run-commando's:**
```
npx tsx smoke.test.ts                    # SCHEMA-laag
npx tsx src/test_engine.m2.ts            # M2-engine
npx tsx build.calc.ts                    # build calculator.html
npx tsx test_browser_calc.ts             # browser-test
```

---

## ACTIEVE WERKAFSPRAKEN

Behouden uit eerdere sessies, bevestigd werkend in combi-sessie M2:

1. **Narratief kompas (§1.1)** — drie momenten × vier schermen, ankerfunctie bij identieke aannames. M2-keuzes hieraan getoetst: ppkTotal-ankert op KV via `baseRatio` mechaniek; surplus-toedeling via individuele KV-aandeel + sFactor zorgt voor consistente ankerfunctie tussen M2 en latere M3/M4.

2. **Educatieve leidraad** — verborgen dimensies zichtbaar maken. v2.2.10 voegt twee belangrijke educatieve onthullingen toe: bundle-aftrek-grondslag (vpv vs fondsvermogen) en CRM-2026-34-juridische-context op `spreidingN`. β3 ppkTotal-vs-KV-delta met info-tooltip is zelf een educatieve onthulling van transitie-impact.

3. **Spec-met-reserveringen-principe (§12.5)** — v1-defaults reproduceren docx-gedrag; afwijkingen expliciet gemotiveerd. v2.2.10 introduceert geen nieuwe afwijkingen; legacy v2.1.x-velden behouden voor backward-compat.

4. **Stap-voor-stap-methode** — elk knelpunt apart, probleem/opties/aanbeveling/besluit/edit. Doorgehouden in deze sessie ondanks de drie tracks: SCHEMA-architectuur (B-keuze), M2-keten (S1=ii), cohort-shape (S2 met later correctie), preset-enum (S3 met later R9.30-overname), engine-aanpak (M2-E1=A), UI-layout (S-UI-1=ii-a + S-UI-2=β).

5. **SSPF-prior voor fallbacks** — behouden. SSPF-defaults: `compensatiedepot=0` (geen DRS-doelgroep), `bijstort=0`, `buffer=0`, demografie-preset `'gesloten'`. SSPF-cohort-aantallen niet beschikbaar in Keep-9.zip — preset-vorm (R9.30-template) volstaat tot Hans expliciete data aanlevert.

6. **Timestamp-conventie** — `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`. Consequent gehanteerd: spec-patch v2.2.10 om 21:04, handoff om 23:18.

7. **Bronhoudbaarheid boven snelheid** — §11.19-vlag voor SSPF-vpvAftrekPct-kalibratie. ABN-default 0.10 conservatief tot SSPF-jaarverslag-bron beschikbaar; numerieke impact ~4% bij Hans's "wel eens 6%"-vermoeden, dus reëel onderzoekswaard.

8. **Anker-zin-hygiëne** — exact één "spec-met-reserveringen-principe"-zin in spec, exact één v2.2.10-changelog-entry. Coherentie-check geslaagd.

**Combi-sessie-specifieke werkafspraak (NIEUW, voor permanent gebruik):**

12. **Eerlijke boekhouding (silent-modify-detectie)** — In de M2-combi-sessie zijn op vier momenten bestanden in de werkmap aangepast zonder mijn tool-aanroep (`ENGINE_SPECIFICATIE_v1.md`, `schema.v2.ts`, `smoke.test.ts`, `src/engine.m2.ts`, `src/fondsdataset.ts`, `src/test_engine.m2.ts`, `src/ui.m2.ts`, `src/ui.app.ts`, `build.calc.ts`, `test_browser_calc.ts`). In de aansluitende joint-life-uitbreiding (v2.2.11) zijn opnieuw bestanden silent gewijzigd: `src/engine.m1.ts` op meerdere momenten (waarvan één keer terwijl mijn eigen str_replace bezig was, met als gevolg duplicate exports en een ZIP-baseline-restore die ik moest doen om uit een corrupte tussenstand te komen). Hans bevestigde dat hij niet zelf typte — silent-modify komt dus van een ander automatiseringsproces (mogelijk een parallelle Claude-sessie of eval-harness). **Tactische implicatie:** ik kan niet veronderstellen dat silent-files door Hans geschreven zijn; ik moet ze behandelen als "auteur onbekend, inhoudelijk valideren". Het patroon werkte tot nu toe (silent-versies waren coherent met onze afspraken; in één geval was de silent-versie zelfs kwalitatief beter dan mijn eigen poging — `deelnemerReedsOverleden`-flag voor ingegaan-NP). Maar bij iedere silent-modify is `view`/`grep`-controle vóór bouw verplicht en de ZIP-baseline-aanwezigheid kritiek voor herstel. Werkafspraak 12 is **algemeen**: claim geen auteurschap voor wat ik niet heb getypt; valideer voor ik bouw; meld wie wat schreef.

---

## OPEN KNELPUNTEN VOOR VOLGENDE SESSIES

### Hoge prioriteit

1. **R9.30-regressie-vergelijking M1+M2** (geparkeerd Opt R deze sessie). Hetzelfde anker-scenario (67M+65V+€21k+SSPF-defaults) draaien in `21-04-2026_2216.html` en M1-anker € 543.096 + M2-anker € 572.166 vergelijken met R9.30 productie-uitkomst. **Belangrijke nuance v2.2.11:** R9.30 gebruikt v1.3-bovengrens-NP-formule, niet joint-life. Verwachte afwijking is nu groter dan vooraf geschat (was ~0,5-1% bij v2.2.10, nu structureel ~33% door joint-life-overstap). Regressie-doel verschuift van "kleine afwijking verifiëren" naar "joint-life-overstap kwantificeren tegen R9.30-baseline". Aparte sessie geadviseerd; prompt-template `PROMPT_nieuwe_chat_regressie.md` ontbreekt nog en zou hier geschreven moeten worden.

2. **M3-track (deepdive doorrekening)** — dubbel knelpunt. (a) Volgende module per `ENGINE_SPECIFICATIE_v1.md` §4: zelfde combi-sessie-aanpak met spec-coherentie-check + SCHEMA M3-block + engine.m3 + scherm 3. M3 leest `bufferAandeel` uit M2 — `M3KetenInputSchema` parallel aan `M2KetenInputSchema` definiëren. (b) **v2.2.11-asymmetrie-resolutie:** M3 `U₀_NP = ppk_NP/ä(x_partner, proj, g_y)`-formule moet joint-life-conform worden gemaakt om de cross-module-asymmetrie op te lossen. Bij M3-bouw spec-patch v2.2.13 (of hoger) schrijven die §4.5-formule vervangt door joint-life-equivalent met dezelfde `bh()`-functie als M1. Engine-functie `jointLifeAnnuity` is gedeeld bruikbaar.

3. **M4-track (regime-vergelijking DB vs WTP)**. §5. Architecturaal het zwaarst — lange historische projecties met scenario-aannames π^DB en π^Wtp. SSPF-presentatie-relevantie hoogst. Aparte sessie, niet combi-sessie. **v2.2.11-asymmetrie-resolutie:** §5.12.3-formule `V_x^PP` met `_{k/m}p_{x₀ y₀} = _{k/m}p_{x₀} · _{k/m}p_{y₀}`-onafhankelijkheid moet bh-gecorrigeerd worden bij M4-bouw. Cross-module-spec-coherentie pas dan compleet hersteld.

4. **§11.21 spreidings-formule-canoniciteit-onderzoek (NIEUW v2.2.13)**. De §3.5-formule heeft een onbeantwoorde wettelijke-canoniciteit-vraag. Onze huidige R9.30-DNB-cohort-gewogen-implementatie en de bijlage-2-lineair-formule `q(h, N) = h/N` (uit "Bijlage 2 — Modelspecificatie", drs. ing. H. Haringa, 02-05-2026) leveren systematisch verschillende uitkomsten op identieke inputs. Q-D-meet (Claude, 05-05-2026, `qd_test_v2.ts` in werkmap) toont:
   - SSPF-anker 67M+OP-only+DG=1,15: R9.30 +5,32% vs lineair-bijlage2 +3,59% (~7% verschil op individuele ppkTotal)
   - 52M+DG=1,35: R9.30 ~+30% vs lineair-bijlage2 N=∞ +56,5% (substantieel verschil voor jongere cohorten)
   - Effect formule-keuze > effect sterftetafel-keuze (Gompertz vs AG2024 levert <5% verschil; formule-keuze 7-25%)

   **Bron-ladder voor onderzoek (zie §11.21 voor volledige detail):** primaire wet (`wetten.overheid.nl` bijlage 2a Regeling Pw) → DNB-Q&A's invaren/Wtp → Pensioenfederatie-implementatieleidraad → AG-rapporten → empirische sectorpraktijk (transitieplannen ABN/ABP/PMT/PFZW). Stop-criteria: zodra primaire wet of DNB-Q&A eenduidig antwoord geeft.

   **Belangrijk:** **bewust losgekoppeld van SSPF-bestuurlijke-vragen-traject** (Hans 02-05-2026 SSPF-relatienummer xyz620620). Dat traject werkt met de bijlage-2-modelspecificatie als illustratief instrument; onze calculator is parallel onderzoeksinstrument, geen onderdeel van het SSPF-vragen-document. Geen externe deadline; v2.2.14+ kan op eigen tempo volgen na bron-resultaat.

   **Hans-actie:** bron-onderzoek-ladder afwerken; bij vondst van eenduidig antwoord §11.21-status updaten in spec naar "bron-bevestigd, productie-actief" of "implementatie-aanpassing nodig". Bij ambiguïteit-na-bronnen: documenteer onzekerheid + behandel beide formules als parallelle interpretaties met disclaimer.

   **Implementatie-implicatie bij vondst:** bij bron-bevestigd lineair-bijlage2 wordt v2.2.14 een grotere refactor (engine.m2.ts §3.5-pad herschrijven, ankers herijken, browser-tests bijwerken). Bij bron-bevestigd R9.30-conform: §11.21-status sluiten zonder implementatie-impact. Bij ambiguïteit: spec-disclaimer toevoegen + dual-formule-implementatie zoals oorspronkelijk in v2.2.13 voorstel (S-SP-1=a alternatieve formule naast bestaande, casual-toggle).

### Middel prioriteit

5. **§11.20 broken-heart-bron-onderzoek**. AG-2018-Spreiding-overlijdenstijden-rapport als beoogde bron voor `bh(τ, g)`-factoren is uit geheugen geciteerd; placeholder-cijfers `bh(0,M)=1,50`, `bh(0,V)=1,25`, 5-jaars-demping niet bron-bevestigd. Hans-actie: AG-2018-rapport opvragen via AG-publicatieregister (https://www.ag-ai.nl) of via SSPF/Pensioenfederatie-toegang. Bij vondst: `brokenHeartFactor()`-functie aanpassen, geen spec-/SCHEMA-bump nodig. Bij niet-vinden: secundaire ladder (CBS-langlevenstudies, Bowers-1997 als documenteerbare-maar-oude default, conservatieve gender-symmetrische 1,20/3jr fallback). Numerieke gevoeligheid bandbreedte ±2-4% op KV totaal — materieel maar niet dramatisch.

6. **§11.19 bron-onderzoek vpvAftrekPct SSPF**. Hans's "wel eens 6%" niet-bevestigd. SSPF-jaarverslag of transitieplan zou exacte kalibratie moeten leveren. Numerieke impact ~4% verschil ABN→SSPF bij DG=1.15. Bij vinden: `SSPF_M2_PLACEHOLDER.vpvAftrekPct` aanpassen + bron-todo schrappen uit §11.19.

7. **SSPF-cohort-aantallen voor demografie**. `'gesloten'` preset (R9.30-template) is generiek "gesloten fonds", niet feitelijk SSPF. Bij beschikbaarheid jaarverslag-cijfers: `SSPF_M2_PLACEHOLDER.demografie` overstappen naar `customCounts: [...]` zonder spec/SCHEMA-bump.

8. **CohortOutcome `surplusBijdrage`-interpretatie**. Diagnostisch fonds-niveau veld, niet sommatie-haak naar individuele ppkSurplus. `.describe()` in deze sessie gecorrigeerd, maar in audit-deepdive kan een numeriek voorbeeld helpen. UX-verbetering, niet blokkerend.

9. **§2.5 + §11.20 numerieke-impact-tekst-update (cosmetisch).** v2.2.12 corrigeert v2.2.11-changelog-claim ("30-60% KV_NP-verlaging" → "−72% gemeten"), maar inline-tekst in §2.5-numerieke-impact-tabel + §11.20-gevoeligheid-blok noemt nog "ongeveer €90k-€100k" voor Henk-Anna terwijl werkelijk €67.558. v2.2.12-doorwerking-noot vermeldt de correctie maar werkt de inline-getallen niet bij. Bij volgende cosmetische-spec-patch meenemen.

### Lage prioriteit / observaties

10. **`survivalProbBhConditional`-functie status**. Deze referentie-implementatie van bh-gecorrigeerde-survival staat in `engine.m1.ts` maar wordt na v2.2.11-optimalisatie niet meer aangeroepen door `jointLifeAnnuity()`. Functie blijft beschikbaar voor regressie-validatie tegen geoptimaliseerde implementatie. Niet exporteren uit module — private blijven, alleen voor toekomstige unit-tests die equivalentie willen aantonen. Niet-blokkerend; geen actie nodig tenzij dead-code-cleanup gewenst is.

11. **ν(N) tweede-orde claim §11.17**. Spec stelt "<0,5% impact"; werkelijke ν=1.144 voor gesloten preset → 14% verschuiving in ppkSurplus → ~0.7-3% in ppkTotal afhankelijk van DG. Aankaart-punt voor latere spec-precisering.

12. **~~Tikfout in §3.10 — "gepensheerden" mist `io`.~~** **Afgevinkt v2.2.13 (05-05-2026 11:44):** "gepensheerden" → "gepensioneerden" gecorrigeerd in §3.10 reviewpunt-tekst. Tweede occurrence in v2.2.12-changelog-tekst "gepensheerden-leeftijden 60-70" eveneens gecorrigeerd (tijdens v2.2.13-uitvoering ontdekt; werkafspraak 12 niet-perfect uitgevoerd in v2.2.12-coherentie-check). Eén "gepensheerden"-occurrence rest in v2.2.13-changelog als citaat van de tikfout-die-we-corrigeren — moet zo blijven voor changelog-historiciteit.

13. **`overigeReserves`/`operationeleReserveringPct` v3-verwijdering**. Deprecated v2.2.10 maar nog SCHEMA-vereist voor backward-compat. Bij v3-major-bump verwijderen + migratie-script schrijven voor v2.x-datasets.

14. **build.ts vs build.calc.ts duplicatie**. Twee parallelle build-pipelines (M1-only `scherm1.html` vs M1+M2 `calculator.html`). Bij M3/M4 zou een geconsolideerde `build.ts` met `--target=scherm1|calculator|deepdive` flag de duplicatie wegnemen.

15. **Gevoeligheidsgrid M2 hertest tegen v2.2.11-ankers**. Het grid in NUMERIEKE ANKERS-sectie (DG en vpvAftrekPct-gevoeligheid) is nog v2.2.10-niveau. Numerieke verhoudingen blijven gelden (joint-life is multiplicatieve scaling, niet structurele wijziging), maar absolute getallen schuiven. Bij M3-implementatie of R9.30-regressie meenemen.

---

## BESTANDS-INVENTARIS NA SESSIE

**Spec-track:**
- `ENGINE_SPECIFICATIE_v1.md` (v2.2.13, 2161 regels) — patch v2.2.10 (~70 regels) + v2.2.11 (~80 regels) + v2.2.12 (~10 regels mini-correctie) + v2.2.13 (~5 regels mini-correctie + ~70 regels §11.21-blok); §2.5 NP-blok herschreven; §11.20 broken-heart-bron-onderzoek-blok; **§11.21 spreidings-formule-canoniciteit-onderzoek-blok**.

**Verificatie-script-track:**
- `qd_test_v2.ts` (106 regels) — Q-D numerieke equivalentie-test, R9.30-DNB vs bijlage-2-lineair op SSPF-demografie. Verifieerbaar door derden; gebruikt door §11.21-bron-onderzoek-cyclus voor latere meet-iteraties.

**SCHEMA-track:**
- `schema.v2.ts` (968 regels) — Model B + M2-block; geen wijziging in v2.2.11+12 (NP-formule-update is engine-laag, geen SCHEMA-impact).
- `smoke.test.ts` (277 regels) — 17 tests, geen wijziging.

**Engine-track:**
- `src/engine.m1.ts` (481 regels, +198 t.o.v. ZIP-baseline) — joint-life-uitbreiding: `brokenHeartFactor`, `survivalProbBhConditional` (referentie), `jointLifeAnnuity` met O(K²)-optimalisatie + memoisatie-cache; `KV_NP`-switch in `computeM1`.
- `src/engine.m2.ts` (485 regels) — onveranderd in v2.2.11+12 (M2-keten ontvangt verlaagde KV_NP automatisch via cascade).
- `src/fondsdataset.ts` (74 regels) — onveranderd.
- `src/test_engine.ts` (134 regels) — geen wijziging deze sessie. **Knelpunt:** test verwacht `/home/claude/m1_build/ag2024.json`-pad dat niet bestaat in huidige map-structuur (pre-bestaande pad-bug, niet door v2.2.11 veroorzaakt). Bij volgende sessie pad fixen + ankers herzien naar € 543.096.
- `src/test_engine.m2.ts` (208 regels) — geen wijziging deze sessie; tests passeren met v2.2.11-ankers via M2-keten-cascade.

**UI-track:**
- `src/ui.m1.ts` (619 regels) — onveranderd.
- `src/ui.m2.ts` (466 regels) — onveranderd in v2.2.11+12.
- `src/ui.app.ts` (702 regels) — onveranderd in v2.2.11+12.

**Build-track:**
- `build.ts` (261 regels) — onveranderd, M1-only `scherm1.html`.
- `build.calc.ts` (347 regels) — onveranderd, M1+M2 `calculator.html`.
- `test_browser.ts` (148 regels) — onveranderd, M1-only.
- `test_browser_calc.ts` (141 regels) — bijgewerkt voor v2.2.11-ankers (M1 € 543.096, M2 € 572.166 in tests 2 + 3).

**Output:**
- `calculator.html` 198.1 KB (v2.2.11, in `/mnt/user-data/outputs/`).
- `scherm1.html` 168.4 KB (M1-only-demo, **niet bijgewerkt naar v2.2.11**; reflecteert nog v1.3-bovengrens-NP. Bij volgende sessie hertest of expliciet markeren als v2.2.10-baseline-snapshot voor regressie).

**Documenten (onveranderd):**
- `ARCHITECTUUR_v1.md`, `DESIGN_engine_v0.md`, `HANDOFF_IMPL_M1.md`, `HANDOFF_R9.30.md`, `HANDOFF_SCHEMA_M1.md`, `HANDOFF_v2.1.md`, `HANDOFF_v2.1.3.md`, `HANDOFF_v2.1.9.md`, `HANDOFF_v2.2.7.md`, `PROMPT_*.md`, `SCHEMA_v1.md`, `STRATEGY_R9.30.md`.

**Data:**
- `ag2024.json` (82 KB) — onveranderd, jaren 2022-2050.
- `21-04-2026_2216.html` (564 KB) — R9.30-productie-baseline, behouden voor regressie. **Belangrijk:** R9.30 gebruikt v1.3-bovengrens-NP-formule, dus regressie moet daar rekening mee houden — niet "verschil binnen 1%" verwachten zoals bij v2.2.10, maar "joint-life-overstap kwantificeren".

---

## VOLGENDE SESSIE — AANBEVELING

**Optie 1 (gevalideerd-doorgaan-eerst):** R9.30-regressie M2. Nieuwe sessie 1-2 uur. Output: `HANDOFF_regressie_M2.md` met afwijkings-analyse. Dit verlaagt risico op latente bugs voor M3/M4 die op M2-keten bouwen.

**Optie 2 (volgende-module-eerst):** M3 combi-sessie. Nieuwe sessie 4-6 uur (vergelijkbaar met deze). Output: `calculator.html` uitgebreid met scherm 3, `HANDOFF_combi_M3.md`. R9.30-regressie blijft openstaan, geaccepteerd als latente-debt.

**Optie 3 (parallel):** Hans regressie (Optie 1) zelf, Claude M3 (Optie 2). Werkt alleen als Hans bereid is regressie-werk te trekken.

**Mijn aanbeveling:** Optie 1. De vier silent-modificatie-momenten in deze sessie zijn elegant verlopen, maar hebben wel coherentie-overhead opgeleverd. Een R9.30-regressie als puur Claude-uitgevoerde sessie zonder parallelle-edit-overlap is waardevol als consolidatie-moment vóór M3.

---

## PROMPT-TEMPLATE NIEUWE SESSIE

Voorgestelde opening voor regressie-sessie of M3-sessie (overschrijft oude `PROMPT_nieuwe_chat_impl_M2.md` welke nu obsolete is):

```
Hans: Hoi Claude, dit is een vervolgsessie op combi-sessie M2.

Bestanden in zip uitgepakt en gelezen. Belangrijkste status-anker: HANDOFF_combi_M2.md
(dit bestand). Lees dat eerst voor context.

Doel deze sessie: [R9.30-regressie M2 / M3-combi-sessie / anders].

Werkafspraken: alle 12 (inclusief werkafspraak 12 silent-modify-detectie).

Bevestig wat je hebt gelezen en stel het eerste knelpunt voor.
```

---

Einde HANDOFF.
