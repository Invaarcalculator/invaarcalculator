# HANDOFF v3.0.119 — Invaarcalculator® · Gevoeligheidsgrafiek + UI-opruiming

**Datum:** Wo 13 mei 2026, einde-sessie
**Vorige handoff:** HANDOFF_v3.0.108.md (in werkdir, naast deze)
**Versie in werkdir bij sessie-eind:** **v3.0.119** (`src/ui.app.ts` regel met `RELEASE_VERSION = '3.0.119'`)
**Status werkdir:** alle source v3.0.119 compleet; geen regressie-tests gedraaid in deze sessie (engine niet aangeraakt)
**Status binary:** `calculator.html` v3.0.119 gebouwd; bundle 141.8 KB (was 134.3 KB pre-sessie), totaal 778.5 KB

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip:
  cd /home/claude
  unzip -q /mnt/user-data/uploads/Keep-14_v3.0.119_sessie.zip
  # → maakt /home/claude/Keep-14/ met alle source en docs

Dependencies (na verse restore):
  cd /home/claude/Keep-14 && npm install --silent

Build calculator (default fonds=sspf):
  cd /home/claude/Keep-14 && npx tsx build.calc.ts
  # → schrijft /mnt/user-data/outputs/calculator.html (≈ 778 KB)
  # NB: vereist modelspecificatie.pdf in werkdir-root, anders FAILS hard.
  # PDF is nog v3.0.108 — UI is v3.0.119; modelspec-knop levert v3.0.108-PDF.
  # Zie §6 voor de stand van Werkafspraak 17 (PDF-sync).

Regressie-suite (engine niet aangeraakt deze sessie):
  npx tsx test_browser_calc.ts        # UI smoke, ankers, audit-rapport
  npx tsx test_aftrek_komma.ts        # NL-decimaalkomma + DG 1-decimaal
  npx tsx test_v3_cascade.ts          # Engine-only cascade-ankers
  # test_print_report.ts is rood-baseline sinds v3.0.108 (zie §6).
```

### Werkafspraken (cumulatief, peildatum 13-05-2026)

Allemaal uit voorgaande sessies, ongewijzigd:

- **Werkafspraak 12**: één wijziging per turn (uitzondering: expliciet "all-in-one"-modus per gebruikers-instemming)
- **Werkafspraak 13** (06-05-2026): HANDOFF altijd in werkdir én zip
- **Werkafspraak 14** (10-05-2026): ?-helptekst is puur invul-help, geen op- of aanmerkingen, geen parameters tussen haakjes; uitzondering voor concepten die functie-uitleg verdienen (rekenrente, spreidingstermijn) waar twee secties zijn toegestaan: "WAT DOET …?" + "WAT KUNT U INSTELLEN?"
- **Werkafspraak 15** (10-05-2026): audit-uitvoer via rapport-knop, niet via aparte view of code-bescherming
- **Werkafspraak 16** (11-05-2026): elke turn die `src/`, `build.calc.ts` of `fondsen/` raakt verhoogt `RELEASE_VERSION` met +1
- **Werkafspraak 17** (12-05-2026, PDF-sync): elke RELEASE_VERSION-bump die de modelspecificatie ook publiek raakt, vereist hercompilatie van `modelspecificatie.pdf` voordat build draait. Deze sessie **bewust niet** toegepast op verzoek van Hans (zie §6).

Geen Werkafspraak 18 vastgelegd deze sessie. Twee leerpunten die ik in §6 opneem als observatie ipv genummerde regel: (a) bij terminologie-wijziging in user-facing tekst altijd volledige scan op alle plekken, niet ad-hoc; (b) bij aannames over curve-vorm of wiskundige eigenschappen eerst meten, dan claimen.

---

## 2. Wat is er gebeurd in deze sessie

Veertien turns, één grote feature (gevoeligheidsgrafiek) plus zes opruim/UI-aanpassingen. Versie ging van v3.0.108 → **v3.0.119**.

### Turn 1: Persoonlijk + Actuarieel overzicht-knoppen verwijderd (v3.0.109)
- `src/ui.app.ts`: twee imports weg (`triggerPrint`, `triggerAuditReport`), twee click-handlers weg, twee `<button>`-blokken weg
- `ui.print.ts` (283 r) en `ui.audit-report.ts` (652 r) zijn nu unreachable code maar **niet verwijderd** — cleanup expliciet uitgesteld
- Bundle: 161.3 → 134.8 KB (esbuild treeshook beide files volledig)
- Alleen "Modelspecificatie"-knop blijft in pane-actions

### Turn 2: Spreidingstermijn radio → dropdown (v3.0.110)
- `src/ui.m2.ts`: `<input type="radio">` × 2 → `<select class="dropdown-pill">` met drie opties (10 jaar, Oneindig, plus optionele "Aangepast: N jaar" voor niet-standaard waarden)
- `src/ui.app.ts`: dode `[data-spreiding-stand]`-updater opgeruimd
- Stijl in lijn met M1-dropdowns (geslacht/hoog-laag/heeftPartner)

### Turn 3: M1 slider-pair full-width (v3.0.111)
- `build.calc.ts`: `.slider-pair { grid-template-columns: 1fr 1fr }` → `1fr`
- Drie slider-paren in pane-m1 (leeftijd/pensioen, partner, hoog-laag) nu full-width op alle viewports
- Dead-code-bonus opgemerkt: `.m2-controls .slider-pair { 1fr 1fr }` is dood sinds v3.0.110 — niet aangeraakt (Werkafspraak 12)

### Turn 4: M2 dropdown-padding (v3.0.112 → v3.0.113 rollback)
- **v3.0.112** voegde `padding: 0 18px` toe aan `.m2-controls` om de dropdown uit te lijnen met de kpi-card-tekst — Hans gaf screenshot dat dit overshoot opleverde
- **v3.0.113** rollback: padding terug naar leeg. M2 dropdown krijgt nu zelfde edge-uitlijning als M1-dropdowns. Leerpunt: mijn analyse "dropdown ligt 18px voorbij kpi-card" was feitelijk juist, maar M1 heeft dezelfde "afwijking" en dat is gewoon het bestaande edge-alignment-systeem

### Turn 5: "(wettelijke standaard)" weg uit dropdown (v3.0.114)
- `src/ui.m2.ts`: "10 jaar (wettelijke standaard)" → "10 jaar"

### Turn 6: Witruimte na VERDEELBAAR OVERSCHOT verminderd (v3.0.115)
- `build.calc.ts`: `cascade-table margin-bottom: 14px` verwijderd, `.cascade-total { padding-bottom: 0 }` toegevoegd
- −22px witruimte onder de cascade-totaal-rij

### Turn 7: Deepdive code-quality (geen versie-bump, lees-alleen)
- Inventaris dead source files (`ui.print.ts`, `ui.audit-report.ts`, `build.ts`, `render_mockup.ts`, `test_browser.ts`, `test_print_report.ts`, `spreidcheck.ts`, `qd_test_v2.ts`) — totaal ~2200 r dood
- Dead CSS: 14 ongebruikte klassen, 6 hooglaag-duplicates op regels 595-624
- Aangevuld in §6 als cleanup-roadmap voor latere sessie. **Niet uitgevoerd** deze sessie

### Turn 8: ? bij Transitiebijdrage in cascade-pane (v3.0.116)
- `src/ui.app.ts`: `helpIcon('bijstort')` toegevoegd in cascade-label "+ Transitiebijdrage werkgever"
- Nieuwe `bijstort` entry in `HELP_CONTENT` met drie secties: WAT IS DIT? / HOE HOOG IS HET BEDRAG? / LET OP
- Help-tekst legt expliciet uit dat calculator de bijdrage niet automatisch aan DG koppelt (deelt scope met Hans' eerdere "transitiebijdrage als DG-functie"-vraag — voor nu blijven we bij handmatige slider)

### Turn 9: Topline-subtitle compacter (v3.0.117 → v3.0.118)
- v3.0.117 probeerde "Voor wie SSPF-pensioen ontvangt na AOW" (na de … -leeftijd → na AOW)
- v3.0.118 ging naar **"Voor SSPF-gepensioneerden na de AOW-leeftijd"** op Hans' verzoek
- Discussie over "fondsleden" ipv "gepensioneerden" — afgewezen want te breed (inclusief pre-AOW-actieven die deze tool niet kunnen gebruiken)

### Turn 10-13: Gevoeligheidsgrafiek prototype (geen calculator-bumps)
**Vier turns prototype-werk in `/home/claude/Keep-14/prototypes/`** — calculator zelf onaangeraakt. Iteratief gebouwd:

1. **Initieel: x-as 125-150%, vier elementen** (lijn, sprongen, persoonlijke dot, SSPF-standaard dot)
2. **Hans: laat lopen vanaf 125** — al gedaan
3. **Hans: kleinere DG-stappen voor smoother graph** — bleek dat 0.1%-rooster wel de échte bijstort-sprongen op 130%/135% blootlegt (−€2.532 en −€1.915, eerder verstopt in 1%-rooster)
4. **Hans: geen tekst in grafiek + alleen persoonlijke berekening** — SSPF-standaard-marker en alle euro-labels uit SVG verwijderd; alleen as-labels en één blauwe dot blijven
5. **Hans: consistente labeling "t.o.v. huidige aanspraak"** — drie ronden waarin steeds een plek bleef hangen (title, aria-label, legend); leerpunt: bij terminologie-wijziging altijd volledige scan, niet per locatie
6. **Hans: SI-conventie dimensieloos** — x-as "Dekkingsgraad / [%]" en y-as "Uw aandeel t.o.v. huidige pensioenaanspraak / [%]", tick-waarden zonder eenheid-suffix
7. **Hans: laat lopen vanaf 100%** — uitgebreid met gestippelde "hypothetisch" segment voor DG 100-125% waar SSPF niet zou invaren; curve kruist 0% rond DG 106%. Didactisch sterk: laat zien waarom de SSPF-drempel bij 125% ligt
8. **Hans: invaring is slecht Nederlands** — alle zelfstandig-naamwoord "invaring" in user-facing tekst vervangen door werkwoord "wordt (niet) ingevaren". Code-symbolen (`invaarStatus`, `'invaring'`-enum) blijven
9. **Hans: cascade-aftrek betekent niks** — gejargonneerde meta-note herschreven: "bedragen die het fonds opzij zet voor wettelijke reserves en risicodeling — pas als het fondsvermogen daar bovenuit komt, blijft er voor u iets te verdelen over"

### Turn 14: Integratie in calculator (v3.0.119)
- **Nieuw bestand `src/ui.sensitivity.ts`** (172 r): `runSweep()` (501 M2-runs voor DG 100-150% in 0.1%-stappen, met SSPF-bijstort-staffel) + `renderSensitivityHTML()` (volledige modal-body HTML inclusief inline SVG)
- **Nieuwe knop in pane-actions**: "Gevoeligheidsgrafiek", links van "Modelspecificatie"
- **Modal**: hergebruikt `help-modal-overlay`-patroon maar met aparte `.sensitivity-modal` (max-width 800px ipv 520px) voor grafiek-viewport
- **Drie sluit-mechanismen**: X-knop, klik buiten modal, Escape-toets
- **Live-data**: elke klik draait 501 verse M2-runs voor de huidige deelnemer (geen cache); ~600-900 ms in browser
- **CSS**: ~70 r voor `.sens-*` klassen (chart, legend, summary, meta-note) plus `.sensitivity-modal`
- JSDOM-validatie: modal opent, sluit via X/overlay/Escape, polylines+circle correct gerenderd, summary toont €312.539 / 24,1% (matcht KPI-blok van M2-pane voor de SSPF-default-deelnemer)
- Bundle: 134.3 → 141.8 KB (+7.5 KB voor de hele feature)

---

## 3. Werkmap-status — wat is veranderd

### Source-edits (`src/`)
| File | Status |
|---|---|
| `ui.app.ts` | gewijzigd — knop, click-handler, openSensitivityModal/closeSensitivityModal, helpIcon('bijstort'), HELP_CONTENT.bijstort, version-bump, M1 slider-pair full-width is in build.calc.ts maar zie hieronder |
| `ui.m2.ts` | gewijzigd — spreidingN radio → dropdown, (wettelijke standaard) weg |
| `ui.sensitivity.ts` | **nieuw** (172 r) |
| `ui.print.ts` | **onaangeraakt** maar unreachable sinds v3.0.109 — cleanup uitgesteld |
| `ui.audit-report.ts` | **onaangeraakt** maar unreachable sinds v3.0.109 — cleanup uitgesteld |
| Andere `src/*.ts` | onaangeraakt |

### Build (`build.calc.ts`)
- Modal-HTML voor sensitivity toegevoegd na de help-modal
- CSS voor `.sensitivity-modal` + `.sens-*` klassen
- Topline-subtitle wijziging (v3.0.117 → v3.0.118)
- `.slider-pair grid-template-columns: 1fr` (v3.0.111)
- `.cascade-table margin-bottom` weg, `.cascade-total padding-bottom: 0` (v3.0.115)

### Prototypes (`prototypes/`)
- **`sweep_dg.ts`** — script dat 501 M2-runs draait en JSON dumpt
- **`sweep_dg.json`** — output: 501 datapoints, 80 KB
- **`dg_grafiek_template.html`** — standalone proto met `__SWEEP_DATA__`-placeholder

Deze prototypes zijn historische artefacten; de productie-code zit nu in `src/ui.sensitivity.ts`. Toch bewust meegenomen in de zip omdat ze de iteratie-historie illustreren en als regressie-anker dienen mocht de productie-code ooit moeten worden vergeleken.

### Calculator-output
- `outputs/calculator_v3.0.108.html` — pre-sessie binary
- (Nieuwe `calculator.html` v3.0.119 staat in `/mnt/user-data/outputs/`, dus niet in werkdir)

---

## 4. Belangrijke design-kennis voor de gevoeligheidsgrafiek

### Wiskundige eigenaardigheden in de DG-curve

Binnen elke bijstort-trede is `aandeel = a · DG + b` (lineair). Helling per 1% DG is voor de SSPF-default-deelnemer (70j M, €25k pensioen) constant op **€2.441** per 1% DG — drie schuine parallelle lijntjes.

Bij DG-overgangen (125%, 130%, 135%) springt de bijstort en valt het aandeel discontinu:

| Overgang | Bijstort-stap | Sprong in aandeel (€) |
|---|---|---|
| 124.9% → 125.0% | €0 → €850 mln | **+€11.108** (sprong omhoog, eerste bijdrage) |
| 129.9% → 130.0% | €850 → €650 mln | **−€2.312** (omlaag) |
| 134.9% → 135.0% | €650 → €500 mln | **−€1.673** (omlaag) |

De grafiek toont deze sprongen als verticale stippel-lijntjes; cruciaal om eerlijk te zijn over het discontinue gedrag van de regel.

### Het null-doorgangspunt bij DG ≈ 106%

Bij hypothetisch invaren zonder bijstort onder 125%:
- DG 100%: aandeel **−€14.648** (vermogensverlies)
- DG 106%: aandeel **€0** (kruispunt)
- DG 124.9%: aandeel **+€46.140**

Dit is wat de gestippelde curve onder 125% laat zien — feitelijk juist en didactisch sterk: het verklaart waarom SSPF de drempel bij 125% legt (zonder werkgevers-vangnet zou het fondsvermogen onvoldoende zijn om de cascade-aftrek te dekken).

### N_deelnemers-invariantie

Belangrijk inzicht uit Turn 7 (deepdive): `x_fonds` is **wiskundig invariant** onder N_deelnemers-schaling. N valt eruit als gemeenschappelijke factor in de proxy-loop. Alleen `ppkComp = compensatiedepot / N × wRel` is N-gevoelig (lineair invers). Voor SSPF maakt dat geen verschil want `compensatiedepot = 0`.

### Curve-vorm per deelnemer

**Niet** uniform — elke deelnemer krijgt zijn eigen curve, niet alleen een geschaalde versie:

| Deelnemer | Aandeel bij DG=150% (% van KV) |
|---|---|
| 70j M, €25k | 35,1% |
| 65j V, €40k | 45,5% |
| 85j M, €15k | 16,5% |
| 75j V, €50k | 31,2% |

Factor 2,8 verschil tussen hoogste en laagste. Verklaring: leeftijds-effect (langere verwachte uitkeringshorizon bij jonger = meer NCW van surplus), geslacht (vrouwen langer leven), KV-schaal (cw-star/cw-voor-verhouding niet constant). Daarom is de sweep per-deelnemer, niet pre-rendered build-time.

---

## 5. Hoe de gevoeligheidsgrafiek werkt — code-architectuur

```
[ click op "Gevoeligheidsgrafiek" ]
        ↓
ui.app.ts click-handler (rond regel 1577)
        ↓
runSweep(deelnemer, m1Out, m2Params)  ← src/ui.sensitivity.ts
        ↓ (501 M2-runs)
SensitivitySweep object
        ↓
openSensitivityModal(sweep)  ← src/ui.app.ts (~regel 1083)
        ↓
renderSensitivityHTML(sweep)  ← src/ui.sensitivity.ts
        ↓ (string-template met inline SVG)
innerHTML van sensitivity-modal-body
        ↓
overlay.style.display = 'flex'  ← modal verschijnt
```

### Belangrijke eigenschappen

- **Volledig device-agnostic**: modal vult mobile-viewport vanzelf; SVG viewBox=760×380 schaalt met `width: 100%`
- **Geen cache**: runSweep bij élke klik. Op desktop ~300 ms, mobile ~600-900 ms (acceptable voor one-shot)
- **Bijstort-staffel hardcoded in `bijstortForDG()`** in `ui.sensitivity.ts` — SSPF-specifiek; bij meer fondsen moet dit naar fonds-config
- **Persoonlijke DG = `m2Params.dekkingsgraad`** uit huidige state; clamp op [1.00, 1.50] voor de marker, geen extrapolatie buiten range
- **Y-as**: dimensieloos in %, ticks afgerond op 5% beneden en boven; 0-lijn visueel benadrukt (donkergrijs ipv stippel)
- **Vier polyline-segmenten**: hypothetisch (gestippeld, 250 punten), drie invaring-tredes (doorgetrokken, 50/50/151 punten)

---

## 6. Aandachtspunten voor volgende sessie

### A. PDF-sync (Werkafspraak 17) — uitgesteld
- UI is v3.0.119, embedded `modelspecificatie.pdf` is nog v3.0.108
- Hans expliciet akkoord gegaan met deze mismatch in deze sessie
- Modelspec-knop downloadt nu `Modelspecificatie_Invaarcalculator_v3.0.119.pdf` (filename volgt RELEASE_VERSION) maar de inhoud is v3.0.108
- Voor publicatie: PDF moet hercompileerd worden (zie HANDOFF v3.0.108 §1 voor pdflatex-procedure)

### B. test_print_report.ts — rood baseline sinds v3.0.108
- Test verwacht nog OP/NP-rijen en formules-appendix die in v3.0.108 verwijderd zijn
- Wordt erger sinds v3.0.109: hele print-feature is verwijderd, test target bestaat niet meer
- Aanbeveling: test verwijderen (zit in §C-cleanup-lijst)

### C. Cleanup-roadmap uit deepdive (Turn 7 — nog niet uitgevoerd)

Aanbevolen volgorde (van veilig naar controversieel):

1. **Onbereikbare src-files weg** (één turn, ~940 r): `src/ui.print.ts`, `src/ui.audit-report.ts`
2. **Onbereikbare root-files weg** (één turn, ~1300 r): `build.ts`, `render_mockup.ts`, `test_browser.ts`, `test_print_report.ts`, `spreidcheck.ts`, `qd_test_v2.ts` (laatste eventueel houden als debug-tool)
3. **Dead CSS**: 14 ongebruikte klassen (`.audit-unlock`, `.audit-unlock-form`, `.fonds-radio`, `.fonds-radio-row`, `.fonds-radios`, `.fonds-single`, `.hooglaag-block`, `.hooglaag-toggle`, `.kpi-delta`, `.kpi-foot`, `.radio-group`, `.slider-help`, `.topline-help-btn`, `.wrap`) + 6 hooglaag-duplicates op regels 595-624
4. **`.cascade-total`-rules consolideren** tot één rule (drie top-level definities nu)
5. **`test_ui_spreidingN.ts`** comment-tekst bijwerken naar dropdown, test voor "Aangepast: N jaar"-pad toevoegen

De engine/schema-export-audit (45 exports zonder cross-file gebruik in `engine.m1.ts`, `engine.m2.ts`, `schema.v2.ts`) is een aparte beslissing over publieke API-vorm — niet "even opruimen".

### D. Transitiebijdrage als DG-functie — niet gemodelleerd
Discussie in Turn 8: de SSPF-bijstort is feitelijk een DG-functie (drie treden) maar de engine ziet het als handmatige scalar. De gevoeligheidsgrafiek bewijst nu visueel dat dit ertoe doet — bij DG-slider verschuiven over een drempel mist de gebruiker de bijstort-stap. Hans heeft expliciet besloten dit "te laten zitten" met als enige actie het toegevoegde help-icon. Mocht dit later toch geïmplementeerd worden: zie de architectuur-discussie in Turn 8 (optie 1 = stuksgewijze array in fonds-config, evaluatie in UI-laag, sticky override).

### E. Sensitivity-grafiek uitbreidingen
De huidige implementatie is **één** grafiek. Mogelijke uitbreidingen voor v4+:

1. **Tweede grafiek** in dezelfde modal (knop wordt dropdown of tabs): leeftijd → ppkTotal, spreidingstermijn 10 vs ∞ per leeftijd
2. **Pre-defined "lees-pad"**: gebruiker scrollt door 3-4 verschillende grafieken in een modal
3. **DG-functie-koppeling voor bijstort**: zou de "vlakke" zone in trede-binnen worden vervangen door de échte continue regel (zie D)

Voor nu: één grafiek, dat dekt 80% van de "wat zou er gebeuren als"-vraag.

---

## 7. Observaties voor nieuwe sessie (geen genummerde Werkafspraak)

**Twee dingen die in deze sessie misgingen en die ik wil dat de volgende Claude weet:**

### Observatie A: bij terminologie-wijziging altijd volledige scan
Hans wees me drie keer op een plek die nog oude terminologie had toen ik "Uw aandeel verdeelbaar overschot" → "Uw aandeel t.o.v. huidige pensioenaanspraak" wijzigde:
- Eerst y-as label
- Toen subtitle
- Toen legend
- Toen browser-`<title>` en `aria-label`

Aanpak voor volgende keer: **bij elke terminologie-wijziging eerst grep over alle user-facing strings**, dan in één keer alle plekken aanpassen. Niet ad-hoc per locatie. Werkpatroon:
```bash
grep -nE "<term>" src/*.ts build.calc.ts fondsen/sspf/fonds.config.ts
```
Output triagéren in: (a) user-facing tekst — moet mee, (b) code-symbolen (variabele-namen, enum-waardes) — blijft staan tenzij refactor.

### Observatie B: aannames over wiskundige eigenschappen toetsen voor je claimt
Toen Hans zei "zelfde verloop, andere schaal" was mijn instinct dat te bevestigen voor één deelnemer (waar het inderdaad waar is). Maar ik claim­de het ook voor **alle deelnemers** zonder te meten — dat bleek fout (factor 2,8 spread tussen verschillende deelnemers, zie §4).

Aanpak: **wiskundige claims toetsen met script vóór je ze in een advies opneemt**, ook al lijkt het triviaal. In deze codebase staat een complete engine; één tsx-run kost <1 sec.

---

## 8. Bestanden in werkdir (volledig)

Top-level: 71 bestanden, 4.0 MB exclusief node_modules.

**Source (`src/`):**
- `engine.m1.ts` (1136 r) — M1-engine, onaangeraakt
- `engine.m2.ts` (905 r) — M2-engine, onaangeraakt
- `schema.v2.ts` (1030 r) — Zod-schemas, onaangeraakt
- `fondsdataset.ts` (39 r) — fonds-injection-helper
- `fondsdataset.types.ts` (41 r) — fonds-config-types
- `ui.app.ts` (~1670 r) — **gewijzigd** deze sessie (turns 1, 5, 6, 7, 9, 14)
- `ui.m1.ts` (581 r) — onaangeraakt
- `ui.m2.ts` (434 r) — **gewijzigd** (turn 2, turn 5)
- `ui.shared.ts` (267 r) — onaangeraakt
- `ui.sensitivity.ts` (172 r) — **NIEUW** (turn 14)
- `ui.print.ts` (283 r) — onbereikbaar, niet verwijderd
- `ui.audit-report.ts` (652 r) — onbereikbaar, niet verwijderd
- `test_engine.ts`, `test_engine.m2.ts` — engine-tests, onaangeraakt

**Root TypeScript:**
- `build.calc.ts` — **gewijzigd** deze sessie (turns 3, 6, 9, 14)
- `build.ts`, `render_mockup.ts` — onbereikbaar (uit deepdive)
- Tests in root: `smoke.test.ts`, `test_aftrek_komma.ts`, `test_bh_decompositie.ts`, `test_browser.ts`, `test_browser_calc.ts`, `test_cwstar_smoke.ts`, `test_hans_replication.ts`, `test_print_report.ts` (rood), `test_ui_spreidingN.ts`, `test_v3_cascade.ts`, `qd_test_v2.ts`, `spreidcheck.ts`

**Fonds-config:**
- `fondsen/sspf/fonds.config.ts` — onaangeraakt

**Documentatie (markdown):**
- Eerdere HANDOFFs: v2.1, v2.1.3, v2.1.9, v2.2.7, v3.0, v3.0.36, v3.0.37, v3.0.89, v3.0.91, v3.0.92, v3.0.106, v3.0.107, v3.0.108
- IMPL/SCHEMA-handoffs: HANDOFF_IMPL_M1, HANDOFF_SCHEMA_M1, HANDOFF_combi_M2, HANDOFF_R9.30
- Architectuur: `ARCHITECTUUR_v1.md`, `DESIGN_engine_v0.md`, `ENGINE_SPECIFICATIE_v1.md`, `SCHEMA_v1.md`, `STRATEGY_R9.30.md`
- Reconstructie-log: `RECONSTRUCTION_LOG_v3.0.92_to_v3.0.106.md`
- Prompts: `PROMPT_nieuwe_chat_impl_M1.md`, `PROMPT_nieuwe_chat_impl_M2.md`, `PROMPT_nieuwe_chat_schema_M2.md`

**Modelspecificatie:**
- `BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.106.md` (oud)
- `BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.108.md` (huidig)
- `BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.108.tex` (LaTeX-bron)
- `modelspecificatie.pdf` — v3.0.108-compilation, behouden voor build
- `outputs/BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.108.pdf` — backup

**Prototypes (`prototypes/`):**
- `sweep_dg.ts` — sweep-script
- `sweep_dg.json` — 501 datapoints
- `dg_grafiek_template.html` — standalone proto

**Overig:**
- `ag2024.json` — AG2024 sterftekansen-data (81 KB)
- `21-04-2026_2216.html` — historische snapshot
- `mockup_m1.html`, `scherm1.html` — vroege mockups
- `outputs/calculator_v3.0.108.html` — pre-sessie binary
- `package.json`, `tsconfig.json` — build-config

Deze HANDOFF zelf wordt na schrijven toegevoegd aan de werkdir als `HANDOFF_v3.0.119.md`.

---

**Einde HANDOFF v3.0.119.**
