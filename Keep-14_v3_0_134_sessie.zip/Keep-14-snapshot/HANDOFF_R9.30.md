# WTP-PENSIOENCALCULATOR — HANDOFF R9.30

Datum: 22-04-2026 21:15
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Licentie: CC BY-NC 4.0

Dit document bevat de volledige **technische** status voor het starten van de volgende ontwikkelsessie. Het vervangt `HANDOFF_R9.23.md`. De strategische richting staat in `STRATEGY_R9.30.md`. Het dataset-schema staat in `SCHEMA_v1.md` en is **ongewijzigd** — het schema is precies zoals beschreven geïmplementeerd.

---

## BELANGRIJKE CONTEXT — STAND NA R9.30

De R9.23-voorbereidingssessie tikte beslispunt 1 (schema-ontwerp) af. De reeks R9.24 t/m R9.30 heeft vervolgens **beslispunten 2 t/m 6 in code afgehandeld** en de complete Fase A-infrastructuur opgeleverd. De documentatiesessie die R9.30 moest beschrijven crashte voortijdig; dit document herstelt die achterstand.

Kernpunten die de volgende sessie moet weten:
- **Fase A is afgerond** — dataset-object, validator, apply-helpers, reset-knoppen, audit-footer en regeling-pill staan live in het werkbestand
- **Beslispunten 2-6 zijn in code beantwoord** — zie decision log hieronder voor elk punt afzonderlijk
- **Engine is bewust niet gemigreerd** — `snapshotCurrentParams`, `ppkCalculate`, `verwSimulate` blijven DOM-gedreven; de reden daarvoor is architectureel scherp en wordt apart behandeld in dit document
- **Werkbestand is `21-04-2026_2216.html`** (Release 9.30), 6862 regels — alle regel-offsets zijn ~390 regels opgeschoven t.o.v. R9.22 door de dataset-sectie bovenaan
- **Eén pending sub-vraag** (niet-blocker): aging-methode voor de `grijzend`-preset blijft openstaan — oplossen in Fase B bij SSPF-publiek-v1 data-curatie

---

## DECISION LOG — BESLISPUNTEN 2-6 (R9.24 — R9.30)

De R9.23-STRATEGY hield vijf beslispunten open voor start van de R9.23-sessie. Alle vijf zijn in de code opgelost:

### Beslispunt 2: Dataset-locatie in code

**Gekozen:** aparte `<script id="fonds-dataset" data-schema-version="1.0">`-tag vóór het hoofdscript (regel 2610-2707). Het `data-schema-version`-attribuut maakt de schema-versie declarabel op DOM-niveau en valideerbaar door externe tooling.

Rationale: het dataset-object is declaratieve configuratie, niet uitvoerbare applicatielogica. Aparte `<script>`-tag maakt dat visueel en syntactisch zichtbaar. Object.freeze garandeert dat de engine de dataset nooit kan muteren.

### Beslispunt 3: Grensgevallen — "dataset-default, UI-overschrijfbaar"

**Feitelijk geïmplementeerd:** alle parameters die én in de dataset staan én een slider hebben zitten automatisch in deze categorie. Het `applyDatasetDefaultsPPK/Verw`-mechanisme vult sliders bij init uit de dataset; de gebruiker overschrijft ze vervolgens vrij; `resetPPKToDataset`/`resetVerwToDataset` maakt de terugweg zichtbaar via een knop per scherm.

Dit beantwoordt de oorspronkelijke kandidaten-lijst (σ, μ, π, projectierendement, demping, compensatie-curve) volledig: ze staan in `defaults` en `beleid`, zijn UI-zichtbaar, en worden bij reset teruggezet. Velden zonder slider (RDR_initieel, invaardatum, minimaleInvaarDG, sterftekansTabelId) zijn strikt dataset-waarden — geen UI-override, geen engine-read in Fase A.

### Beslispunt 4: Validator-striktheid

**Gekozen:** hard weigeren. Bij falen vervangt de validator `document.body` met een dev-leesbare foutmelding (geel waarschuwingsvlak, één `<li>` per fout, versielabel onderaan) en gooit een Error om verdere init te stoppen. Geen fallback op defaults.

Geïmplementeerd als IIFE op regel 2855-2874, direct na de validator-functie zelf. De validator dekt SCHEMA v1 sectie 6 volledig met één bewuste limiet: `demografie.preset`-naam wordt niet gecheckt tegen `DEMOGRAFIE_PRESETS` omdat die constante pas later in het script staat (hoisting-volgorde). Commentaar documenteert dit expliciet; oplossing voor Fase B.

### Beslispunt 5: UI-zichtbaarheid dataset-metadata

**Gekozen:** permanente footer-bar onderaan elke pagina (`<footer class="dataset-footer" id="dataset-footer">` op regel 2559, CSS vanaf regel 85). Toont: `Engine {versie} · {fondsnaam} v{datasetversie} · peildatum {datum} · bron: {bron}` plus een subtiel `i`-icoon (Georgia serif, `cursor:help`) met de dataset-disclaimer als native browser-tooltip.

Rationale: elke screenshot wordt nu zelf-traceerbaar naar een engine×dataset-paar. Het icoon is toegankelijk via `tabindex=0` + `aria-label`, zodat de disclaimer ook voor toetsenbord- en screenreader-gebruikers bereikbaar is.

### Beslispunt 6: Regeling-selector UI-plaats

**Gekozen:** een derde weg die noch in STRATEGY noch in HANDOFF_R9.23 expliciet werd overwogen — een **pill naast de scherm-titel** op zowel scherm 2 als scherm 3. Niet top-level (zou suggereren dat de keuze de hele app overspant), niet alleen in scherm 3 (zou suggereren dat regeling alleen FPR-simulatie raakt).

Geïmplementeerd via `.regeling-pill`-class (CSS regel 444-471), HTML-elementen op regel 1497-1500 (PPK) en 1936-1939 (Verw), en `renderRegelingSelector()`-functie (regel 6845-6854). In Fase A: statisch, gedimd, met tooltip "SPR-clean en SPR-hybride komen in Fase B". In Fase B: zelfde element wordt een dropdown met drie opties.

---

## STATUS WERKBESTAND

**Laatste live bestand:** `21-04-2026_2216.html` — Release 9.30 · 21-04-2026 22:16 — 6862 regels

De regel-offsets uit de R9.23-HANDOFF zijn allemaal ~390 regels opgeschoven door de dataset-sectie die bovenaan is toegevoegd. Hieronder de bijgewerkte map van belangrijke regio's.

### Nieuwe infrastructuur (R9.24-R9.30)

| Regio | Regelnr | Beschrijving |
|---|---|---|
| CSS dataset-footer | 80-121 | `.dataset-footer` + `.df-info` |
| CSS reset-btn | 425-439 | `.reset-btn` — terug-naar-dataset-knoppen |
| CSS regeling-pill | 441-471 | `.regeling-pill` + sub-elementen |
| HTML dataset-footer | 2559 | `<footer class="dataset-footer" id="dataset-footer">` |
| HTML regeling-pill PPK | 1497-1500 | `<span class="regeling-pill" id="ppk-regeling-pill">` |
| HTML reset-knop PPK | 1502 | `<button id="ppk-reset-dataset">` |
| HTML regeling-pill Verw | 1936-1939 | `<span class="regeling-pill" id="verw-regeling-pill">` |
| HTML reset-knop Verw | 1941 | `<button id="verw-reset-dataset">` |
| **FONDS_DATASET object** | **2611-2705** | SCHEMA v1, Object.freeze, 26 herkomst-entries |
| **validateFondsDataset** | **2738-2850** | Volledige SCHEMA v1 sectie 6 dekking |
| Validator-IIFE | 2855-2874 | Hard fail met body-replace |
| **applyDatasetDefaultsPPK** | **6741** | Scherm 2 sliders + demografie uit dataset |
| **applyDatasetDefaultsVerw** | **6781** | Scherm 3 sliders uit dataset + buffer 0 |
| applyDatasetDefaults | 6796 | Orchestrator |
| resetPPKToDataset | 6806 | User-facing reset scherm 2 |
| resetVerwToDataset | 6810 | User-facing reset scherm 3 |
| Init-call applyDatasetDefaults | 6815 | Draait één keer bij pageload |
| **renderDatasetFooter** | **6822** | Vult footer met engine×dataset-info |
| **renderRegelingSelector** | **6845** | Vult beide regeling-pills |
| Init-calls footer + selector | 6857-6858 | Direct vóór `gotoScreen('hub')` |

### Bijgewerkte regelnummers bestaande engine-functies

Alle functies uit de R9.22-code zijn ~390 regels opgeschoven:

| Regio | Regelnr | Oorspronkelijk (R9.22) |
|---|---|---|
| Top-comment + versie | 5 | 5 |
| VERSION-constante | 2721 | 2487 |
| AG2022 sterftekansen `Q` | 185 van script = 2896 | 2510 |
| annuityTo | 214 van script = 2925 | 2539 |
| lifeExp | 232 van script = 2943 | 2557 |
| renderStart (scherm 1 render) | 317 van script = 3028 | 2642 |
| COHORT_BOUNDS | 625 van script = 3336 | 2950 |
| DEMOGRAFIE_PRESETS | 633-644 van script | 2958-2964 |
| snapshotCurrentParams | 3496 | 3110 |
| ppkCalculate | 3643 | 3257 |
| ppkRender | 3762 | 3376 |
| mulberry32 / nextNormal | 5443 / 5455 | 5052 / 5064 |
| **verwSimulate** | **5477** | 5085 |
| MC config (N_PATHS, MASTER_SEED) | 5538 / 5539 | 5146 / 5147 |
| verwRender | 5688 | 5297 |
| startddRender | 4804 | 4413 |

(Nauwkeurige regelnummers verifieerbaar met `grep -n "function X" 21-04-2026_2216.html`.)

---

## DATASET-IMPLEMENTATIE — ARCHITECTUUR

### Het FONDS_DATASET object

Bevroren via `Object.freeze`, acht top-level blokken conform SCHEMA v1: `meta`, `regeling`, `fondsbalans`, `beleid`, `demografie`, `defaults`, `actuarieel`, `herkomst`, plus `reserveringenFaseB` (drie null-velden: `rtsCurve`, `agHerzienPeriode`, `renteAfdekkingFactor`). Alle waarden zijn placeholders die 1-op-1 de oude tool-defaults reproduceren (135% DG, 25 mrd, `grijzend` preset). Alle 26 herkomst-entries staan op tier `reconstructie` met een notitie die expliciet "placeholder; Fase B: echte SSPF-waarde" vermeldt.

### Validator (SCHEMA v1 sectie 6)

Volledige dekking van structuur, verplichte velden, demografie exact-één-van, waardenbereiken en herkomst-consistentie. Bewuste limiet: preset-bestaan niet gecheckt vanwege hoisting-volgorde (DEMOGRAFIE_PRESETS komt later in het script). Verkeerde preset-naam leidt tot runtime-fout bij lookup, niet tot validator-fout.

### Apply-helpers

`applyDatasetDefaultsPPK` vult de scherm-2-sliders (fondsbalans + beleid.spreidingN/compensatieMu/Sigma + demografie). `applyDatasetDefaultsVerw` vult scherm-3-sliders (demping + alle defaults-rate). Buffer wordt op 0 gezet — buffer is geen fondsfeit in SCHEMA v1. Bij init zetten ze slider-values programmatic; HTML-attribuut-defaults blijven staan als fallback voor als JS faalt.

### Reset-knoppen

Per scherm één knop (`resetPPKToDataset` / `resetVerwToDataset`). Roepen dezelfde apply-helpers aan + `renderActive()` om de UI bij te werken. Gebruikersinvoer (leeftijd, pensioenbedrag, disconterings­rente) blijft staan — die zijn geen fondsfeiten.

### Audit-footer + regeling-pill

`renderDatasetFooter` schrijft één keer bij laden de footer-tekst. `renderRegelingSelector` vult beide pills. Beiden worden één keer aangeroepen; geen live-update nodig want dataset-waarden veranderen niet tijdens een sessie.

---

## ENGINE-MIGRATIE — BEWUST NIET GEDAAN

Dit is het belangrijkste architecturele punt dat de HANDOFF_R9.23 niet had kunnen voorzien. De R9.23-STRATEGY kondigde aan: "de reads in ppkCalculate/verwSimulate/snapshotCurrentParams moeten worden gemigreerd naar dataset-reads." In R9.24-R9.30 is dat **niet gebeurd**, en bij reflectie blijkt dat de betere keuze.

### Hoe het nu werkt

```
FONDS_DATASET  (Object.freeze, bron-van-waarheid configuratie)
      │
      ▼  applyDatasetDefaults bij init
sliders (DOM, runtime-mutatielaag)
      │
      ▼  user kan overschrijven
engine leest uit DOM
      │
      ▼  reset-knop zet sliders terug op dataset-waarden
```

### Waarom dit geen refactor-schuld is

1. **De gebruiker ziet de dataset als uitgangspunt.** Sliders starten bij dataset-waarden, zijn overschrijfbaar, en resetten terug naar dataset. Dat is de "dataset-default, UI-overschrijfbaar"-semantiek in zuivere vorm.
2. **De engine ziet de DOM als invoer.** Dat is simpel, test-baar en ontkoppeld van dataset-loading-mechanismen. `snapshotCurrentParams` hoeft nooit te weten waar een waarde vandaan komt.
3. **Migreren zou sliders degraderen.** Als de engine direct `FONDS_DATASET.xxx` zou lezen, zouden sliders "schijn-invoer" worden die de gebruiker wel ziet maar die niet in de berekening terugkomen. Of de migratie zou voor elke parameter een aparte overschrijf-state moeten bouwen — die al bestaat, in de vorm van de DOM.

### Waar de splitsing wél rechtstreeks is

De velden die in de dataset staan maar **geen** slider hebben, worden in Fase A door geen enkele engine-code gelezen:

- `beleid.RDR_initieel` — wacht op FPR/SPR-RDR-mechaniek
- `beleid.RDR_max_pct` — idem
- `beleid.invaardatum` — wacht op invaartoets-logica
- `beleid.minimaleInvaarDG` — idem
- `actuarieel.sterftekansTabelId` — wacht op multi-tabel-support
- `reserveringenFaseB.*` — alle drie null, wachten op SPR-hybride

Wanneer in Fase B de SPR-regelingen, RDR-toets en AG-herziening erbij komen, zullen die velden **voor het eerst** door engine-code gelezen worden — en dan wel rechtstreeks uit `FONDS_DATASET`, niet via DOM, omdat er geen UI-sliders voor zijn. Daar krijgt de splitsing dus een tweede, rechtstreekse laag.

### Samenvattend

De huidige architectuur is gelaagd:

- **Slider-gedekte velden** → engine leest via DOM (dataset = init + reset-bron)
- **Niet-slider-gedekte velden** → engine leest rechtstreeks uit dataset (zodra Fase-B-code ze gaat gebruiken)

Dit vraagt geen refactor. Het vraagt alleen dat Fase-B-code bij het lezen van RDR/invaar/AG-velden inderdaad de dataset gebruikt, niet nieuwe hardcoded constanten bouwt. Dat is een code-review-afspraak, geen architecturele openstaande taak.

---

## PROJECTDOEL (onveranderd)

Single-file HTML-calculator waarmee **SSPF-gepensioneerden** (leeftijd 65-100, vanaf Fase B) kunnen verkennen wat invaren onder de Wet Toekomst Pensioenen betekent voor hun eigen situatie. Geen financieel-advies-tool maar een **verkenner**: hoe werken de mechanismen, wat als SSPF dit of dat doet, wat is het effect van rendement/inflatie/demping/buffer op de jaarlijkse uitkering.

De engine is bewust zó ontworpen dat hij met een andere dataset ook andere fondsen zou kunnen bedienen — dat is de commerciële horizon (Fase C+).

---

## DRIE SCHERMEN (onveranderd)

1. **Huidig pensioen** (start): laat zien wat de bestaande aanspraak nu waard is en hoe die zich onder de oude regeling zou ontwikkelen
2. **Pensioenpotje (PPK)**: hoeveel vermogen krijgt u toegedeeld bij invaren — demografie, dekkingsgraad, DNB-spreidingsmethode, compensatie voor afschaffing doorsneesystematiek
3. **Verwacht pensioen (FPR)**: simulatie van de jaarlijkse uitkering onder de Flexibele Premieregeling met Monte Carlo

---

## DRIE REGELING-ROUTES (ARCHITECTUURPLAN, ONVERANDERD)

| Element              | FPR (klaar)                | SPR clean (Fase B)        | SPR hybride (Fase B-eind) |
|----------------------|----------------------------|---------------------------|---------------------|
| Startpunt U₀         | potje / ä_x                | huidige uitkering         | huidige uitkering + buffer-opslag |
| Update noemer        | constant μ_proj            | constant 1-jaars RTS      | tijdsvariërende RTS-curve |
| Update teller        | r_t (log-normaal)          | r_t (log-normaal)         | r_t met rente-afdekking correlatie |
| Demping              | opt-in slider              | opt-in slider             | default aan, 5 jr |
| AG-herziening        | n.v.t.                     | n.v.t.                    | schok elke 2 jaar |
| Sterfte-afwijking    | n.v.t.                     | mortality pooling         | mortality pooling + noise |
| **Dataset-veld**     | **regeling: 'FPR'**        | **regeling: 'SPR-clean'** | **regeling: 'SPR-hybride'** |

Routes delen 80% MC-infrastructuur; alleen inner loop `r_t → U_{t+1}` verschilt.

Het Implementatieplan 15-7-2025 bevestigt dat SSPF definitief voor **FPR** heeft gekozen, niet SPR-hybride zoals eerder aangenomen. SSPF heeft wel een collectieve toedelingskring binnen FPR met 5-jaars demping; dat is structureel FPR, niet SPR. De regeling-selector blijft drie opties omvatten omdat andere fondsen (ABP) wel SPR kiezen en die ook door de engine moeten worden ondersteund.

**Status regeling-selector in UI (R9.30):** de pill naast scherm-titels toont de actieve regeling (in Fase A altijd `FPR` uit `FONDS_DATASET.regeling`). Dropdown-versie komt in Fase B.

---

## SLIDER-CONVENTIES (bijgewerkt, bijstort toegevoegd)

- `verw-sl-proj`: 0-4%, step 0.25, value 2%, midpoint 2%
- `verw-sl-rend`: 0-8%, step 0.25, value 4%, midpoint 4%
- `verw-sl-vola`: 0-25%, step 0.5, value 10%, midpoint 12,5%, display fmtNL1
- `verw-sl-demp`: 0-10 jr, step 1, value 0
- `verw-sl-inf`: 0-8%, step 0.25, value 2.5%, midpoint 4%
- `verw-sl-buffer`: 0-3000 mln, step 50, value 0
- `ppk-sl-bijstort`: nieuw in dataset (`fondsbalans.bijstort`, placeholder 500 mln)

Middenlabels staan op wiskundig midpoint, niet default-waarde. Dataset-defaults overschrijven slider-defaults bij init.

---

## KLEURCODERING (onveranderd)

- **Groen**: waardes uit Pensioenpotje-scherm (potje, buffer)
- **Blauw**: FPR-uitkering (grafiek-lijn, KPI's, U₀)
- **Rood**: huidig pensioen (benchmark)

Opbouw-kaart: groen (potje) → blauw (U₀) = conversie-visualisatie.

---

## VOLGENDE STAPPEN — DRIE SPOREN

Fase A is afgerond. De volgende sessie kiest uit drie niet-exclusieve sporen. Geen aanbeveling; Hans kiest.

### Spoor 1: Fase B starten — SPR-clean implementeren

Eerste regeling-variant naast FPR. Raakt `verwSimulate` (nieuwe inner-loop-variant), regeling-selector (dropdown werkend maken), validator (per-regeling verplichte velden al gespecificeerd in SCHEMA v1 sectie 6.2). Geeft de engine zijn eerste rechtstreekse dataset-reads via `beleid.RDR_initieel`, `beleid.invaardatum`, etc.

Alternatief binnen spoor 1: **SPR-hybride direct** als SSPF-context dichterbij staat dan generiek SPR. Vult ook `reserveringenFaseB`-velden.

### Spoor 2: SSPF-publiek-v1 data-curatie

Placeholder-waarden (135% DG, 25 mrd, `grijzend` preset) vervangen door echte SSPF-cijfers per eind 2024 (129% DG, 27,2 mrd, RDR 500 mln enz.). Herkomst-entries migreren van alle-`reconstructie` naar de feitelijke tier-tabel uit SCHEMA v1 sectie 5 (overwegend `publiek` + een paar `afgeleid`/`reconstructie`). Inclusief oplossen van pending sub-vraag over `grijzend`-aging.

Regressie-scenario verandert hiermee van U₀ ≈ €128k (placeholder) naar een nieuwe SSPF-gebaseerde basislijn. Dit is **data-werk**, geen architectuur-werk.

### Spoor 3: R9.30+-polish / backlog

Openstaande items uit de R9.22/R9.23-backlog (zie hieronder). Geen van deze is blocker; goed werk als warming-up of tussen de zwaardere sporen door.

Alternatief binnen spoor 3: **benchmark FPR-simulatie** tegen Implementatieplan p.115-124 ALM-uitkomsten (netto profijt + pensioenverwachtingen voor DG-scenario's 125%/127,5%/137,5%). Sanity-check op de eigen simulatie-uitkomsten, nuttig als validatie en als marketing-materiaal.

---

## BACKLOG — STAND

Niet-verifieerbaar of afgehandeld in R9.24-R9.30 (geen expliciete commentaar-tags gevonden); als ongewijzigd behandeld t.o.v. R9.23-HANDOFF:

### Nog open
- **B1**: ppk N>0 guard
- **B3**: percentile floor
- **C1/C2**: CSS duplicaten (CSS is wel gegroeid — opschoning kan nuttig zijn)
- **X1-X4**: accessibility (role=dialog, aria-modal) — help-overlay heeft al `role="dialog" aria-modal="true"` (regel 2562), rest niet gecheckt
- **P1**: Chart.js update() ipv destroy — destroy-calls nog aanwezig op 4231, 4232, 4303, 4361, 5920
- **P2**: debounce MC
- **Q1**: unicode apostrof
- **V1**: demografie bound edge cases
- Soft-warnings onrealistische rente-combinaties
- Open beslispunt R8.10: dubbele "Totaal: X deelnemers" weergave
- Buffer-trigger `effR < inf` herzien bij opt-in buffer-herontwerp (`effR < proj + inf` zuiverder)

### Opgeloste items in R9.29 (wél verifieerbaar uit commentaar)
- Buffer-kaart niet meer verbergen bij buffer=0 op scherm 3 (regel 5722-5726) — conflicteerde met reset-knop en verborg ook de uitleg-tekst

### Nieuwe items uit Fase A
- Preset-naam validatie in validator oplossen (hoisting) — Fase B bij SSPF-publiek-v1
- Pending sub-vraag `grijzend`-aging-methode — Fase B
- `FONDS_DATASET` serialiseren naar JSON-bestand voor multi-dataset distributie — Fase C

### Vervallen
- ~~Engine-migratie naar FONDS_DATASET-reads~~ — expliciet als niet-nodig geclassificeerd, zie sectie "Engine-migratie — bewust niet gedaan"

---

## SSPF-CONTEXT VOOR FASE B (onveranderd)

De regeling-keuze staat **definitief vast per Implementatieplan 15-7-2025**: SSPF kiest FPR. Binnen FPR heeft SSPF een **collectieve toedelingskring** voor variabele uitkeringen, met:

- 5-jaars demping van resultaten (publiek, dataset-veld `beleid.dempingJaren`)
- RDR €500 mln initieel, max 2,5% (publiek, dataset-veld `beleid.RDR_initieel` / `RDR_max_pct`)
- 3 lifecycles opbouwfase (offensief/neutraal/defensief)
- Invaardatum 1-1-2027, min invaarDG 125%
- Compensatiedepot €400 mln voor afschaffing doorsneesystematiek
- Transitiebijdrage werkgever dekkingsgraadafhankelijk: €500/650/850 mln
- Noodprotocol bij DG <125% in Q3 2026 (kan leiden tot hard sluiten en overgang actieven naar SNPS)
- Norm kortingskans gepensioneerden: gemiddeld <5% over eerste 15 jaar

Voor SPR-implementatie in Fase B blijft relevant — ABP en andere fondsen kiezen wel SPR — maar niet voor SSPF-publiek-v1. De engine moet beide regelingen ondersteunen; de SSPF-publiek-v1 dataset gebruikt alleen `regeling: 'FPR'`.

---

## WERKAFSPRAKEN (onveranderd)

- Nederlandse communicatie, technisch maar toegankelijk
- Elke wijziging: JS parse-check, version bump, output-save met timestamp-filename (DD-MM-YYYY_HHMM.html), present_files
- Eerst lezen, dan denken, dan voorstellen — geen grote veranderingen zonder akkoord
- Bij beslissingen met impact: korte analyse + opties met pro/con + aanbeveling, wachten op go
- Release-nummers vanaf R9.31 verder tellen
- Tijdstamp via `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`
- File-output: `/mnt/user-data/outputs/DD-MM-YYYY_HHMM.html`

---

## HOE VERDER TE GAAN

In een nieuwe chat:

1. Plak de prompt uit `HANDOFF_PROMPT.md` (indien nog gebruikt)
2. Upload:
   - `21-04-2026_2216.html` (werkbestand R9.30)
   - `HANDOFF_R9.30.md` (dit document)
   - `STRATEGY_R9.30.md` (bijgewerkte strategie)
   - `SCHEMA_v1.md` (onveranderd — nog steeds het canonieke schema-referentiedocument)
3. Eerste werksessie: kies een spoor uit "Volgende stappen" en bespreek scope voordat code wijzigt.

De volgende Claude begint niet met "Fase A afmaken" — Fase A is af. De vraag is welk Fase-B-spoor (of polish-spoor) eerst komt.
