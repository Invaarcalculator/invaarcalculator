# WTP-PENSIOENCALCULATOR — STRATEGIE R9.30

Datum: 22-04-2026 21:15
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Status: Fase A voltooid (R9.24-R9.30) — Fase B-spoorkeuze open voor volgende sessie

Dit document vangt de strategische richting die in de R9.22-sessie is vastgesteld, in de R9.23-voorbereidingssessie is aangescherpt op schema-ontwerp, en in de uitvoeringsronde R9.24-R9.30 tot werkende Fase-A-infrastructuur heeft geleid. Het vervangt `STRATEGY_R9.23.md`. De technische status staat in `HANDOFF_R9.30.md`. Het dataset-schema staat uitgewerkt in `SCHEMA_v1.md` en is **ongewijzigd** gebleven — het is precies zoals beschreven geïmplementeerd.

---

## DE DRIE SPANNINGEN (onveranderd)

In R9.22 zijn drie fundamentele spanningen in het ontwerp expliciet gemaakt:

**1. Verkenner versus Rekenmachine.** Hoe meer invoer de tool vraagt, hoe meer de gebruiker gelooft dat de uitkomst *zijn getal* is — maar voor een eerlijke individuele raming is veel fondsdata nodig die de gebruiker niet heeft. De tool zat op een ongemakkelijk middelpunt: genoeg sliders om rekenmachine te lijken, maar genoeg benaderingen om dat niet echt te zijn.

**2. Rijk standaardscherm versus Minimaal met drill-down.** Veel standaardcontent schakelt doorklikken uit; weinig content laat gebruikers afhaken voor ze de diepte zien. De deepdive-ontdekbaarheid is een symptoom hiervan.

**3. Generiek versus Fondsspecifiek.** Parameters die alleen zin hebben voor specifieke fondsen (DG, demografie, compensatiedepot) werden generiek behandeld. Dit creëerde de "bron 2"-divergentie die in R9.21/R9.22 werd opgelost via gebruikersconsistentie — maar de onderliggende spanning bleef.

---

## DE SCOPE-BESLISSING — ROUTE S-MINUS (onveranderd)

Na verkenning van scope-niveaus van "Hans-only" tot "iedereen + fondsbesturen" is gekozen voor **Route S-minus**:

> **Doelgroep:** SSPF-gepensioneerden, leeftijd 65-100.
> **Uitgesloten:** andere fondsen (voorlopig), slapers, actieven, fondsbestuurders.
> **Bron:** de tool bestaat omdat SSPF niet transparant is; deze oorsprong wordt de positionering.

Dit lost de drie spanningen in één klap grotendeels op:
- De verkenner-rekenmachine-spanning verdwijnt omdat SSPF-parameters bekende feiten worden
- Het rijk-versus-minimaal-dilemma krimpt omdat minder generieke sliders nodig zijn
- De generiek-specifieke spanning wordt een *feature*: de tool is expliciet SSPF-specifiek

**Niet-gekozen opties en waarom niet:**
- *Niveau 2 (NL-breed benaderend)*: behoudt rekenmachine-pretentie zonder de data om die te dragen
- *Niveau 3/4 (slapers/actieven)*: fundamenteel andere vragen, andere wiskunde, andere UX
- *Niveau 5 (bestuur/beleid)*: heel ander product, heel andere UI

---

## DE PRODUCT-STRATEGIE — TWEE PRODUCTEN, ÉÉN ENGINE (onveranderd)

De inzicht dat tool = engine + dataset leidt tot een productstrategie met **twee producten** op dezelfde engine:

| | Publiek-SSPF (gratis) | Fonds-licentie (commercieel) |
|---|---|---|
| **Wie maakt 't** | Hans | Het fonds zelf |
| **Data-bron** | Publieke SSPF-rapportage | Interne fondsdata |
| **Doel** | Verkennen waar fondstransparantie tekortschiet | Transparantie bieden aan deelnemers |
| **Waarde** | Deelnemers begrijpen SSPF ruwweg | Deelnemers zien hun eigen positie |
| **Business** | Gratis, missie-gedreven | Licentie/abonnement |

**Waarom dit een markt kan zijn:**
- Wtp dwingt transparantie af; fondsen bouwen nu ieder hun eigen communicatie
- Zelf bouwen is duur (IT + actuariaat + UX); licentie is een fractie
- Fondsen willen géén simulatie-code zelf onderhouden vanwege aansprakelijkheid
- Jouw edge is SSPF-kritiek: marketing-verhaal voor fondsen die wél open willen zijn

**De SSPF-oorsprong als hefboom:** het verhaal "deze engine ontstond uit roep om transparantie" is een onderscheidende waardepropositie voor fondsen die zich willen positioneren als open.

---

## DE ARCHITECTURALE CONSEQUENTIES — MET IMPLEMENTATIE-STATUS

De twee-producten-strategie legde drie harde eisen op de code. Stand per R9.30:

**1. Dataset-scheiding is niet optioneel. — GEÏMPLEMENTEERD.** Fondsspecifieke data zit in `FONDS_DATASET`, bevroren via `Object.freeze`, apart `<script>`-blok met `data-schema-version="1.0"` vóór het hoofdscript. Validator hard-weigert bij schema-afwijking. Acht top-level blokken conform SCHEMA v1 plus `reserveringenFaseB` voor Fase B.

**2. Engine moet regeling-agnostisch zijn. — STRUCTUUR KLAAR, ALLEEN FPR GEÏMPLEMENTEERD.** Het veld `regeling` staat op top-level van de dataset; validator controleert dat het één van `['FPR', 'SPR-clean', 'SPR-hybride']` is; de regeling-pill in de UI toont de actieve waarde statisch/gedimd met tooltip dat SPR-varianten in Fase B komen. `reserveringenFaseB` reserveert `rtsCurve`, `agHerzienPeriode` en `renteAfdekkingFactor` als `null` — expliciet aanwezig om Fase B-schema-migratie te vermijden.

**3. White-labelbaarheid moet mogelijk gemaakt worden. — ARCHITECTUREEL TOEGELATEN, NIET GEBOUWD.** Het `meta`-blok bevat `fondsnaam`, `versie`, `bron` en `disclaimerTekst`; de dataset-footer leest deze velden. Voor werkelijke white-labeling (kleurenschema, branding per fonds) moet later een tokens-laag erbij; de huidige hardgecodeerde kleuren zijn placeholder. Fase C.

**De onverwachte architecturale bevinding in R9.24-R9.30:** de scheiding tussen engine en dataset is niet zo vlak als oorspronkelijk gedacht. Er is een gelaagdheid ontstaan die pragmatischer en zuiverder is dan een platte refactor:

- **Slider-gedekte fondsvelden**: dataset → slider-init → DOM → engine. De gebruiker kan dataset-waarden tijdelijk overschrijven via de slider; reset-knoppen zetten sliders terug naar dataset-waarden.
- **Niet-slider-gedekte fondsvelden** (RDR, invaardatum, minimaleInvaarDG, sterftekansTabelId): dataset → engine rechtstreeks, zodra Fase-B-code ze gaat lezen.

Dit betekent dat de "engine-migratie" die de R9.23-STRATEGY aankondigde niet nodig is voor slider-gedekte velden (DOM is juist de UI-overschrijflaag die je wil), en automatisch gebeurt voor niet-slider-gedekte velden (die krijgen hun eerste reads pas in Fase B). Zie `HANDOFF_R9.30.md` sectie "Engine-migratie — bewust niet gedaan" voor de volledige redenering.

---

## FASE-ROADMAP — BIJGEWERKT

**Fase A — Fundament (R9.23 → R9.30) — AFGEROND**
- ✓ Dataset-schema ontworpen en tegen SSPF-bronnen getoetst (beslispunt 1, R9.23-voorbereidingssessie)
- ✓ Beslispunten 2-6 in code afgehandeld (R9.24-R9.30)
- ✓ `FONDS_DATASET` geïntroduceerd met Object.freeze + parallel herkomst-blok
- ✓ Validator conform SCHEMA v1 sectie 6 (hard-fail mode)
- ✓ `applyDatasetDefaults` + reset-knoppen per scherm (zichtbaar bewijs dat dataset bron-van-waarheid is)
- ✓ Dataset-footer voor audit-traceerbaarheid op elke screenshot
- ✓ Regeling-pill naast scherm-titel (statisch in Fase A, dropdown in Fase B)
- ✓ Placeholder-waarden = oude tool-defaults; regressie-scenario intact (Hans' 100k/135%/70 → U₀ ≈ €128k)
- ✗ Engine-migratie — expliciet als niet-nodig geclassificeerd (zie architecturale consequenties)
- ✗ SSPF-publiek-v1 data-curatie — naar Fase B verschoven
- ✗ SPR-regelingen — naar Fase B verschoven

**Fase B — Compleetheid (R9.31 → ongeveer R9.40)** — *de volgende sessie start hier*

Drie mogelijke startpunten, niet-exclusief:

1. **SPR-clean implementeren** naast FPR. Nieuwe inner-loop-variant in `verwSimulate`, regeling-selector dropdown werkend maken, validator-scope per regeling activeren. Eerste rechtstreekse dataset-reads van `beleid.RDR_initieel` / `RDR_max_pct` / `invaardatum` / `minimaleInvaarDG`.

2. **SPR-hybride direct** (in plaats van of na SPR-clean). Vult `reserveringenFaseB`-velden: `rtsCurve` (rentetermijnstructuur), `agHerzienPeriode` (elke 2 jaar in SSPF-context), `renteAfdekkingFactor`. Aangezien SSPF zelf FPR heeft gekozen niet SPR, is deze route generiek-fonds-gedreven, niet SSPF-gedreven.

3. **SSPF-publiek-v1 data-curatie**. Placeholder-waarden (135% DG, 25 mrd, `grijzend` preset) vervangen door echte SSPF-cijfers per eind 2024. Herkomst-entries migreren van alle-`reconstructie` naar de feitelijke tier-tabel uit SCHEMA v1 sectie 5. Pending sub-vraag `grijzend`-aging oplossen. Regressie-scenario krijgt een nieuwe basislijn.

**Fase C — Verkoopbaarheid (R10.0+)** (onveranderd)
- White-label configuratie (fondsnaam, kleuren, terminologie via dataset)
- Dataset-SDK: schema-validator, voorbeelden, documentatie
- Juridische disclaimer-per-dataset
- Pakketdistributie-mechanisme (upload, signed datasets, of server-fetch)
- Demo-datasets voor prospects

**Fase D — Markt (parallel aan C)** (onveranderd)
- Positionering, website-narratief, casestudy's
- Eerste gesprekken met kleine-middelgrote fondsen
- Pilot met een eerste fonds

---

## WAT FASE B FEITELIJK GAAT INHOUDEN

Nu Fase A draait, kan Fase B scherper worden omschreven dan in de R9.23-STRATEGY. Twee soorten werk zijn te onderscheiden:

### Architectuur-werk: nieuwe regelingen

Elke regeling-implementatie is additief. De bestaande FPR-code blijft intact; SPR-clean en SPR-hybride worden alternatieve inner-loops binnen `verwSimulate`. De regeling-selector (nu een statische pill) wordt een dropdown die het actieve dataset-veld `regeling` live kan schakelen — maar dan moet óf de hele dataset herladen worden, óf de engine moet per-regeling-velden lazy lezen. Dat is een Fase B sub-beslispunt.

Nieuwe engine-reads die hierbij voor het eerst rechtstreeks uit `FONDS_DATASET` komen:

- `beleid.RDR_initieel` en `RDR_max_pct` — voor RDR-toedelingslogica
- `beleid.invaardatum` en `minimaleInvaarDG` — voor invaartoets-simulatie
- `reserveringenFaseB.agHerzienPeriode` — voor AG-sterftetafel-updates in SPR-hybride
- `reserveringenFaseB.rtsCurve` en `renteAfdekkingFactor` — voor SPR-hybride noemer-update

Dit is de gelegenheid om de "slechte refactor"-valkuil te vermijden: nieuwe code schrijft rechtstreeks uit `FONDS_DATASET`, niet nieuwe DOM-sliders en niet nieuwe hardgecodeerde constanten. Een code-review-afspraak, geen architectuur-stap.

### Data-werk: SSPF-publiek-v1

Dit is puur content, geen code. De placeholder-waarden worden vervangen door echte cijfers; de 26 herkomst-entries worden bijgewerkt van alle-`reconstructie` naar de feitelijke tier-tabel (overwegend `publiek` voor fondsbalans en Wtp-parameters, `afgeleid` voor demografie-aging, `reconstructie` voor forward-looking simulatie-parameters).

Bij dit werk wordt ook de pending sub-vraag over `grijzend`-aging opgelost: welke exacte methode is gebruikt, en is de bar-chart in Transitieplan Bijlage 8 de enige bron of staat er ergens een cijferreeks? Antwoord komt in de `methode`-string van de herkomst-entry.

Benchmark-optie: na samenstellen van SSPF-publiek-v1 kun je de tool-uitkomsten vergelijken met Implementatieplan p.115-124 ALM-uitkomsten (netto profijt + pensioenverwachtingen per leeftijd voor DG-scenario's 125%/127,5%/137,5%). Reality-check op de eigen simulatie, nuttig als validatie en als marketing-materiaal.

---

## OPEN BESLISPUNTEN — ALLE ZES AFGEROND

De R9.23-STRATEGY hield zes beslispunten open (1: schema, en 2-6 aan begin van de R9.23-sessie). Stand per R9.30:

**~~1. Schema-diepte — welke velden komen in versie 1?~~** **AFGEROND (R9.23-voorbereidingssessie).** Zie `SCHEMA_v1.md`.

**~~2. Dataset-locatie in code.~~** **AFGEROND.** Aparte `<script id="fonds-dataset" data-schema-version="1.0">`-tag vóór hoofdscript.

**~~3. Grensgevallen — welke parameters "dataset-default, UI-overschrijfbaar"-status?~~** **AFGEROND.** Alle parameters met én dataset-vermelding én slider. Reset-knoppen per scherm maken dit expliciet voor de gebruiker.

**~~4. Validator-striktheid.~~** **AFGEROND.** Hard weigeren — body-replace met foutmelding, Error gegooid. Geen fallback.

**~~5. UI-zichtbaarheid dataset-metadata.~~** **AFGEROND.** Permanente footer-bar onder elke pagina, met disclaimer achter `i`-icoon.

**~~6. Regeling-selector UI-plaats.~~** **AFGEROND.** Derde weg: pill naast scherm-titel op scherm 2 én scherm 3.

### Nieuwe open vragen voor de volgende sessie

1. **Welk Fase-B-spoor start eerst?** SPR-clean, SPR-hybride, SSPF-publiek-v1 data-curatie, of een polish-ronde op de openstaande backlog?
2. **SPR-implementatie-scope**: gaan we clean en hybride in één sessie-serie doen, of clean eerst compleet afmaken voor hybride begint?
3. **Live-schakelen regeling**: wordt de regeling-dropdown in Fase B een live-switcher (dataset wisselt runtime) of een load-time-keuze (page reload)? Architectureel verschil in how het `FONDS_DATASET`-object wordt beheerd.
4. **Pending sub-vraag `grijzend`-aging**: wanneer oplossen — bij data-curatie, of eerder als losse research-sessie?
5. **Benchmark ALM-uitkomsten**: wanneer plannen — direct na SSPF-publiek-v1, of later als polish?

---

## WAT DIT BETEKENT VOOR DE BACKLOG

De R9.23-backlog is herzien per Fase-afronding:

### Blijven relevant (Fase B/polish)
- B1, B3 (ppk/percentile guards)
- C1/C2 (CSS duplicaten — CSS is gegroeid met footer + pill + reset-btn, opschoning kan nuttig zijn)
- X1-X4 (accessibility — help-overlay heeft al `role="dialog" aria-modal="true"`, rest nog te checken)
- P1, P2 (Chart.js update() ipv destroy, debounce MC)
- Q1, V1 (unicode apostrof, demografie bound edge cases)
- Soft-warnings onrealistische rente-combinaties
- Open R8.10 (dubbele "Totaal: X deelnemers")
- Buffer-trigger `effR < inf` herzien

### Toegevoegd uit Fase A
- Preset-naam validatie in validator (hoisting-limitatie) — bij SSPF-publiek-v1
- Pending sub-vraag `grijzend`-aging — Fase B data-curatie
- `FONDS_DATASET` serialiseren naar apart JSON-bestand voor multi-dataset distributie — Fase C
- CSS-opschoning na R9.26 footer-toevoeging — optioneel

### Vervallen
- ~~Engine-migratie naar `FONDS_DATASET`-reads~~ — expliciet geclassificeerd als niet-nodig, zie `HANDOFF_R9.30.md`

### Onveranderd vervallen uit R9.23
- ~~Pad 2 (binnen-cohort percentiel)~~ — minder urgent onder S-minus
- ~~Toggle individueel/fonds~~ — gebruikersconsistentie is enige modus
- ~~Drie-modi-framing~~ — vereenvoudigd naar twee modi: "verken dataset" (default-waarden) en "speel met parameters" (alles overschrijfbaar via sliders)

---

## HOE DIT DOOR TE DRAGEN

De volgende sessie:

1. Plak de prompt uit `HANDOFF_PROMPT.md` in een nieuwe chat (indien nog gebruikt)
2. Upload:
   - `21-04-2026_2216.html` (werkbestand R9.30)
   - `HANDOFF_R9.30.md` (technische stand)
   - `STRATEGY_R9.30.md` (dit document)
   - `SCHEMA_v1.md` (ongewijzigd — canoniek schema)
3. Eerste werksessie: kies een Fase B-spoor uit de lijst hierboven, bespreek scope voordat code wijzigt.

De volgende Claude begint niet met "Fase A afmaken" — Fase A is af. De vraag is welk Fase-B-spoor (of polish-ronde) eerst komt.

---

## KERNWAARDEN DIE WE VASTHOUDEN (onveranderd)

1. **Eerlijke positionering** — de tool is een verkenner, niet een rekenmachine
2. **Gebruikersconsistentie** — individuele uitkomsten zijn functies van eigen KV, niet fondsgeschaald
3. **Transparantie als oorsprong** — waarom de tool bestaat is ook waarom hij verkoopbaar kan worden
4. **Architecturale discipline** — geen premature optimization, wel toekomstopties openhouden. R9.24-R9.30 bewezen dat dit pragmatisch mag zijn: niet alles wat "een refactor" lijkt is er ook een.
5. **Nederlandse taal, technisch maar toegankelijk** — blijft de werkafspraak
