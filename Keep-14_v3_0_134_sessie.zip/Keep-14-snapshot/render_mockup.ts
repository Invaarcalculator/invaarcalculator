/**
 * Mockup-renderer — genereert statische HTML uit SCHEMA-metadata.
 *
 * Doel: laten zien dat `display`- en `uiDisclosure`-metadata voldoende zijn
 * om zowel een casual-scherm (scherm 1) als een audit-scherm-sectie (M1)
 * mechanisch te renderen — géén handmatige veld-lijsten.
 *
 * NB: dit is geen UI-ontwerp. Layout/copy/toegankelijkheid komen later.
 */

import { z } from 'zod'
import {
  M1,
  FIELD_REGISTRY,
  fieldsByDisplay,
  type FieldMeta,
} from './schema.v2'

// ============================================================================
// Schema-inspectie: haal veld-definities uit Zod-objects via .shape
// ============================================================================

type FieldInfo = {
  name: string              // 'x0', 'pen', enz.
  path: string              // 'M1.deelnemer.x0'
  meta: FieldMeta
  typeLabel: string         // 'getal', 'ja/nee', 'M | V | gemengd'
  default?: unknown
  description: string       // uit .describe()
  nullable: boolean
}

function describeZodType(schema: z.ZodTypeAny): string {
  // Unwrap optional/default/nullable om de kern-type te vinden
  let inner: z.ZodTypeAny = schema
  while (
    inner instanceof z.ZodOptional ||
    inner instanceof z.ZodDefault ||
    inner instanceof z.ZodNullable
  ) {
    inner = inner._def.innerType
  }
  if (inner instanceof z.ZodNumber) return 'getal'
  if (inner instanceof z.ZodBoolean) return 'ja/nee'
  if (inner instanceof z.ZodString) return 'tekst'
  if (inner instanceof z.ZodEnum) return inner._def.values.join(' | ')
  if (inner instanceof z.ZodUnion) {
    return inner._def.options
      .map((o: z.ZodTypeAny) => describeZodType(o))
      .join(' | ')
  }
  if (inner instanceof z.ZodLiteral) return String(inner._def.value)
  return inner._def.typeName ?? 'onbekend'
}

function getDefault(schema: z.ZodTypeAny): unknown {
  let inner: z.ZodTypeAny = schema
  while (inner instanceof z.ZodOptional || inner instanceof z.ZodNullable) {
    inner = inner._def.innerType
  }
  if (inner instanceof z.ZodDefault) {
    const def = inner._def.defaultValue
    return typeof def === 'function' ? def() : def
  }
  return undefined
}

function isNullable(schema: z.ZodTypeAny): boolean {
  let inner: z.ZodTypeAny = schema
  while (inner instanceof z.ZodOptional || inner instanceof z.ZodDefault) {
    inner = inner._def.innerType
  }
  return inner instanceof z.ZodNullable
}

function collectFields(
  zodObj: z.ZodObject<z.ZodRawShape> | z.ZodEffects<z.ZodObject<z.ZodRawShape>>,
  pathPrefix: string
): FieldInfo[] {
  const obj =
    zodObj instanceof z.ZodEffects ? (zodObj.innerType() as z.ZodObject<z.ZodRawShape>) : zodObj
  const shape = obj.shape
  const out: FieldInfo[] = []
  for (const [name, fieldSchema] of Object.entries(shape)) {
    const fullPath = `${pathPrefix}.${name}`
    const reg = FIELD_REGISTRY.find((f) => f.path === fullPath)
    if (!reg) continue
    out.push({
      name,
      path: fullPath,
      meta: reg.meta,
      typeLabel: describeZodType(fieldSchema as z.ZodTypeAny),
      default: getDefault(fieldSchema as z.ZodTypeAny),
      description: (fieldSchema as z.ZodTypeAny)._def.description ?? '',
      nullable: isNullable(fieldSchema as z.ZodTypeAny),
    })
  }
  return out
}

// ============================================================================
// Renderers
// ============================================================================

const LABEL_MAP: Record<string, string> = {
  x0: 'Uw leeftijd',
  pen: 'Jaarlijks bruto ouderdomspensioen (€)',
  g: 'Uw geslacht',
  t0: 'Peildatum (jaar)',
  heeftPartner: 'Partnerpensioen van toepassing?',
  y0: 'Jaarlijks bruto nabestaandenpensioen (€)',
  x_partner: 'Leeftijd partner',
  g_y: 'Geslacht partner',
}

const OUTPUT_LABEL_MAP: Record<string, string> = {
  KV: 'Huidige waarde van uw aanspraak',
  KV_OP: '  waarvan eigen ouderdomspensioen',
  KV_NP: '  waarvan nabestaandenpensioen',
  a_x0: 'Annuïteitsfactor deelnemer ä(x₀, r)',
  a_partner: 'Annuïteitsfactor partner ä(x_partner, r)',
  lifeExp_x0: 'Verwachte sterfleeftijd deelnemer',
  lifeExp_partner: 'Verwachte sterfleeftijd partner',
  rho_effectief: 'Effectieve kostenopslag ρ',
}

// Mock M1-berekening voor tonen demo-resultaat (niet de echte engine)
function mockComputeM1(
  deelnemer: { x0: number; pen: number; heeftPartner: boolean; y0: number | null; x_partner: number | null },
  r: number
): { KV: number; KV_OP: number; KV_NP: number; a_x0: number; a_partner: number | null; lifeExp_x0: number; lifeExp_partner: number | null; rho_effectief: number } {
  // Schatting annuïteitsfactor via levensverwachting (puur indicatief voor mockup)
  const est_ax = (x: number) => {
    const lifeExp = 85 - (x - 65) * 0.3
    const years = Math.max(0, lifeExp - x)
    // Simpele arrears-annuïteit benadering
    let a = 0
    for (let k = 1; k <= years * 12; k++) {
      a += Math.pow(1 + r, -k / 12)
    }
    return a / 12
  }
  const rho = 0.02 // ultieme default
  const a_x0 = est_ax(deelnemer.x0)
  const KV_OP = (1 + rho) * deelnemer.pen * a_x0
  const a_partner =
    deelnemer.heeftPartner && deelnemer.x_partner !== null ? est_ax(deelnemer.x_partner) : null
  const y0_eff =
    deelnemer.heeftPartner && deelnemer.y0 !== null
      ? deelnemer.y0
      : deelnemer.heeftPartner
        ? 0.7 * deelnemer.pen
        : 0
  const KV_NP = a_partner !== null ? (1 + rho) * y0_eff * a_partner : 0
  return {
    KV: KV_OP + KV_NP,
    KV_OP,
    KV_NP,
    a_x0,
    a_partner,
    lifeExp_x0: 85 - (deelnemer.x0 - 65) * 0.3,
    lifeExp_partner:
      deelnemer.heeftPartner && deelnemer.x_partner !== null
        ? 85 - (deelnemer.x_partner - 65) * 0.3
        : null,
    rho_effectief: rho,
  }
}

function renderInput(f: FieldInfo): string {
  const label = LABEL_MAP[f.name] ?? f.name
  const id = `f-${f.name}`
  let control: string
  if (f.typeLabel === 'ja/nee') {
    const checked = f.default === true ? 'checked' : ''
    control = `<input type="checkbox" id="${id}" ${checked}>`
  } else if (f.typeLabel.includes(' | ')) {
    const opts = f.typeLabel.split(' | ')
    control = `<select id="${id}">${opts
      .map((o) => `<option ${o === f.default ? 'selected' : ''}>${o}</option>`)
      .join('')}</select>`
  } else if (f.typeLabel === 'getal') {
    const val = f.default !== undefined && f.default !== null ? f.default : ''
    control = `<input type="number" id="${id}" value="${val}" ${f.nullable ? 'placeholder="optioneel"' : ''}>`
  } else {
    control = `<input type="text" id="${id}" value="${f.default ?? ''}">`
  }
  const disclosure = f.meta.uiDisclosure
    ? `<div class="disclosure">⚠ ${f.meta.uiDisclosure}</div>`
    : ''
  return `<div class="field">
    <label for="${id}">${label}</label>
    ${control}
    ${disclosure}
  </div>`
}

function renderOutputRow(name: string, value: unknown, meta: FieldMeta): string {
  const label = OUTPUT_LABEL_MAP[name] ?? name
  const formatted =
    typeof value === 'number'
      ? name.startsWith('KV')
        ? '€ ' + value.toLocaleString('nl-NL', { maximumFractionDigits: 0 })
        : value.toLocaleString('nl-NL', { maximumFractionDigits: 2 })
      : value === null
        ? '—'
        : String(value)
  const disclosureMark = meta.uiDisclosure ? ' <span class="info" title="' + meta.uiDisclosure.replace(/"/g, '&quot;') + '">ⓘ</span>' : ''
  return `<tr class="display-${meta.display}"><td>${label}${disclosureMark}</td><td class="num">${formatted}</td></tr>`
}

// ============================================================================
// Build the HTML
// ============================================================================

const deelnemerFields = collectFields(M1.deelnemer, 'M1.deelnemer')
const parametersetFields = collectFields(M1.parameterset, 'M1.parameterset')
const outputFields = collectFields(M1.output, 'M1.output')

// Demo-waardes voor output-tabel
const demo = {
  deelnemer: { x0: 67, pen: 30000, heeftPartner: true, y0: 21000, x_partner: 65 },
  r: 0.02,
}
const demoOut = mockComputeM1(demo.deelnemer, demo.r)

// --- Casual scherm 1 ---
const casualInputs = deelnemerFields
  .filter((f) => f.meta.display === 'hoofdpad')
  .map(renderInput)
  .join('\n')

const casualOutputRow = (fieldName: keyof typeof demoOut) => {
  const f = outputFields.find((x) => x.name === fieldName)
  if (!f || f.meta.display !== 'hoofdpad') return ''
  return renderOutputRow(fieldName, demoOut[fieldName], f.meta)
}

// --- Audit-scherm M1-sectie ---
const auditDecomposition = outputFields
  .filter((f) => ['decompositie', 'deepdive', 'diagnose'].includes(f.meta.display))
  .map((f) => renderOutputRow(f.name, (demoOut as Record<string, unknown>)[f.name], f.meta))
  .join('\n')

const auditParameters = parametersetFields
  .map((f) => {
    const disclosure = f.meta.uiDisclosure
      ? `<div class="disclosure-inline">⚠ ${f.meta.uiDisclosure}</div>`
      : ''
    const defStr = f.default === null ? '(geen)' : f.default !== undefined ? String(f.default) : '—'
    return `<tr>
      <td><code>${f.name}</code></td>
      <td>${f.typeLabel}</td>
      <td>${defStr}</td>
      <td><span class="specref">${f.meta.specRef}</span></td>
      <td>${f.description}${disclosure}</td>
    </tr>`
  })
  .join('\n')

// Ook hoofdpad-velden uit deelnemer die disclosure hebben (bijv. t0)
const deelnemerMetDisclosure = deelnemerFields.filter(
  (f) => f.meta.uiDisclosure && f.meta.display === 'parameter-audit'
)

const html = `<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<title>WTP-calculator — mockup uit SCHEMA v2</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, system-ui, sans-serif; max-width: 960px; margin: 2em auto; padding: 0 1em; color: #222; line-height: 1.5; }
  h1 { font-size: 1.4em; margin-top: 0; }
  h2 { font-size: 1.15em; border-bottom: 2px solid #333; padding-bottom: .3em; margin-top: 2em; }
  h3 { font-size: 1em; color: #555; margin-top: 1.5em; }
  .pane { border: 1px solid #ccc; padding: 1.2em 1.4em; margin: 1em 0; background: #fafafa; border-radius: 4px; }
  .pane.casual { background: #f0f6ff; border-color: #4a7bc8; }
  .pane.audit { background: #fff8e8; border-color: #c8994a; }
  .field { display: grid; grid-template-columns: 240px 1fr; gap: .7em; align-items: center; margin-bottom: .6em; }
  .field label { font-size: .92em; }
  .field input, .field select { padding: .35em .5em; font-size: .92em; border: 1px solid #999; border-radius: 3px; }
  .field input[type="checkbox"] { justify-self: start; }
  .disclosure { grid-column: 2; font-size: .8em; color: #886600; background: #fff8e0; padding: .3em .5em; border-left: 3px solid #c8994a; margin-top: .3em; }
  .disclosure-inline { font-size: .85em; color: #886600; margin-top: .3em; padding: .3em .5em; background: #fff8e0; border-left: 3px solid #c8994a; }
  table { border-collapse: collapse; width: 100%; margin-top: .5em; font-size: .92em; }
  th, td { border: 1px solid #ddd; padding: .45em .7em; text-align: left; vertical-align: top; }
  th { background: #eee; font-weight: 600; }
  td.num { text-align: right; font-variant-numeric: tabular-nums; font-family: monospace; }
  tr.display-decompositie td { background: #fafafa; }
  tr.display-deepdive td { background: #f2f2f2; color: #666; }
  tr.display-diagnose td { background: #fff0f0; color: #884444; }
  .specref { font-family: monospace; font-size: .82em; color: #666; }
  code { font-family: monospace; background: #eee; padding: 1px 4px; border-radius: 2px; font-size: .88em; }
  .info { cursor: help; color: #c8994a; font-size: .9em; }
  .meta-note { font-size: .82em; color: #666; margin-top: 1em; border-top: 1px dashed #ccc; padding-top: .8em; }
  .banner { background: #f8f8f8; border-left: 4px solid #4a7bc8; padding: .7em 1em; margin: 1em 0; font-size: .88em; }
  .kpi { font-size: 1.6em; font-weight: 600; color: #004488; }
  .intro { color: #555; font-size: .95em; }
</style>
</head>
<body>

<h1>Mockup uit SCHEMA v2 — <em>geen UI-ontwerp, alleen structuur-toets</em></h1>

<div class="banner">
  Deze pagina is <strong>mechanisch gegenereerd</strong> uit <code>schema.v2.ts</code> via de <code>display</code>- en
  <code>uiDisclosure</code>-metadata. Geen enkel veld is hardcoded in deze renderer — als je een veld toevoegt in SCHEMA, verschijnt het
  automatisch op de juiste plek. Doel: toetsen of de structuur klopt, niet hoe het er uiteindelijk uit moet zien.
</div>

<h2>Scherm 1 — casual (hoofdpad-velden)</h2>

<div class="pane casual">
  <p class="intro">Wat is uw pensioen nu waard?</p>

  <h3>Uw gegevens</h3>
  ${casualInputs}

  <h3>Uitkomst</h3>
  <table>
    ${casualOutputRow('KV')}
  </table>
  <div class="meta-note">
    <em>Alleen de totale huidige waarde staat op het casual-scherm.
    De opsplitsing OP/NP, de annuïteitsfactoren, de levensverwachtingen en de effectieve kostenopslag
    zitten op het audit-scherm (zie onder).</em>
  </div>
</div>

<h2>Audit-scherm — M1-sectie (alle decompositie, deepdive, parameters, diagnose)</h2>

<div class="pane audit">
  <h3>Decompositie + deepdive + diagnose (uit output-contract §2.4)</h3>
  <table>
    <tr><th>Veld</th><th class="num">Waarde</th></tr>
    ${auditDecomposition}
  </table>

  <h3>Parameterset-inzage (§2.3 + §2.7)</h3>
  <table>
    <tr>
      <th>Naam</th>
      <th>Type</th>
      <th>Default</th>
      <th>Spec</th>
      <th>Beschrijving</th>
    </tr>
    ${auditParameters}
  </table>

  ${
    deelnemerMetDisclosure.length > 0
      ? `<h3>Deelnemer-velden met disclosure-eis</h3>
  <table>
    <tr><th>Naam</th><th>Spec</th><th>Disclosure</th></tr>
    ${deelnemerMetDisclosure
      .map(
        (f) => `<tr><td><code>${f.name}</code></td><td><span class="specref">${f.meta.specRef}</span></td><td>${f.meta.uiDisclosure}</td></tr>`
      )
      .join('\n')}
  </table>`
      : ''
  }

  <div class="meta-note">
    <em>Rij-kleuren corresponderen met <code>display</code>-klasse:
    <span style="background:#fafafa;padding:2px 6px">decompositie</span>
    <span style="background:#f2f2f2;padding:2px 6px;color:#666">deepdive</span>
    <span style="background:#fff0f0;padding:2px 6px;color:#884444">diagnose</span></em>
  </div>
</div>

<h2>Wat dit bewijst</h2>
<ul>
  <li><strong>Model D werkt mechanisch.</strong> Eén SCHEMA-definitie voedt twee schermen (casual + audit); geen parallel veld-lijst.</li>
  <li><strong>Disclosures landen automatisch.</strong> De zeven <code>uiDisclosure</code>-velden verschijnen op de juiste plek zonder handmatige keuze.</li>
  <li><strong>Uitbreiding is gratis.</strong> Nieuwe velden in M2/M3/M4 verschijnen bij hun module-sectie zodra hun <code>display</code>-tag gezet is.</li>
  <li><strong>Dit is nog geen UI.</strong> Copy is SCHEMA-ruw, layout is kaal. Echte UI-sessie (toon, interactie, toegankelijkheid, vormgeving) komt later.</li>
</ul>

<div class="meta-note">
  Gegenereerd uit: <code>schema.v2.ts</code> + <code>FIELD_REGISTRY</code>.
  Demo-waardes (x₀=67, pen=30.000, partner x=65, y₀=21.000, r=2%).
  Let op: de KV-berekening in deze mockup is een <em>schatting</em> (vereenvoudigde annuïteit met levensverwachting-proxy),
  niet de echte M1-engine. Die komt in de implementatie-track na SCHEMA v2-voltooiing.
</div>

</body>
</html>`

console.log(html)
