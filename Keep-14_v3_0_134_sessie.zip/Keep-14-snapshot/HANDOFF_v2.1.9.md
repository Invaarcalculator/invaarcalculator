# WTP-PENSIOENCALCULATOR — HANDOFF ENGINE SPEC v2.1.9

Datum: 23-04-2026 17:17
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Licentie: CC BY-NC 4.0

Dit document markeert de afronding van de **scherm-3-spec-sessie** (23-04-2026, middag/avond) en geeft de scherm-4-sessie een schone start. Het bouwt voort op `HANDOFF_v2.1.md` (scherm 1) en `HANDOFF_v2.1.3.md` (scherm 2); alle drie samen beschrijven de stand van zaken voor schermen 1–3.

---

## KERN IN ÉÉN ALINEA

Op 23-04-2026 zijn in deze derde spec-sessie zes scherm-3-besluiten stap-voor-stap genomen en geïmplementeerd via zes patches (v2.1.4 t/m v2.1.9). Een mix van architecturaal (NP-schakel mechaniek), formaliserend (gender M3-doorwerking, plot-horizon UI-laag), en inhoudelijk-met-SSPF-bron-input (BufferTrigger+RDR+demping, lifecycle+μ/σ-concretisering+RTS-distinctie). Drie items bewust geparkeerd voor latere bron-onderzoeks-rondes (RDR-uitputtingsmechaniek, SSPF-correlatie-kalibratie, lifecycle-bundel-activering voor niet-SSPF-Wtp-fondsen). Spec-omvang gegroeid van 1734 naar 1849 regels (+115). Een nieuw architecturaal patroon ontstaan: "gekoppelde v2-paden" als reservering-discipline, drie keer toegepast in scherm 3 (inflatie-stochastiek+correlatie, lifecycle-bundel, parallel aan bestaande SPR-reservering). Scherm 3 is daarmee volledig af en klaar voor uitbreiding naar scherm 4.

---

## STAND VAN ZAKEN — SPEC v2.1.9

**Hoofdbestand:** `ENGINE_SPECIFICATIE_v1.md` (1849 regels).

**Voltooide scherm-3-besluiten (zes, chronologisch):**

| Patch | Punt | Datum | Kern |
|---|---|---|---|
| v2.1.4 | NP-schakel mechaniek (§11.18 follow-up bullet 2) | 15:22 | Optie A: impliciete annuïteit-splitsing. `U₀_OP = ppk_OP / ä(x₀, proj, g)` + `U₀_NP = ppk_NP / ä(x_partner, proj, g_y)` als deepdive; hoofdpad `U₀ = U₀_OP`. Mortality pooling impliciet via beide annuïteiten. Joint-life als v2-reservering. |
| v2.1.5 | Cross-punt 3 — gender in M3 | 15:47 | Optie 1: minimale formaliseringspatch. §4.2/§4.3/§4.6/§4.8 spiegelgelijk getrokken aan §2-administratie van M1. Nieuwe aanname 15. Geen numerieke wijziging. |
| v2.1.6 | §11.6 BufferTrigger + RDR + dempJaren | 16:14 | Vier-delige uitkomst, SSPF-bron: `bufferTrigger='koopkracht'` default (vier enum-waardes); `dempJaren=5` (was placeholder); RDR-terminologie-koppeling; nieuw RDR-uitputtingsmechaniek-reviewpunt geparkeerd. |
| v2.1.7 | §11.7 Correlatie rendement-inflatie | 16:34 | Optie 3: parametrische structuur met expliciete koppeling. `correlatieRenteInflatie` gekoppeld aan nieuw gereserveerd `inflatieStochastiek`-object; beide null in v1, gekoppeld v2-pad. |
| v2.1.8 | §11.8 Lifecycle-rente + μ/σ + RTS-distinctie | 16:55 | Optie 4: vlakke rente met expliciete bundel-koppeling. `μ=4,5%`/`σ=8%` indicatief voor SSPF 60/40-portfolio (was placeholder). Nieuw `rtsCurve`-veld FPR-lifecycle, expliciet onderscheiden van bestaand `RTS` (SPR-rente). Lifecycle-bundel als gekoppeld v2-pad. |
| v2.1.9 | §11.9 Plot-horizon | 17:05 | Optie 4: scheiding berekening (altijd tot ω) en presentatie (UI-cap via `plotHorizonRule`-enum, vier waardes); v1-default `'lifeExpPlus10'`. Geen numerieke wijziging op berekening. |

**Totaal gesloten besluiten over drie sessies:** 21 (12 scherm-1, 3 scherm-2, 6 scherm-3).

**Bewust geparkeerd in scherm-3-sessie:**
- **RDR-uitputtingsmechaniek** (v2.1.6, §4.10). R9.30-implementatie volledig tekort tot bufferbodem; SSPF-design mogelijk anders (plafond, gefasering, prioritering) maar mechanisme onbekend bij Hans. Voor latere bron-onderzoeks-ronde.
- **SSPF-specifieke kalibratie correlatie rendement-inflatie** (v2.1.7, §4.10). DNB-FTK-publicaties, AG-stochastische-set-parameters voor latere bron-ronde.
- **Lifecycle-bundel-activering voor niet-SSPF-Wtp-fondsen** (v2.1.8, §4.10). SSPF heeft geen lifecycles, maar andere Wtp-fondsen wel; spec-structuur klaar, kalibratie voor v2.

---

## ACTIEVE WERKAFSPRAKEN

Behouden uit eerdere sessies, bevestigd werkend in scherm-3-sessie:

1. **Narratief kompas (§1.1)** — drie momenten × vier schermen, ankerfunctie bij identieke aannames. Elke scherm-3-beslissing is hieraan getoetst: v2.1.4 borgt `KV_NP ↔ U₀_NP · ä(partner)`-anker tussen M1 en M3; v2.1.5 maakt spiegelgelijkheid M1↔M3 in audit-context aantoonbaar; v2.1.6 expliciet "indexatie-anker" als rationale voor koopkracht-trigger.

2. **Educatieve leidraad** — verborgen dimensies zichtbaar maken. v2.1.4 maakt latente NP zichtbaar als deepdive zonder MC-vervuiling; v2.1.9 plot-horizon-Optie `'omega'` laat power-users de impliciete-mortality-pooling-aanname (§4.6.5) visueel toetsen.

3. **Spec-met-reserveringen-principe (§12.5)** — v1-defaults reproduceren R9.30-gedrag tenzij expliciete reden tot afwijking. Scherm-3-sessie: alle zes patches respecteren dit principe op default-pad. Indicatieve μ/σ-waardes (v2.1.8) zijn een verfijning (placeholder→bron) zonder gedragswijziging.

4. **Stap-voor-stap-methode** — elk open punt apart, probleem/opties/aanbeveling/besluit/patch, geen bulk. Gewerkt; tempo lag op één besluit per ~10–15 minuten.

5. **SSPF-prior voor fallbacks** — gender-weging 95/5 deelnemer, 5/95 partner-gegeven-M (v1.9). Nieuw in scherm 3: SSPF-portfolio 60/40 matching/rendement-seeking (v2.1.8) als prior voor μ/σ; SSPF-RDR-buffer en 5-jaars-rolling-demping (v2.1.6) als prior voor M3-buffer.

6. **Timestamp-conventie** — `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`. Consequent gehanteerd in alle zes patches.

7. **Bronhoudbaarheid boven snelheid** — placeholders expliciet gelabeld; SSPF-bron-input concretiseert waar mogelijk (v2.1.6 dempJaren, v2.1.8 μ/σ); upgrade-pad open zonder spec-revisie.

8. **Bronnenonderzoek voor normatieve kwesties** — geen normatief-juridische kwesties in scherm 3 (was wel in scherm 2 ppkComp). Wel **SSPF-design-input van Hans** als interne bron expliciet gewaardeerd in v2.1.6 (RDR/demping) en v2.1.8 (60/40-portfolio).

9. **Geen code-wijzigingen aan R9.30-productiebestand vanuit spec-sessie** — alleen spec-doorwerking documenteren. Gerespecteerd. Implementatie-track is een separate sessie.

10. **Patch-administratie-hygiëne** — bij opeenvolgende patches op hetzelfde blok: nooit str_replace op de voorgaande changelog-entry gebruiken als insert-anker; gebruik een stabiele marker (de spec-met-reserveringen-alinea onderaan de metadata) om eronder in te voegen. **Verfijning v2.1.5-leerstof:** bij gebruik van een stabiele anker als insert-punt moet de anker-zin **letterlijk identiek in zowel `old_str` als `new_str`** voorkomen, met de nieuwe content ervóór ingevoegd. In v2.1.5 is deze regel per ongeluk overtreden (anker-zin afgekapt door alleen begin-fragment in `old_str` te zetten), direct opgemerkt en hersteld via terug-edit. In v2.1.6/v2.1.7/v2.1.8/v2.1.9 correct toegepast — geen herhaling. Coherentie-check moet anker-integriteit elke patch verifiëren.

---

## KRITIEKE ARCHITECTUUR — STRUCTUREEL VASTGELEGD

Deze keuzes moeten bij elke volgende sessie paraat zijn. Scherm-3-aanvullingen op de v2.1.3-handoff-lijst zijn **vetgedrukt**.

### Module-structuur

- **M1** = huidige waarde: levert `KV_OP`, `KV_NP`, `KV` totaal + annuïteitsfactoren per leven + levensverwachtingen
- **M2** = potje: levert `ppkBase + ppkSurplus + ppkComp = ppkTotal`, met geoormerkte subcomponenten `ppk_OP` en `ppk_NP` (v2.0)
- **M3** = uitkeringsbenadering: levert pad + onzekerheidsbanden, gebruikt `ppkTotal` (decompositie via `ppk_OP`/`ppk_NP`)
  - **`U₀_OP = ppk_OP / ä(x₀, proj, g)` als hoofdpad; `U₀_NP = ppk_NP / ä(x_partner, proj, g_y)` als deepdive (v2.1.4)**
  - **Mortality pooling impliciet via beide annuïteiten; geen expliciete event-MC (v2.1.4)**
  - **Gender-administratie spiegelgelijk M1↔M3 (v2.1.5)**
  - **Buffer-mechaniek: koopkracht-trigger default, RDR-terminologie, dempJaren=5 SSPF-bron (v2.1.6)**
  - **Inflatie deterministisch in v1; correlatie+stochastiek als gekoppeld v2-pad (v2.1.7)**
  - **Vlakke rente, μ=4,5%/σ=8% indicatief, lifecycle-bundel als gekoppeld v2-pad (v2.1.8)**
  - **Plot-horizon: berekening tot ω, UI-cap via `plotHorizonRule` (v2.1.9)**
- **M4** = waardevergelijking: docx-spec overgenomen, V_DB vs V_Wtp cohort-correct op AG2024; OP/NP-breakdown blijft presentatie-laag in v1 (heroverweging in scherm-4-sessie open punt #8)

### Sterftetafel

Ongewijzigd: AG2024 per geslacht, M1-3 periode-snapshot t₀=2026, M4 cohort, gender verplicht in UI met SSPF-weging 95/5 als fallback. **Scherm-3-bevestiging: spiegelgelijk M1↔M3 (v2.1.5).**

### Rente

Ongewijzigd: één UI-slider (default 2%) voor discontering; ontkoppelings-toggle voor power-user; `μ` apart. **Scherm-3-aanvulling: `μ=0,045` indicatief (SSPF 60/40), `σ=0,08` (v2.1.8). Lifecycle-bundel `proj`/`lifecycle-profiel`/`rtsCurve` als gekoppeld v2-pad voor niet-SSPF-fondsen. RTS-distinctie SPR (`RTS` vector) vs FPR (`rtsCurve` per leeftijd) expliciet.**

### Annuïteitsconventie

Ongewijzigd: uniform arrears m=12 in alle modules.

### NP-regime

Ongewijzigd: NP mee-ingevaren, geoormerkt binnen één persoonlijk pensioenvermogen. **Scherm-3-bevestiging: M3 decompositief in U₀_OP/U₀_NP (v2.1.4); joint-life als v2-reservering parallel aan §2.10/§4.9.**

### Compensatie-regime

- ppkComp volledig naar OP, wettelijk verankerd (art. 150f lid 1 Pw; DNB Q&A juni 2025; FRP 2024/622 Sdu; ABP-transitieplan 2024) — uit v2.1.2
- Aanpalende kwestie bell-curve-toepasbaarheid voor gepensioneerden geparkeerd in §3.10 voor publieke-release-ronde

### Brug M2↔M4

- `phiDerived = ppkTotal / V_x^Wtp_totaal` als één decoratief anker (v2.1.3)
- Geen `phiDerived_OP` of `phiDerived_NP` in v1
- Upgrade-pad component-varianten als M4's OP/NP-breakdown promoveert tot berekeningslaag in v2 (zie scherm-4 open punt #8)

### Buffer (RDR) en demping (nieuw expliciet v2.1.6)

- **`buffer-aandeel` (M2-output → M3-input) = SSPF-RDR-buffer** (Reserve voor Dempings-Reserve), eenmalig vastgesteld bij invaren
- **`bufferTrigger='koopkracht'`** als default (vier enum-waardes voor latere keuze)
- **`dempJaren=5`** SSPF-design (5-jaars rolling, jaarlijks doorschuivend)
- **RDR-uitputtingsmechaniek geparkeerd** voor latere bron-onderzoeks-ronde

### Architecturaal patroon "gekoppelde v2-paden" (nieuw expliciet v2.1.7/v2.1.8)

Drie keer toegepast in scherm 3 als reservering-discipline: twee of meer velden die conceptueel onlosmakelijk samen geactiveerd moeten worden krijgen explicit-koppelings-noten in §4.3 en parallelle aanname-formuleringen in §4.6:
- **`correlatieRenteInflatie` ↔ `inflatieStochastiek`** (v2.1.7) — correlatie zonder stochastiek is betekenisloos
- **`lifecycle-profiel` ↔ `rtsCurve`** (v2.1.8) — μ(x)/σ(x) zonder leeftijdsafhankelijke discontering is incoherent
- Bestaand parallel: **`RTS` ↔ `agHerzienPeriode` ↔ `renteAfdekkingFactor`** (SPR-Fase B, §4.9)

Dit patroon herhalen in M4 (en SCHEMA v2) waar conceptuele bundeling speelt.

### Plot-horizon-architectuur (nieuw expliciet v2.1.9)

- **Engine berekent altijd tot ω** — geen informatie-verlies in `paths`
- **UI past `plotHorizonRule`-enum toe** als presentatie-laag (vier waardes; default `'lifeExpPlus10'`)
- Output velden: `years` (engine), `years_display` + `endAge_display` (UI)
- Power-users kunnen `'omega'` kiezen om §4.6 aanname 11 visueel te toetsen

---

## OPEN BESLISPUNTEN VOOR SCHERM 4

Acht punten geïnventariseerd in scherm-3-sessie-eindgesprek, gegroepeerd naar diepte:

**Snel-formaliseringen (vergelijkbaar met patch v2.1.5):**

1. **Cross-punt 5 (HANDOFF_v2.1).** Cohort-correct M4 vs periode-snapshot M1 — <1% verschil. UI-disclosure of opheffen?
2. **§5.12.1 V_x^Wtp als waarde-equivalent.** v1-aanname met UI-disclosure formaliseren.
3. **§5.12.2 Afleiding π^Wtp buiten rekenmodule.** Scope-aanscherping: parameterset-verantwoordelijkheid expliciet maken.
4. **§5.12.3 Onafhankelijkheid x⊥y (broken-heart-effect).** Spiegel §2.10/§4.9 joint-life-reservering naar M4. v2-reservering bevestigen.
5. **§5.12.4 Geen SPR/FPR-differentiatie in kern, via parametersets (§5.13).** Bevestig v1-aanpak; markeer als opgelost.

**Inhoudelijke beslissingen (vergelijkbaar met v2.1.6):**

6. **§5.12.5 Toedeelbaar vermogen versus totaal (φ_effectief vs φ-as-supplied).** Koppelt aan M2 §3.5 ppkBase-formule — moet gelijktrekking nodig zijn? Onderzoeken.
7. **§5.12.6 π^DB als vereenvoudiging van toeslagmechaniek.** Koppelt aan §5.6 indexatiescenario's. Aanname documenteren of differentiatie introduceren.

**Diepe architecturale beslissing (potentieel major v2.2):**

8. **OP/NP-breakdown M4 promoveren van presentatie- naar berekeningslaag?** Nieuw agendapunt v2.1.3. Heropent §11.12 Optie 4 (phiDerived-component-varianten in M2). Conservatieve uitkomst (behoud v1-presentatie-laag) is een snel-formalisering; promotie is een major-bump die mogelijk een aparte sessie verdient.

**Risico's:**
- Punt 6 (§5.12.5) kan een doorwerking naar M2 §3.5 triggeren als blijkt dat M2's huidige ppkBase-formule impliciet aanneemt dat φ al effectief is — dan gelijktrekken in scherm-4-sessie of expliciet documenteren.
- Punt 8 conservatief afhandelen tenzij Hans gericht voor de promotie wil gaan.

---

## OPEN BESLISPUNTEN VOOR NA SCHERM 4

Na voltooiing scherm 4 staan deze nog:

- **SCHEMA v2** maken — directe afgeleide van spec v2.x na alle vier schermen (`SCHEMA_v1.md` wordt v2)
- **TEST_FIXTURES v1** — vaste numerieke assertions per module (x=67, x=75, x=85 met vaste parameters), nodig voor implementatie-validatie
- **UI-design voor OP/NP-breakdown op schermen 2/3/4** — §11.18 follow-up bullet 3, thematisch eigen sessie
- **Implementatie-track** — separate sessie(s) voor refactor R9.30 of nieuwe bouw, conform werkafspraak 9

---

## DATA-TODO'S VOOR HANS (NIET-BLOKKEREND)

Behouden uit eerdere handoffs, met scherm-3-aanvullingen:

1. SSPF-specifieke `f`-waarde (Implementatieplan/jaarverslag) → vervangt placeholder 1,0.
2. SSPF uitvoeringskosten per jaar → activeert Variant-A-afleiding voor ρ, vervangt 0,02-placeholder.
3. SSPF M/V-verdeling per cohort → vervangt 95/5-placeholder.
4. AG2024 populatie-data voor NL-neutrale weging.
5. Q-tafel herkomst documentatie (bevestigd als fout).
6. **SSPF-RDR-uitputtingsregels (v2.1.6, geparkeerd)** — bestuursnotitie of reglement waarin staat hoe RDR wordt aangewend (volledig tekort vs plafond vs gefaseerd).
7. **SSPF-officiële μ/σ-bron voor 60/40-portfolio (v2.1.8)** — bestuursnotitie of officiële Wtp-richtlijn met exacte rendementsverwachting/volatiliteit.
8. **DNB-FTK-publicaties of AG-stochastische-set-parameters voor correlatie rendement-inflatie (v2.1.7, geparkeerd)** — voor latere kalibratie bij eventuele activering.

---

## COHERENTIE-CHECK UITGEVOERD BIJ AFRONDING

Tijdens scherm-3-sessie zijn drie structurele controles continu uitgevoerd, conform werkafspraak 10:

1. **Patch-volgorde en changelog-integriteit.** Bij elke patch (v2.1.4 t/m v2.1.9) gecheckt: alle voorgaande v2.x-changelog-entries staan compleet en op volgorde. Eindstand v2.1.9: tien v2.x-entries (v2.1, v2.1.1, v2.1.2, v2.1.3, v2.1.4, v2.1.5, v2.1.6, v2.1.7, v2.1.8, v2.1.9) intact. Geen herhaling van scherm-2-overschrijfbug.

2. **Anker-zin-integriteit** (verfijning werkafspraak 10). In v2.1.5 één keer foutief afgekapt door alleen het begin-fragment van de spec-met-reserveringen-zin in `old_str` te zetten; direct opgemerkt en hersteld via terug-edit. Geen herhaling in v2.1.6/v2.1.7/v2.1.8/v2.1.9. Lesson-learned vastgelegd in werkafspraak 10.

3. **Doorwerkings-consistentie tussen modules.** Bij v2.1.5 expliciet spiegelgelijkheid M1↔M3 getoetst; bij v2.1.6 doorwerking `dempJaren` en `bufferTrigger` naar §4.5/§4.6 gecontroleerd; bij v2.1.7/v2.1.8 het patroon "gekoppelde v2-paden" toegepast als interne consistentie-check; bij v2.1.9 berekening/presentatie-scheiding doorgewerkt naar §4.4 output-velden.

---

## VOLGENDE-SESSIE-AANPAK (VOORSTEL)

1. **Start**: lees `ENGINE_SPECIFICATIE_v1.md` v2.1.9 volledig door, met focus op §1.1 (narratief kompas), §5 (module 4) inclusief §5.12 reviewpunten en §5.13 SPR/FPR-differentiatie, en §11.12 (open punt voor scherm-4-impact via OP/NP-promotie).
2. **Context-injectie**: lees alle drie handoffs: `HANDOFF_v2.1.md` (scherm 1), `HANDOFF_v2.1.3.md` (scherm 2), `HANDOFF_v2.1.9.md` (dit document, scherm 3).
3. **Eerste inventarisatie**: scherm-4-open-punten in compact overzicht (acht punten, gegroepeerd naar diepte zoals hierboven).
4. **Werkwijze**: stap-voor-stap, identiek aan eerdere sessies. Snel-formaliseringen (#1–5) kunnen in serie; inhoudelijke (#6–7) verdienen elk eigen probleem/opties/aanbeveling-blok; #8 conservatief afhandelen tenzij Hans gericht voor major-bump kiest.
5. **Versiebump-regel**: patch (v2.2.0, v2.2.1…) voor scherm-4-besluiten; minor (v2.2 startpatch) voor structuurveranderingen binnen scherm 4; major (v3.0) alleen bij fundamentele herordening zoals OP/NP-promotie tot berekeningslaag.
6. **Aandachtspunt**: Patroon "gekoppelde v2-paden" toepassen waar conceptuele bundeling speelt in M4 (bijvoorbeeld bij π^Wtp-decompositie als #6/#7 erom vragen).
7. **Breekpunt**: na scherm-4-voltooiing HANDOFF maken (HANDOFF_v2.2.x.md, zelfde stijl) voordat SCHEMA v2 of TEST_FIXTURES v1 wordt begonnen.

---

## BRONBESTANDEN — COMPLETE INVENTARIS

Volgende sessie heeft deze bestanden nodig:

**Van deze sessie nieuw:**
- `ENGINE_SPECIFICATIE_v1.md` (v2.1.9, 1849 regels) — normatieve spec
- `HANDOFF_v2.1.9.md` (dit document) — scherm-3-handoff

**Van eerdere sessies behouden:**
- `HANDOFF_v2.1.md` — scherm-1-handoff (brede context)
- `HANDOFF_v2.1.3.md` — scherm-2-handoff (cumulatief)

**Eerder opgeleverd (onveranderd):**
- `ARCHITECTUUR_v1.md` — leidend architectuur-document
- `DESIGN_engine_v0.md` — reverse-engineering R9.30 engine
- `calculator_specificatie.docx` — M4-docx-spec (kritisch voor scherm-4-sessie)
- `SCHEMA_v1.md` — huidige SCHEMA (wordt v2 na scherm 4)
- `STRATEGY_R9.30.md` — strategische context
- `HANDOFF_R9.30.md` — technische handoff code (ander track)
- `21-04-2026_2216.html` — R9.30 werkbestand (code baseline)

**Externe data:**
- `AG2024.xlsx` — AG2024 gemodelleerde prognose-sterftekansen per geslacht
- `51490-Data_AG2024.xlsx` — AG2024 brondata

---

## AFSLUITENDE NOTITIE

Scherm 3 is systematisch doorgenomen zoals scherm 1 en scherm 2: zes open punten, zes besluiten, zes patches, allen aan het narratief kompas getoetst. Het tempo lag hoger dan scherm 2 (zes patches in één sessie versus drie) doordat veel scherm-3-keuzes het patroon "vlakke v1-default + gekoppelde v2-reservering" konden volgen — een patroon dat zelf in scherm 3 expliciet werd herkend en als reservering-discipline is opgeschreven. Twee patches (v2.1.6, v2.1.8) hebben SSPF-design-input van Hans (RDR-buffer/5-jaars-demping; 60/40-portfolio) als interne bron geconcretiseerd, vergelijkbaar met hoe v2.1.2 wettelijke bronnen heeft gebruikt voor ppkComp. Eén patch-administratie-fout (v2.1.5 anker-zin afgekapt) is direct opgemerkt en hersteld; werkafspraak 10 is daarop verfijnd. Scherm 4 kan starten met een spec die op zes plekken inhoudelijk-rijker is dan v2.1.3 zonder het hoofdpad-numeriek te hebben verstoord, en met een nieuw patroon dat in scherm 4 vermoedelijk opnieuw bruikbaar is bij π^Wtp-decompositie en SPR/FPR-differentiatie.

*Einde HANDOFF_v2.1.9.md*
