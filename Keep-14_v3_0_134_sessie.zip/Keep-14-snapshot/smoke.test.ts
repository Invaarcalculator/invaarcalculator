import {
  M1,
  M2,
  FIELD_REGISTRY,
  fieldsByDisplay,
  fieldsWithDisclosure,
} from './schema.v2'

console.log('=== M1 smoke test ===\n')

// Test 1: deelnemer zonder partner (minimale invoer)
console.log('Test 1: minimale deelnemer zonder partner')
const d1 = M1.deelnemer.parse({ x0: 67, pen: 30000 })
console.log('  Parsed:', JSON.stringify(d1, null, 2))
console.log()

// Test 2: deelnemer met partner volledig
console.log('Test 2: deelnemer met partner')
const d2 = M1.deelnemer.parse({
  x0: 67,
  pen: 30000,
  g: 'M',
  heeftPartner: true,
  x_partner: 65,
  y0: 21000,
  g_y: 'V',
})
console.log('  Parsed:', JSON.stringify(d2, null, 2))
console.log()

// Test 3: heeftPartner=true zonder x_partner moet falen
console.log('Test 3: heeftPartner=true zonder x_partner (moet falen)')
const d3 = M1.deelnemer.safeParse({
  x0: 67,
  pen: 30000,
  heeftPartner: true,
})
console.log('  Success:', d3.success)
if (!d3.success) {
  console.log('  Issues:', d3.error.issues.map((i) => `[${i.path.join('.')}] ${i.message}`))
}
console.log()

// Test 4: parameterset met defaults
console.log('Test 4: parameterset met alleen defaults (leeg object)')
const p1 = M1.parameterset.parse({})
console.log('  Parsed:', JSON.stringify(p1, null, 2))
console.log('  NB (v2.2.9): t0 is nu in parameterset, niet meer in deelnemer')
console.log()

// Test 5: parameterset met uitvoeringskosten maar geen fondsvermogen (warning)
console.log('Test 5: parameterset met uitvoeringskosten zonder fondsvermogen')
const p2 = M1.parameterset.safeParse({
  uitvoeringskostenJaarlijks: 50,
  // fondsvermogen ontbreekt
})
console.log('  Success:', p2.success)
if (!p2.success) {
  console.log('  Issues:', p2.error.issues.map((i) => `[${i.path.join('.')}] ${i.message}`))
}
console.log()

// Test 5b: §7.3 cross-module-lock — moet 'due' weigeren (v2.0 SCHEMA-lock, knelpunt 8)
console.log('Test 5b: §7.3-lock — annuiteitsconventie="due" moet falen')
const p3a = M1.parameterset.safeParse({ annuiteitsconventie: 'due' })
console.log('  Success:', p3a.success, p3a.success ? '' : '(correct: §7.3-lock actief)')
console.log()

// Test 5c: §7.3 cross-module-lock — moet m=4 weigeren (v2.0 SCHEMA-lock)
console.log('Test 5c: §7.3-lock — m=4 moet falen')
const p3b = M1.parameterset.safeParse({ m: 4 })
console.log('  Success:', p3b.success, p3b.success ? '' : '(correct: §7.3-lock actief)')
console.log()

// Test 6: metadata-registry inspectie
console.log('=== Metadata-registry inspectie ===\n')
console.log(`Totaal geregistreerde velden: ${FIELD_REGISTRY.length}`)
console.log()

console.log('M1 hoofdpad-velden (casual-schermen):')
fieldsByDisplay('M1', ['hoofdpad']).forEach((f) => {
  console.log(`  ${f.path} — ${f.meta.specRef}`)
})
console.log()

console.log('M1 decompositie+deepdive (audit-scherm M1-sectie):')
fieldsByDisplay('M1', ['decompositie', 'deepdive']).forEach((f) => {
  console.log(`  ${f.path} — ${f.meta.specRef}`)
})
console.log()

console.log('M1 parameter-audit (audit-scherm parameterset-sectie):')
fieldsByDisplay('M1', ['parameter-audit']).forEach((f) => {
  console.log(`  ${f.path} — ${f.meta.specRef}`)
})
console.log()

console.log('Velden met UI-disclosure-eis (audit-scherm disclosure-sectie):')
fieldsWithDisclosure().forEach((f) => {
  console.log(`  ${f.path}`)
  console.log(`    → ${f.meta.uiDisclosure}`)
})

// ============================================================================
// === M2 smoke test (combi-sessie 04-05-2026) ===
// ============================================================================

console.log('\n=== M2 smoke test ===\n')

// Test M2-1: parameterset met minimale verplichte velden
console.log('Test M2-1: parameterset met minimale verplichte velden')
const m2p1 = M2.parameterset.safeParse({
  fondsvermogen: 27202,
  dekkingsgraad: 1.15,
  N_deelnemers: 12500,
  demografie: { soort: 'preset', preset: 'gesloten' },
})
console.log('  Success:', m2p1.success)
if (m2p1.success) {
  console.log('  vpvAftrekPct (default):', m2p1.data.vpvAftrekPct)
  console.log('  spreidingN (default):', m2p1.data.spreidingN)
  console.log('  compensatiedepot (default):', m2p1.data.compensatiedepot)
  console.log('  buffer (default):', m2p1.data.buffer)
}
console.log()

// Test M2-2: fondsvermogen=null moet falen (M2-only constraint via superRefine)
console.log('Test M2-2: fondsvermogen=null moet falen (M2-only)')
const m2p2 = M2.parameterset.safeParse({
  fondsvermogen: null,
  dekkingsgraad: 1.15,
  N_deelnemers: 12500,
  demografie: { soort: 'preset', preset: 'gesloten' },
})
console.log('  Success:', m2p2.success, m2p2.success ? '' : '(correct: M2 vereist non-null)')
console.log()

// Test M2-3: dekkingsgraad buiten [0.5, 2.0] moet falen
console.log('Test M2-3: dekkingsgraad=2.5 moet falen (§3.8)')
const m2p3 = M2.parameterset.safeParse({
  fondsvermogen: 27202,
  dekkingsgraad: 2.5,
  N_deelnemers: 12500,
  demografie: { soort: 'preset', preset: 'gesloten' },
})
console.log('  Success:', m2p3.success, m2p3.success ? '' : '(correct: §3.8 hard reject)')
console.log()

// Test M2-4: customCounts met lengte ≠ 15 moet falen
console.log('Test M2-4: demografie.customCounts lengte 14 moet falen')
const m2p4 = M2.parameterset.safeParse({
  fondsvermogen: 27202,
  dekkingsgraad: 1.15,
  N_deelnemers: 12500,
  demografie: { soort: 'customCounts', customCounts: new Array(14).fill(100) },
})
console.log('  Success:', m2p4.success, m2p4.success ? '' : '(correct: §3.3/§3.8 lengte-eis)')
console.log()

// Test M2-5: demografie zonder discriminator moet falen
console.log('Test M2-5: demografie zonder soort-tag moet falen')
const m2p5 = M2.parameterset.safeParse({
  fondsvermogen: 27202,
  dekkingsgraad: 1.15,
  N_deelnemers: 12500,
  demografie: { preset: 'gesloten' }, // missing soort
})
console.log('  Success:', m2p5.success, m2p5.success ? '' : '(correct: discriminator vereist)')
console.log()

// Test M2-6: customCounts met 15 elementen werkt
console.log('Test M2-6: customCounts lengte 15 moet werken')
const m2p6 = M2.parameterset.safeParse({
  fondsvermogen: 27202,
  dekkingsgraad: 1.15,
  N_deelnemers: 12500,
  demografie: { soort: 'customCounts', customCounts: new Array(15).fill(800) },
})
console.log('  Success:', m2p6.success)
console.log()

// Test M2-7: v2.2.10 bundle-conflict-warning bij vpvAftrekPct + legacy-velden
console.log('Test M2-7: vpvAftrekPct + overigeReserves > 0 → waarschuwing')
const m2p7 = M2.parameterset.safeParse({
  fondsvermogen: 27202,
  dekkingsgraad: 1.15,
  N_deelnemers: 12500,
  demografie: { soort: 'preset', preset: 'gesloten' },
  vpvAftrekPct: 0.10,
  overigeReserves: 50, // legacy + new gelijktijdig actief
})
console.log('  Success:', m2p7.success, m2p7.success ? '' : '(correct: bundle-conflict-warning)')
console.log()

// Test M2-8: M2-output sluitingscontrole — ppk_OP + ppk_NP = ppkTotal exact
console.log('Test M2-8: M2-output sluitingscontrole ppk_OP+ppk_NP=ppkTotal')
const m2o1 = M2.output.safeParse({
  ppkBase: 600,
  ppkSurplus: 150,
  ppkComp: 50,
  ppkTotal: 800,
  ppk_OP: 700,
  ppk_NP: 100, // 700+100=800 ✓
  bufferAandeel: 30,
  cohortOutcomes: Array.from({ length: 15 }, (_, i) => ({
    range: `${25 + i * 5}-${25 + i * 5 + 4}`,
    midage: 25 + i * 5 + 2,
    n: 100,
    kvAvg: 0.5,
    surplusBijdrage: 10,
    compBijdrage: 3.33,
  })),
  vpvTotal: 23700,
  verdeelbaar: 750,
  phiDerived: null,
})
console.log('  Success:', m2o1.success, m2o1.success ? '(sluitingscontroles ✓)' : 'FAIL')
console.log()

// Test M2-9: sluitingscontrole faalt bij ppk_OP+ppk_NP ≠ ppkTotal
console.log('Test M2-9: ppk_OP+ppk_NP ≠ ppkTotal moet falen')
const m2o2 = M2.output.safeParse({
  ppkBase: 600,
  ppkSurplus: 150,
  ppkComp: 50,
  ppkTotal: 800,
  ppk_OP: 700,
  ppk_NP: 110, // 700+110=810 ≠ 800
  bufferAandeel: 30,
  cohortOutcomes: Array.from({ length: 15 }, (_, i) => ({
    range: `${25 + i * 5}-${25 + i * 5 + 4}`,
    midage: 25 + i * 5 + 2,
    n: 100,
    kvAvg: 0.5,
    surplusBijdrage: 10,
    compBijdrage: 3.33,
  })),
  vpvTotal: 23700,
  verdeelbaar: 750,
  phiDerived: null,
})
console.log('  Success:', m2o2.success, m2o2.success ? 'FAIL' : '(correct: v2.1.1 exact-sluitingscontrole)')
console.log()

// Test M2-10: phiDerived=null moet werken (§11.12 Optie 1)
console.log('Test M2-10: phiDerived=null geaccepteerd')
const m2o3 = M2.output.safeParse({
  ppkBase: 600, ppkSurplus: 150, ppkComp: 50, ppkTotal: 800,
  ppk_OP: 700, ppk_NP: 100,
  bufferAandeel: 30,
  cohortOutcomes: Array.from({ length: 15 }, (_, i) => ({
    range: `${25 + i * 5}-${25 + i * 5 + 4}`,
    midage: 25 + i * 5 + 2,
    n: 100, kvAvg: 0.5, surplusBijdrage: 10, compBijdrage: 3.33,
  })),
  vpvTotal: 23700, verdeelbaar: 750,
  phiDerived: null, // §11.12 Optie 1
})
console.log('  Success:', m2o3.success)
console.log()

// Test M2-11: M2-FIELD_REGISTRY-coverage
console.log('=== M2 FIELD_REGISTRY inspectie ===')
const m2Fields = FIELD_REGISTRY.filter((f) => f.meta.module === 'M2')
console.log(`M2-velden geregistreerd: ${m2Fields.length}`)
console.log()

console.log('M2 hoofdpad+decompositie+deepdive (audit-scherm M2-sectie):')
fieldsByDisplay('M2', ['hoofdpad', 'decompositie', 'deepdive']).forEach((f) => {
  console.log(`  ${f.path} — ${f.meta.specRef}`)
})
console.log()

console.log('M2 parameter-audit (M2-parameter-sectie):')
fieldsByDisplay('M2', ['parameter-audit']).forEach((f) => {
  console.log(`  ${f.path} — ${f.meta.specRef}`)
})
