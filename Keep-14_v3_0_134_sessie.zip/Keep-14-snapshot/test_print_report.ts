/**
 * v3.0.41: smoke voor print-feature.
 *   1. Print-knop aanwezig in DOM
 *   2. #print-report container aanwezig
 *   3. Klik op knop vult #print-report met UPO-gegevens en resultaten
 *   4. Bedragen kloppen met de KPI-cards (KV en PPV)
 *   5. Formules-sectie aanwezig met de M-formule en x_fonds-formule
 *   6. Geen em-dashes in print-content
 */
import { JSDOM } from 'jsdom'
import { readFileSync } from 'fs'

;(async () => {
const html = readFileSync('/mnt/user-data/outputs/calculator.html', 'utf8')
const dom = new JSDOM(html, { runScripts: 'dangerously', resources: 'usable' })
;(dom.window as unknown as { matchMedia: (q: string) => unknown }).matchMedia = (q: string) => ({
  matches: false, media: q, onchange: null,
  addListener: () => {}, removeListener: () => {},
  addEventListener: () => {}, removeEventListener: () => {}, dispatchEvent: () => false,
})
// stub window.print zodat triggerPrint niet faalt in JSDOM
;(dom.window as unknown as { print: () => void }).print = () => {}

await new Promise<void>((res) => setTimeout(res, 250))

const doc = dom.window.document
const fail = (msg: string) => { console.log('  ✗ ' + msg); process.exit(1) }
const ok = (msg: string) => console.log('  ✓ ' + msg)

console.log('\n=== Test 1: print-knop en container aanwezig ===')
const btn = doc.getElementById('print-report-btn') as HTMLButtonElement | null
if (!btn) fail('print-report-btn niet gevonden')
ok('print-knop aanwezig')

const target = doc.getElementById('print-report')
if (!target) fail('#print-report container niet gevonden')
if (target!.innerHTML.trim() !== '') fail('print-report initieel niet leeg')
ok('#print-report leeg en aanwezig')

console.log('\n=== Test 2: klik op knop vult report ===')
btn!.click()
await new Promise<void>((res) => setTimeout(res, 50))
const filled = target!.innerHTML
if (filled.length < 500) fail(`report te kort na klik: ${filled.length} chars`)
ok(`report gevuld (${filled.length} chars)`)

console.log('\n=== Test 3: invoer-tabel toont UPO-defaults ===')
if (!filled.includes('70 jaar')) fail('leeftijd 70 niet in report')
if (!filled.includes('100.000')) fail('OP-bedrag 100.000 niet in report')
// v3.0.95: default-state is GEEN partner; report toont "Partnerpensioen geen"
if (!filled.includes('Partnerpensioen') || !filled.includes('geen')) {
  fail('Partnerpensioen "geen" niet in report (no-partner-default v3.0.95+)')
}
ok('UPO-gegevens in report')

console.log('\n=== Test 4: resultaten kloppen met KPI-cards ===')
// KV M1 anker
const m1Text = doc.querySelector('.pane-m1 .kpi-value')?.textContent ?? ''
const m1Match = m1Text.match(/€\s*([\d.]+)/)
if (!m1Match) fail('KV niet leesbaar uit M1-card')
const kvStr = m1Match[1]
if (!filled.includes(kvStr)) fail(`KV ${kvStr} niet in report`)
ok(`KV ${kvStr} matcht KPI-card`)

const m2Text = doc.querySelector('.pane-m2 .kpi-formula-total .kpi-formula-val')?.textContent ?? ''
const m2Match = m2Text.match(/€\s*([\d.]+)/)
if (!m2Match) fail('PPV niet leesbaar uit M2-card')
const ppvStr = m2Match[1]
if (!filled.includes(ppvStr)) fail(`PPV ${ppvStr} niet in report`)
ok(`PPV ${ppvStr} matcht KPI-card`)

console.log('\n=== Test 5: fondsparameters M1+M2 + formules-appendix aanwezig ===')
if (!filled.includes('Module 1 parameters')) fail('M1-parametertabel niet in report')
if (!filled.includes('Module 2 parameters')) fail('M2-parametertabel niet in report')
if (!filled.includes('AG2024')) fail('AG2024 niet in M1-tabel')
if (!filled.includes('500')) fail('bijstort 500 niet in M2-tabel')
ok('M1+M2 parametertabellen aanwezig')

if (!filled.match(/M\s*=.*fondsvermogen/i)) fail('M-formule niet in appendix')
if (!filled.includes('x_fonds')) fail('x_fonds-formule niet in appendix')
if (!filled.includes('Bijlage 2a')) fail('wettelijke verwijzing Bijlage 2a niet aanwezig')
ok('Formules-appendix aanwezig met wettelijke verwijzingen')

console.log('\n=== Test 6: geen em-dashes in print-content ===')
const emDashCount = (filled.match(/—/g) ?? []).length
if (emDashCount > 0) fail(`${emDashCount} em-dash(es) in print-content`)
ok('geen em-dashes')

console.log('\n=== Test 7: WITH-partner scenario rendert correct ===')
// v3.0.95: default geen partner; v3.0.96: heeftPartner is dropdown-select.
// Schakel partner AAN en test of de fields verschijnen.
const partnerSelect = doc.querySelector('select[data-field="heeftPartner"]') as HTMLSelectElement
if (partnerSelect) {
  partnerSelect.value = 'true'
  partnerSelect.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
  await new Promise<void>((res) => setTimeout(res, 50))
  // v3.0.96: partner-toggle triggert volledige re-render, dus btn opnieuw acquireren
  const btnAfter = doc.getElementById('print-report-btn') as HTMLButtonElement | null
  const targetAfter = doc.getElementById('print-report')
  if (!btnAfter || !targetAfter) fail('print-elementen weg na partner-toggle re-render')
  btnAfter!.click()
  await new Promise<void>((res) => setTimeout(res, 50))
  const withPartnerHtml = targetAfter!.innerHTML
  // v3.0.96 hydrate: partner-leeftijd default 65, y0 = 70% van pen = 70.000
  if (!withPartnerHtml.includes('65 jaar')) {
    fail(`with-partner-scenario toont geen partner-leeftijd 65 (html ${withPartnerHtml.length} chars)`)
  }
  ok('with-partner-scenario correct')
}

console.log('\n=== Alle tests geslaagd ✓ ===')
})()
