# HANDOFF v3.0.89 — Invaarcalculator® release-klaar (M1/2 cascade-pane + UI-polish)

**Datum:** Za 9 mei 2026
**Versie:** v3.0.89
**Status:** Release-klaar, alle tests groen
**Werkdir:** `/home/claude/Keep-14/`

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip:
  unzip /mnt/user-data/outputs/Keep-14_v3.0.89_complete.zip -d /home/claude/

Build calculator naar /mnt/user-data/outputs/calculator.html (default fonds=sspf):
  cd /home/claude/Keep-14 && npx tsx build.calc.ts

Build met expliciete fonds-keuze:
  cd /home/claude/Keep-14 && npx tsx build.calc.ts --fonds=sspf

Volledige regression-suite (6 test-files, alle groen verwacht):
  npx tsx test_browser_calc.ts        # M1/M2/cascade smoke + ankers
  npx tsx test_fonds_modal.ts         # Fonds-?-modal cascade-render
  npx tsx test_aftrek_komma.ts        # NL-decimaalkomma in cascade
  npx tsx test_cascade.ts             # Cascade-tabel + fonds_fonds2 absent
  npx tsx test_print_report.ts        # PDF-rapport-generator
  npx tsx test_v3_cascade.ts          # Engine-only cascade-ankers (regressie-anchor)
```

**Werkafspraken:**
- Stap-voor-stap, één wijziging per turn (Werkafspraak 12)
- Alle fonds-parameter-wijzigingen voorzien van bron-citaat in `fondsen/sspf/fonds.config.ts`
- "Persoonlijk pensioenvermogen" canonical in UI; geen "potje"
- Géén em-dashes (—) in user-facing tekst
- NL-decimaalkomma overal
- Sidebar-preview niet geschikt voor print/popup-tests (gebruik visuele review op vol scherm)
- **HANDOFF altijd in werkdir én zip** (Werkafspraak 13, 06-05-2026):
  Schrijf HANDOFF_vX.Y.Z.md ALTIJD eerst naar `/home/claude/Keep-14/HANDOFF_vX.Y.Z.md`,
  daarna kopiëren naar `/mnt/user-data/outputs/`. Bij het zippen wordt de werkdir
  ingepakt — als HANDOFF alleen in /outputs/ staat zit hij NIET in de zip-restore.

---

## 2. Architectuur — fonds-agnostisch via build-time-injectie (v3.0.76+)

**De codebase werkt voor één fonds per build.** Voor een tweede fonds maak je een tweede build vanaf dezelfde codebase:

```
/src/                          ← fonds-onafhankelijk (engine, UI, schema, types)
/fondsen/sspf/fonds.config.ts  ← SSPF-data: M1, M2, AanwendingsCascade
/fondsen/<id>/fonds.config.ts  ← (later) ABN of ander fonds
```

Esbuild path-alias `~fonds` → `/fondsen/<id>/fonds.config.ts`. Build-script accepteert `--fonds=<id>`, default `sspf`. Tsconfig.json heeft path-alias zodat tsx + type-check werken.

Voor een tweede fonds (later, bv. ABN):
1. `mkdir fondsen/abn`
2. Maak `fondsen/abn/fonds.config.ts` met ABN-data
3. `npx tsx build.calc.ts --fonds=abn`
4. Twee fondsen tegelijk in één HTML wordt **expliciet niet meer ondersteund**

---

## 3. Numerieke ankers (canoniek voor v3.0.89)

### UI-default scenario
Bij default-state (x0=70, pen=€100k, NP=€70k, DG=135%, fondsvermogen=€26.000m, bijstort=€500m, wettelijk=2%, RDR=€500m, compdepot=€400m, spreiding=∞):

- **KV M1** = € 1.633.637
- **PPV M2** = € 2.112.708 (was €2.123.136 in v3.0.78; daling 0,5% door cascade-componenten als bron-van-waarheid; effectieve aftrek 6,67% bij DG=135% i.p.v. afgeronde 6,0%)
- **Verdeelbaar overschot** = € 5.956 mln (cascade M1/2-pane eindrij)
- **Uw aandeel verdeelbaar overschot** = € 479.071 (delta in M2 KPI)

### Cascade-test (test_v3_cascade.ts) — eigen inline params, **stabiele regressie-anchor**:
- KV M1 = € 543.096
- ppkTotal v3.0 N=10 = € 569.457 (Δ 4,85%)
- ppkTotal v3.0 N=∞ = € 569.889 (Δ 4,93%)
- ppkTotal R9.30 LEG = € 572.166 (Δ 5,35%)

Deze ankers zijn **engine-only** en bewegen niet mee met UI-state-defaults.

---

## 4. Versie-overzicht v3.0.76 → v3.0.89

### v3.0.76 — Build-time-fondsinjectie [DECISION]
- `/fondsen/sspf/fonds.config.ts` aangemaakt met SSPF-data, exporteert `FONDS` direct
- `/src/fondsdataset.types.ts` — fonds-onafhankelijke types
- `/src/fondsdataset.ts` — bridge, importeert via `~fonds`
- Build-script: `--fonds=<id>` flag, esbuild alias `~fonds`
- Tsconfig.json: paths alias
- Backward-compat exports (`FONDSEN`, `FondsId`, `SSPF_M1/M2_PLACEHOLDER`) blijven

### v3.0.77 — Interne state-cleanup
- `state.fondsKeuze` weg uit `AppState` + init
- `buildFondsHelp()` zonder param, gebruikt `FONDS` direct
- `HELP_CONTENT`: één 'fonds'-entry (geen id-suffix); `data-help="fonds_sspf"` → `data-help="fonds"` via sed-rename
- Multi-fonds-render-tak verwijderd uit `fondsKeuzeBlok`
- `ui.print.ts`: `FondsId/FONDSEN` imports weg, `fondsKeuze` uit `PrintInput`

### v3.0.78 — SSPF-naam volledig
- `FONDS.label`: `'SSPF'` → `'Stichting Shell Pensioenfonds (SSPF)'`

### v3.0.79 — M1/2-pane "Tekort of overschot" (canoniek nu) [DECISION]
- Nieuwe state-sectie `cascadeOverrides: {wettelijkeReservesPct, rdrBedrag, compensatiedepotBedrag}`, init uit `FONDS.aanwendingsCascade`
- `recompute()` aggregeert componenten + DG + bijstort + fondsvermogen → `parameters_m2.vpvAftrekPct` (engine-API onveranderd)
- M1/2-pane `m12Block` tussen pane-m1 en m2Block met cascade-tabel + 6 sliders + afwijking-markers + reset-knop
- M2-pane: DG-slider en aftrek-slider verwijderd, alleen spreidingstermijn-radio resteert
- `vpvAftrekPct`-modal vereenvoudigd tot verwijzings-tekst
- CSS voor `.pane-m12`, `.cascade-table`, `.cascade-row`, `.afwijk-marker`, `.pane-afwijk-banner`, `.reset-cascade-btn`

### v3.0.80 — UI-tweaks (kleuren + label)
- M1: rood → groen, M2: groen → rood, M1/2: amber/geel
- h2 "Wat is er te verdelen?" → "Tekort of overschot"
- Intro-tekst herschreven om vpv/overschot/standaardregel correct uit te leggen
- `.kpi-delta.pos`/`.neg` semantiek (groen/rood) blijft

### v3.0.81 — M2-card opgeruimd: kpi-foot weg
- Verwarrende regel "Verdeelbaar fondsvermogen: 22,9% van fonds — 5956 mln €" verwijderd
- `verdPct`-berekening + `fondsvermogenMln`-parameter uit `renderM2KPI`-signatuur

### v3.0.82 — M2-card en cascade-kleuren
- `kpi-breakdown` (OP/NP-aandelen) verwijderd uit M2-card
- `heeftPartner`-parameter weg uit `renderM2KPI`
- Cascade-getallen amber kleur (consistent met pane-thema)

### v3.0.83 — Cascade-volgorde herzien [DECISION]
- Nieuwe volgorde: fondsvermogen − vpv = (overschot/tekort) + bijstort − reserves = verdeelbaar overschot
- Tekort/overschot expliciete tussenrij; intro herschreven
- `.cascade-negatief`-class voor rood label+val bij negatief
- Engine-ankers exact onveranderd (alleen visuele presentatie)

### v3.0.84 — DG verplaatst + slider-markers
- DG-rij van losse `m12-dg-row` naar cascade-row direct na fondsvermogen, vóór vpv
- `.cascade-context`-class voor contextuele rij (gedempte label-kleur)
- Begin/eind-waardes onder elke cascade-slider (`.cascade-markers`)
- `.cascade-row` van 2-rij naar 3-rij grid (label/val + slider + markers)

### v3.0.85 — M2 KPI als drielaagse opbouwsom [DECISION]
- `renderM2KPI` herschreven naar formule-visualisatie:
  - "Uw huidige aanspraak" (groen)
  - "Uw aandeel verdeelbaar overschot/tekort" (amber, met +/−-teken)
  - "Uw persoonlijk pensioenvermogen" (rood)
- Percentage als kleine voet onder dashed border
- Test-selectoren bijgewerkt: `.kpi-m2 .kpi-formula-total .kpi-formula-val`

### v3.0.86 — Tekstuele opruimingen
- M2-KPI label "Uw aanspraak (M1)" → "Uw aanspraak"
- M1/2-pane introtekst (paragraaf over vpv/overschot) volledig verwijderd

### v3.0.87 — Negatief-label correcties
- Cascade-eindrij switcht "Verdeelbaar overschot" ↔ "Verdeelbaar tekort"
- M2-KPI: operator (`+`/`−`) verwijderd uit het *label* — getal heeft eigen teken

### v3.0.88 — "Uw aanspraak" → "Uw huidige aanspraak"
- M2-KPI label + foot consistent met M1-pane h2

### v3.0.89 — `=`-prefix weg
- "= Uw persoonlijk pensioenvermogen" → "Uw persoonlijk pensioenvermogen"

---

## 5. Tests-status v3.0.89

Alle 6 test-suites groen:

| Test | Wat het dekt |
|------|---|
| test_browser_calc | UI smoke, KV/PPV-ankers, cascade-sliders aanwezig + defaults |
| test_fonds_modal | Fonds-?-modal opent, cascade-tabel render, fonds-naam zichtbaar |
| test_aftrek_komma | NL-decimaalkomma in cascade-tabel + fonds-modal |
| test_cascade | Cascade-tabel verschijnt na klik, fonds_fonds2 afwezig |
| test_print_report | PDF-rapport bevat KV, PPV, cascade-data |
| test_v3_cascade | **Engine-only ankers** (stabiele regressie-anchor) |

Test-selectoren die zijn bijgewerkt in deze sessie:
- `data-m2field` (DG/aftrek) → `data-co` (cascade-componenten)
- `.kpi-m2 .kpi-value` → `.kpi-m2 .kpi-formula-total .kpi-formula-val`
- `.m12-dg-row` → `.cascade-row` voor DG-stand
- `data-help="fonds_sspf"` → `data-help="fonds"` (3 testfiles)

---

## 6. Architecturele aandachtspunten genoteerd

- **DG-afhankelijke bijstort** (€500m/€650m/€850m staffels in fondsdata-comment) niet gemodelleerd; gebruiker kan inconsistente combinaties verkennen via slider zonder waarschuwing
- **Engine modelleert standaardregel** (Bijlage 2a Pw); vba-fondsen niet correct (in disclaimer benoemd)
- **Cascade in fonds-?-modal en M1/2-pane tonen dezelfde getallen**: M1/2-pane is interactief, fonds-modal toont read-only-versie via `buildAanwendingsCascadeBlock`
- **vpvAftrekPct in m2-state is afgeleide**; bron-of-waarheid zijn cascadeOverrides + fondsvermogen + DG + bijstort. UI synchroniseert in recompute()-start
- **ageFromDob snap-to-integer** regelt 365.25-edge rond verjaardagen
- **Alle aanrakingspunten cascade-componenten triggeren full render()** (niet `updateOutputsInPlace`), want afwijking-markers en banner moeten verspringen + cascade-tabel-getallen mee-bewegen
- **Verdeelbaar overschot — uw aandeel** hangt af van zes parameters: uw KV (M1-deelnemer-data) + spreidingstermijn + rekenrente + fondsdemografie (verborgen) + sterftekansentabel (AG2024) + de cascade-componenten. Engine-formule: `ppk(i) = KV(i) + x_fonds × CW_star(i)` met `x_fonds = (M − CW_voor_fonds) / CW_star_fonds`

---

## 7. PENDING action items

### Strategisch (in te plannen)
1. **Fondsdemografie zichtbaar/aanpasbaar maken**
   - Nu verborgen parameter: SSPF gebruikt preset 'gesloten'
   - Beïnvloedt PPV-uitkomst sterk via `x_fonds`
   - Mogelijke toekomstige UX: tonen welke demografie geldt, eventueel schuifbaar
2. **DG-staffel-waarschuwing** — bij DG<125% klopt de bijstort/RDR-staffel uit fonds-default niet, maar tool laat verkennen toe. Inline waarschuwing nog niet geïmplementeerd
3. **M1 KV-fix actieve deelnemer**
4. **67%-randvoorwaarde art. 150n lid 4 Pw**
5. **M3 Monte Carlo**
6. **M4 DB-vs-WTP**

### Operationeel
7. **Hosting-deployment** naar invaarcalculator.nl
8. **iPad-issue** (HTML opent niet) — niet gediagnosticeerd
9. **Visuele review v3.0.89** in echte browser door user

### Code-opruim (latere refactor)
10. **Backward-compat-symbols opruimen**: `SSPF_M1_PLACEHOLDER`, `SSPF_M2_PLACEHOLDER`, `FONDSEN`, `FondsId` nog gebruikt in `src/test_engine.ts`, `src/test_engine.m2.ts`, `src/ui.m1.ts`. Allen kunnen na verificatie weg ten gunste van directe `FONDS`-import

---

## 8. Source-files-overzicht (canoniek voor v3.0.89)

```
/home/claude/Keep-14/
├── src/
│   ├── ui.app.ts              # main, ~1860 regels (M1/2-pane gegenereerd hier)
│   ├── ui.m2.ts               # M2-render (KPI als formule-card + spreiding-radio)
│   ├── ui.m1.ts               # M1-render
│   ├── ui.print.ts            # PDF-rapport
│   ├── ui.shared.ts           # gedeelde helpers
│   ├── engine.m1.ts           # KV-berekening
│   ├── engine.m2.ts           # PPV-berekening (standaardregel)
│   ├── schema.v2.ts           # types + zod-validatie
│   ├── fondsdataset.ts        # bridge: importeert FONDS van ~fonds
│   ├── fondsdataset.types.ts  # fonds-onafhankelijke types
│   └── ag2024.ts              # AG-prognosetafels
├── fondsen/
│   └── sspf/
│       └── fonds.config.ts    # SSPF-bron-van-waarheid
├── build.calc.ts              # build-script (--fonds=<id>-flag)
├── tsconfig.json              # paths-alias '~fonds'
├── test_browser_calc.ts
├── test_fonds_modal.ts
├── test_aftrek_komma.ts
├── test_cascade.ts
├── test_print_report.ts
├── test_v3_cascade.ts
├── HANDOFF_v3.0.89.md         # ← deze file
└── journal.txt                # transcript-catalogus
```
