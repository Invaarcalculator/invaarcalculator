/**
 * Decompositie KV_NP voor 70M+70M om het broken-heart-effect te isoleren.
 */
import * as fs from 'fs'
import { computeM1 } from './src/engine.m1'
const ag = JSON.parse(fs.readFileSync('/home/claude/Keep-14/ag2024.json', 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag }

// Hans's scenario: 70M deelnemer + 70M partner
// Aannames: pen = €96k OP, y0 = ?? — moeten we afleiden uit KV_OP=1.303.766
// Maar we kunnen ook KV_OP+KV_NP-ratio rechtstreeks bekijken voor een ronde y0.

const r = 0.02
const t0 = 2026

// Eerst: wat is ä(70, M, r=2%) onder huidige config?
const m1params = {
  r, sterftekansTabelId: 'AG2024' as const,
  t0, ervaringsSterfte: 1.0, m: 12 as 12,
  annuiteitsconventie: 'arrears' as const, pi: 0,
  fondsvermogen: 1, omega: 110,
  uitvoeringskostenJaarlijks: null, kostenOpslagPct: null,
}

// Met partner (om KV_NP te krijgen): pen=96k, y0=21k als test
const deelnemer = {
  x0: 70, g: 'M' as const,
  heeftPartner: true,
  x_partner: 70, g_y: 'M' as const,
  pen: 96000, y0: 21000,
}

const out = computeM1(deelnemer, m1params)
console.log('=== KV-decompositie 70M+70M (pen=96k, y0=21k) ===\n')
console.log(`KV_OP            = €${out.KV_OP.toFixed(0)}`)
console.log(`KV_NP            = €${out.KV_NP.toFixed(0)}`)
console.log(`Verhouding NP/OP = ${(out.KV_NP / out.KV_OP * 100).toFixed(1)}%`)
console.log(`KV (totaal)      = €${out.KV.toFixed(0)}`)
console.log()

// Nu schalen om Hans's situatie te reproduceren (KV_OP=1.303.766)
const scaleOP = 1303766 / out.KV_OP
console.log(`Schaalfactor pen om KV_OP=1.303.766 te krijgen: ×${scaleOP.toFixed(3)}`)
console.log(`Geschatte pen = €${(96000 * scaleOP).toFixed(0)}/jaar`)
console.log(`Bij KV_NP/KV_OP-ratio van ${(out.KV_NP / out.KV_OP * 100).toFixed(1)}%: KV_NP zou €${(1303766 * out.KV_NP / out.KV_OP).toFixed(0)} zijn`)
console.log(`Hans rapporteert KV_NP = €307.667 → match: ${Math.abs(1303766 * out.KV_NP / out.KV_OP - 307667) < 5000 ? '✓' : '✗ (verschil door y0-aanname)'}`)
console.log()

// Nu: wat zou KV_NP zijn ZONDER broken-heart?
// Daarvoor moet ik bh()-functie effectief uitschakelen. De engine.m1.ts heeft
// jointLifeAnnuity met broken-heart hardcoded. Ik kan een quick-and-dirty
// vergelijking doen door direct ä_{x|y} te berekenen.

import { type AG2024Data, getAG2024, survivalProb } from './src/engine.m1'

const data = getAG2024()
const opts = { f: 1.0, data }

// Joint-life annuiteit ZONDER broken-heart (puur P(x dood) · P(y levend))
function annuityXY_noBrokenHeart(x: number, y: number, gx: 'M'|'V', gy: 'M'|'V', r: number, t0: number): number {
  const m = 12
  const horizon = 110 - Math.min(x, y)
  let sum = 0
  for (let k = 1; k <= m * horizon; k++) {
    const t = k / m
    const probXAlive = survivalProb(x, t, t0, gx, 1.0, data)
    const probXDead = 1 - probXAlive
    const probYAlive = survivalProb(y, t, t0, gy, 1.0, data)
    const v_t = Math.pow(1 + r, -t)
    sum += probXDead * probYAlive * v_t
  }
  return sum / m
}

const aXY_noBh = annuityXY_noBrokenHeart(70, 70, 'M', 'M', r, t0)
const KV_NP_noBh = 21000 * aXY_noBh
console.log(`=== KV_NP zonder broken-heart ===`)
console.log(`ä_{x|y} (geen broken-heart) = ${aXY_noBh.toFixed(4)} jaar-eenheden`)
console.log(`KV_NP (y0=21k, geen bh)     = €${KV_NP_noBh.toFixed(0)}`)
console.log()

console.log(`=== Vergelijking met broken-heart (uit engine, v2.2.11) ===`)
console.log(`KV_NP (y0=21k, MET bh)      = €${out.KV_NP.toFixed(0)}`)
console.log(`Δ broken-heart-effect       = €${(KV_NP_noBh - out.KV_NP).toFixed(0)} = ${((KV_NP_noBh - out.KV_NP) / KV_NP_noBh * 100).toFixed(1)}% lager dóór broken-heart`)
console.log()

// En de verwachte sterfleeftijd
const expectedDeath = (() => {
  let sum = 0
  for (let t = 0; t < 40; t += 1/12) {
    const survivalAtT = survivalProb(70, t, t0, 'M', 1.0, data)
    const survivalAtTplus = survivalProb(70, t + 1/12, t0, 'M', 1.0, data)
    const deathProb = survivalAtT - survivalAtTplus
    sum += (70 + t) * deathProb
  }
  // Plus residue
  const tailSurvival = survivalProb(70, 40, t0, 'M', 1.0, data)
  sum += 110 * tailSurvival // benadering
  return sum
})()
console.log(`Verwachte sterfleeftijd 70M onder AG2024: ${expectedDeath.toFixed(1)} jaar (vergelijk Hans's UI: 85,3)`)
