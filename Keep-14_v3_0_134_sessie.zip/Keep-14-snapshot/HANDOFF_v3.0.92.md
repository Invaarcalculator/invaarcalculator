# HANDOFF v3.0.92 — Invaarcalculator® release-klaar (?-tekst-cleanup, auditscherm → audit-rapport)

**Datum:** Zo 10 mei 2026
**Versie:** v3.0.92
**Status:** Release-klaar, alle 6 testsuites groen
**Werkdir:** `/home/claude/Keep-14/`

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip:
  unzip /mnt/user-data/outputs/Keep-14_v3.0.92_complete.zip -d /home/claude/

Dependencies (na verse restore):
  cd /home/claude/Keep-14 && npm install --silent

Build calculator naar /mnt/user-data/outputs/calculator.html (default fonds=sspf):
  cd /home/claude/Keep-14 && npx tsx build.calc.ts

Build met expliciete fonds-keuze:
  cd /home/claude/Keep-14 && npx tsx build.calc.ts --fonds=sspf

Volledige regression-suite (6 test-files, alle groen verwacht):
  npx tsx test_browser_calc.ts        # M1/M2/cascade smoke + ankers + audit-rapport
  npx tsx test_fonds_modal.ts         # Fonds-?-modal cascade-render
  npx tsx test_aftrek_komma.ts        # NL-decimaalkomma in cascade
  npx tsx test_cascade.ts             # Cascade-tabel + fonds_fonds2 absent
  npx tsx test_print_report.ts        # PDF-rapport-generator (Mijn rapport)
  npx tsx test_v3_cascade.ts          # Engine-only cascade-ankers (regressie-anchor)
```

**Werkafspraken:**
- Stap-voor-stap, één wijziging per turn (Werkafspraak 12)
- Alle fonds-parameter-wijzigingen voorzien van bron-citaat in `fondsen/sspf/fonds.config.ts`
- "Persoonlijk pensioenvermogen" canonical in UI; geen "potje"
- Géén em-dashes (—) in user-facing tekst
- NL-decimaalkomma overal
- Sidebar-preview niet geschikt voor print/popup-tests (gebruik visuele review op vol scherm)
- **HANDOFF altijd in werkdir én zip** (Werkafspraak 13, 06-05-2026)
- **?-helptekst is puur invul-help, geen op- of aanmerkingen, geen parameters tussen haakjes** (Werkafspraak 14, 10-05-2026 — zie §4 v3.0.92-a)

---

## 2. Architectuur — fonds-agnostisch via build-time-injectie (v3.0.76+)

**De codebase werkt voor één fonds per build.** Voor een tweede fonds maak je een tweede build vanaf dezelfde codebase:

```
/src/                          ← fonds-onafhankelijk (engine, UI, schema, types)
/fondsen/sspf/fonds.config.ts  ← SSPF-data: M1, M2, AanwendingsCascade
/fondsen/<id>/fonds.config.ts  ← (later) ABN of ander fonds
```

Esbuild path-alias `~fonds` → `/fondsen/<id>/fonds.config.ts`. Build-script accepteert `--fonds=<id>`, default `sspf`. Tsconfig.json heeft path-alias zodat tsx + type-check werken.

---

## 3. Numerieke ankers (canoniek voor v3.0.92, ongewijzigd t.o.v. v3.0.91)

### UI-default scenario
Bij default-state (x0=70, pen=€100k, NP=€70k, DG=135%, fondsvermogen=€26.000m, bijstort=€500m, wettelijk=2%, RDR=€500m, compdepot=€400m, spreiding=∞, f=0,90):

- **KV M1** = € 1.679.814
- **PPV M2** = € 2.174.362
- **Verdeelbaar overschot** = € 5.956 mln (cascade-eindrij)
- **Verwachte sterfleeftijd (lifeExp_x0)** = 86,02

### Cascade-test (test_v3_cascade.ts) — eigen inline params, **stabiele regressie-anchor**:
- KV M1 = € 543.096
- ppkTotal v3.0 N=10 = € 569.457 (Δ 4,85%)
- ppkTotal v3.0 N=∞ = € 569.889 (Δ 4,93%)
- ppkTotal R9.30 LEG = € 572.166 (Δ 5,35%)

---

## 4. Versie-overzicht v3.0.91 → v3.0.92

### v3.0.92-a — ?-helptekst cleanup naar pure invul-help [DECISION]

**Probleem:** 12 ?-modals in `HELP_CONTENT` (`src/ui.app.ts`) bevatten een mix van invul-help, conceptueel commentaar, typische-waarden-anekdotes en theoretische uitleg. Voor de eindgebruiker (gepensioneerden, niet-actuarissen) staat de feitelijke invul-instructie verstopt tussen achtergrond-prose. Ook overal parenthetische parameter-symbolen ((KV), (PPV), (r), (π), (m), (N), (t₀), (ω), (DG), (MVEV), (RTS)) die voor leken eerder afschrikken dan informeren.

**Werkafspraak 14 vastgelegd:** ?-helptekst is **puur invul-help**, géén op- of aanmerkingen, geen parameters tussen haakjes.

**Wijzigingen per modal:**

| Key | UI-locatie | Voor | Na |
|---|---|---|---|
| `x0` | "Uw geboortedatum" | 2 secties commentaar over leeftijdseffect + AG2024 | 1 invul-zin; titel "Uw geboortedatum" |
| `pen` | "Pensioen" / "Pensioen tot knip" | UPO-vindplaats + commentaar over schaling | alleen UPO-vindplaats |
| `y0` | "Uw partner krijgt na uw overlijden" | UPO-vindplaats + commentaar 70%-norm | alleen UPO-vindplaats |
| `x_partner` | "Geboortedatum partner" | 2 secties commentaar joint-life + broken-heart | 1 invul-zin; titel "Geboortedatum partner" |
| `r` | label "Rekenrente" | 2 secties theoretisch + DNB/RTS-typische-waarden | 1 zin: "Verschuif de slider om een rekenrente te kiezen tussen 0% en 4%" |
| `dekkingsgraad` | label "Dekkingsgraad" | 2 secties betekenis + MVEV/typische-waarden | 1 zin met range 100%–170% |
| `spreidingN` | label "Spreidingstermijn" | 2 secties Bijlage 2a achtergrond + cohort-effect | 1 zin: "Kies tussen 10 jaar of levenslang." |
| `hooglaag` | radio "Hoog-laag-uitkering" | 3 secties (wat-is + wat-vult-u-in + effect) | alleen "WAT VULT U IN?" |
| `vpvAftrekPct` | (deprecated) | deprecated-pointer naar cascade | ongewijzigd |
| `fonds` | "Fondsparameters"-knop | parameter-parens overal | parens gestript: titles, currentValue, alle 6 row-labels |
| `legal`, `uitleg` | top-line knoppen | reference-info | ongewijzigd (scope-keuze user) |

**Geraakte parens-symbolen:** (KV), (PPV), (r), (t₀), (π), (m), (ω), (N), "DG =", "rekenrente r =". Allen verdwenen uit user-facing tekst.

**Niet-geraakt** (bewust, scope-keuze):
- "(Bijlage 2a Regeling Pw)" in fonds-modal-intro — wettelijke verwijzing, geen parameter
- "(value based ALM)" in legal — definitie van vba
- "(Wtp)" in uitleg — uitleg-scope bleef ongewijzigd

**Files:** `src/ui.app.ts` regel 460-705 (HELP_CONTENT en buildFondsHelp). Tests ongewijzigd (geen ?-tekst-assertions).

### v3.0.92-b — Auditscherm vervangen door audit-rapport [DECISION]

**Probleem:** Auditscherm zat verborgen achter een toegangscode (`AUDIT_CODE = 'innovation-nestor2026'`) via een `<details>`-blok of URL-parameter `?audit=...`. Inline-render via view-toggle die alleen verscheen na unlock. Voor professionals/auditors (de doelgroep) was deze code-bescherming overbodig en bovendien beperkte het de afdrukbaarheid van de audit-uitvoer. De pendant "Mijn rapport" toonde dat de print-rapport-aanpak (browser-PDF via `@media print` + `#print-report`) een nettere, deelbare deliverable oplevert.

**Werkafspraak 15 vastgelegd:** audit-uitvoer verloopt via een rapport-knop, niet via een aparte view of code-bescherming.

**Refactor in twee files:**

1. **NIEUW** `src/ui.audit-report.ts` (~360 regels) — paralleel aan `ui.print.ts`:
   - `AuditReportInput` interface (deelnemer + parameters_m1 + parameters_m2 + lastM1/2 + errors + version/date)
   - `buildAuditReportHtml(input)` met 6 secties:
     1. Kop + invoer
     2. Module 1: decompositie/deepdive/diagnose + parameterset
     3. Module 2: output-decompositie + cohort-deepdive (15-rijen-tabel met verifieerbaarheidshaak) + parameterset
     4. UI-disclosure-eisen (M1 + M2 gescheiden lijsten)
     5. Methodologie + spec-verwijzingen + formules-appendix
     6. Disclaimer
   - Hergebruikt `pr-section`, `pr-table`, `pr-pagebreak`, `pr-disclaimer`, `cohort-table`, `modtag-shared/m1/m2` CSS-classes
   - `triggerAuditReport(input)` paralleel aan `triggerPrint`: vult `#print-report`, opent `window.print()` met setTimeout(50ms) voor Safari/iOS

2. **AFGESLANKT** `src/ui.app.ts`:
   - **Verwijderd:** `AUDIT_CODE` constante, `state.view`, `state.auditUnlocked`, `view-toggle`-blok, `audit-unlock-form`-blok (`<details>` met code-input), URL `?audit=`-parser, view-toggle event-handler, audit-code event-handler, `renderM1Audit()`, `renderAudit()`, `M1_OUTPUT_LABELS`, `M1_PARAM_LABELS`, import `renderM2Audit` uit `ui.m2`
   - **Toegevoegd:** import `triggerAuditReport`, knop `#audit-report-btn` in pane-actions naast `#print-report-btn`, click-handler voor audit-rapport-btn

3. **TEST-AANPASSING** `test_browser_calc.ts`:
   - `window.print` gestubt voor jsdom (analoog aan `test_print_report.ts`)
   - Test 6 herschreven: klik op `audit-report-btn` → controleer `#print-report.innerHTML` op 20.000+ chars + cohort-table 15 rijen + "Verifieerbaarheidshaak"-tekst + ≥9 shared-modtags + ≥1 M1-modtag + ≥11 M2-modtags

**Architecturele notitie:** `renderM2Audit()` in `src/ui.m2.ts` blijft als geëxporteerde functie bestaan (legacy export), maar wordt nergens meer aangeroepen. `src/ui.m1.ts` was al dood (alleen genoemd in comments) — beiden te verwijderen in latere refactor (zie §7 item 12).

**Geen migratiepad voor URL-bookmarks:** wie een `?audit=innovation-nestor2026`-bookmark had komt nu op de gewone calculator-pagina; klik op "Audit-rapport" voor de uitvoer.

---

## 5. Tests-status v3.0.92

Alle 6 test-suites groen:

| Test | Wat het dekt | v3.0.92-status |
|------|---|---|
| test_browser_calc | UI smoke, KV/PPV-ankers (1.679.814 / 2.174.362), cascade-sliders, **audit-rapport-knop** | ✓ Test 6 herschreven |
| test_fonds_modal | Fonds-?-modal opent, cascade-tabel render, fonds-naam zichtbaar | ✓ ongewijzigd |
| test_aftrek_komma | NL-decimaalkomma in cascade-tabel + fonds-modal | ✓ ongewijzigd |
| test_cascade | Cascade-tabel verschijnt na klik, fonds_fonds2 afwezig | ✓ ongewijzigd |
| test_print_report | Mijn rapport bevat KV, PPV, cascade-data | ✓ ongewijzigd |
| test_v3_cascade | Engine-only ankers (stabiele regressie-anchor) | ✓ ongewijzigd |

**Test 6 nieuwe assertions (audit-rapport):**
- audit-rapport gevuld (≈20.029 chars): ✓
- cohort-table 15 rijen: ✓
- Verifieerbaarheidshaak-tekst: ✓
- shared-modtags 18 (≥9): ✓
- M1-modtags 2 (≥1): ✓
- M2-modtags 12 (≥11): ✓

---

## 6. Architecturele aandachtspunten genoteerd

- **DG-afhankelijke bijstort** (€500m/€650m/€850m staffels in fondsdata-comment) niet gemodelleerd; gebruiker kan inconsistente combinaties verkennen via slider zonder waarschuwing
- **Engine modelleert standaardregel** (Bijlage 2a Pw); vba-fondsen niet correct (in disclaimer benoemd)
- **Cascade in fonds-?-modal en M1/2-pane tonen dezelfde getallen**: M1/2-pane is interactief, fonds-modal toont read-only-versie via `buildAanwendingsCascadeBlock`
- **vpvAftrekPct in m2-state is afgeleide**; bron-of-waarheid zijn cascadeOverrides + fondsvermogen + DG + bijstort. UI synchroniseert in recompute()-start
- **ageFromDob snap-to-integer** regelt 365.25-edge rond verjaardagen
- **Alle aanrakingspunten cascade-componenten triggeren full render()** (niet `updateOutputsInPlace`), want afwijking-markers en banner moeten verspringen + cascade-tabel-getallen mee-bewegen
- **Verdeelbaar overschot — uw aandeel** hangt af van zes parameters: uw KV (M1-deelnemer-data) + spreidingstermijn + rekenrente + fondsdemografie (verborgen) + sterftekansentabel (AG2024) + de cascade-componenten
- **Ervaringssterfte 0,90 is vlak** (geen leeftijds-/gender-differentiatie)
- **Audit-rapport en Mijn rapport delen `#print-report`** (sequentiële vulling): elke knop overschrijft de vorige inhoud voordat `window.print()` opent. Geen race omdat de DOM-mutatie synchroon is en `window.print()` blokkerend wordt aangeroepen
- **`renderM2Audit` in `src/ui.m2.ts` is dead-code** sinds v3.0.92 (export blijft bestaan, geen aanroepers); te verwijderen in code-opruim-ronde

---

## 7. PENDING action items

### Actuaris-bevindingen — actief binnen scope (gepensioneerden + publieke informatie)

Vier punten resterend uit de v3.0.91 deep-dive (ongewijzigd):

1. **C1 — Compensatiedepot-routing transparantie** (HOOG)
   €400 mln wordt uit cascade geknipt zonder zichtbare toekenning aan een groep. Voor gepensioneerden onduidelijk waar geld heen gaat. Voorstel: help-icon-tooltip op cascade-rij "Compensatiedepot" met tekst "toegekend aan actieven, niet aan gepensioneerden". Gebruikt bestaand `helpIcon()`-patroon.

2. **D2 — RDR labelen als bestemd voor pensioengerechtigden** (MIDDEL)
   €500 mln RDR komt later via solidariteits-/risicodelingsmechanisme deels terug naar gepensioneerden. Tool toont alleen "weg uit cascade". Voorstel: vergelijkbare help-icon-tooltip; kan in dezelfde turn als C1.

3. **D5 — DG-afhankelijke bijstort-staffel** (HOOG)
   Bijstort vast op €500m, beweegt niet mee met DG-slider. Bij DG-tegenvaller stijgt werkgeversbijstort juist (publieke staffel: ≥135% €500m, 130-135% €650m, 125-130% €850m). Voor gepensioneerden misleidend. DG<125% staffel-waarde uit publieke bron nog te verifiëren. Twee opties: visuele waarschuwing onder slider, óf functioneel meebeweeg-mechanisme.

4. **A3 — Broken-heart factoren uit AG-2018-publicatie** (MIDDEL)
   Huidige placeholders (`bh₀(M)=1,50`, `bh₀(V)=1,25`, lineair 5j) in `engine.m1.ts` regel 489-500 zijn bron-comment "todo AG-2018". Echte waarden uit AG-werkgroep "Sterfte na overlijden partner" (2018) opzoeken. Effect: 1-3% op KV_NP, dus ~0,3-1% op KV-totaal.

### Buiten scope (forward-projectie + nieuw pensioen-omrekening; uitgesteld per user)
- **D3** — Variabele uitkering-projectie post-invaren (M3 Monte Carlo)
- **D4** — Partner-na-overlijden-uitkering-per-maand-projectie
- **PPV → maandbedrag onder SPR** — omrekening naar nieuw pensioen

### Buiten scope (geaccepteerd voor educatieve scope, met disclaimer)
- **A1** — Vlakke r=2,5% vs UFR-curve (voor gepensioneerden duratie 8-12 → effect <1%)
- **A4** — π=0 (geen voorwaardelijke indexatie)
- **A5** — Pensioenleeftijd 65 hardcoded in cohort-proxy (effect <0,5% via ratio-cancellatie)
- **B1** — 67%-toets art. 150n lid 4 Pw (bestuurs-verantwoordelijkheid, niet gepensioneerde-vraag)
- **B3** — Geen vba-pad
- **B4** — N=1000 als ∞-proxy (engineering-correct via ratio-cancellatie)
- **C2** — SSPF-genderweging hardcoded in engine.m2 (pas relevant bij ABN-build)
- **C3** — NP-proxy (70%, partner −3j, allen gehuwd) — <0,5% effect via ratio-cancellatie

### Strategisch (eerder geïdentificeerd, nog steeds open)
5. **Fondsdemografie zichtbaar/aanpasbaar maken** — preset 'gesloten' nu verborgen; beïnvloedt PPV-uitkomst sterk via `x_fonds`
6. **M1 KV-fix actieve deelnemer**
7. **M3 Monte Carlo** (overlapt met D3)
8. **M4 DB-vs-WTP**

### Operationeel
9. **Hosting-deployment** naar invaarcalculator.nl
10. **iPad-issue** (HTML opent niet) — niet gediagnosticeerd
11. **Visuele review v3.0.92** in echte browser door user — twee items:
    - ?-helpteksten cleaner uitstralen (kortere modals)
    - Audit-rapport via "Audit-rapport"-knop opent print-dialoog met technische uitvoer

### Code-opruim (latere refactor)
12. **Backward-compat-symbols opruimen**: `SSPF_M1_PLACEHOLDER`, `SSPF_M2_PLACEHOLDER`, `FONDSEN`, `FondsId` nog gebruikt in `src/test_engine.ts`, `src/test_engine.m2.ts`, `src/ui.m1.ts`. Allen kunnen na verificatie weg ten gunste van directe `FONDS`-import. **Nieuw v3.0.92:** ook `renderM2Audit` in `src/ui.m2.ts` en heel `src/ui.m1.ts` zijn dead-code geworden (zie §6 + §2). De label-tabellen `M1_OUTPUT_LABELS` / `M1_PARAM_LABELS` zijn al verwijderd uit `ui.app.ts` en gemigreerd naar `ui.audit-report.ts`.

---

## 8. Source-files-overzicht (canoniek voor v3.0.92)

```
/home/claude/Keep-14/
├── src/
│   ├── ui.app.ts              # main, ~1700 regels (was ~1885 in v3.0.91)
│   │                          # afgeslankt: -view/auditUnlocked, -renderM1Audit/renderAudit,
│   │                          # -M1_OUTPUT_LABELS/M1_PARAM_LABELS, -view-toggle UI,
│   │                          # -audit-unlock-form, -URL ?audit=parser, +audit-report-btn
│   ├── ui.m2.ts               # M2-render (renderM2Audit nu dead-code, te verwijderen)
│   ├── ui.m1.ts               # dead-code (al sinds v3.0.x; te verwijderen)
│   ├── ui.print.ts            # PDF-rapport (Mijn rapport)
│   ├── ui.audit-report.ts     # NIEUW v3.0.92 — audit-rapport (paralleel aan ui.print)
│   ├── ui.shared.ts           # gedeelde helpers
│   ├── engine.m1.ts           # KV-berekening (broken-heart placeholders regel 489-500)
│   ├── engine.m2.ts           # PPV-berekening (standaardregel)
│   ├── schema.v2.ts           # types + zod-validatie
│   ├── fondsdataset.ts        # bridge: importeert FONDS van ~fonds
│   └── fondsdataset.types.ts  # fonds-onafhankelijke types
├── ag2024.json                # AG-prognosetafels (geinjecteerd in HTML-template)
├── fondsen/
│   └── sspf/
│       └── fonds.config.ts    # SSPF-bron-van-waarheid (ervaringsSterfte 0,90)
├── build.calc.ts              # build-script (--fonds=<id>-flag, font-tokens in :root)
├── tsconfig.json              # paths-alias '~fonds'
├── package.json               # tsx + jsdom + esbuild + zod
├── test_browser_calc.ts       # ankers + audit-rapport-flow (Test 6 herschreven v3.0.92)
├── test_fonds_modal.ts
├── test_aftrek_komma.ts
├── test_cascade.ts
├── test_print_report.ts
├── test_v3_cascade.ts         # engine-only stabiele regressie (ongewijzigd)
├── HANDOFF_v3.0.91.md         # vorige handoff
└── HANDOFF_v3.0.92.md         # ← deze file
```
