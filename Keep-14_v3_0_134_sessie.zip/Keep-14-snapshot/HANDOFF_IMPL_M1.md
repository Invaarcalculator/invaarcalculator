# WTP-PENSIOENCALCULATOR — HANDOFF M1-IMPLEMENTATIE

Datum: 23-04-2026 23:10
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Licentie: CC BY-NC 4.0

Dit document markeert de afronding van de **M1-implementatie-sessie** (23-04-2026, avond) — de eerste bouw-sessie op basis van SCHEMA v2.0 M1-block. Het sluit een track: van spec → SCHEMA → werkende calculator. Scherm 1 functioneert end-to-end in een browser.

---

## KERN IN ÉÉN ALINEA

Op 23-04-2026 is na twee voorbereidingsrondes (spec-track v2.2.9, SCHEMA-track v2.0 M1-block) in één sessie een werkende `scherm1.html` opgeleverd: 164 KB single-file calculator die de huidige waarde (KV) van een pensioenaanspraak berekent volgens ENGINE SPEC §2.5-formules, met AG2024-sterftetafel per geslacht (periode-snapshot t₀=2026), §2.7 ρ-fallback-ladder, Model-D UX (casual scherm 1 + audit-scherm M1-sectie met alle 7 UI-disclosures mechanisch gerenderd uit SCHEMA metadata), en drie performance-optimalisaties (debounce 150ms op numerieke input, Enter-doorbreekt-debounce met KV-flash, annuïteit-memoisatie). Acht engine-regressietests groen, acht browser-simulatie-tests groen. Geen spec-patches nodig; geen SCHEMA-wijzigingen; alle keuzes uit SCHEMA-M1-sessie bleken bruikbaar zonder aanpassing. Verificatie: 67M + 65V + €21k NP + SSPF-defaults = € 808.815 (engine-test en browser-test geven identieke waarde). De geketende methodologie (stap-voor-stap spec-beslissingen → SCHEMA als contract → implementatie als afleiding) werkt in praktijk zonder terug-patches. Scherm 1 is productie-klaar als proof-of-concept; scherm 2/3/4 zijn volgende fases.

---

## STAND VAN ZAKEN — M1 WERKEND

**Hoofdartefact:**
- `scherm1.html` (164 KB, single-file) — werkende calculator; open in elke moderne browser, offline bruikbaar, geen CDN-dependencies

**Bron-artefacten (implementatie-track):**
- `src/engine.m1.ts` (~260 regels) — §2.5-formules, §2.7-ρ-ladder, AG2024-resolver
- `src/ui.m1.ts` (~380 regels) — Model-D casual + audit renderer, event-handlers, debounce, flash
- `src/fondsdataset.ts` (~25 regels) — SSPF-placeholder (R9.30-defaults)
- `extract_ag2024.py` — AG2024.xlsx → JSON extractie (leeftijden 0-120, jaren 2022-2050)
- `ag2024.json` (82 KB) — geëxtraheerde data voor HTML-inbedding
- `build.ts` — esbuild-bundelaar + HTML-template-injector
- `src/test_engine.ts` — 8 regressie-assertions op engine
- `test_browser.ts` — 8 browser-simulatie-assertions via jsdom

**Technische stack:**
- TypeScript 5.4 + Zod 3.23 als SCHEMA-runtime
- esbuild 0.21 voor bundeling naar single-file
- jsdom 24 voor browser-simulatie-testen
- Vanilla DOM voor UI (geen framework, single-file HTML, geen externe dependencies)

**Implementatie-beslissingen genomen in deze sessie:**

| # | Onderwerp | Keuze | Rationale |
|---|---|---|---|
| 1 | Build-target | Single-file HTML met inline JS en JSON | Conform R9.30-filosofie; offline-bruikbaar; audit-vriendelijk |
| 2 | AG2024-opslag | JSON embedded in HTML (82 KB) | Geen runtime-fetch; werkt zonder netwerk; kan je in de browser inspecteren |
| 3 | AG2024-jaren geëmbed | 2022-2050 (29 jaren), niet 2022-2200 | HTML-omvang-beperking; voor SSPF t₀=2026 ruim voldoende; uit te breiden bij behoefte |
| 4 | `gemengd`-weging voor M1-berekening | SSPF-deelnemer-prior 95/5 (§11.17) | Spec-default; samensteller kan overriden via genderMix-parameter |
| 5 | Memoisatie-strategie | In-memory Map met 256-entry LRU-cap | Voorkomt herberekening bij herhaalde (x, r, g)-combinaties (bijv. rente-slider) |
| 6 | Debounce-tijd | 150ms | Onderzocht optimum tussen vloeiend typen en snelle feedback |
| 7 | Enter-gedrag | Doorbreek debounce + 450ms flash-animatie op KV-kaart | Gebruikersverzoek tijdens sessie; bevestiging van input-acceptatie |
| 8 | Blur-gedrag | Zelfde als Enter (onmiddellijke recompute + flash) | Tab-navigatie voelt consistent |
| 9 | Select (dropdown) | Geen debounce, direct recompute | Één klik = één beslissing; debounce zou misleidend traag voelen |
| 10 | Partner-checkbox | Onmiddellijk tonen/verbergen partner-velden + recompute | Discrete keuze, geen typpatroon |
| 11 | Rente-slider | requestAnimationFrame-throttled | Synct met browser-frame, voorkomt queue-opbouw bij slepen |
| 12 | Regressie-test-strategie | 8 engine-unit-tests + 8 browser-simulatie-tests; geen formele TEST_FIXTURES v1 nog | Dat is §11.11-aanbeveling voor latere sessie; voor M1-demo volstaan ad-hoc assertions |

**Geen SCHEMA-wijzigingen of spec-patches in deze sessie.** Alle SCHEMA v2.0 M1-contracten zijn zonder aanpassing gebruikt; `M1.deelnemer.parse()`, `M1.parameterset.parse()` en het `FIELD_REGISTRY` werken zoals bedacht.

---

## ACTIEVE WERKAFSPRAKEN

Behouden uit alle voorgaande sessies, bevestigd werkend in implementatie-context:

1. **Narratief kompas (§1.1)** — in de UI vertaald als: casual scherm 1 toont alleen "hoofdpad"-velden (KV totaal als anker); decompositie (OP/NP) verschijnt alleen als er partner is; audit-scherm toont de volledige actuariële structuur.
2. **Educatieve leidraad** — alle 7 UI-disclosures uit `fieldsWithDisclosure()` verschijnen mechanisch op het audit-scherm; bij de deelnemer-`gemengd`-keuze verschijnt de disclosure direct bij het veld (niet alleen in audit).
3. **Spec-met-reserveringen-principe (§12.5)** — bewust gevolgd: R9.30-defaults als placeholder (€27.202 mln fondsvermogen, `f=1.0`, SSPF-gender-weging 95/5). Variant-A-ρ-afleiding actief indien samensteller `uitvoeringskostenJaarlijks` vult; anders fallback naar ultieme default 0,02.
4. **Stap-voor-stap-methode** — Hans heeft in deze sessie niet knelpunt-voor-knelpunt beslist (gezien het signaal "go for it, only ask when stuck"), maar twee signalen ondersteund: (a) trage respons → drievoudige optimalisatie; (b) Enter-feedback → flash-bevestiging. Tussen deze signalen was directe afwerking mogelijk omdat SCHEMA-M1 alle contract-keuzes al had vastgelegd.
5. **SSPF-prior voor fallbacks** — in engine-implementatie actief (95/5 deelnemer-weging voor `gemengd`); staat als comment in engine.m1.ts met verwijzing naar §11.17.
6. **Timestamp-conventie** — `TZ="Europe/Amsterdam"` gehanteerd.
7. **Bronhoudbaarheid boven snelheid** — `SSPF_M1_PLACEHOLDER` heeft expliciete comments welke waardes R9.30-default versus SSPF-publiek-toekomst zijn; upgrade zonder code-wijziging mogelijk.
8. **Bronnenonderzoek** — niet ingeroepen in deze sessie.
9. **R9.30-productiebestand (`21-04-2026_2216.html`) onaangeroerd** — gerespecteerd. `scherm1.html` is greenfield. Formele regressie-vergelijking staat open als latere stap.
10. **Patch-administratie-hygiëne** — niet van toepassing (geen patches nodig).
11. **Parameterset-discipline als architecturale laag** — zichtbaar in UI: audit-scherm toont welke parameter een disclosure-plicht draagt (§5.12.2/§5.12.5/§5.12.6). SSPF-samensteller krijgt dat overzicht cadeau bij elk dataset-load.
12. **Eerlijke boekhouding bij vereenvoudiging** — in deze sessie toegepast bij: (a) opmerking dat de mock-berekening in de eerste mockup een *schatting* was, nu vervangen door echte engine; (b) eerlijk benoemen dat performance-issues reëel waren en rechtvaardig oplossen.
13. **SCHEMA-afgeleide spec-patches toegestaan** — geen ingeroepen; SCHEMA bleek compleet.
14. **Implementatie-afgeleide SCHEMA/spec-patches toegestaan (nieuw)** — tijdens implementatie kunnen omissies in SCHEMA of spec opduiken. In deze sessie niet voorgevallen; SCHEMA-M1-sessie had voldoende afgedekt. Patroon beschikbaar voor M2/M3/M4-implementatie waar nieuwe wiskunde wordt ingevoerd.

---

## KRITIEKE ARCHITECTUUR — STRUCTUREEL VASTGELEGD

M1-implementatie-aanvullingen op voorgaande architectuur-lijst zijn **vetgedrukt**.

### Module-structuur

Ongewijzigd uit eerdere handoffs. **M1 is nu productie-klaar als werkend scherm.**

### Build-architectuur (nieuw)

- **Single-file HTML** als eind-artefact (scherm1.html, 164 KB). Bundle-omvang: esbuild-geminifieerde JS 77 KB + AG2024 JSON 82 KB + HTML/CSS 5 KB
- **esbuild** als bundelaar met format='iife', target='es2020'; werkt offline zonder ES-modules-dependency
- **AG2024-data** inline als `window.__AG2024__`-constante in eerste script-blok, vóór de bundel-code. Geen fetch-calls in runtime
- **Geen externe runtime-dependencies** — Zod is meegebundeld, geen CDN-links, geen NPM-require in browser
- **TypeScript als enige brontaal** voor engine + UI; gedeeld SCHEMA-bestand (schema.v2.ts) is de contract-brug
- **Reproducible build:** `npm install` → `npx tsx build.ts` geeft identieke scherm1.html tot op de byte

### UX Model D (implementatie-bewijs)

Ongewijzigd uit SCHEMA-M1. **Bewijs in deze sessie: mockup-filosofie werkt — het casual-scherm rendert uit `fieldsByDisplay('M1', ['hoofdpad'])`, het audit-scherm uit de andere display-klassen + `fieldsWithDisclosure()`. Geen enkele hardcoded veldlijst in UI-code.**

### Performance-architectuur (nieuw)

- **Debounce 150ms** op numerieke input (pen, y0, x_partner); voorkomt per-keystroke recompute
- **Enter-key doorbreekt debounce** + start 450ms kleurflash op .kpi-card; geeft expliciete input-bevestiging
- **Blur-event** doorbreekt eveneens debounce; tab-navigatie voelt consistent
- **Select-wijzigingen** niet gedebounced; direct recompute (discrete keuze)
- **requestAnimationFrame-throttling** op rente-slider; voorkomt queue-opbouw bij sleep
- **Annuïteit-memoisatie** in engine: `Map<key, result>` met 256-entry LRU-cap; key = `${x}|${r}|${t0}|${g}|${m}|${pi}|${f}|${omega}`. Bij rente-slider-wijzigingen (veel identieke x/g/...) is dit effectief
- **Partiële re-render** via `updateOutputInPlace()` voor live-input (geen volledige DOM-rebuild); volledige render alleen bij view-toggle casual↔audit

### Numerieke correctheid (nieuw)

Engine-regressie geverifieerd (Test 5 engine + Test 4 browser, beide €808.815):

- `ä(67, 2%, M) = 14.421`, `ä(67, 2%, V) = 16.060` (gender-verschil 11,4%)
- `lifeExp(67, M) = 84.65`, `lifeExp(67, V) = 87.01`
- `q(67, 2026, M) = 0.01210`, `q(67, 2026, V) = 0.00828` (V/M = 0.685)
- `KV_OP (67M, €30k, ρ=0.02) = €441.283`
- `KV_NP (65V, €21k, ρ=0.02) = €367.532`
- `KV totaal = €808.815`
- NP-aandeel 45,4% (bevestigt §1.1 "NP is dominant deel van aanspraak" voor SSPF-profiel)
- ρ-fallback-ladder 3 stappen alle geverifieerd (Variant-A, direct, default)
- NP-fallback 70% van pen (§11.5 v1.8) geverifieerd

---

## OPEN BESLISPUNTEN — NA M1-IMPLEMENTATIE

**M1-scherm is functioneel compleet als proof-of-concept.** Geen open punten binnen M1-implementatie.

**Volgende fases:**

1. **SCHEMA v2 M2-block** — scherm 2 (potje). Uitgebreide SCHEMA met OP/NP-decompositie, sluitingscontrole, demografie-input. Voorbereid in `PROMPT_nieuwe_chat_schema_M2.md`
2. **M2-implementatie + scherm 2 integratie** — potje-berekening (§3.5 formules), audit-scherm uitbreiden met M2-sectie, mockup-renderer laten detecteren M2-velden
3. **SCHEMA v2 M3-block + M3-implementatie** — Monte Carlo projectie met banden, gekoppelde v2-paden-validatie
4. **SCHEMA v2 M4-block + M4-implementatie** — waardevergelijking; waarschijnlijk spec-patches nodig voor naamgeving-verzoening (B_OP vs pen, etc.)
5. **FONDS_DATASET-compositie** — samenvoeging M1/M2/M3/M4-subsets tot één schema met top-level meta/regeling/herkomst
6. **TEST_FIXTURES v1** — vaste numerieke assertions per module (§11.11 aanbeveling); gebruikt SCHEMA voor dataset-construction
7. **Regressie-vergelijking met R9.30** — bewijzen dat M1-output overeenkomt met huidige calculator binnen verwachte ~0.5-1% afwijking (v1.2 annuïteitsconventie-migratie §2.5)
8. **UI-copy- en design-ronde** — huidige Nederlandse copy is functioneel; geen visuele identiteit, geen toegankelijkheid-audit, geen mobile-optimalisaties. Aparte sessie.

**Mogelijke later heropen (niet blokkerend):**

- M1-regressie-vergelijking met R9.30 (punt 7 hierboven)
- AG2024 jaren > 2050 inbedden als SSPF of andere fondsen latere t₀ kiezen (huidige subset 2022-2050)
- Parameterset-override via audit-scherm (power-user kan r, f, π, ρ direct wijzigen) — nu alleen rente-slider op casual; audit-scherm toont waardes maar bewerkt niet
- Export-functionaliteit (PDF-snapshot, delen-link, CSV-download)

---

## DATA-TODO'S VOOR HANS (NIET-BLOKKEREND)

Behouden uit alle voorgaande handoffs plus één nieuwe:

1-9: ongewijzigd uit HANDOFF_SCHEMA_M1
10: ongewijzigd uit HANDOFF_SCHEMA_M1
11. **Nieuw bij M1-implementatie:** AG2024-publicatiedatum controleren (KAG 12-09-2024 in spec) tegen feitelijke datum; ervoor zorgen dat `AG2024.xlsx` in de zip inderdaad de publieke versie is en niet een draft

---

## COHERENTIE-CHECK UITGEVOERD BIJ AFRONDING

Vier controles uitgevoerd tijdens implementatie-sessie:

1. **Engine ↔ SCHEMA consistency.** Elk engine-functie-signatuur gebruikt `M1Deelnemer`, `M1Parameterset`, `M1Output` uit schema.v2.ts. Bij Zod-parse-fail wordt gracefully gereageerd (state.lastError). Geen parallelle type-definities.
2. **Numerieke equivalentie engine ↔ browser.** Test 5 engine-regressie en Test 4 browser-simulatie geven identieke €808.815 voor hetzelfde input-scenario. Bewijst dat jsdom-simulatie dezelfde code-path uitvoert als een echte browser.
3. **Metadata-laag effectief in UI.** Alle 7 UI-disclosures uit `fieldsWithDisclosure()` (M1) verschijnen op het audit-scherm. Geen enkele disclosure is in UI-code hardcoded. Bij toevoeging van een nieuwe M1-disclosure in SCHEMA verschijnt hij automatisch.
4. **Optimalisaties breken correctheid niet.** Na debounce + memoisatie + partial-render zijn alle 8 browser-tests nog steeds groen; output-waardes ongewijzigd.

**Extra coherentie-check uniek voor implementatie-sessie: workflow-integriteit.**

Spec → SCHEMA → implementatie is in drie opeenvolgende sessies doorlopen, elk met eigen handoff:
- Spec-track: 4 sessies, eindigde bij v2.2.7 (HANDOFF_v2.2.7)
- SCHEMA-track: 1 sessie + 2 retro-patches (v2.2.8, v2.2.9), eindigde bij HANDOFF_SCHEMA_M1
- Implementatie-track: 1 sessie, eindigt bij dit document

Geen retro-wijzigingen aan spec of SCHEMA tijdens implementatie nodig. De iteratie van spec-patches (v2.2.8 / v2.2.9) tijdens SCHEMA-schrijven was voorspeld (werkafspraak 13) en werkte; de afwezigheid van patches tijdens implementatie bevestigt dat SCHEMA v2.0 M1-block een stevig contract is.

---

## VOLGENDE-SESSIE-AANPAK (VOORSTEL)

Drie scenario's, naar aflopende impact en prioriteit:

**Primair voorgesteld: SCHEMA v2 M2-block + M2-implementatie** — analoog aan deze sessie, maar dan voor scherm 2. SCHEMA-sessie en bouw-sessie kunnen als twee aparte sessies worden gedaan (conservatief, zoals bij M1) of gecombineerd in één langere sessie. Combinatie is verdedigbaar nu de methodologie bewezen is.

**Alternatief: UI-copy/design-ronde voor scherm 1** — voordat M2 erbij komt, eerst de huidige scherm-1-UX aankleden (copy, visuele identiteit, toegankelijkheid, mobile-responsiveness). Voordeel: scherm 1 echt publicatie-klaar voordat schaal. Nadeel: opschalen naar 4 schermen vergt later nog een design-pas.

**Alternatief: R9.30-regressie-vergelijking** — bewijzen dat M1 de huidige calculator binnen ~0,5-1% reproduceert. Sanity-check voor migratie.

**Aanbeveling**: Scenario 1 (M2-SCHEMA + implementatie) als volgende stap. Design-ronde en regressie-vergelijking passen beter als parallele of latere sessies.

---

## BRONBESTANDEN — COMPLETE INVENTARIS

**Van deze sessie nieuw:**
- `scherm1.html` (164 KB) — eind-artefact
- `HANDOFF_IMPL_M1.md` (dit document)
- `src/engine.m1.ts` — M1-engine (§2.5, §2.7)
- `src/ui.m1.ts` — Model-D UI-renderer
- `src/fondsdataset.ts` — SSPF-placeholder
- `src/test_engine.ts` — engine-regressietests
- `test_browser.ts` — browser-simulatie-tests
- `extract_ag2024.py` — AG2024-extractor
- `ag2024.json` — geëxtraheerde sterftetafel
- `build.ts` — bundelaar
- `PROMPT_nieuwe_chat_schema_M2.md` (bijgewerkt)
- `PROMPT_nieuwe_chat_impl_M2.md` (nieuw — voor de combi-sessie)
- `PROMPT_nieuwe_chat_regressie.md` (nieuw — voor R9.30-vergelijking)
- `PROMPT_nieuwe_chat_design.md` (nieuw — voor UI-design-ronde)

**Van voorgaande sessies behouden** (zie HANDOFF_SCHEMA_M1 voor volledige inventaris):
- ENGINE_SPECIFICATIE_v1.md (v2.2.9)
- HANDOFF_v2.1.md, HANDOFF_v2.1.3.md, HANDOFF_v2.1.9.md, HANDOFF_v2.2.7.md
- HANDOFF_SCHEMA_M1.md
- schema.v2.ts, smoke.test.ts, render_mockup.ts, mockup_m1.html
- tsconfig.json, package.json
- ARCHITECTUUR_v1.md, DESIGN_engine_v0.md, calculator_specificatie.docx
- SCHEMA_v1.md, STRATEGY_R9.30.md, HANDOFF_R9.30.md, 21-04-2026_2216.html
- AG2024.xlsx, 51490-Data_AG2024.xlsx

---

## AFSLUITENDE NOTITIE

Drie iteraties van de methodologie:
- Spec-track: besluit-gedreven, elk punt apart afwegen, patch
- SCHEMA-track: contract-afleiding, 9 knelpunten stap-voor-stap
- Implementatie-track: bouw volgens contract, signaal-gedreven bij UX-feedback

Elke iteratie voegde eigen discipline toe en bleek te werken. De gekoppelde artefacten — spec v2.2.9 (1970 regels), SCHEMA v2.0 M1-block (474 regels), scherm1.html (164 KB) — vormen samen een traceerbare keten: elke regel in de calculator-output kan teruggebracht worden naar een spec-paragraaf via SCHEMA-`specRef`-metadata.

Twee dingen die opmerkelijk waren in deze sessie:
- **Tempo.** Van "go for it" tot werkende calculator met drievoudige optimalisatie in één sessie-blok, zonder SCHEMA- of spec-terugpatches nodig. Dat zegt iets over de waarde van de voorbereiding — wanneer contracten eerst zijn vastgelegd, wordt implementatie een mechanische afleiding
- **Gebruikersfeedback-lus.** Twee signalen van Hans tijdens implementatie ("reageert slow as hell" / "na Enter lijkt of er niks gebeurd") leidden tot concrete verbeteringen (debounce + memoisatie; Enter-doorbreekt-debounce + flash-bevestiging) zonder SCHEMA-wijziging. UX-verfijning valt in de implementatie-laag, niet in het contract

M1 is hiermee demo-klaar. Scherm 2/3/4 zijn volgende fases.

*Einde HANDOFF_IMPL_M1.md*
