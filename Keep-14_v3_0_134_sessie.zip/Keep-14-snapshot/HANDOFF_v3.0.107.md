# HANDOFF v3.0.107 — Invaarcalculator® · werkdir-source ingehaald naar v3.0.106

**Datum:** Ma 11 mei 2026, einde-sessie
**Vorige handoff:** HANDOFF_v3.0.106.md (in werkdir)
**Huidige versie in werkdir:** v3.0.106 (`src/ui.app.ts` regel met `RELEASE_VERSION = '3.0.106'`)
**Status werkdir:** v3.0.106-source compleet, alle relevante tests groen
**Status binary:** `calculator_v3.0.106_reconstructed.html` gebouwd uit deze source (290 KB)

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip (NIEUW: v3.0.106 als baseline, niet meer v3.0.92):
  mkdir -p /home/claude/Keep-14
  cd /home/claude/Keep-14
  unzip -q /mnt/user-data/uploads/<sessie-zip>.zip
  # of, als de Keep-14-zip apart geüpload is:
  unzip -q /mnt/user-data/uploads/Keep-14_v3.0.106_complete.zip

Dependencies (na verse restore):
  cd /home/claude/Keep-14 && npm install --silent

Build calculator (default fonds=sspf):
  cd /home/claude/Keep-14 && npx tsx build.calc.ts
  # → schrijft /mnt/user-data/outputs/calculator.html (≈ 290 KB)

Regression-suite (alle 4 hoofdtests groen verwacht):
  npx tsx test_browser_calc.ts        # UI smoke, ankers, audit-rapport
  npx tsx test_aftrek_komma.ts        # NL-decimaalkomma + DG 1-decimaal
  npx tsx test_print_report.ts        # Persoonlijk overzicht + partner-toggle
  npx tsx test_v3_cascade.ts          # Engine-only cascade-ankers
```

### Werkafspraken (cumulatief, peildatum 11-05-2026)
Identiek aan HANDOFF_v3.0.106 §1. De belangrijkste twee in herhaling:
- **Werkafspraak 12**: één wijziging per turn (uitzondering: expliciet "all-in-one"-modus per gebruikers-instemming)
- **Werkafspraak 16**: elke turn die `src/`, `build.calc.ts` of `fondsen/` raakt verhoogt `RELEASE_VERSION` met +1

---

## 2. Wat is er gebeurd in deze sessie

In één lange sessie is Optie A uit HANDOFF_v3.0.106 §8 uitgevoerd:
**werkdir-source-reconstructie v3.0.92 → v3.0.106**.

### Belangrijke ontdekking
De §8-"regressie" uit HANDOFF_v3.0.106 was **niet** een rollback van source-
code, maar een **versie-constant-regressie**. De v3.0.92-zip-source bevatte
feitelijk al een groot deel van de v3.0.93..v3.0.95-mutaties (alle bijbehorende
`v3.0.93/94/95`-comment-stempels aanwezig), maar `RELEASE_VERSION` stond
achter op `'3.0.89'`. Source evolueerde wel door, alleen het zichtbare
versielabel stond stil. Werkafspraak 16 is exact het verband dat deze drift
voorkomt.

Voor v3.0.96..v3.0.106 was de doorlek gestopt; die mutaties zijn deze
sessie alsnog handmatig aangebracht.

### Per-versie reconstructie-werk dat deze sessie is uitgevoerd

| Versie | Wat in deze sessie is gedaan |
|---|---|
| v3.0.93 | Volledig aangebracht: geslacht-swap, lifeexp-caption, kpi-foot strip, divider-soft, mid-markers, CSS, live-update wiring |
| v3.0.94 | Alleen DG mid-marker 135% → 136%; rest zat al in zip |
| v3.0.95 | Nul source-edits; volledig al in zip |
| v3.0.96-105 | Allemaal aangebracht — modal-padding, modal-renderer empty-heading-skip, uitleg-modal herschreven, "huidige aanspraak" → "huidige pensioenaanspraak" (7×), DG-helpicon weg, rapport-knop labels & flex-row, spreidingstermijn WAT DOET-sectie, h1 padding weg, .m2-controls cleanup |
| v3.0.106 | RELEASE_VERSION 3.0.95 → 3.0.106 |

### Test-aanpassingen
Sinds v3.0.95 is default `heeftPartner=false`, en sinds v3.0.96 is
heeftPartner een `<select>` ipv checkbox. Twee test-files moesten daarom
worden bijgewerkt:

- **test_browser_calc.ts**:
  - Test 2 M1-anker `1.679.814` → `1.298.341` (no-partner)
  - Test 3 M2-anker `2.174.362` → `1.611.130` (no-partner)
  - Test 4 DG-default `'1.35'` → `'1.361'` (uit vpvTotal-anker)
  - Test 5 reset-value `'1.15'` → `'1.361'`
- **test_print_report.ts**:
  - Test 3 verwijdert NP-bedrag/partner-leeftijd assertions; verwacht
    nu "Partnerpensioen geen" in report
  - Test 7 omgedraaid: schakelt partner AAN (was UIT); gebruikt
    `select[data-field="heeftPartner"]` ipv checkbox; her-acquireert
    btn na partner-toggle-re-render

### Binary-diff vs reference
Reconstructed v3.0.106: 290.089 bytes
Reference v3.0.106:     293.018 bytes
Δ:                        2.929 bytes (≈ 1 %)

Geen inhoudelijke marker-verschillen. Δ vermoedelijk: andere `RELEASE_DATE`,
en cumulatieve v3.0.93-95-comment-strings die in reference-binary
opgeschoond waren maar in deze reconstructie nog aanwezig zijn.

---

## 3. Test-status v3.0.106 reconstructed werkdir

| Test | Status | Opmerking |
|------|--------|-----------|
| test_browser_calc.ts | ✓ 8/8 | ankers aangepast naar no-partner-default |
| test_aftrek_komma.ts | ✓ 3/3 | DG "136,1%" met 1 decimaal NL-locale |
| test_print_report.ts | ✓ 7/7 | Test 3+7 aangepast voor select+no-partner |
| test_v3_cascade.ts | ✓ 4/4 ankers | engine-only regressie, ongewijzigd |
| test_cwstar_smoke.ts | ✓ 4/4 smoke-tests | ongewijzigd |
| test_ui_spreidingN.ts | ✓ alle | ongewijzigd |
| test_bh_decompositie.ts | ✓ informatief | geen asserts, alleen output |
| test_hans_replication.ts | 7/10 ✓ | pre-existing, niet v3.0.96+-gerelateerd |
| test_browser.ts | ✗ kapot | legacy multi-bestand (scherm1.html); pre-single-binary; niet in §7-reconstructie-eis |

---

## 4. Numerieke ankers (canoniek voor v3.0.106) — ongewijzigd

### UI-default scenario
Bij default-state (x0=70, pen=€100k, GEEN partner, DG=136,1%, F=26.000 mln,
vpvTotal=19.100 mln (anker), bijstort=€500m, wettelijk=2%, RDR=€500m,
compdepot=€400m, spreiding=∞, f=0,90):

- **KV M1 = € 1.298.341** (alleen OP, KV_NP = 0)
- **PPV M2 = € 1.611.130**
- Verdeelbaar overschot = € 6.840 mln
- Verwachte sterfleeftijd (lifeExp_x0) = 86,02

### Bij partner aan (heeftPartner toggled to true; hydrate y0=70.000, dob_partner=65j)
- KV M1 ≈ € 1.606.774
- PPV M2 ≈ € 2.071.039

### Cascade-test (test_v3_cascade.ts), stabiele regressie-anchor
- KV M1 = € 543.096
- ppkTotal v3.0 N=10 = € 569.457 (Δ 4,85%)
- ppkTotal v3.0 N=∞ = € 569.889 (Δ 4,93%)
- ppkTotal R9.30 LEG = € 572.166 (Δ 5,35%)

---

## 5. PENDING action items voor volgende sessie

### Eerst beslissen: hoe verder?
De reconstructie is af; de openstaande lijst uit HANDOFF_v3.0.106 §7 is
ongewijzigd. Aanbevolen startpunt: **één van de actuaris-bevindingen**.

### Actuaris-bevindingen — actief binnen scope
1. **C1 — Compensatiedepot-routing transparantie** (HOOG)
2. **D2 — RDR labelen als bestemd voor pensioengerechtigden** (MIDDEL)
3. **D5 — DG-afhankelijke bijstort-staffel** (HOOG)
4. **A3 — Broken-heart factoren uit AG-2018-publicatie** (MIDDEL)

### Buiten scope (uitgesteld per user)
- D3 (M3 Monte Carlo)
- D4 (partner-overlijden-uitkering)
- PPV naar maandbedrag onder SPR

### Buiten scope (geaccepteerd educatief, met disclaimer)
- A1, A4, A5, B1, B3, B4, C2, C3 (zie v3.0.91 handoff voor toelichting)

### Strategisch (open)
5. Fondsdemografie zichtbaar/aanpasbaar maken
6. M1 KV-fix actieve deelnemer
7. M3 Monte Carlo
8. M4 DB-vs-WTP

### Operationeel
9. Hosting-deployment naar invaarcalculator.nl
10. iPad-issue (HTML opent niet)

### Code-opruim (laagprioriteit)
11. Backward-compat-symbols opruimen
12. `src/ui.m1.ts` is dead-code
13. `renderM2Audit` is dead-code
14. `.kpi-foot` CSS-regel in `build.calc.ts` is dode styling (class wordt
    sinds v3.0.93 nergens meer gerenderd)
15. `test_browser.ts` legacy-test repareren of verwijderen
    (verwijst naar pre-single-binary `scherm1.html`)
16. Cumulatieve v3.0.93-95-comment-strings in source mogelijk opschonen
    om de 2,9 KB binary-delta met reference te dichten (cosmetisch)

### Eerste turn aanbeveling
Open met actuaris C1 (HOOG, en concreet afgebakend: compensatiedepot-
routing transparantie in audit-rapport). Dit raakt source én UI, dus
turn-1 bumpt naar v3.0.107 per Werkafspraak 16.

---

## 6. Source-files-overzicht v3.0.106 (zoals actueel in werkdir)

```
/home/claude/Keep-14/
├── src/                              (13 files, 1578 regels in ui.app.ts)
│   ├── ui.app.ts                     # RELEASE_VERSION = '3.0.106'
│   ├── ui.m2.ts
│   ├── ui.m1.ts                      # dead-code
│   ├── ui.print.ts                   # Persoonlijk overzicht
│   ├── ui.audit-report.ts            # Actuarieel overzicht (sectie 4 Fondsparameters)
│   ├── ui.shared.ts
│   ├── engine.m1.ts
│   ├── engine.m2.ts                  # vpvTotal uit params, niet F/DG
│   ├── schema.v2.ts                  # met v3.0.94 vpvTotal-veld
│   ├── fondsdataset.ts
│   ├── fondsdataset.types.ts         # Fonds type met shortLabel?: string
│   ├── test_engine.ts
│   └── test_engine.m2.ts
├── ag2024.json
├── fondsen/
│   └── sspf/
│       └── fonds.config.ts           # label, shortLabel='SSPF', vpvTotal=19100, dekkingsgraad=1.361
├── build.calc.ts                     # met fondsShort substitutie
├── tsconfig.json
├── package.json
├── test_browser_calc.ts              # ✓ ankers aangepast deze sessie
├── test_aftrek_komma.ts              # ✓
├── test_print_report.ts              # ✓ Test 3+7 aangepast deze sessie
├── test_v3_cascade.ts                # ✓
├── test_cwstar_smoke.ts              # ✓
├── test_ui_spreidingN.ts             # ✓
├── test_bh_decompositie.ts           # informatief
├── test_hans_replication.ts          # 7/10, pre-existing
├── test_browser.ts                   # ✗ legacy, kapot
├── HANDOFF_v3.0.92.md                # historisch
├── HANDOFF_v3.0.106.md               # vorige sessie-overdracht
├── HANDOFF_v3.0.107.md               # ← deze file
└── RECONSTRUCTION_LOG_v3.0.92_to_v3.0.106.md  # detail-log deze sessie
```

---

## 7. Verschillen met HANDOFF_v3.0.106 om aandacht voor

1. **§8 van vorige handoff is opgelost** — werkdir-source staat nu op v3.0.106
2. **`RELEASE_VERSION = '3.0.106'`** is nu correct gestempeld in source
3. **Twee test-files zijn aangepast** voor no-partner-default — als je
   ergens een referentie ziet naar "M1-anker 1.679.814" of "DG 1.35" in
   ouderr handoffs/comments: dat is pre-v3.0.95
4. **`test_print_report` Test 7 is omgedraaid** — was no-partner, is nu
   with-partner. Reden: default in v3.0.95+ is GEEN partner, dus
   no-partner-scenario is al gedekt door Test 3
5. **Werkafspraak 16 is nu in werking** — vanaf v3.0.107 elke source-
   rakende turn bumpt

---

## 8. Quick-orient voor de nieuwe Claude in volgende sessie

Lees in deze volgorde:
1. **Deze file** (HANDOFF_v3.0.107.md) — sessie-startstaat
2. **HANDOFF_v3.0.106.md** §1 (werkafspraken), §2 (architectuur), §4 (ankers) — context
3. **RECONSTRUCTION_LOG_v3.0.92_to_v3.0.106.md** — alleen als je wilt weten wat
   per versie is gedaan en waarom; voor doorwerken meestal overslaan
4. **HANDOFF_v3.0.92.md** — alleen bij historische vragen

Voorgaande handoffs (v2.x, v3.0.91 etc.) zijn niet in deze werkdir; vraag
de gebruiker er apart om als je een actuaris-bevinding gaat oppakken die
in oudere handoffs is gedefinieerd.

Vraag aan begin van eerste turn: **"Waarmee beginnen?"** met als opties
de vier actuaris-bevindingen (C1/D2/D5/A3), Optie 11-16 code-opruim,
operationele zaken, of een eigen onderwerp.
