/**
 * End-to-end smoke-test M1+M2 v3.0 cascade — wet-canonieke standaardregel.
 *
 * Doel:
 *   1. SSPF-anker scenario: 67M+65V+€30k OP+€21k NP, DG=1.15
 *   2. M1 leveren KV + cw_star (via m2Context)
 *   3. M2 leveren ppk via wet-canonieke formule
 *   4. Sluitingscontroles: ppk_OP + ppk_NP = ppkTotal (machine-tolerantie)
 *   5. Vergelijking N=10 vs N=1000
 *   6. Vergelijking computeM2 (v3.0) vs computeM2_R930_LEGACY (oude ankers)
 */
import * as fs from 'fs'
import { computeM1 } from './src/engine.m1'
import { computeM2, computeM2_R930_LEGACY } from './src/engine.m2'
const ag = JSON.parse(fs.readFileSync('/home/claude/Keep-14/ag2024.json', 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag }

const deelnemer = {
  x0: 67, g: 'M' as const,
  heeftPartner: true,
  x_partner: 65, g_y: 'V' as const,
  pen: 30000, y0: 21000,
}

const m1Params = {
  r: 0.02, sterftekansTabelId: 'AG2024' as const,
  t0: 2026, ervaringsSterfte: 1.0, m: 12 as 12,
  annuiteitsconventie: 'arrears' as const, pi: 0,
  fondsvermogen: 27202, omega: 110,
  uitvoeringskostenJaarlijks: null, kostenOpslagPct: null,
}

const m2Params = {
  ...m1Params,
  dekkingsgraad: 1.15,
  // v3.0.94: expliciet vpvTotal-anker. Tot v3.0.93 leidde de engine vpvTotal
  // af uit fondsvermogen/dekkingsgraad (27202/1.15 ≈ 23653,913 mln). Vanaf
  // v3.0.94 is vpvTotal een params-veld; we zetten 'm hier expliciet op die
  // historisch-afgeleide waarde zodat de regressie-ankers ongewijzigd blijven.
  vpvTotal: 27202 / 1.15,
  compensatiedepot: 0,
  vpvAftrekPct: 0.10,
  overigeReserves: 0,
  operationeleReserveringPct: 0,
  bijstort: 0,
  N_deelnemers: 10000,
  spreidingN: 10,
  compensatieMu: 50,
  compensatieSigma: 8,
  buffer: 0,
  demografie: { soort: 'preset' as const, preset: 'gesloten' as const },
}

console.log('=== M1+M2 v3.0 cascade smoke-test ===\n')

// === Test A: M1 met N=10 cascade
const m1_N10 = computeM1(deelnemer, m1Params, { spreidingN: 10 })
console.log('[A] M1 met m2Context N=10:')
console.log(`    KV_OP=${m1_N10.KV_OP.toFixed(0)}, KV_NP=${m1_N10.KV_NP.toFixed(0)}, KV=${m1_N10.KV.toFixed(0)}`)
console.log(`    cw_star_op=${m1_N10.cw_star_op?.toFixed(0)}, cw_star_np=${m1_N10.cw_star_np?.toFixed(0)}\n`)

const ketenInput_N10 = {
  KV: m1_N10.KV,
  KV_OP: m1_N10.KV_OP,
  KV_NP: m1_N10.KV_NP,
  cw_star_op: m1_N10.cw_star_op!,
  cw_star_np: m1_N10.cw_star_np!,
}

const m2_N10 = computeM2(deelnemer, ketenInput_N10, m2Params)
console.log('[B] M2 v3.0 wet-canoniek N=10:')
console.log(`    ppkBase=${m2_N10.ppkBase.toFixed(0)}, ppkSurplus=${m2_N10.ppkSurplus.toFixed(0)}, ppkComp=${m2_N10.ppkComp.toFixed(0)}`)
console.log(`    ppkTotal=${m2_N10.ppkTotal.toFixed(0)}`)
console.log(`    ppk_OP=${m2_N10.ppk_OP.toFixed(0)}, ppk_NP=${m2_N10.ppk_NP.toFixed(0)}`)
console.log(`    Δ vs KV: ${((m2_N10.ppkTotal - m1_N10.KV) / m1_N10.KV * 100).toFixed(2)}%`)

const sluiting1 = Math.abs((m2_N10.ppk_OP + m2_N10.ppk_NP) - m2_N10.ppkTotal)
const sluiting2 = Math.abs((m2_N10.ppkBase + m2_N10.ppkSurplus + m2_N10.ppkComp) - m2_N10.ppkTotal)
console.log(`    Sluiting OP+NP=Total: ${sluiting1.toExponential(2)} ${sluiting1 < 1e-6 ? '✓' : '✗'}`)
console.log(`    Sluiting Base+Surplus+Comp=Total: ${sluiting2.toExponential(2)} ${sluiting2 < 1e-6 ? '✓' : '✗'}\n`)

// === Test C: N=1000
const m1_N1000 = computeM1(deelnemer, m1Params, { spreidingN: 1000 })
const ketenInput_N1000 = {
  KV: m1_N1000.KV,
  KV_OP: m1_N1000.KV_OP,
  KV_NP: m1_N1000.KV_NP,
  cw_star_op: m1_N1000.cw_star_op!,
  cw_star_np: m1_N1000.cw_star_np!,
}
const m2_N1000 = computeM2(deelnemer, ketenInput_N1000, { ...m2Params, spreidingN: 1000 })
console.log('[C] M2 v3.0 wet-canoniek N=1000 (proxy ∞):')
console.log(`    ppkTotal=${m2_N1000.ppkTotal.toFixed(0)}`)
console.log(`    Δ vs KV: ${((m2_N1000.ppkTotal - m1_N1000.KV) / m1_N1000.KV * 100).toFixed(2)}%`)
console.log(`    (verwachting: opslag-percentage hoger dan N=10 voor jonge cohorten;`)
console.log(`     voor 67M lichtelijk lager of vergelijkbaar omdat kasstromen direct)\n`)

// === Test D: Legacy R9.30 voor regressie tegen oud anker
// Legacy heeft geen cw_star nodig — gebruik M1 zonder m2Context
const m1_legacy = computeM1(deelnemer, m1Params)
const ketenInput_legacy = {
  KV: m1_legacy.KV,
  KV_OP: m1_legacy.KV_OP,
  KV_NP: m1_legacy.KV_NP,
  cw_star_op: 0,  // niet gebruikt door legacy
  cw_star_np: 0,
}
const m2_legacy = computeM2_R930_LEGACY(deelnemer, ketenInput_legacy, m2Params)
console.log('[D] Legacy R9.30 (regressie-vergelijking):')
console.log(`    ppkTotal=${m2_legacy.ppkTotal.toFixed(0)}`)
console.log(`    Verwacht oud anker € 572.166 (handoff v2.2.11+12)`)
console.log(`    Match: ${Math.abs(m2_legacy.ppkTotal - 572166) < 50 ? '✓' : `✗ (verschil ${Math.abs(m2_legacy.ppkTotal - 572166).toFixed(0)})`}\n`)

// === Samenvatting
console.log('=== Samenvatting v3.0 ankers (SSPF 67M+65V+€30k OP+€21k NP, DG=1.15) ===')
console.log(`  KV (M1)             = €${m1_N10.KV.toFixed(0).padStart(8)}`)
console.log(`  ppkTotal v3.0 N=10  = €${m2_N10.ppkTotal.toFixed(0).padStart(8)}  (Δ ${((m2_N10.ppkTotal/m1_N10.KV-1)*100).toFixed(2)}%)`)
console.log(`  ppkTotal v3.0 N=∞   = €${m2_N1000.ppkTotal.toFixed(0).padStart(8)}  (Δ ${((m2_N1000.ppkTotal/m1_N1000.KV-1)*100).toFixed(2)}%)`)
console.log(`  ppkTotal R9.30 LEG  = €${m2_legacy.ppkTotal.toFixed(0).padStart(8)}  (Δ ${((m2_legacy.ppkTotal/m1_legacy.KV-1)*100).toFixed(2)}%)`)

const allOk = sluiting1 < 1e-6 && sluiting2 < 1e-6
process.exit(allOk ? 0 : 1)
