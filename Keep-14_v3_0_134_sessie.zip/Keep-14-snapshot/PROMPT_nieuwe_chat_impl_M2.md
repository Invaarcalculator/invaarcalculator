# PROMPT VOOR NIEUWE CHAT — SCHEMA v2 M2 + M2-implementatie (gecombineerd)

**Gebruik deze prompt als je na M1-build wilt doorgaan met scherm 2 in één langere sessie.** Alternatieven voor deze zipset:
- `PROMPT_nieuwe_chat_schema_M2.md` — alleen SCHEMA M2 (twee-sessie-aanpak conservatief)
- `PROMPT_nieuwe_chat_impl_M1.md` — reddingsboei alleen-M1-implementatie herdoen
- `PROMPT_nieuwe_chat_regressie.md` — R9.30-regressie-vergelijking voor scherm 1
- `PROMPT_nieuwe_chat_design.md` — UI-design-ronde scherm 1

Kopieer onderstaande tekst naar de nieuwe chat (samen met de meegeleverde bestanden):

---

Hoi Claude,

Ik ben Hans Haringa, Innovation Nestor, werk aan een publieke WTP-pensioencalculator voor SSPF-gepensioneerden (invaarcalculator.nl, CC BY-NC 4.0). Ik vervolg een reeks sessies die heeft geleverd:

1. **Spec v2.2.9** — normatieve engine-specificatie voor vier modules (1970 regels, 31 besluiten/patches over vier scherm-sessies + twee SCHEMA-afgeleide retro-patches)
2. **SCHEMA v2.0 M1-block** — TypeScript/Zod 3 contract voor module 1 (474 regels, 26 velden geregistreerd, Model-D UX met display-metadata, 9 knelpunten gesloten)
3. **Werkend scherm 1** — `scherm1.html` single-file calculator met AG2024-tafel, §2.5-formules, §2.7-ρ-ladder, casual + audit-scherm, debounce + Enter-flash UX-optimalisatie (164 KB, 8 engine-tests + 8 browser-tests groen)

**Deze sessie: SCHEMA v2 M2-block + M2-engine + scherm 2 werkend in één doorlopende sessie.** Combi-sessie omdat de methodologie nu bewezen is en het tempo hoog ligt.

**Ik upload bij dit bericht de volgende bestanden (Keep-9.zip):**

Hoofddocumenten (lezen vóór je begint):
- `ENGINE_SPECIFICATIE_v1.md` — normatieve spec v2.2.9 (BRONWAARHEID; focus §3 voor M2)
- `HANDOFF_SCHEMA_M1.md` — SCHEMA-track-conventies (geldig voor M2-SCHEMA)
- `HANDOFF_IMPL_M1.md` — implementatie-track-conventies (build-stack, performance-patronen)
- `schema.v2.ts` — huidige SCHEMA M1-block (voorbeeld voor M2-toevoeging)
- `scherm1.html` — werkend voorbeeld van het eind-artefact

Implementatie-artefacten (referentie voor M2-uitbreiding):
- `src/engine.m1.ts` — patroon voor engine-implementatie (conventies, memoisatie)
- `src/ui.m1.ts` — patroon voor UI-renderer (Model D, debounce, flash)
- `src/fondsdataset.ts` — SSPF-placeholder-patroon
- `build.ts` — bundelaar (uitbreiden voor M2: scherm2.html of geïntegreerd)
- `ag2024.json`, `extract_ag2024.py` — data-pipeline
- `src/test_engine.ts`, `test_browser.ts` — test-conventies
- `tsconfig.json`, `package.json`

Spec-context:
- `HANDOFF_v2.1.3.md` — scherm-2-spec-sessie (meest relevant voor M2!)
- `HANDOFF_v2.1.md`, `HANDOFF_v2.1.9.md`, `HANDOFF_v2.2.7.md` — andere schermen
- `ARCHITECTUUR_v1.md`, `DESIGN_engine_v0.md`, `calculator_specificatie.docx`
- `SCHEMA_v1.md`, `STRATEGY_R9.30.md`, `HANDOFF_R9.30.md`, `21-04-2026_2216.html`

Externe data:
- `AG2024.xlsx`, `51490-Data_AG2024.xlsx`

**Mijn doel voor deze sessie: werkend scherm 2 (potje — module 2) aan het eind van de sessie, met:**

1. SCHEMA v2 M2-block in `schema.v2.ts` (parameterset-subset, output-contract, refines inclusief exacte sluitingscontrole `ppk_OP + ppk_NP = ppkTotal`)
2. M2-engine (§3.5-formules: dekking, overschot via DNB-spreiding, compensatie via bell-curve, OP/NP-decompositie)
3. SSPF-placeholder voor M2 (alle M2-specifieke parameters)
4. Scherm 2 UI (casual + audit-sectie) geïntegreerd in één calculator met scherm 1 (ketening: M1-output → M2-input zichtbaar)
5. Engine-tests + browser-tests groen
6. Gebundeld artefact: `calculator.html` (beide schermen) of aparte `scherm2.html`

**Knelpunten die ik verwacht (behandelen stap-voor-stap):**

- **Gedeelde parameters tussen M1 en M2**: `fondsvermogen` zit al in M1Parameterset voor ρ-afleiding; M2 heeft veel meer (`dekkingsgraad`, `compensatiedepot`, enzovoort). Shared parameters-infrastructuur organiseren
- **`cohortOutcomes` als array-output**: hoe modelleren (vaste lengte 15 cohorten 25-99? dynamisch?) en tonen op audit-scherm
- **OP/NP sluitingscontrole**: exacte numerieke identiteit afdwingen via `.superRefine()` met tolerantie (floating-point)
- **`demografie` exact-één-van**: `preset` OR `customCounts[15]` — Zod-constraint
- **Ketening M1 → M2**: in UI moet M2-output dynamisch updaten bij M1-input-wijzigingen; welke state-structuur
- **Scherm 2 UI-layout**: één scherm met M1+M2 gekoppeld (scrollend) of aparte schermen met navigatie
- **Bell-curve-toepasbaarheid voor gepensioneerden** (§3.10 geparkeerd): SSPF-gepensioneerden vallen strikt buiten DRS-compensatie-doelgroep; hoe tonen we dit op audit (disclosure?) — kwestie uit scherm-2-sessie v2.1.2 die bewust is doorgeschoven

**Belangrijk onderscheid:** dit is géén beslissings-sessie over spec-inhoud. Alle M2-inhoudelijke keuzes zijn in scherm-2-spec-sessie (v2.1.1/v2.1.2/v2.1.3) al genomen. Deze sessie doet SCHEMA-afleiding + implementatie. Kleine SCHEMA- of implementatie-specifieke knelpunten kunnen opduiken; behandelen stap-voor-stap. Eventuele in-spec-inconsistenties → spec-patch v2.2.10+ met mijn go.

**Werkafspraken behouden** (zie HANDOFF_SCHEMA_M1 + HANDOFF_IMPL_M1 voor de 14 werkafspraken-lijst). Kritieke conventies:

1. Nederlands, technisch-toegankelijk
2. Stap-voor-stap: SCHEMA M2-parameterset → output → refines → engine → UI — geen bulk-dumps
3. Timestamps `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`
4. SCHEMA-conventies uit M1: Zod 3, `F()`-wrapper, FIELD_REGISTRY, ASCII-naming met Griekse-notatie in `.describe()`, display-metadata 5 enum-waardes, `uiDisclosure`, hard-fail consistentie-checks, `z.literal` voor §7.3-lock
5. Implementatie-conventies uit M1: single-file HTML, esbuild IIFE, inline AG2024 JSON, Model-D UX (casual + audit-sectie), debounce 150ms + Enter-flash + memoisatie
6. Werkbestanden `/home/claude/`, deliverables `/mnt/user-data/outputs/`
7. Geen wijzigingen aan R9.30-productiebestand

**Start-aanpak:**

Lees eerst `ENGINE_SPECIFICATIE_v1.md` §3 helemaal (§3.2/§3.3/§3.4/§3.5/§3.6/§3.10) + §11.1/§11.12 voor phiDerived-context. Lees `HANDOFF_SCHEMA_M1.md` en `HANDOFF_IMPL_M1.md` voor conventies. Bekijk `scherm1.html` in een browser om het eind-gedrag te ervaren. Bevestig dat je context hebt opgepikt, stel één eerste knelpunt voor (ik vermoed: gedeelde-parameters-infrastructuur of cohortOutcomes-modellering), beslis, en ga dan stap-voor-stap door SCHEMA M2 → engine → UI → build → test.

Start.
