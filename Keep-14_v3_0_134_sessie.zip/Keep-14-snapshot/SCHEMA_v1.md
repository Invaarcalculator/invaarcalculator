# WTP-PENSIOENCALCULATOR — DATASET-SCHEMA v1

Datum: 21-04-2026 17:33
Auteur: Hans Haringa, Innovation Nestor
Status: Beslispunt 1 (schema-ontwerp) voltooid — gereed voor implementatie in Fase A

Dit document is het **definitieve referentiedocument** voor het dataset-schema dat in Fase A (vanaf R9.23) wordt geïmplementeerd. Het vervangt alle schema-fragmenten die eerder rondzweefden in STRATEGY- en HANDOFF-documenten.

---

## 1. FILOSOFIE

De calculator is een **engine + dataset**. De engine bevat de wiskunde; de dataset bevat alle fondsspecifieke feiten en beleidsparameters. Dezelfde engine kan daarmee meerdere fondsen bedienen — dat is de commerciële horizon (Fase C+).

Drie principes sturen het schema:

1. **Platte key-value waar mogelijk.** Geneste sub-objecten alleen als ze een natuurlijke groepering vormen. Geen diep-geneste structuren die validators en UI-renderers compliceren.
2. **Engine blijft schoon.** De engine leest `p.fondsbalans.fondsvermogen`, niet `p.fondsbalans.fondsvermogen.waarde` of `p.fondsbalans.fondsvermogen.metBron()`. Bronverantwoording staat in een parallel `herkomst`-blok.
3. **Auditeerbaar per veld.** Elke waarde in de dataset kan in de UI herleid worden naar haar herkomst — publiek cijfer, afgeleide transformatie, of educatieve reconstructie.

---

## 2. SCHEMA-STRUCTUUR (Optie B — middel)

```javascript
const FONDS_DATASET = {
  meta: {
    fondsnaam:       string,   // 'Stichting Shell Pensioenfonds'
    peildatum:       string,   // ISO-datum, bv. '2024-12-31'
    versie:          string,   // '1.0.0' — dataset-versie, niet schema-versie
    bron:            string,   // kort label, bv. 'JV2024 + Impl.plan 2025-07-15'
    disclaimerTekst: string,   // vrije tekst voor UI-footer
    schemaVersie:    '1.0'     // versie van het schema zelf, voor migratie
  },

  regeling: 'FPR' | 'SPR-clean' | 'SPR-hybride',

  fondsbalans: {
    fondsvermogen:              number,   // in mln euro
    dekkingsgraad:              number,   // fractie, bv. 1.29
    compensatiedepot:           number,   // in mln euro, 0 bij geen compensatie
    overigeReserves:            number,   // in mln euro
    operationeleReserveringPct: number,   // fractie, bv. 0.02
    bijstort:                   number    // in mln euro, meestal 0
  },

  beleid: {
    spreidingN:       number,         // DNB-spreidingstermijn, bv. 10 jaar
    compensatieMu:    number,         // leeftijd-middelpunt bell-curve
    compensatieSigma: number,         // breedte bell-curve
    RDR_initieel?:    number,         // in mln euro; alleen FPR/SPR
    RDR_max_pct?:     number,         // fractie, alleen FPR/SPR
    dempingJaren:     number,         // 0-10, default per regeling
    invaardatum?:     string,         // ISO-datum, alleen bij invaar-fondsen
    minimaleInvaarDG?: number         // fractie, bv. 1.25
  },

  demografie: {
    preset?:      string,             // 'uniform' | 'grijzend' | ...
    customCounts?: number[15]         // 15 cohorten 25-99, lengte altijd 15
    // Exact één van beide is verplicht; 'eigen' preset impliceert customCounts
  },

  defaults: {
    rendementMu:        number,    // forward-looking μ
    rendementSigma:     number,    // forward-looking σ
    projectierendement: number,
    inflatieVerwacht:   number
  },

  actuarieel: {
    sterftekansTabelId: string     // 'AG2022' — hardgecodeerde tabel in engine
  },

  herkomst: {
    // Platte key-value, zie sectie 4
    '<dotpad>': { tier, bron?, peildatum?, methode?, startpeildatum?, notitie? }
  },

  reserveringenFaseB: {
    rtsCurve:           null,   // Fase B: SPR-hybride rentetermijnstructuur
    agHerzienPeriode:   null,   // Fase B: AG-herzieningsfrequentie (jaren)
    renteAfdekkingFactor: null  // Fase B: impact op μ/σ
  }
};
```

**Toelichting op keuzes:**

- `regeling` staat op top-level, niet in `beleid`, omdat het een fundamentele keuze is die de engine-code stuurt (inner-loop-wiskunde verschilt per regeling).
- `demografie.preset` en `demografie.customCounts` zijn alternatieven — dataset kan één van beide specificeren. Validator moet dit controleren.
- `actuarieel.sterftekansTabelId` verwijst naar een tabel die in de engine-code zit. De dataset bevat dus géén volledige AG2022-tabel; alleen een ID.
- `reserveringenFaseB` is expliciet leeg in Fase A. Dit voorkomt dat Fase B een schema-migratie nodig heeft — de velden zijn er al, ze hebben alleen nog geen waarde.

---

## 3. DRIE-TIER-DEFINITIES — SCHERP AANGETROKKEN

Elk veld dat in `herkomst` wordt gedocumenteerd krijgt één van drie labels. De definities zijn in R9.23-sessie scherp aangetrokken om grensgevallen eenduidig te maken.

### `publiek`

Het cijfer staat **letterlijk** in een brondocument, op een te verifiëren pagina. Een lezer kan de bron openen, de pagina opzoeken, en de waarde één-op-één terugvinden.

**Verplicht:** `bron` (inclusief paginaverwijzing waar mogelijk).

**Voorbeelden:**
- Fondsvermogen €27.202 mln (SSPF JV2024 p.49)
- Dekkingsgraad 129% (SSPF JV2024 p.50)
- Invaardatum 1-1-2027 (Implementatieplan 2025 p.27)
- RDR €500 mln (Implementatieplan 2025 p.105)

### `afgeleid`

Het cijfer is een **mechanische transformatie** uit publieke data, gedocumenteerd met een methode die onafhankelijk reproduceerbaar is. De transformatie mag standaard actuariële assumpties gebruiken (bv. AG2022-sterfte), maar geen forward-looking verwachtingen.

**Verplicht:** `methode` (beschrijft de transformatie) en een verwijzing naar de brondata.

**Voorbeelden:**
- Demografie op 1-1-2027 afgeleid uit Transitieplan SSPF 1-7-2024 Bijlage 8 (peildatum 31-12-2023) via forward aging met AG2022-sterfte en geen nieuwe instroom (fonds gesloten sinds 2013)
- Buffer in euro's = fondsvermogen − VPV − afgesplitste reserves (componenten publiek, eindcijfer afgeleid)

### `reconstructie`

Het cijfer berust op een **educatieve keuze** die niet uit publieke data volgt. Typisch: forward-looking simulatie-parameters waarvoor geen fonds-specifieke publicatie bestaat.

**Verplicht:** `notitie` (uitleg waarom deze waarde is gekozen).

**Voorbeelden:**
- `defaults.rendementMu`: historisch 3,5% is publiek, maar forward-looking verwachting is een keuze
- `defaults.rendementSigma`: nergens direct gepubliceerd; afgeleid uit asset-allocatie is mogelijk maar vereist aanname
- `beleid.compensatieMu` / `compensatieSigma`: de bell-curve-vorm is een educatieve reconstructie, het totaalbedrag van het depot is publiek

**Regel voor grensgevallen:** als een waarde een forward-looking assumptie bevat, is het `reconstructie`, ook als er publieke historische data is die de aanname ondersteunt. Dit houdt de categorie `afgeleid` eerlijk beperkt tot mechanische transformaties.

---

## 4. HERKOMST-BLOK — ZES VELDEN

Elk herkomst-entry is een platte key-value struct met maximaal zes velden:

```javascript
herkomst: {
  '<dotpad>': {                              // bv. 'fondsbalans.fondsvermogen'
    tier:           'publiek' | 'afgeleid' | 'reconstructie',
    bron?:          string,   // verplicht bij 'publiek', optioneel elders
    peildatum?:     string,   // ISO-datum waarop de waarde geldig is
    methode?:       string,   // verplicht bij 'afgeleid'
    startpeildatum?: string,  // bij aging-transformaties: originele peildatum
    notitie?:       string    // vrije tekst, verplicht bij 'reconstructie'
  }
}
```

**Voorbeelden — volledig ingevuld:**

```javascript
'fondsbalans.fondsvermogen': {
  tier: 'publiek',
  bron: 'SSPF JV2024 p.49 "Balans per 31 december 2024"',
  peildatum: '2024-12-31'
},

'demografie.customCounts': {
  tier: 'afgeleid',
  bron: 'SSPF Transitieplan 1-7-2024, Bijlage 8 Demografie SSPF 2023',
  startpeildatum: '2023-12-31',
  peildatum: '2027-01-01',
  methode: 'Forward aging met AG2022-sterfte, geen nieuwe instroom (fonds zacht-gesloten sinds 2013)',
  notitie: 'Exacte afleesmethode van bar-chart staat in Fase-B-documentatie'
},

'defaults.rendementMu': {
  tier: 'reconstructie',
  notitie: 'SSPF 10-jaars gerealiseerd rendement = 3,5% (JV2024 p.50). Forward-looking μ = 4% gekozen als educatieve middelweg tussen historisch en sector-gemiddelde.'
}
```

---

## 5. TIER-TABEL VOOR SSPF-VELDEN (ter voorbereiding SSPF-publiek-v1 in Fase B)

Deze tabel is **niet normatief voor Fase A**. In Fase A krijgen alle velden placeholder-waarden gelijk aan de huidige hardcoded defaults (behoud van regressie-scenario). In Fase B, bij samenstelling van de SSPF-publiek-v1 dataset, dient deze tabel als guide.

| Veld | Tier | Bron |
|---|---|---|
| `meta.fondsnaam` | publiek | — |
| `meta.peildatum` | publiek | JV2024 |
| `regeling` | publiek | Impl.plan p.11 |
| `fondsbalans.fondsvermogen` | publiek | JV2024 p.49 |
| `fondsbalans.dekkingsgraad` | publiek | JV2024 p.50 |
| `fondsbalans.compensatiedepot` | publiek | Impl.plan p.107 |
| `fondsbalans.overigeReserves` | afgeleid | Componenten publiek (RDR + compensatie + operationeel), totaal berekend |
| `fondsbalans.operationeleReserveringPct` | publiek | Impl.plan p.103 (2%, wordt herzien H2 2025) |
| `fondsbalans.bijstort` | publiek | 0 bij huidige DG |
| `beleid.RDR_initieel` | publiek | Impl.plan p.105 |
| `beleid.RDR_max_pct` | publiek | Impl.plan p.106 (2,5%) |
| `beleid.dempingJaren` | publiek | Impl.plan p.33 (5 jaar default) |
| `beleid.invaardatum` | publiek | Impl.plan p.27 |
| `beleid.minimaleInvaarDG` | publiek | Impl.plan p.10 |
| `beleid.spreidingN` | reconstructie | DNB-methodiek (10 jaar standaard), niet SSPF-specifiek |
| `beleid.compensatieMu` | reconstructie | Depot-totaal is publiek; curve-vorm is educatief |
| `beleid.compensatieSigma` | reconstructie | idem |
| `demografie.customCounts` | afgeleid | Transitieplan Bijlage 8 + aging naar 1-1-2027 |
| `defaults.rendementMu` | reconstructie | Historisch 3,5% publiek; forward-looking is keuze |
| `defaults.rendementSigma` | reconstructie | Niet publiek gepubliceerd |
| `defaults.projectierendement` | reconstructie | In ABTN, niet publiek |
| `defaults.inflatieVerwacht` | reconstructie | Niet fonds-specifiek |
| `actuarieel.sterftekansTabelId` | publiek | AG2022 is sector-standaard |

**Open sub-vraag voor Fase B:** de exacte aging-methode voor `demografie.customCounts` en of het Transitieplan naast de bar-chart (Bijlage 8) ook elders een precieze cijferreeks bevat. De huidige tool-preset `grijzend` is Hans' afleiding; voor SSPF-publiek-v1 moet de afleiding expliciet gedocumenteerd worden in de `methode`-string.

---

## 6. VALIDATOR-REGELS

De validator (Fase A implementatie) controleert de dataset bij laden. Hieronder de regels die in versie 1 actief moeten zijn.

### 6.1 Structuur

- `meta`, `regeling`, `fondsbalans`, `beleid`, `demografie`, `defaults`, `actuarieel`, `herkomst` zijn allemaal verplicht als top-level sleutels.
- `reserveringenFaseB` is verplicht aanwezig (mag leeg zijn); dit zorgt dat Fase B geen schema-migratie nodig heeft.
- `meta.schemaVersie` moet `'1.0'` zijn.

### 6.2 Verplichte velden per regeling

| Veld | FPR | SPR-clean | SPR-hybride |
|---|---|---|---|
| `beleid.RDR_initieel` | verplicht | verplicht | verplicht |
| `beleid.RDR_max_pct` | verplicht | verplicht | verplicht |
| `beleid.invaardatum` | verplicht | verplicht | verplicht |
| `beleid.minimaleInvaarDG` | verplicht | verplicht | verplicht |
| `reserveringenFaseB.rtsCurve` | `null` toegestaan | `null` toegestaan | verplicht bij implementatie |
| `reserveringenFaseB.agHerzienPeriode` | `null` toegestaan | `null` toegestaan | verplicht bij implementatie |

### 6.3 Demografie

- Exact één van `preset` of `customCounts` moet aanwezig zijn.
- Als `customCounts`: lengte moet 15 zijn, alle waarden ≥ 0.
- Als `preset`: waarde moet in `DEMOGRAFIE_PRESETS` bestaan.

### 6.4 Herkomst-consistentie

Voor elk veld dat in de dataset een waarde heeft, **moet** er een corresponderende entry in `herkomst` zijn met:
- `tier = 'publiek'` ⇒ `bron` verplicht
- `tier = 'afgeleid'` ⇒ `methode` verplicht
- `tier = 'reconstructie'` ⇒ `notitie` verplicht

Ontbrekende herkomst-entries zijn een validator-fout.

### 6.5 Waardenbereik

- `fondsbalans.dekkingsgraad`: 0.5 ≤ x ≤ 2.0
- `fondsbalans.fondsvermogen`: > 0
- `beleid.RDR_max_pct`: 0 ≤ x ≤ 0.15 (wettelijke bovengrens Wtp)
- `beleid.spreidingN`: 1 ≤ x ≤ 30
- `beleid.dempingJaren`: 0 ≤ x ≤ 10
- `defaults.rendementMu`: -0.05 ≤ x ≤ 0.15
- `defaults.rendementSigma`: 0 ≤ x ≤ 0.30
- `defaults.inflatieVerwacht`: -0.02 ≤ x ≤ 0.10

### 6.6 Beslispunt 4 nog open

Of de validator **hard weigert** bij invalide dataset, of **fallback met waarschuwing** gebruikt, is beslispunt 4 uit Fase A. Dit document specificeert alleen welke checks de validator uitvoert; wat hij doet bij een falende check is nog te beslissen.

---

## 7. FASE-B RESERVERINGEN — DETAIL

Het blok `reserveringenFaseB` is bedoeld om Fase B schema-stabiel te laten zijn. De drie velden die nu als `null` geplaatst zijn:

### `rtsCurve`

Voor SPR-hybride is een rentetermijnstructuur nodig (elke looptijd zijn eigen rente). In Fase A is dit `null` omdat alleen FPR is geïmplementeerd. In Fase B wordt dit een object met looptijd-rente-paren of een functie-representatie.

### `agHerzienPeriode`

SPR-hybride kent een periodieke AG-herziening (elke 2 jaar in SSPF-context). In Fase A is dit `null`. In Fase B wordt dit een getal (in jaren) dat de periode van sterftetafel-updates aangeeft.

### `renteAfdekkingFactor`

De mate van rente-afdekking (SSPF: 100%) beïnvloedt hoe rente-risico doorwerkt in μ/σ. In Fase A is dit `null`; in Fase B wordt het een fractie 0-1 die de engine gebruikt om portfolio-effecten te simuleren.

Deze drie velden zijn expliciet genoemd omdat het SSPF-doel-regeling is SPR-hybride (Fase B-eind). Door ze nu al te reserveren, vermijdt de codebase een tweede refactor-ronde bij de SPR-overgang.

---

## 8. WAT DIT SCHEMA NIET DOET

Dit schema is bewust **niet** ontworpen voor:

- **Historische pensioenopbouw-regels** (doorsneepremie, opbouwpercentages, franchises). Deze zijn pre-Wtp en niet relevant voor een calculator over de post-Wtp situatie.
- **Deelnemer-individuele data** (geboortedatum, salaris, dienstjaren). De calculator is een verkenner voor gebruikersconsistente uitkomsten; individuele fondsdata blijft bij de pensioenuitvoerder.
- **Communicatie- en disclaimer-logica per deelnemersgroep**. Alleen één fondsbrede `disclaimerTekst` in `meta`. Differentiatie per deelnemersgroep is Fase C+.
- **Multi-regeling-datasets** (fondsen met zowel FPR als SPR). Elk dataset-object beschrijft één regeling. Fondsen met meerdere regelingen laden meerdere datasets.

---

## 9. BESLISPUNT 1 — AFGEROND MET

✓ **Optie B** (middel) schema-diepte met 8 top-level blokken plus `reserveringenFaseB`
✓ **Aanpak 2** (parallel herkomst-blok) voor bronverantwoording
✓ **Drie tiers** met scherpe definities (publiek / afgeleid / reconstructie)
✓ **Zes-velden herkomst-struct** (tier, bron?, peildatum?, methode?, startpeildatum?, notitie?)
✓ **Fase-B reserveringen** voorgekookt (rtsCurve, agHerzienPeriode, renteAfdekkingFactor)
✓ **Tier-test uitgevoerd** tegen SSPF JV2024, Implementatieplan 2025 en Transitieplan Bijlage 8 — drie tiers houdbaar

**Pending sub-vraag (niet-blocker voor Fase A):** exacte aging-methode voor `demografie.customCounts` in SSPF-publiek-v1 dataset. Te beantwoorden in Fase B bij data-curatie, niet bij refactor.

**Pending placeholder-beslissing:** Fase A gebruikt de huidige tool-defaults als placeholder (135% DG, 25 mrd fondsvermogen, huidige grijzend preset), niet echte SSPF-waarden (129% DG, 27,2 mrd). Rationale: scheidt **refactor** (Fase A, architectuur) van **data-curatie** (Fase B, inhoud). Het regressie-scenario (pen €100k, DG 135%, age 70 → U₀ ≈ €128k) blijft intact.
