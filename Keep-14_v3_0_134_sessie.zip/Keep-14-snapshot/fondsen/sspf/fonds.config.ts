/**
 * SSPF fonds-definitie.
 *
 * v3.0.76 (build-time-fondsinjectie): deze file is de SSPF-bron-of-waarheid
 * voor alle fonds-specifieke data. Bij build wordt hij geïmporteerd via
 * de path-alias '~fonds' (zie build.calc.ts en tsconfig.json). De codebase
 * onder /src/ is fonds-onafhankelijk; deze file (en zustermappen voor
 * andere fondsen) is fonds-afhankelijk.
 *
 * Voor een tweede fonds (bv. ABN): kopieer deze map naar /fondsen/abn/,
 * vul met ABN-data, en bouw met `--fonds=abn`. Zelfde codebase, andere
 * fondsdefinitie, andere output-HTML.
 *
 * Historische bron-citaten staan in src/fondsdataset.ts (v3.0.28-39 commit-
 * comments). Hier alleen de actuele waarden + bron-comment per veld.
 */

import type { Fonds, AanwendingsCascade, M1Parameterset, M2Parameterset } from '../../src/fondsdataset.types'

const SSPF_M1: M1Parameterset = {
  r: 0.025,                         // SSPF-presentatie 14-04-2026: DNB UFR-curve eind 2025 ~2,5%
  sterftekansTabelId: 'AG2024',
  t0: 2026,
  ervaringsSterfte: 0.90,           // v3.0.90 (zie M2-block voor bron-onderbouwing)
  m: 12,
  annuiteitsconventie: 'arrears',
  pi: 0,
  fondsvermogen: 26000,             // SSPF-presentatie 14-04-2026: eind feb 2026 26,0 mld €
  uitvoeringskostenJaarlijks: null,
  kostenOpslagPct: null,
  omega: 120,
}

const SSPF_M2: M2Parameterset = {
  r: 0.025,
  sterftekansTabelId: 'AG2024',
  t0: 2026,
  ervaringsSterfte: 0.90,           // v3.0.90: conservatieve schatting voor SSPF-populatie (hoog-opgeleid wit-boord, top-inkomensquintiel). Bron: CBS levensverwachting naar inkomen (vzinfo.nl/levensverwachting/inkomen, peildata 2019/2022): 65-jarige mannen hoogste inkomensquintiel 20,5j vs laagste 16,4j (verschil 4,1j); CBS welvaartsstudie verschil hoogste vs laagste welvaartsgroep ruim 4j op 65-jarige leeftijd. f=0,90 als conservatief midpoint t.o.v. industrie-benchmark hoog-opgeleide witte-boorden-fondsen (typisch 0,85-0,95). Beperking: vlak (geen leeftijds-/gender-differentiatie); v2-uitbreidingspad in §11.13 voor leeftijdsafhankelijke vorm. Een echt SSPF-fondsspecifiek getal vraagt niet-publieke ABTN-data en zou waarschijnlijk lager liggen.
  m: 12,
  annuiteitsconventie: 'arrears',
  pi: 0,
  fondsvermogen: 26000,
  omega: 120,

  dekkingsgraad: 1.361,             // v3.0.94: SSPF stand eind feb 2026 (was 1.35 ~135%; nu 26.000/19.100=1,3613...). DG en F bewegen in tandem rond vpvTotal-anker.
  vpvTotal: 19100,                  // v3.0.94 anker: SSPF totale technische voorziening eind feb 2026 in mln euro. F en DG zijn afgeleiden hieromheen via F = DG × vpvTotal.
  compensatiedepot: 0,              // SSPF: geen DRS-compensatie-doelgroep
  vpvAftrekPct: 0.06,               // Cascade-middenwaarde: 2% wettelijk + €500m RDR + €400m comp.depot ≈ 6,7% bij DG=135%, afgerond 6,0%
  overigeReserves: 0,
  operationeleReserveringPct: 0.02,
  bijstort: 500,                    // SSPF-implementatieplan 15-07-2025: werkgevers-bijstort €500 mln (DG≥135%)
  N_deelnemers: 26000,              // ~26k totaal in 2025 (~2k actief + ~6k gewezen + ~18k gepensioneerd)
  spreidingN: 1000,                 // SSPF-implementatieplan §5.6: levenslang (afwijking van 10-jaars Pw-default)
  compensatieMu: 55,
  compensatieSigma: 8,
  buffer: 0,
  demografie: {
    soort: 'preset',
    preset: 'gesloten',
  },
}

const SSPF_AANWENDINGSCASCADE: AanwendingsCascade = {
  bijstortLabel: 'Transitiebijdrage werkgever',
  bijstortNote: 'Compensatie voor vervallen sponsorgarantie. Geldt bij DG ≥ 135%; bij DG 130-135% is de bijdrage € 650 mln, bij DG 125-130% € 850 mln. Deze tool houdt € 500 mln vast.',
  wettelijkeReservesPct: 0.02,
  wettelijkeReservesNote: 'Impl.plan §5.5 stap 1 (ingeschat)',
  rdrBedrag: 500,
  rdrNote: 'Impl.plan §5.9: bestemd voor risicodeling pensioengerechtigden',
  compensatiedepotBedrag: 400,
  compensatiedepotNote: 'Impl.plan §5.10: compensatie afschaffing doorsneesystematiek voor actieven',
  outroTekst: 'Onze engine modelleert deze cascade als één geaggregeerde aftrek (vpvAftrekPct = 6,0%) plus de losse bijstort-toevoeging. De som van de drie afsplitsingen ligt bij DG = 135% rond 6,7% van de voorziening; wij ronden af op 6,0% als conservatieve middenwaarde, omdat de samenstelling met de DG meebeweegt.',
  intro: 'Bij invaren wordt het fondsvermogen eerst opgehoogd met de transitiebijdrage van de werkgever, en daarna in drie stappen afgesplitst voor wettelijke en collectieve reserves. Wat overblijft wordt over de persoonlijke pensioenvermogens verdeeld via de standaardregel (Bijlage 2a Regeling Pw).',
}

export const FONDS: Fonds = {
  label: 'Stichting Shell Pensioenfonds (SSPF)',
  shortLabel: 'SSPF',
  m1: SSPF_M1,
  m2: SSPF_M2,
  aanwendingsCascade: SSPF_AANWENDINGSCASCADE,
}
