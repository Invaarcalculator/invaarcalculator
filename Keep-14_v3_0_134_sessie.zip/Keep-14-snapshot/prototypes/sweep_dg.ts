/**
 * DG-sensitivity sweep voor prototype-grafiek.
 *
 * Genereert: voor elke DG in [1.00 .. 1.50] (step 0.01):
 *   - bijstort volgens SSPF-trapregel (implementatieplan 15-07-2025):
 *       DG ≥ 1.35  → bijstort 500 mln
 *       DG 1.30-1.35  → bijstort 650 mln
 *       DG 1.25-1.30  → bijstort 850 mln
 *       DG < 1.25  → INVAREN GAAT NIET DOOR (geen run)
 *   - vpvTotal blijft op SSPF-anker 19100 mln
 *   - fondsvermogen wordt afgeleid: F = DG × vpvTotal
 *   - alle andere parameters SSPF-default
 *
 * Output: JSON met data-punten voor de grafiek.
 */

import * as fs from 'fs'
import * as path from 'path'
import { FONDS } from '../fondsen/sspf/fonds.config'
import { computeM1 } from '../src/engine.m1'
import { computeM2 } from '../src/engine.m2'
import { M1, M2 } from '../src/schema.v2'
import type { M1Deelnemer, M1Parameterset } from '../src/schema.v2'

// AG2024-data injectie (engine vereist dit via globalThis.window.__AG2024__)
const ag = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../ag2024.json'), 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag }

function bijstortForDG(dg: number): number {
  // Onder 125%: geen werkgevers-transitiebijdrage. SSPF-implementatieplan
  // zegt dat onder die DG niet wordt ingevaren. De grafiek toont het
  // hypothetische gedrag (gestippeld) om zichtbaar te maken waarom de
  // drempel bij 125% ligt.
  if (dg < 1.25) return 0
  if (dg < 1.30) return 850
  if (dg < 1.35) return 650
  return 500
}

// SSPF-default deelnemer (70 jaar, € 25.000 pensioen, man, geen partner)
const deelnemer: M1Deelnemer = M1.deelnemer.parse({
  x0: 70,
  pen: 25000,
  g: 'M',
  heeftPartner: false,
  y0: null,
  x_partner: null,
  g_y: 'M',
  hooglaagActief: false,
  pen_laag: 0,
  pen_hoog: 0,
  x_knip: null,
})

const p1: M1Parameterset = M1.parameterset.parse(FONDS.m1)
const m1Out = computeM1(deelnemer, p1, { spreidingN: FONDS.m2.spreidingN })

const ketenInput = {
  KV: m1Out.KV,
  KV_OP: m1Out.KV_OP,
  KV_NP: m1Out.KV_NP,
  cw_star_op: m1Out.cw_star_op,
  cw_star_np: m1Out.cw_star_np,
}

const datapoints: Array<{
  dg: number
  bijstort: number
  ppkTotal: number
  aandeel: number
  invaarStatus: 'hypothetisch' | 'invaring'
}> = []

for (let dgPct = 1000; dgPct <= 1500; dgPct += 1) {
  const dg = dgPct / 1000
  const bijstort = bijstortForDG(dg)
  const invaarStatus: 'hypothetisch' | 'invaring' = dg < 1.25 ? 'hypothetisch' : 'invaring'

  // F = DG × vpvTotal (vpvTotal is anker, mln euro)
  const fondsvermogen = dg * FONDS.m2.vpvTotal

  const params = M2.parameterset.parse({
    ...FONDS.m2,
    dekkingsgraad: dg,
    fondsvermogen,
    bijstort,
  })

  const m2 = computeM2(deelnemer, ketenInput, params)
  const aandeel = m2.ppkTotal - m1Out.KV

  datapoints.push({
    dg,
    bijstort,
    ppkTotal: m2.ppkTotal,
    aandeel,
    invaarStatus,
  })
}

// SSPF-default-run als referentie-anker (DG 1.361). Nu rooster 0.1% is,
// matcht 1.361 exact op een grid-punt; tolerantie 0.0005 voor float-veiligheid.
const sspfDefault = datapoints.find(d => Math.abs(d.dg - 1.361) < 0.0005)

const out = {
  metadata: {
    deelnemer: { x0: 70, pen: 25000, g: 'M', heeftPartner: false },
    fonds: 'SSPF',
    spreidingN: FONDS.m2.spreidingN,
    vpvTotal_mln: FONDS.m2.vpvTotal,
    sspfDefaultDG: FONDS.m2.dekkingsgraad,
    KV: m1Out.KV,
    timestamp: new Date().toISOString(),
  },
  datapoints,
  sspfDefault,
}

fs.writeFileSync(
  path.resolve(__dirname, 'sweep_dg.json'),
  JSON.stringify(out, null, 2)
)

console.log(`Geschreven: prototypes/sweep_dg.json (${datapoints.length} punten)`)
console.log(`M1 KV = €${Math.round(m1Out.KV).toLocaleString('nl-NL')}`)
console.log('')
console.log('DG%   | bijstort | aandeel       | status')
console.log('------+----------+---------------+----------')
// Toon elk 10de punt (= elke 1%) plus alle grid-randen rond bijstort-overgangen
const showAt = new Set<number>()
for (let dgPct10 = 1000; dgPct10 <= 1500; dgPct10 += 10) showAt.add(dgPct10)
// Plus de overgangen scherper bekijken: 129.8-130.2, 134.8-135.2
for (const c of [1298, 1299, 1300, 1301, 1348, 1349, 1350, 1351]) showAt.add(c)

for (const d of datapoints) {
  const dg10 = Math.round(d.dg * 1000)
  if (!showAt.has(dg10)) continue
  const statusStr = d.invaarStatus === 'hypothetisch' ? 'hypothetisch (geen invaring)' : 'invaring'
  console.log(
    `${(d.dg * 100).toFixed(1).padStart(5)} | ${String(d.bijstort).padStart(8)} | €${Math.round(d.aandeel).toLocaleString('nl-NL').padStart(13)} | ${statusStr}`
  )
}
