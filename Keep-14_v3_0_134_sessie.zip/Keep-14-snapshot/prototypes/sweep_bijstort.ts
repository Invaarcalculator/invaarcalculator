/**
 * Bijstort-sensitivity sweep voor prototype-grafiek 2 (vereenvoudigd).
 *
 * Wijzigingen v3:
 *   - X-range: 0 → 2500 mln (matching slider-max in app), 251 punten
 *   - App-defaults: pen=€100k (zoals UI; was €25k voor eerste prototypes)
 *   - Anker voor Y-as: huidige bijstort-slider-stand (SSPF-default €500 mln)
 *   - Y-as toont delta-euro t.o.v. anker, kan negatief en positief
 *
 * Bijstort is DG-onafhankelijk additief — de curve is een rechte lijn
 * met identieke helling ongeacht DG, en hier door (anker, 0).
 */

import * as fs from 'fs'
import * as path from 'path'
import { FONDS } from '../fondsen/sspf/fonds.config'
import { computeM1 } from '../src/engine.m1'
import { computeM2 } from '../src/engine.m2'
import { M1, M2 } from '../src/schema.v2'

const ag = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../ag2024.json'), 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag }

// App-defaults: pen=€100k (zoals UI bij eerste load)
const deelnemer = M1.deelnemer.parse({
  x0: 70, pen: 100000, g: 'M',
  heeftPartner: false, y0: null, x_partner: null, g_y: 'M',
  hooglaagActief: false, pen_laag: 0, pen_hoog: 0, x_knip: null,
})

const p1 = M1.parameterset.parse(FONDS.m1)
const m1Out = computeM1(deelnemer, p1, { spreidingN: FONDS.m2.spreidingN })
const ketenInput = {
  KV: m1Out.KV,
  KV_OP: m1Out.KV_OP,
  KV_NP: m1Out.KV_NP,
  cw_star_op: m1Out.cw_star_op,
  cw_star_np: m1Out.cw_star_np,
}

const DG = FONDS.m2.dekkingsgraad  // 1.361
const fondsvermogen = DG * FONDS.m2.vpvTotal

type Point = { bijstort: number; aandeel: number }
const points: Point[] = []

for (let bijstort = 0; bijstort <= 2500; bijstort += 10) {
  const params = M2.parameterset.parse({
    ...FONDS.m2,
    dekkingsgraad: DG,
    fondsvermogen,
    bijstort,
  })
  const m2 = computeM2(deelnemer, ketenInput, params)
  const aandeel = m2.ppkTotal - m1Out.KV
  points.push({ bijstort, aandeel })
}

const ankerBijstort = FONDS.m2.bijstort
const ankerPunt = points.find(p => p.bijstort === ankerBijstort)
const ankerAandeel = ankerPunt?.aandeel ?? 0

// Annuïteit-factor: KV_OP / pen geeft de "kapitaal per jaareuropensioen"
// verhouding voor deze deelnemer. Wordt in de grafiek gebruikt voor
// een tweede Y-as die de delta-kapitaal omrekent naar delta-jaarpensioen.
const annuiteitFactor = m1Out.KV_OP / deelnemer.pen

const out = {
  metadata: {
    deelnemer: { x0: 70, pen: 100000, g: 'M', heeftPartner: false },
    fonds: 'SSPF',
    DG,
    vpvTotal_mln: FONDS.m2.vpvTotal,
    spreidingN: FONDS.m2.spreidingN,
    KV: m1Out.KV,
    KV_OP: m1Out.KV_OP,
    pen: deelnemer.pen,
    annuiteitFactor,
    ankerBijstort,
    ankerAandeel,
    timestamp: new Date().toISOString(),
  },
  points,
}

fs.writeFileSync(
  path.resolve(__dirname, 'sweep_bijstort.json'),
  JSON.stringify(out, null, 2)
)

console.log(`Geschreven: prototypes/sweep_bijstort.json (${points.length} punten)`)
console.log(`Deelnemer: 70j M, pen €${deelnemer.pen.toLocaleString('nl-NL')}, DG ${(DG*100).toFixed(1)}%`)
console.log(`KV = €${Math.round(m1Out.KV).toLocaleString('nl-NL')}`)
console.log(`Anker: bijstort €${ankerBijstort} mln → aandeel €${Math.round(ankerAandeel).toLocaleString('nl-NL')}`)
console.log('')
console.log('Bijstort | aandeel        | delta-€ (vs anker €' + ankerBijstort + ' mln)')
console.log('---------+----------------+--------------------------------')
const showAt = new Set([0, 250, 500, 750, 1000, 1250, 1500, 1750, 2000, 2250, 2500])
for (const p of points) {
  if (!showAt.has(p.bijstort)) continue
  const delta = p.aandeel - ankerAandeel
  const sign = delta >= 0 ? '+' : ''
  console.log(
    String(p.bijstort).padStart(8) + ' | ' +
    `€${Math.round(p.aandeel).toLocaleString('nl-NL')}`.padStart(14) + ' | ' +
    `${sign}€${Math.round(delta).toLocaleString('nl-NL')}`.padStart(20)
  )
}
