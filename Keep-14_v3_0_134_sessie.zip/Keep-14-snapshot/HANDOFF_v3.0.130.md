# HANDOFF v3.0.130 — Verantwoording-disclaimer

## Wat is nieuw

Tweede knop in de topline rechtsboven: **"Verantwoording"** (rode tekst-variant), naast de bestaande "Uitleg"-knop. Opent een help-modal met een uitgebreide disclaimer-tekst in acht secties.

### De acht secties

1. Wat is deze tool en wat is het niet?
2. Door wie en waarom is deze tool gemaakt? (aanleiding Voeks-ALV 14 april 2026, bredere observatie over "digital twin"-leemte, type vragen die ermee onderbouwd kunnen worden, AI-tools die zijn gebruikt)
3. Hoe ontstaat de afwijking tussen calculator en werkelijkheid? (drie oorzaken)
4. Implicaties per scherm en bronnen van onnauwkeurigheid, plus onafhankelijke verificatie via ABN AMRO Pensioenfonds met twee tabellen (productie-engine v3.0.130 vergelijking tegen ABN-publieke cijfers) en drie observaties inclusief de "verrassing" bij 65-jarige met partner
5. Wat u wel uit deze tool kunt halen
6. Wat u expliciet niet uit deze tool kunt halen
7. Bronnen en versies
8. Contact en feedback

## Wijzigingen per artifact

### `src/ui.app.ts` (vier wijzigingen)

1. **`RELEASE_VERSION = '3.0.130'`** (was 3.0.129)
2. **Type-uitbreiding `HelpSection`** met vierde variant voor simpele tabellen:
   ```typescript
   | { heading: string; tableHeaders: string[]; tableRows: string[][]; intro?: string; outro?: string }
   ```
3. **Render-logic in `openHelpModal`** voor de nieuwe tableRows-variant (`else if ('tableRows' in sec)`): rendert een HTML-tabel met klasse `help-modal-simpletable`, alle cellen geëscaped.
4. **`HELP_CONTENT.verantwoording`** entry toegevoegd na `uitleg`-entry. ~30 secties (tekst-blokken en twee tabel-secties met de ABN-vergelijking).

### `build.calc.ts` (drie wijzigingen)

1. **Tweede knop in topline** naast Uitleg:
   ```html
   <button type="button" class="topline-text-btn topline-text-btn-red" data-help="verantwoording">Verantwoording</button>
   ```
2. **CSS-modifier `.topline-text-btn-red`** met rode tekst (#c00) en rode border, met hover-state (#900 op #fee-achtergrond).
3. **CSS-styling `.help-modal-simpletable`** voor de disclaimer-tabellen: full-width, 0.5px borders, padding 6×8, font-size 12px, lichtgrijze header-achtergrond.

## Engine-regressiecheck

`verify_jaarequivalent.ts` gedraaid na de build. Resultaat ongewijzigd:
- Zonder partner: ≈ +€ 24.091 per jaar levenslang
- Met partner: ≈ +€ 30.496 per jaar levenslang

Geen wijzigingen in `engine.m1.ts`, `engine.m2.ts`, `schema.v2.ts` of fonds-config in deze release.

## Build-artifacts

- `calculator_v3.0.130.html` — 827,6 KB totaal (bundle 189,3 KB + AG2024 81,8 KB + PDF-base64 511,9 KB + HTML/CSS ~44,5 KB)
- Bundle-toename t.o.v. v3.0.129: van 159,8 KB → 189,3 KB (+29,5 KB door HELP_CONTENT.verantwoording-tekst)
- PDF-bytes blijven embedded modelspec v3.0.108 (W17 staat nog open)

## Toegankelijkheid en hergebruik van bestaande infrastructuur

- Click-handler werkt automatisch via bestaande `[data-help]`-attribuut-detector in document-listener (regel 1171 in ui.app.ts) — geen nieuwe event-binding nodig.
- Sluitknop, ESC-key-handling, focus-trap, en overlay-click-to-close werken via bestaande `help-modal-overlay`-infrastructuur.
- De modal scrollt verticaal binnen zijn eigen body-container; lange disclaimer-tekst is volledig leesbaar.

## Bestaande "Disclaimer"-link in footer

De footer bevat al een link `<a data-help="legal">Disclaimer</a>` die de korte `HELP_CONTENT.legal`-tekst opent. Deze blijft ongewijzigd; de nieuwe Verantwoording is een uitgebreider tweede toegangspunt, niet een vervanging. Twee toegangsroutes naar disclaimer-info met verschillende detailniveaus.

## Modelspecificatie

De modelspecificatie-PDF (toegankelijk via de vierde actie-knop "Modelspecificatie") is in v3.0.130 niet herbouwd; de embedded PDF-bytes zijn nog van versie 3.0.108. De disclaimer-tekst (§7) benoemt dit expliciet: "De embedded modelspecificatie-PDF wordt periodiek bijgewerkt en kan tijdelijk een versie achterlopen op de UI." Bij gelegenheid (W17, staat al pending sinds v3.0.108) zou een hercompilatie naar v3.0.130 op zijn plaats zijn; modelspec-inhoud is in de tussentijd inhoudelijk niet wezenlijk veranderd (alleen §9-toevoeging in v3.0.129 over OP/PP-proportionaliteit).

## Pending items (onveranderd uit eerdere handoffs)

- W17: PDF-hercompilatie modelspec (PDF-bytes nog v3.0.108)
- Tekortscenario tekst-tweak bij jaarequivalent-regel
- Cleanup onbereikbare files + CSS
- Transitiebijdrage als DG-functie (bewust laten zitten)
- Visuele tests grafieken op echte devices

## Werkafspraken-context

- W12 (één wijziging per turn): expliciet gerelaxeerd op verzoek van auteur ("Klaar, plaats onder button..."). Drie samenhangende wijzigingen in twee artifacts (type+render+content in ui.app.ts; knop+CSS in build.calc.ts) plus versie-bump.
- W13 (HANDOFF in workdir + zip): dit document plus session-zip in /mnt/user-data/outputs.
- W16 (RELEASE_VERSION+1 voor wijzigingen in src/, build.calc.ts, fondsen/): 3.0.129 → 3.0.130, toegepast.
- W17 (PDF-sync bij modelspec-wijziging): n.v.t. in deze release; geen modelspec-wijziging.

## Verwijzingen die de tool nu naar buiten brengt

De Verantwoording-modal noemt expliciet:
- Drie documenten richting SSPF/DNB (zienswijze 1 sept 2025, vragenbrief 2 mei 2026, aanvullende zienswijze 2 mei 2026), opvraagbaar via e-mail in footer
- LinkedIn-artikel van 9 februari 2026 (volledige URL als plain text, niet als hyperlink — escapeHtml-beperking)
- AI-tools-attributie (Claude tot Opus 4.7, Claude Excel-add-in, PensioenGPT, Mistral, browser-AI's)
- ABN AMRO Pensioenfonds-cohort-cijfers ter onafhankelijke verificatie
- College voor de Rechten van de Mens oordeel 2026-34 d.d. 4 maart 2026

## Volgende stap-suggesties

Niet voor deze release, wel voor toekomst:
- De plain-text URL in §2 zou een echte clickable hyperlink kunnen worden als de modal-renderer een veilige link-variant van de section krijgt (bijv. een `link: { url, label }`-veld) — vergt extra render-logica en escape-uitzondering.
- De Verantwoording-knop staat nu naast Uitleg in de topline; op smalle viewports (mobiel) zou een dropdown of compactere layout overweegbaar zijn.
- De modelspec-PDF kan bij gelegenheid worden hercompileerd naar v3.0.130 (W17).
