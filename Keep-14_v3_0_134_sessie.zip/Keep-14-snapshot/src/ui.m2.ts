/**
 * UI-module 2 — scherm 2 KPI's, sliders, M2-audit-secties.
 *
 * Exporteert pure render-functies + state-mutators. Geen eigen init().
 * Wordt door ui.app.ts geïntegreerd in de gebundelde calculator-pagina.
 *
 * S-UI-2 keuze β (combi-sessie M2 04-05-2026):
 *   - dekkingsgraad-slider (0,85-1,50, stap 0,01, default 1,15)
 *   - vpvAftrekPct-slider (0,06-0,15, stap 0,005, default 0,10)
 *     met §11.19-disclosure direct zichtbaar onder slider
 *   - KPI's: ppkTotal (groot), ppk_OP, ppk_NP, verdeelbaar%, delta vs KV
 */

import { z } from 'zod'
import {
  M2,
  FIELD_REGISTRY,
  fieldsByDisplay,
  fieldsWithDisclosure,
  type FieldMeta,
} from './schema.v2'
import type {
  M1Output,
  M2Parameterset,
  M2Output,
} from './schema.v2'
import { type FieldInfo, escapeHtml, helpIcon } from './ui.shared'

// ============================================================================
// Labels
// ============================================================================

const M2_OUTPUT_LABELS: Record<string, string> = {
  ppkBase: 'Persoonlijk pensioenkapitaal — basis (KV-aandeel)',
  ppkSurplus: 'Persoonlijk pensioenkapitaal — surplus (DG-overschot)',
  ppkComp: 'Persoonlijk pensioenkapitaal — compensatie',
  ppkTotal: 'Persoonlijk pensioenkapitaal — totaal',
  ppk_OP: 'Toedeling — eigen ouderdomspensioen',
  ppk_NP: 'Toedeling — nabestaandenpensioen',
  bufferAandeel: 'Buffer-aandeel (M2→M3-input)',
  vpvTotal: 'Voorziening pensioenverplichtingen (totaal)',
  verdeelbaar: 'Verdeelbaar fondsvermogen',
  phiDerived: 'Indexatie-tempo φ (afgeleid)',
  cohortOutcomes: 'Cohort-uitkomsten (deepdive)',
}

const M2_PARAM_LABELS: Record<string, string> = {
  dekkingsgraad: 'Dekkingsgraad (DG)',
  compensatiedepot: 'Compensatiedepot (mln €)',
  vpvAftrekPct: 'Aftrek bundle (% van vpv)',
  overigeReserves: 'Overige reserves (deprecated)',
  operationeleReserveringPct: 'Operationele reservering % (deprecated)',
  bijstort: 'Bijstort (mln €)',
  N_deelnemers: 'Aantal deelnemers fonds',
  spreidingN: 'Spreidingstermijn N (jaren)',
  compensatieMu: 'Bell-curve μ (compensatie)',
  compensatieSigma: 'Bell-curve σ (compensatie)',
  buffer: 'Buffer (mln €)',
  demografie: 'Demografie-preset / -verdeling',
}

// ============================================================================
// Type-inspectie helpers (minimal duplication van ui.m1 — pure functies)
// ============================================================================

function unwrap(schema: z.ZodTypeAny): z.ZodTypeAny {
  let inner: z.ZodTypeAny = schema
  while (
    inner instanceof z.ZodOptional ||
    inner instanceof z.ZodDefault ||
    inner instanceof z.ZodNullable
  ) {
    inner = inner._def.innerType
  }
  return inner
}

function describeType(schema: z.ZodTypeAny): string {
  const inner = unwrap(schema)
  if (inner instanceof z.ZodNumber) return 'getal'
  if (inner instanceof z.ZodBoolean) return 'ja/nee'
  if (inner instanceof z.ZodString) return 'tekst'
  if (inner instanceof z.ZodEnum) return inner._def.values.join(' | ')
  if (inner instanceof z.ZodLiteral) return String(inner._def.value)
  if (inner instanceof z.ZodArray) return 'array'
  if (inner instanceof z.ZodObject) return 'object'
  if (inner instanceof z.ZodDiscriminatedUnion) return 'union'
  if (inner instanceof z.ZodUnion) {
    return inner._def.options.map((o: z.ZodTypeAny) => describeType(o)).join(' | ')
  }
  return 'onbekend'
}

function isNullable(schema: z.ZodTypeAny): boolean {
  let inner: z.ZodTypeAny = schema
  while (inner instanceof z.ZodOptional || inner instanceof z.ZodDefault) {
    inner = inner._def.innerType
  }
  return inner instanceof z.ZodNullable
}

/**
 * Verzamel velden uit FIELD_REGISTRY voor M2-audit-tabel.
 * fieldsByDisplay('M2', ['parameter-audit']) geeft automatisch shared+M2.
 */
function collectAuditParams(): FieldInfo[] {
  return fieldsByDisplay('M2', ['parameter-audit']).map((f) => ({
    name: f.path.split('.').pop() as string,
    path: f.path,
    meta: f.meta,
    typeLabel: describeType(f.schema),
    nullable: isNullable(f.schema),
  }))
}

/** Output-velden voor M2 (decompositie + deepdive + diagnose). */
function collectAuditOutput(): FieldInfo[] {
  return fieldsByDisplay('M2', ['decompositie', 'deepdive', 'diagnose']).map((f) => ({
    name: f.path.split('.').pop() as string,
    path: f.path,
    meta: f.meta,
    typeLabel: describeType(f.schema),
    nullable: isNullable(f.schema),
  }))
}

// ============================================================================
// Format helpers
// ============================================================================

function euro(n: number, decimals = 0): string {
  return '€ ' + n.toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

function num(n: number | null, decimals = 2): string {
  if (n === null || !Number.isFinite(n)) return '—'
  return n.toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

function pct(n: number, decimals = 1): string {
  return (n * 100).toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }) + '%'
}

// ============================================================================
// M2-uiDisclosure ophalen voor sliders (gebruikt in casual scherm 2)
// ============================================================================

function getDisclosureFor(path: string): string | undefined {
  const f = FIELD_REGISTRY.find((x) => x.path === path)
  return f?.meta.uiDisclosure
}

// ============================================================================
// Casual scherm 2 — KPI's + sliders (β-keuze)
// ============================================================================

/**
 * Render M2-KPI-blok als drielaagse opbouwsom:
 *   M1 (groen) + aandeel verdeelbaar overschot (amber) = M2 (rood)
 *
 * v3.0.85: drielaagse weergave — laat het opbouwverhaal zien tussen M1 en M2.
 * Het middengetal is letterlijk het aandeel van de gebruiker in het
 * verdeelbaar overschot uit de M1/2-cascade, voor of tekort als negatief.
 */
export function renderM2KPI(
  m1Out: M1Output,
  m2Out: M2Output,
  pen: number
): string {
  const aandeel = m2Out.ppkTotal - m1Out.KV
  const aandeelPct = m1Out.KV > 0 ? (aandeel / m1Out.KV) * 100 : 0
  const isPositief = aandeel >= 0
  const operator = isPositief ? '+' : '−'
  const aandeelLabel = isPositief
    ? 'Uw aandeel verdeelbaar overschot'
    : 'Uw aandeel verdeelbaar tekort'
  const pctSign = isPositief ? '+' : '−'

  // v3.0.122: jaarpensioen-equivalent. Omrekening via annuïteit-factor
  // KV / pen, identiek aan rechter Y-as van bijstort-grafiek.
  // Toont alleen als pen > 0 én KV > 0 (anders factor ongedefinieerd).
  // v3.0.123: expliciet "extra (boven uw huidige € X)" zodat duidelijk is
  // dat dit een verhoging is bovenop het huidige pensioen, niet het totaal.
  // v3.0.127: factor KV_OP/pen → KV/pen omdat KV de PP-verplichting al
  // bevat (KV_NP = y0 × ä꜀|ₚ). KV/pen = ä꜀ + (y0/pen)·ä꜀|ₚ, conform
  // pot-formule: Vermogen = pen·ä꜀ + y0·ä꜀|ₚ. Bij partner ligt KV/pen
  // hoger dan KV_OP/pen, dus jaarequivalent realistisch lager.
  let jaarEquivalentRow = ''
  if (pen > 0 && m1Out.KV > 0) {
    const annuiteitFactor = m1Out.KV / pen
    const jaarEquivalent = aandeel / annuiteitFactor
    const jaarSign = jaarEquivalent >= 0 ? '+' : '−'
    const jaarEur = '€ ' + Math.round(Math.abs(jaarEquivalent)).toLocaleString('nl-NL')
    const penEur = '€ ' + Math.round(pen).toLocaleString('nl-NL')
    const extraOrMinder = jaarEquivalent >= 0 ? 'extra' : 'minder'
    jaarEquivalentRow = `
      <div class="kpi-formula-foot kpi-formula-foot-secondary">
        ≈ ${jaarSign} ${jaarEur} ${extraOrMinder} (boven uw huidige ${penEur}) per jaar pensioen levenslang ${helpIcon('jaarequivalent')}
      </div>
    `
  }

  return `
    <div class="kpi-card kpi-m2">
      <div class="kpi-formula">
        <div class="kpi-formula-row">
          <div class="kpi-formula-label">Uw huidige pensioenaanspraak</div>
          <div class="kpi-formula-val kpi-m1-color">${euro(m1Out.KV)}</div>
        </div>
        <div class="kpi-formula-row">
          <div class="kpi-formula-label">${aandeelLabel}</div>
          <div class="kpi-formula-val kpi-m12-color">${operator} ${euro(Math.abs(aandeel))}</div>
        </div>
        <div class="kpi-formula-row kpi-formula-total">
          <div class="kpi-formula-label">Uw persoonlijk pensioenvermogen</div>
          <div class="kpi-formula-val kpi-m2-color">${euro(m2Out.ppkTotal)}</div>
        </div>
      </div>
      <div class="kpi-formula-foot">
        ${pctSign}${Math.abs(aandeelPct).toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}% t.o.v. uw huidige pensioenaanspraak
      </div>
      ${jaarEquivalentRow}
    </div>
  `
}

/**
 * Render scherm-2 sliders + bijbehorende disclosures (β: dekkingsgraad + vpvAftrekPct).
 *
 * Slider-data-attributen (`data-m2field`) worden door ui.app.ts opgepakt.
 */
export function renderM2Sliders(params: M2Parameterset): string {
  const isN10 = params.spreidingN === 10
  const isN1000 = params.spreidingN === 1000
  const isCustom = !isN10 && !isN1000

  // v3.0.79: alleen spreidingstermijn-radio nog over in M2.
  // - dekkingsgraad: verhuisd naar M1/2-pane (waar het past bij de cascade)
  // - vpvAftrekPct: verhuisd naar M1/2-pane (componentsgewijs uit cascade)
  // v3.0.110: radio-group → dropdown in M1-stijl (field-inline-radio +
  // dropdown-pill). isCustom-pad blijft: aangepaste waarden krijgen een
  // expliciete derde optie zodat de dropdown de echte state weergeeft.
  return `
    <div class="m2-controls">
      <div class="field-inline-radio" data-field-row="spreidingN">
        <label for="in-m2-spreidingN" class="inline-radio-label">
          Spreidingstermijn ${helpIcon('spreidingN')}
        </label>
        <select id="in-m2-spreidingN" class="dropdown-pill" data-m2field="spreidingN">
          ${isCustom ? `<option value="${params.spreidingN}" selected>Aangepast: ${params.spreidingN} jaar</option>` : ''}
          <option value="10" ${isN10 ? 'selected' : ''}>10 jaar</option>
          <option value="1000" ${isN1000 ? 'selected' : ''}>Oneindig</option>
        </select>
      </div>
    </div>
  `
}

// ============================================================================
// Audit-scherm M2-secties (parallel aan M1-secties in ui.m1)
// ============================================================================

function renderOutputRow(name: string, value: unknown, meta: FieldMeta): string {
  const label = M2_OUTPUT_LABELS[name] ?? name
  let formatted: string
  if (Array.isArray(value)) {
    formatted = `array[${value.length}]`
  } else if (typeof value === 'number') {
    formatted = name === 'phiDerived'
      ? num(value, 4)
      : (name.startsWith('ppk') || name === 'verdeelbaar' || name === 'vpvTotal' || name === 'bufferAandeel')
        ? euro(value)
        : num(value, 4)
  } else if (value === null) {
    formatted = '—'
  } else {
    formatted = String(value)
  }
  const disclosureMark = meta.uiDisclosure
    ? ` <span class="info" title="${escapeHtml(meta.uiDisclosure)}">ⓘ</span>`
    : ''
  const spec = `<span class="specref">${escapeHtml(meta.specRef)}</span>`
  return `<tr class="display-${meta.display}"><td>${label}${disclosureMark}</td><td class="num">${formatted}</td><td>${spec}</td></tr>`
}

function renderCohortTable(out: M2Output): string {
  const rows = out.cohortOutcomes.map((c) => `
    <tr>
      <td>${c.range}</td>
      <td class="num">${c.midage}</td>
      <td class="num">${c.n.toLocaleString('nl-NL')}</td>
      <td class="num">${c.kvAvg !== null ? euro(c.kvAvg) : '—'}</td>
      <td class="num">${euro(c.surplusBijdrage)}</td>
      <td class="num">${euro(c.compBijdrage)}</td>
    </tr>
  `).join('\n')

  const sumSur = out.cohortOutcomes.reduce((s, c) => s + c.surplusBijdrage, 0)
  const sumComp = out.cohortOutcomes.reduce((s, c) => s + c.compBijdrage, 0)

  return `
    <h3>Cohort-deepdive (§3.4)</h3>
    <table class="cohort-table">
      <thead>
        <tr>
          <th>Cohort</th>
          <th class="num">Midage</th>
          <th class="num">N</th>
          <th class="num">KV gem.</th>
          <th class="num">Surplus-bijdrage (fonds)</th>
          <th class="num">Comp-bijdrage</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>
        <tr class="cohort-totals">
          <td colspan="4">Σ over cohorten (fonds-niveau):</td>
          <td class="num">${euro(sumSur)}</td>
          <td class="num">${euro(sumComp)}</td>
        </tr>
      </tfoot>
    </table>
    <div class="meta-note">
      <strong>Verifieerbaarheidshaak:</strong> Σ comp-bijdrage = compensatiedepot (bell-curve normalisatie).
      Σ surplus-bijdrage is een fonds-niveau diagnostisch getal, NIET gelijk aan persoonlijke ppkSurplus
      (die volgt uit (KV/vpvTotal)·surplus·sFactor(x₀,g)·ν, los van cohort-tabel).
    </div>
  `
}

/**
 * Render M2-audit-secties: decompositie, parameter-audit, cohort-deepdive,
 * disclosure-lijst (M2-only, M1-disclosures staan in M1-audit-sectie).
 *
 * Aangeroepen door ui.app.ts en geplaatst direct ONDER de M1-audit-sectie.
 */
export function renderM2Audit(params: M2Parameterset, out: M2Output | undefined, error?: string): string {
  if (error) {
    return `<div class="pane audit"><h2>Audit-scherm — Module 2 (persoonlijk pensioenvermogen)</h2><div class="error">M2-fout: ${escapeHtml(error)}</div></div>`
  }
  if (!out) {
    return `<div class="pane audit"><h2>Audit-scherm — Module 2 (persoonlijk pensioenvermogen)</h2><p>Geen M2-resultaat beschikbaar.</p></div>`
  }

  const outputFields = collectAuditOutput()
  const paramFields = collectAuditParams()
  const disclosureFields = fieldsWithDisclosure().filter(
    (f) => f.meta.module === 'M2' || (f.meta.module === 'shared' && f.path.includes('parameterset'))
  )

  const o = out as unknown as Record<string, unknown>

  const decompRows = outputFields
    .filter((f) => f.name !== 'cohortOutcomes')
    .map((f) => renderOutputRow(f.name, o[f.name], f.meta))
    .join('\n')

  const paramRows = paramFields
    .map((f) => {
      // Voor demografie-veld special-case (object, niet scalar)
      let displayVal: string
      const current = (params as unknown as Record<string, unknown>)[f.name]
      if (f.name === 'demografie') {
        const d = current as { soort: string; preset?: string; customCounts?: number[] }
        displayVal = d.soort === 'preset' ? `preset: ${d.preset}` : `customCounts[15]`
      } else if (current === null || current === undefined) {
        displayVal = '(niet gezet)'
      } else {
        displayVal = String(current)
      }
      const disclosure = f.meta.uiDisclosure
        ? `<div class="disclosure-inline">⚠ ${escapeHtml(f.meta.uiDisclosure)}</div>`
        : ''
      const moduleTag = f.meta.module === 'shared'
        ? `<span class="modtag modtag-shared">shared</span>`
        : `<span class="modtag modtag-m2">M2</span>`
      return `<tr>
        <td>${moduleTag}<code>${M2_PARAM_LABELS[f.name] ?? f.name}</code></td>
        <td>${escapeHtml(f.typeLabel)}</td>
        <td class="num">${escapeHtml(displayVal)}</td>
        <td><span class="specref">${escapeHtml(f.meta.specRef)}</span></td>
        <td>${disclosure || ''}</td>
      </tr>`
    })
    .join('\n')

  const disclosureList = disclosureFields
    .map((f) => `<li><code>${f.path}</code> — ${escapeHtml(f.meta.uiDisclosure || '')}</li>`)
    .join('\n')

  const m2Count = FIELD_REGISTRY.filter(f => f.meta.module === 'M2').length
  const sharedCount = FIELD_REGISTRY.filter(f => f.meta.module === 'shared').length

  return `
    <div class="pane audit pane-m2">
      <h2>Audit-scherm — Module 2 (persoonlijk pensioenvermogen)</h2>

      <h3>Output-decompositie (§3.4 + §3.5 v2.2.10)</h3>
      <table>
        <thead><tr><th>Grootheid</th><th class="num">Waarde</th><th>Spec</th></tr></thead>
        <tbody>${decompRows}</tbody>
      </table>

      ${renderCohortTable(out)}

      <h3>Parameterset (§3.3 + shared) — ${paramFields.length} velden</h3>
      <table>
        <thead><tr><th>Parameter</th><th>Type</th><th class="num">Waarde</th><th>Spec</th><th>Noot</th></tr></thead>
        <tbody>${paramRows}</tbody>
      </table>

      <h3>UI-disclosure-eisen M2 (spec-verankerd)</h3>
      <ul class="disclosure-list">
        ${disclosureList || '<li>(geen)</li>'}
      </ul>

      <div class="meta-note">
        Gegenereerd uit SCHEMA v2.0 metadata: ${m2Count} M2-velden + ${sharedCount} shared-velden geregistreerd.
        v2.2.10 Model C: bundle-aftrek <code>vpvAftrekPct·vpvTotal</code> + losse <code>compensatiedepot</code>.
        <code>overigeReserves</code> en <code>operationeleReserveringPct</code> zijn deprecated v2.2.10 (legacy v2.1.x; SCHEMA-vereist voor backward-compat).
      </div>
    </div>
  `
}

// ============================================================================
// Slider-event-handlers — exporteren voor ui.app.ts
// ============================================================================

/**
 * Pas een slider-input toe op M2-parameterset state. Returnt nieuwe parameters.
 * Slider-veldnamen: 'dekkingsgraad' | 'vpvAftrekPct' | 'spreidingN'.
 */
export function applyM2SliderInput(
  params: M2Parameterset,
  field: string,
  rawValue: string
): M2Parameterset {
  const num = Number(rawValue)
  if (!Number.isFinite(num)) return params
  if (field === 'dekkingsgraad' || field === 'vpvAftrekPct') {
    return { ...params, [field]: num }
  }
  if (field === 'spreidingN') {
    // Integer-cast voor radio-input "10" / "1000"
    const N = Math.round(num)
    if (N < 0 || N > 1000) return params
    return { ...params, spreidingN: N }
  }
  return params
}
