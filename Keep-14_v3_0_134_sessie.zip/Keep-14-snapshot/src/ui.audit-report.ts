/**
 * v3.0.92 — Audit-rapport (browser-native print).
 *
 * Bouwt een verborgen <div id="print-report"> uit de huidige state met de
 * volledige audit-uitvoer (decompositie, parameterset, cohort, disclosures).
 * Verschijnt alleen in print-context (CSS @media print) zodat de gebruiker
 * via "Afdrukken / Opslaan als PDF" een nette weergave krijgt.
 *
 * Vervangt de inline audit-pane (v3.0.3 t/m v3.0.91) die via toegangscode
 * verborgen was. De audit-uitvoer is nu een normaal print-rapport zonder
 * code-bescherming, parallel aan ui.print.ts (Mijn rapport).
 *
 * Structuur (parallel aan ui.print.ts):
 *   1. Kop: invoerdatum, fonds, ingevulde UPO-gegevens
 *   2. Module 1: decompositie + parameterset
 *   3. Module 2: decompositie + cohort-tabel + parameterset
 *   4. Fondsparameters: per module welke parameters het fonds vastlegt
 *      en welke daarvan via de UI aanpasbaar zijn, plus aanwendings-cascade
 *      (v3.0.95 verhuisd uit ui.app.ts buildFondsHelp/buildAanwendingsCascadeBlock)
 *   5. UI-disclosure-eisen (gecombineerd M1+M2, spec-verankerd)
 *   6. Methodologie en spec-verwijzingen
 *   7. Disclaimer
 *
 * Privacy: alle data blijft client-side; window.print() opent de browser-PDF.
 *
 * Geen em-dashes in user-facing tekst (Werkafspraak v3.0.40).
 */

import type { M1Output, M2Output, M2Parameterset } from './schema.v2'
import {
  M1,
  FIELD_REGISTRY,
  fieldsByDisplay,
  fieldsWithDisclosure,
} from './schema.v2'
import { FONDS } from './fondsdataset'
import { escapeHtml } from './ui.shared'

// ============================================================================
// Input-contract
// ============================================================================

export interface AuditReportInput {
  deelnemer: {
    x0: number
    pen: number
    g: 'M' | 'V' | 'gemengd'
    heeftPartner: boolean
    y0: number | null
    x_partner: number | null
    g_y: 'M' | 'V' | 'gemengd'
  }
  parameters_m1: { r: number; [k: string]: unknown }
  parameters_m2: M2Parameterset
  lastM1?: M1Output
  lastM2?: M2Output
  lastM1Error?: string
  lastM2Error?: string
  releaseVersion: string
  releaseDate: string
}

// ============================================================================
// Format helpers (lokaal, identiek aan ui.print.ts)
// ============================================================================

const eur = (n: number): string =>
  '\u20AC ' + Math.round(n).toLocaleString('nl-NL')
const num = (n: number, d = 0): string =>
  n.toLocaleString('nl-NL', { minimumFractionDigits: d, maximumFractionDigits: d })
const pct = (n: number, d = 2): string =>
  (n * 100).toLocaleString('nl-NL', { minimumFractionDigits: d, maximumFractionDigits: d }) + '%'

const GESLACHT_LABEL: Record<string, string> = { M: 'man', V: 'vrouw', gemengd: 'gemengd' }

// ============================================================================
// Audit-output- en parameter-labels (gemigreerd uit oude renderM1Audit/M2Audit)
// ============================================================================

const M1_OUTPUT_LABELS: Record<string, string> = {
  KV: 'Huidige waarde van uw aanspraak',
  KV_OP: 'Aandeel ouderdomspensioen',
  KV_NP: 'Aandeel nabestaandenpensioen',
  lifeExp_x0: 'Verwachte sterfleeftijd deelnemer',
  lifeExp_x_partner: 'Verwachte sterfleeftijd partner',
  sFactor_OP: 's-factor ouderdomspensioen',
  sFactor_NP: 's-factor nabestaandenpensioen',
  cw_OP: 'Contante waarde ouderdomspensioen',
  cw_NP: 'Contante waarde nabestaandenpensioen',
  CW_star: 'CW* (q-factor toegepast)',
}

const M1_PARAM_LABELS: Record<string, string> = {
  r: 'Rekenrente',
  pi: 'Indexatie',
  m: 'Uitkeringsfrequentie',
  t0: 'Peiljaar',
  omega: 'Eindleeftijd',
  ervaringsSterfte: 'Ervaringssterfte',
  annuiteitsconventie: 'Annuiteitsconventie',
  sterftekansTabelId: 'Sterftetafel',
}

const M2_OUTPUT_LABELS: Record<string, string> = {
  ppkBase: 'Persoonlijk pensioenkapitaal basis',
  ppkSurplus: 'Persoonlijk pensioenkapitaal surplus',
  ppkComp: 'Persoonlijk pensioenkapitaal compensatie',
  ppkTotal: 'Persoonlijk pensioenkapitaal totaal',
  ppk_OP: 'Toedeling eigen ouderdomspensioen',
  ppk_NP: 'Toedeling nabestaandenpensioen',
  bufferAandeel: 'Buffer-aandeel',
  vpvTotal: 'Voorziening pensioenverplichtingen totaal',
  verdeelbaar: 'Verdeelbaar fondsvermogen',
  phiDerived: 'Indexatie-tempo afgeleid',
}

const M2_PARAM_LABELS: Record<string, string> = {
  dekkingsgraad: 'Dekkingsgraad',
  compensatiedepot: 'Compensatiedepot in mln euro',
  vpvAftrekPct: 'Aftrek-bundel als percentage van vpv',
  overigeReserves: 'Overige reserves (deprecated)',
  operationeleReserveringPct: 'Operationele reservering percentage (deprecated)',
  bijstort: 'Bijstort in mln euro',
  N_deelnemers: 'Aantal deelnemers fonds',
  spreidingN: 'Spreidingstermijn in jaren',
  compensatieMu: 'Bell-curve mu compensatie',
  compensatieSigma: 'Bell-curve sigma compensatie',
  buffer: 'Buffer in mln euro',
  demografie: 'Demografie-preset of -verdeling',
}

// ============================================================================
// Sectie-builders
// ============================================================================

function formatM1OutputValue(name: string, value: unknown): string {
  if (value === null || value === undefined) return '—'
  if (typeof value === 'number') {
    if (name.startsWith('KV') || name.startsWith('cw')) return eur(value)
    if (name.startsWith('lifeExp')) return num(value, 2)
    return num(value, 3)
  }
  return String(value)
}

function formatM2OutputValue(name: string, value: unknown): string {
  if (Array.isArray(value)) return `array[${value.length}]`
  if (value === null || value === undefined) return '—'
  if (typeof value === 'number') {
    if (name === 'phiDerived') return num(value, 4)
    if (name.startsWith('ppk') || name === 'verdeelbaar' || name === 'vpvTotal' || name === 'bufferAandeel') {
      return eur(value)
    }
    return num(value, 4)
  }
  return String(value)
}

function buildKopSectie(input: AuditReportInput, printDate: string): string {
  const { deelnemer, releaseVersion, releaseDate } = input
  const fonds = FONDS

  const partnerRows = deelnemer.heeftPartner && deelnemer.y0 !== null && deelnemer.x_partner !== null
    ? `
        <tr><td>Leeftijd partner</td><td class="num">${num(deelnemer.x_partner)} jaar</td></tr>
        <tr><td>Geslacht partner</td><td class="num">${escapeHtml(GESLACHT_LABEL[deelnemer.g_y] ?? deelnemer.g_y)}</td></tr>
        <tr><td>Jaarlijks bruto nabestaandenpensioen</td><td class="num">${eur(deelnemer.y0)}</td></tr>
      `
    : `<tr><td>Partnerpensioen</td><td class="num">geen</td></tr>`

  return `
    <header class="pr-header">
      <h1>Invaarcalculator&reg; audit-rapport</h1>
      <p class="pr-subtitle">Technische uitvoer voor controle en verificatie</p>
      <p class="pr-meta">
        Datum afdruk: ${escapeHtml(printDate)}<br>
        Gekozen pensioenfonds: ${escapeHtml(fonds.label)}<br>
        Versie: ${escapeHtml(releaseVersion)} (build ${escapeHtml(releaseDate)})
      </p>
    </header>

    <section class="pr-section">
      <h2>1. Uw invoer</h2>
      <table class="pr-table">
        <tbody>
          <tr><td>Leeftijd</td><td class="num">${num(deelnemer.x0)} jaar</td></tr>
          <tr><td>Geslacht</td><td class="num">${escapeHtml(GESLACHT_LABEL[deelnemer.g] ?? deelnemer.g)}</td></tr>
          <tr><td>Jaarlijks bruto ouderdomspensioen</td><td class="num">${eur(deelnemer.pen)}</td></tr>
          ${partnerRows}
        </tbody>
      </table>
    </section>
  `
}

function buildM1Sectie(input: AuditReportInput): string {
  const { lastM1, lastM1Error, parameters_m1 } = input

  if (lastM1Error) {
    return `<section class="pr-section"><h2>2. Module 1: huidige waarde</h2>
      <p class="pr-error">M1-fout: ${escapeHtml(lastM1Error)}</p></section>`
  }
  if (!lastM1) {
    return `<section class="pr-section"><h2>2. Module 1: huidige waarde</h2>
      <p class="pr-error">Geen M1-resultaat beschikbaar.</p></section>`
  }

  const o = lastM1 as unknown as Record<string, unknown>

  // Decompositie/deepdive/diagnose-rijen uit FIELD_REGISTRY
  const outputFields = fieldsByDisplay('M1', ['decompositie', 'deepdive', 'diagnose'])
  const decompositionRows = outputFields
    .map((f) => {
      const fieldName = f.path.split('.').pop() as string
      const label = M1_OUTPUT_LABELS[fieldName] ?? fieldName
      const formatted = formatM1OutputValue(fieldName, o[fieldName])
      return `<tr><td>${escapeHtml(label)}</td>
        <td class="num">${formatted}</td>
        <td><code>${escapeHtml(f.meta.specRef)}</code></td></tr>`
    })
    .join('\n')

  // M1 parameterset-rijen
  const m1ParamFields = fieldsByDisplay('M1', ['parameter-audit'])
  const parameterRows = m1ParamFields
    .map((f) => {
      const fieldName = f.path.split('.').pop() as string
      const current = (parameters_m1 as Record<string, unknown>)[fieldName]
      const displayVal = current === null || current === undefined ? '(niet gezet)' : String(current)
      const moduleTag = f.meta.module === 'shared'
        ? `<span class="modtag modtag-shared">shared</span>`
        : `<span class="modtag modtag-m1">M1</span>`
      const label = M1_PARAM_LABELS[fieldName] ?? fieldName
      return `<tr>
        <td>${moduleTag} ${escapeHtml(label)}</td>
        <td class="num">${escapeHtml(displayVal)}</td>
        <td><code>${escapeHtml(f.meta.specRef)}</code></td>
      </tr>`
    })
    .join('\n')

  return `
    <section class="pr-section pr-pagebreak">
      <h2>2. Module 1: huidige waarde</h2>

      <h3>Decompositie, deepdive en diagnose</h3>
      <table class="pr-table">
        <thead><tr><th>Grootheid</th><th class="num">Waarde</th><th>Spec</th></tr></thead>
        <tbody>${decompositionRows}</tbody>
      </table>

      <h3>Parameterset (${m1ParamFields.length} velden)</h3>
      <table class="pr-table">
        <thead><tr><th>Parameter</th><th class="num">Waarde</th><th>Spec</th></tr></thead>
        <tbody>${parameterRows}</tbody>
      </table>
    </section>
  `
}

function buildM2Sectie(input: AuditReportInput): string {
  const { lastM2, lastM2Error, parameters_m2 } = input

  if (lastM2Error) {
    return `<section class="pr-section"><h2>3. Module 2: persoonlijk pensioenvermogen</h2>
      <p class="pr-error">M2-fout: ${escapeHtml(lastM2Error)}</p></section>`
  }
  if (!lastM2) {
    return `<section class="pr-section"><h2>3. Module 2: persoonlijk pensioenvermogen</h2>
      <p class="pr-error">Geen M2-resultaat beschikbaar.</p></section>`
  }

  const o = lastM2 as unknown as Record<string, unknown>

  // M2 decompositie (zonder cohortOutcomes; die krijgt eigen tabel)
  const outputFields = fieldsByDisplay('M2', ['decompositie', 'deepdive', 'diagnose'])
    .filter((f) => f.path.split('.').pop() !== 'cohortOutcomes')
  const decompRows = outputFields
    .map((f) => {
      const fieldName = f.path.split('.').pop() as string
      const label = M2_OUTPUT_LABELS[fieldName] ?? fieldName
      const formatted = formatM2OutputValue(fieldName, o[fieldName])
      return `<tr><td>${escapeHtml(label)}</td>
        <td class="num">${formatted}</td>
        <td><code>${escapeHtml(f.meta.specRef)}</code></td></tr>`
    })
    .join('\n')

  // Cohort-tabel
  const cohortRows = lastM2.cohortOutcomes
    .map((c) => `
      <tr>
        <td>${escapeHtml(c.range)}</td>
        <td class="num">${num(c.midage)}</td>
        <td class="num">${c.n.toLocaleString('nl-NL')}</td>
        <td class="num">${c.kvAvg !== null ? eur(c.kvAvg) : '—'}</td>
        <td class="num">${eur(c.surplusBijdrage)}</td>
        <td class="num">${eur(c.compBijdrage)}</td>
      </tr>
    `)
    .join('\n')
  const sumSur = lastM2.cohortOutcomes.reduce((s, c) => s + c.surplusBijdrage, 0)
  const sumComp = lastM2.cohortOutcomes.reduce((s, c) => s + c.compBijdrage, 0)

  // M2 parameterset
  const m2ParamFields = fieldsByDisplay('M2', ['parameter-audit'])
  const paramRows = m2ParamFields
    .map((f) => {
      const fieldName = f.path.split('.').pop() as string
      const current = (parameters_m2 as unknown as Record<string, unknown>)[fieldName]
      let displayVal: string
      if (fieldName === 'demografie') {
        const d = current as { soort: string; preset?: string; customCounts?: number[] }
        displayVal = d.soort === 'preset' ? `preset: ${d.preset}` : 'customCounts'
      } else if (current === null || current === undefined) {
        displayVal = '(niet gezet)'
      } else {
        displayVal = String(current)
      }
      const moduleTag = f.meta.module === 'shared'
        ? `<span class="modtag modtag-shared">shared</span>`
        : `<span class="modtag modtag-m2">M2</span>`
      const label = M2_PARAM_LABELS[fieldName] ?? fieldName
      return `<tr>
        <td>${moduleTag} ${escapeHtml(label)}</td>
        <td class="num">${escapeHtml(displayVal)}</td>
        <td><code>${escapeHtml(f.meta.specRef)}</code></td>
      </tr>`
    })
    .join('\n')

  return `
    <section class="pr-section pr-pagebreak">
      <h2>3. Module 2: persoonlijk pensioenvermogen</h2>

      <h3>Output-decompositie</h3>
      <table class="pr-table">
        <thead><tr><th>Grootheid</th><th class="num">Waarde</th><th>Spec</th></tr></thead>
        <tbody>${decompRows}</tbody>
      </table>

      <h3>Cohort-deepdive</h3>
      <table class="pr-table cohort-table">
        <thead>
          <tr>
            <th>Cohort</th>
            <th class="num">Midage</th>
            <th class="num">N</th>
            <th class="num">KV gem.</th>
            <th class="num">Surplus-bijdrage</th>
            <th class="num">Comp-bijdrage</th>
          </tr>
        </thead>
        <tbody>${cohortRows}</tbody>
        <tfoot>
          <tr>
            <td colspan="4">Som over cohorten op fondsniveau</td>
            <td class="num">${eur(sumSur)}</td>
            <td class="num">${eur(sumComp)}</td>
          </tr>
        </tfoot>
      </table>
      <p class="pr-note"><strong>Verifieerbaarheidshaak:</strong> som comp-bijdrage gelijk aan compensatiedepot (bell-curve normalisatie). Som surplus-bijdrage is fonds-niveau diagnostisch en niet gelijk aan persoonlijke ppkSurplus.</p>

      <h3>Parameterset (${m2ParamFields.length} velden)</h3>
      <table class="pr-table">
        <thead><tr><th>Parameter</th><th class="num">Waarde</th><th>Spec</th></tr></thead>
        <tbody>${paramRows}</tbody>
      </table>
    </section>
  `
}

function buildDisclosureSectie(): string {
  const all = fieldsWithDisclosure()
  const m1Items = all.filter((f) => f.meta.module === 'M1' || (f.meta.module === 'shared' && f.path.includes('parameterset')))
  const m2Items = all.filter((f) => f.meta.module === 'M2')

  const m1List = m1Items
    .map((f) => `<li><code>${escapeHtml(f.path)}</code>: ${escapeHtml(f.meta.uiDisclosure ?? '')}</li>`)
    .join('\n')
  const m2List = m2Items
    .map((f) => `<li><code>${escapeHtml(f.path)}</code>: ${escapeHtml(f.meta.uiDisclosure ?? '')}</li>`)
    .join('\n')

  return `
    <section class="pr-section pr-pagebreak">
      <h2>5. UI-disclosure-eisen</h2>
      <p class="pr-intro">Spec-verankerde transparantie-eisen per veld; zichtbaar gemaakt in de calculator-UI of in dit rapport.</p>

      <h3>Module 1 disclosures</h3>
      <ul class="pr-refs">${m1List || '<li>(geen)</li>'}</ul>

      <h3>Module 2 disclosures</h3>
      <ul class="pr-refs">${m2List || '<li>(geen)</li>'}</ul>
    </section>
  `
}

function buildMethodologieSectie(): string {
  const m1Count = FIELD_REGISTRY.filter((f) => f.meta.module === 'M1').length
  const m2Count = FIELD_REGISTRY.filter((f) => f.meta.module === 'M2').length
  const sharedCount = FIELD_REGISTRY.filter((f) => f.meta.module === 'shared').length

  return `
    <section class="pr-section pr-pagebreak">
      <h2>6. Methodologie en spec-verwijzingen</h2>

      <h3>Berekeningsmodel</h3>
      <p>Module 1 berekent de huidige waarde door alle toekomstige uitkeringen contant te maken naar vandaag, gewogen met de overlevingskans uit de AG2024-prognosetafel:</p>
      <pre class="pr-formula">KV_OP = (1 + ervaringsSterfte) &middot; pen &middot; &auml;(x&#8320;, r)
KV_NP = (1 + ervaringsSterfte) &middot; y&#8320; &middot; &auml;_jointLife(x&#8320;, x_partner, r)
KV    = KV_OP + KV_NP</pre>

      <p>Module 2 implementeert de standaardregel uit Bijlage 2a Regeling Pensioenwet:</p>
      <pre class="pr-formula">M           = fondsvermogen &minus; vpvAftrekPct &middot; vpvTotal
              &minus; compensatiedepot &minus; buffer + bijstort

x_fonds     = (M &minus; vpvTotal) / CW_star_fonds

ppkBase     = KV
ppkSurplus  = x_fonds &middot; cw_star
ppkTotal    = ppkBase + ppkSurplus + ppkComp</pre>

      <h3>Wettelijke verwijzingen</h3>
      <ul class="pr-refs">
        <li>Pensioenwet, hoofdstuk 5 (transitie naar Wtp)</li>
        <li>Bijlage 2a Regeling Pensioenwet, artikel 2 (q-factor en spreiding) en artikel 3 (verdeelbaar fondsvermogen)</li>
        <li>Artikel 150f Pensioenwet (compensatie)</li>
        <li>AG-prognosetafel 2024</li>
        <li>DNB risicovrije rentetermijnstructuur</li>
      </ul>

      <p class="pr-note">Schema-omvang: ${m1Count} M1-velden, ${m2Count} M2-velden, ${sharedCount} shared-velden geregistreerd in FIELD_REGISTRY (SCHEMA v2.2.10 Model C). Bundle-aftrek <code>vpvAftrekPct&middot;vpvTotal</code> + losse <code>compensatiedepot</code>; <code>overigeReserves</code> en <code>operationeleReserveringPct</code> deprecated.</p>
    </section>
  `
}

function buildDisclaimerSectie(): string {
  return `
    <section class="pr-section pr-disclaimer">
      <h2>7. Disclaimer</h2>
      <p>Dit audit-rapport bevat de technische uitvoer van de Invaarcalculator&reg; voor de invoer en parameter-instellingen op het moment van afdrukken. Aan deze uitvoer kunnen geen rechten worden ontleend; de werkelijke waarde van uw pensioenaanspraak en uw persoonlijk pensioenvermogen na invaren wordt vastgesteld door uw pensioenfonds.</p>
      <p>De Invaarcalculator&reg; verwerkt uw invoer uitsluitend in uw eigen browser. Er worden geen gegevens verstuurd, opgeslagen of gedeeld met derden.</p>
    </section>
  `
}

// ============================================================================
// Hoofdbouwer en trigger
// ============================================================================

// ============================================================================
// Sectie 4: Fondsparameters (v3.0.95 verhuisd uit ui.app.ts buildFondsHelp +
// buildAanwendingsCascadeBlock). Toont per module welke parameters het fonds
// vastlegt en welke daarvan via de UI aanpasbaar zijn, plus de aanwendings-
// cascade voor het fondsvermogen bij invaren.
// ============================================================================

function buildFondsparametersSectie(): string {
  const fonds = FONDS
  const m1 = fonds.m1
  const m2 = fonds.m2
  const c = fonds.aanwendingsCascade
  const spreidLabel = m2.spreidingN >= 1000 ? 'Oneindig (levenslang)' : `${m2.spreidingN} jaar`
  const demoLabel = m2.demografie.soort === 'preset'
    ? `Preset "${m2.demografie.preset}"`
    : 'Maatwerk'

  type Row = { label: string; value: string; adj: boolean; note: string }
  const m1Rows: Row[] = [
    { label: 'Rekenrente', value: pct(m1.r), adj: true,
      note: 'Slider in scherm "Uw huidige pensioenaanspraak"' },
    { label: 'Sterftetafel', value: m1.sterftekansTabelId, adj: false, note: '' },
    { label: 'Peiljaar', value: String(m1.t0), adj: false, note: '' },
    { label: 'Indexatie', value: pct(m1.pi), adj: false, note: '' },
    { label: 'Uitkeringsfrequentie', value: `${m1.m}\u00D7 per jaar`, adj: false, note: '' },
    { label: 'Annu\u00EFteitsconventie', value: m1.annuiteitsconventie, adj: false, note: '' },
    { label: 'Eindleeftijd', value: `${m1.omega} jaar`, adj: false, note: '' },
    { label: 'Ervaringssterfte', value: m1.ervaringsSterfte.toFixed(2), adj: false, note: '' },
  ]
  const m2Rows: Row[] = [
    { label: 'Dekkingsgraad', value: pct(m2.dekkingsgraad, 1), adj: true,
      note: 'Slider in scherm "Tekort of overschot"; beweegt in tandem met fondsvermogen' },
    { label: 'Aftrek voor reserveringen', value: pct(m2.vpvAftrekPct, 1), adj: true,
      note: 'Cascade-sliders in scherm "Tekort of overschot"' },
    { label: 'Spreidingstermijn', value: spreidLabel, adj: true,
      note: 'Radio in scherm "Uw persoonlijk pensioenvermogen"' },
    { label: 'Fondsvermogen', value: `\u20AC ${num(m2.fondsvermogen)} mln`, adj: false,
      note: 'Zie aanwendings-cascade hieronder' },
    { label: 'Compensatiedepot', value: `\u20AC ${num(m2.compensatiedepot)} mln`, adj: false,
      note: m2.compensatiedepot === 0 ? 'In aftrek-bundel verrekend' : '' },
    { label: 'Bijstort werkgever', value: `\u20AC ${num(m2.bijstort)} mln`, adj: false,
      note: 'Zie aanwendings-cascade hieronder' },
    { label: 'Aantal deelnemers', value: num(m2.N_deelnemers), adj: false, note: '' },
    { label: 'Demografie', value: demoLabel, adj: false, note: '' },
  ]

  const renderRow = (r: Row) => `
        <tr>
          <td>${escapeHtml(r.label)}${r.adj ? ' <span class="adj-tag">Aanpasbaar</span>' : ''}</td>
          <td class="num">${escapeHtml(r.value)}</td>
          <td>${r.note ? escapeHtml(r.note) : ''}</td>
        </tr>`

  const m1Tbody = m1Rows.map(renderRow).join('')
  const m2Tbody = m2Rows.map(renderRow).join('')

  // Aanwendings-cascade tabel (alleen wanneer fonds een cascade definieert)
  let cascadeBlock = ''
  if (c) {
    const vpv = m2.vpvTotal > 0 ? m2.vpvTotal : m2.fondsvermogen / m2.dekkingsgraad
    const wettelijkEur = c.wettelijkeReservesPct * vpv
    const M = m2.fondsvermogen + m2.bijstort - wettelijkEur - c.rdrBedrag - c.compensatiedepotBedrag
    type CascadeRow = { kind: string; label: string; value: string; note: string }
    const cascadeRows: CascadeRow[] = [
      { kind: 'input', label: 'Fondsvermogen',
        value: `\u20AC ${num(m2.fondsvermogen)} mln`, note: '' },
      { kind: 'plus', label: c.bijstortLabel,
        value: `\u20AC ${num(m2.bijstort)} mln`, note: c.bijstortNote ?? '' },
      { kind: 'subtotal', label: 'Opgehoogd fondsvermogen',
        value: `\u20AC ${num(m2.fondsvermogen + m2.bijstort)} mln`, note: '' },
      { kind: 'minus', label: 'Wettelijke reserves (MVEV + operationele reserve)',
        value: pct(c.wettelijkeReservesPct, 1), note: c.wettelijkeReservesNote ?? '' },
      { kind: 'minus', label: 'Risicodelingsreserve',
        value: `\u20AC ${num(c.rdrBedrag)} mln`, note: c.rdrNote ?? '' },
      { kind: 'minus', label: 'Compensatiedepot',
        value: `\u20AC ${num(c.compensatiedepotBedrag)} mln`, note: c.compensatiedepotNote ?? '' },
      { kind: 'total', label: 'Verdeelbaar voor persoonlijke vermogens',
        value: `\u20AC ${num(Math.round(M))} mln`,
        note: 'Wordt vervolgens via de standaardregel (Bijlage 2a Pw) over alle deelnemers verdeeld.' },
    ]
    const cascadeTbody = cascadeRows.map((r) => `
        <tr class="pr-cascade-${r.kind}">
          <td>${escapeHtml(r.label)}</td>
          <td class="num">${escapeHtml(r.value)}</td>
          <td>${escapeHtml(r.note)}</td>
        </tr>`).join('')
    cascadeBlock = `
      <h3>Aanwending fondsvermogen bij invaren</h3>
      <p class="pr-intro">${escapeHtml(c.intro ?? 'Bij invaren wordt het fondsvermogen eerst opgehoogd met de transitiebijdrage van de werkgever, en daarna in stappen afgesplitst voor wettelijke en collectieve reserves. Wat overblijft wordt over de persoonlijke pensioenvermogens verdeeld via de standaardregel (Bijlage 2a Regeling Pw).')}</p>
      <table class="pr-table pr-cascade-table">
        <thead><tr><th>Post</th><th class="num">Bedrag</th><th>Bron / toelichting</th></tr></thead>
        <tbody>${cascadeTbody}</tbody>
      </table>
      ${c.outroTekst ? `<p class="pr-note">${escapeHtml(c.outroTekst)}</p>` : ''}`
  }

  return `
    <section class="pr-section pr-pagebreak">
      <h2>4. Fondsparameters</h2>
      <p class="pr-intro">Volledige set parameters die ${escapeHtml(fonds.label)} gebruikt in deze berekening. Module 1 berekent uw huidige pensioenaanspraak; Module 2 berekent uw persoonlijk pensioenvermogen na invaren. Parameters met "Aanpasbaar"-label kunt u via de calculator-sliders verschuiven; de overige zijn fondsspecifiek.</p>

      <h3>Module 1 &middot; Uw huidige pensioenaanspraak</h3>
      <p class="pr-intro">Parameters voor de actuari\u00EBle waardering van uw aanspraak vandaag.</p>
      <table class="pr-table">
        <thead><tr><th>Parameter</th><th class="num">Waarde</th><th>Toelichting</th></tr></thead>
        <tbody>${m1Tbody}</tbody>
      </table>

      <h3>Module 2 &middot; Uw persoonlijk pensioenvermogen</h3>
      <p class="pr-intro">Aanvullende parameters voor de invaarberekening (Bijlage 2a Regeling Pw). Module 2 gebruikt ook alle parameters uit Module 1.</p>
      <table class="pr-table">
        <thead><tr><th>Parameter</th><th class="num">Waarde</th><th>Toelichting</th></tr></thead>
        <tbody>${m2Tbody}</tbody>
      </table>

      ${cascadeBlock}

      <h3>Wie stelt wat in?</h3>
      <p>De parameters die als "Aanpasbaar" zijn gemarkeerd kunt u in deze calculator zelf verschuiven om de gevoeligheid van uw uitkomst te verkennen, bijvoorbeeld om te zien wat een lagere dekkingsgraad of een 10-jaars spreiding voor u betekent. De overige parameters zijn fondsspecifiek en worden door het bestuur en de uitvoerder van het pensioenfonds vastgesteld op basis van het transitieplan en de wet- en regelgeving (Pensioenwet, Bijlage 2a Regeling Pensioenwet, DNB-rentetermijnstructuur, AG-prognosetafels). Voor onderbouwing per parameter, zie de bron-citaten in de codebron-documentatie van deze tool.</p>
    </section>
  `
}

export function buildAuditReportHtml(input: AuditReportInput): string {
  // Datum-helper inline, parallel aan ui.print.ts
  const today = new Date()
  const dd = String(today.getDate()).padStart(2, '0')
  const mm = String(today.getMonth() + 1).padStart(2, '0')
  const yyyy = today.getFullYear()
  const printDate = `${dd}-${mm}-${yyyy}`

  // Workaround tegen unused-import-warning voor M1 (FIELD_REGISTRY-import is
  // wel noodzakelijk via fieldsByDisplay; M1 schema niet hier gebruikt maar
  // beschikbaar voor toekomstige uitbreiding zoals deelnemer-velden uit
  // M1.deelnemer)
  void M1

  return (
    buildKopSectie(input, printDate) +
    buildM1Sectie(input) +
    buildM2Sectie(input) +
    buildFondsparametersSectie() +
    buildDisclosureSectie() +
    buildMethodologieSectie() +
    buildDisclaimerSectie()
  )
}

/**
 * Vul #print-report met de actuele audit-state en open browser-print-dialoog.
 * Volgt hetzelfde robuustheidspatroon als triggerPrint in ui.print.ts:
 *   - Console-logging voor diagnose
 *   - Visuele knop-feedback ("Audit-rapport wordt voorbereid...")
 *   - window.print() in setTimeout(50ms) voor Safari/iOS DOM-commit
 */
export function triggerAuditReport(input: AuditReportInput): void {
  console.info('[audit-print] triggerAuditReport aangeroepen')
  const target = document.getElementById('print-report')
  if (!target) {
    console.error('[audit-print] #print-report element niet gevonden in DOM')
    alert('Kan audit-rapport niet genereren: print-target ontbreekt in de DOM. Probeer de pagina te herladen.')
    return
  }

  const btn = document.getElementById('audit-report-btn') as HTMLButtonElement | null
  const originalLabel = btn?.textContent ?? ''
  if (btn) {
    btn.disabled = true
    btn.textContent = 'Audit-rapport wordt voorbereid...'
  }

  try {
    const html = buildAuditReportHtml(input)
    target.innerHTML = html
    console.info(`[audit-print] rapport gerenderd (${html.length} chars), open print-dialoog...`)
  } catch (err) {
    console.error('[audit-print] fout bij genereren audit-rapport:', err)
    if (btn) {
      btn.disabled = false
      btn.textContent = originalLabel
    }
    alert('Kan het audit-rapport niet genereren. Zie de browserconsole (F12) voor details.')
    return
  }

  window.setTimeout(() => {
    try {
      window.print()
      console.info('[audit-print] window.print() teruggekeerd')
    } catch (err) {
      console.error('[audit-print] window.print() faalde:', err)
      alert('Print-dialoog kan niet geopend worden. Zie de browserconsole voor details.')
    } finally {
      if (btn) {
        btn.disabled = false
        btn.textContent = originalLabel
      }
    }
  }, 50)
}
