/**
 * M1-engine regressie-test.
 *
 * Doel: verifieer dat §2.5-formules correcte KV geven voor referentiescenario's.
 * Handmatig verifieerbare smoke test; geen formele TEST_FIXTURES v1 (dat is
 * latere sessie per §11.11).
 */

// Injecteer AG2024 via globale window-proxy vóór imports
import * as fs from 'fs'
const ag2024Data = JSON.parse(fs.readFileSync('/home/claude/m1_build/ag2024.json', 'utf-8'))
// @ts-expect-error — window-proxy voor node
globalThis.window = { __AG2024__: ag2024Data }

import { M1 } from './schema.v2'
import { computeM1, annuity, getAG2024, q, lifeExpectancy } from './engine.m1'
import { SSPF_M1_PLACEHOLDER } from './fondsdataset'

console.log('=== M1-engine regressie-test ===\n')

// ============================================================================
// Test 1: AG2024 data bereikbaar en correct
// ============================================================================
console.log('Test 1: AG2024 data')
const data = getAG2024()
const q67M = q(67, 2026, 'M', data)
const q67V = q(67, 2026, 'V', data)
console.log(`  q(67, 2026, M) = ${q67M.toFixed(6)}`)
console.log(`  q(67, 2026, V) = ${q67V.toFixed(6)}`)
console.log(`  V/M ratio = ${(q67V / q67M).toFixed(3)}  (verwacht ~0.685)`)
console.log()

// ============================================================================
// Test 2: Annuïteitsfactor ä(67, 2%) bij M
// ============================================================================
console.log('Test 2: Annuïteitsfactor')
const a_x0_M = annuity(67, 0.02, 2026, 'M', { m: 12, pi: 0, f: 1.0, omega: 120, data })
const a_x0_V = annuity(67, 0.02, 2026, 'V', { m: 12, pi: 0, f: 1.0, omega: 120, data })
const a_x0_mix = annuity(67, 0.02, 2026, 'gemengd', { m: 12, pi: 0, f: 1.0, omega: 120, data })
console.log(`  ä(67, 2%, M)       = ${a_x0_M.toFixed(3)}`)
console.log(`  ä(67, 2%, V)       = ${a_x0_V.toFixed(3)}`)
console.log(`  ä(67, 2%, gemengd) = ${a_x0_mix.toFixed(3)}`)
console.log(`  Gender-verschil    = ${((a_x0_V - a_x0_M) / a_x0_M * 100).toFixed(1)}%  (verwacht ~9.7% per §11.16)`)
console.log()

// ============================================================================
// Test 3: Levensverwachting
// ============================================================================
console.log('Test 3: Levensverwachting (sterfleeftijd)')
const le_M = lifeExpectancy(67, 2026, 'M', { f: 1.0, omega: 120, data })
const le_V = lifeExpectancy(67, 2026, 'V', { f: 1.0, omega: 120, data })
console.log(`  lifeExp(67, M) = ${le_M.toFixed(2)}  (jaren)`)
console.log(`  lifeExp(67, V) = ${le_V.toFixed(2)}  (jaren)`)
console.log()

// ============================================================================
// Test 4: Volledige M1-berekening — scenario zonder partner
// ============================================================================
console.log('Test 4: M1 — 67-jarige man, €30k, geen partner, SSPF-defaults')
const deelnemer1 = M1.deelnemer.parse({ x0: 67, pen: 30000, g: 'M' })
const params = M1.parameterset.parse(SSPF_M1_PLACEHOLDER)
const out1 = computeM1(deelnemer1, params)
console.log(`  KV_OP       = € ${out1.KV_OP.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}`)
console.log(`  KV_NP       = € ${out1.KV_NP.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}`)
console.log(`  KV (totaal) = € ${out1.KV.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}`)
console.log(`  ä(x₀, r)    = ${out1.a_x0.toFixed(3)}`)
console.log(`  lifeExp     = ${out1.lifeExp_x0.toFixed(2)}`)
console.log(`  ρ effectief = ${(out1.rho_effectief * 100).toFixed(2)}%`)
console.log()

// ============================================================================
// Test 5: Met partner — NP-bijdrage zichtbaar
// ============================================================================
console.log('Test 5: M1 — 67-jarige man, €30k OP, partner V 65, y₀=€21k')
const deelnemer2 = M1.deelnemer.parse({
  x0: 67, pen: 30000, g: 'M',
  heeftPartner: true, y0: 21000, x_partner: 65, g_y: 'V',
})
const out2 = computeM1(deelnemer2, params)
console.log(`  KV_OP       = € ${out2.KV_OP.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}`)
console.log(`  KV_NP       = € ${out2.KV_NP.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}`)
console.log(`  KV (totaal) = € ${out2.KV.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}`)
console.log(`  NP-aandeel  = ${(out2.KV_NP / out2.KV * 100).toFixed(1)}%`)
console.log(`  ä(partner)  = ${(out2.a_partner as number).toFixed(3)}`)
console.log(`  lifeExp V   = ${(out2.lifeExp_partner as number).toFixed(2)}`)
console.log()

// ============================================================================
// Test 6: NP-fallback 70% van pen (§11.5 v1.8)
// ============================================================================
console.log('Test 6: NP-fallback (y₀=null → 0.70 × pen)')
const deelnemer3 = M1.deelnemer.parse({
  x0: 67, pen: 30000, g: 'M',
  heeftPartner: true, y0: null, x_partner: 65, g_y: 'V',
})
const out3 = computeM1(deelnemer3, params)
console.log(`  KV_NP met y₀=null → ${out3.KV_NP.toLocaleString('nl-NL', { maximumFractionDigits: 0 })} (impliceert y₀_eff = 0.70 × €30k = €21k)`)
console.log(`  Moet overeenkomen met Test 5 bij gelijke effective y₀`)
console.log(`  Verschil vs Test 5: ${Math.abs(out3.KV_NP - out2.KV_NP).toFixed(2)} (moet ~0 zijn)`)
console.log()

// ============================================================================
// Test 7: ρ-fallback-ladder stap 2 (direct kostenOpslagPct)
// ============================================================================
console.log('Test 7: ρ-fallback stap 2 (direct kostenOpslagPct)')
const params_direct_rho = M1.parameterset.parse({
  ...SSPF_M1_PLACEHOLDER,
  kostenOpslagPct: 0.05,  // hoger dan default 0.02
})
const out4 = computeM1(deelnemer1, params_direct_rho)
console.log(`  Met kostenOpslagPct=0.05 → ρ_effectief = ${out4.rho_effectief.toFixed(4)} (moet 0.05)`)
console.log(`  KV_OP: € ${out4.KV_OP.toLocaleString('nl-NL', { maximumFractionDigits: 0 })} vs Test 4's € ${out1.KV_OP.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}`)
console.log(`  Verhouding: ${((out4.KV_OP / out1.KV_OP - 1) * 100).toFixed(2)}% hoger (verwacht ~3% door ρ=0.05 ipv 0.02)`)
console.log()

// ============================================================================
// Test 8: ρ-fallback-ladder stap 1 (Variant-A afleiding)
// ============================================================================
console.log('Test 8: ρ-fallback stap 1 (Variant-A: uitvoeringskosten/fondsvermogen · ä)')
const params_variantA = M1.parameterset.parse({
  ...SSPF_M1_PLACEHOLDER,
  fondsvermogen: 27202,               // SSPF JV2024
  uitvoeringskostenJaarlijks: 68,     // placeholder ~0.25%
})
const out5 = computeM1(deelnemer1, params_variantA)
const c_jaar = 68 / 27202
const rho_verwacht = c_jaar * out5.a_x0
console.log(`  c_jaar = 68/27202 = ${(c_jaar * 100).toFixed(3)}%`)
console.log(`  ρ verwacht = c_jaar · ä(x₀) = ${rho_verwacht.toFixed(4)}`)
console.log(`  ρ effectief = ${out5.rho_effectief.toFixed(4)}`)
console.log(`  Klopt: ${Math.abs(out5.rho_effectief - rho_verwacht) < 0.0001 ? '✓' : '✗'}`)
console.log()

console.log('=== Alle tests uitgevoerd ===')
