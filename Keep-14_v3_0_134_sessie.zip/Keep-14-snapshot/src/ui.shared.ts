/**
 * UI-shared — gedeelde renderer-helpers tussen ui.m1, ui.m2, en ui.app.
 *
 * v3.0.2 (05-05-2026): introductie van dit module om DRY-violatie op te lossen.
 * Voor v3.0.1 hadden ui.m1 en ui.app elk hun eigen kopie van `renderInputField`,
 * en alle drie ui-modules hadden hun eigen kopie van `escapeHtml`. Dit leidde
 * tot bugs zoals v3.0.1 'gemengd'-fix die in één van de twee renderers werd
 * vergeten — een fix moest twee plekken raken om te werken in calculator.html.
 *
 * Dit bestand bevat puur functionele helpers (geen module-state); de callers
 * geven hun eigen state als parameter door. Dit voorkomt closure-leakage tussen
 * UI-modules en maakt unit-tests eenvoudig.
 */

import type { FieldMeta } from './schema.v2'
import type { M1Deelnemer } from './schema.v2'

// ============================================================================
// FieldInfo — gedeeld type tussen alle UI-renderers
// ============================================================================

export type FieldInfo = {
  name: string
  path: string
  meta: FieldMeta
  typeLabel: string
  default?: unknown
  nullable: boolean
}

// ============================================================================
// escapeHtml — voorkom XSS in dynamische content (disclosure, labels)
// ============================================================================

export function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[c] as string))
}

// ============================================================================
// helpIcon — render een ? icoon dat een help-modal opent (handler in ui.app.ts)
// ============================================================================

export function helpIcon(key: string): string {
  return `<button type="button" class="help-icon" data-help="${key}" aria-label="Uitleg over dit veld">?</button>`
}

// ============================================================================
// Display-mapping per veld voor enum-opties
//
// Sommige enum-waardes (bv. 'M', 'V') zijn correct als data-value voor de engine
// maar niet ideaal als label voor de eindgebruiker. Deze mapping geeft per veld
// per waarde een gebruikersvriendelijk label; engine-value en form-data blijven
// ongewijzigd.
// ============================================================================

const OPTION_LABELS: Record<string, Record<string, string>> = {
  g: { M: 'Man', V: 'Vrouw' },
  g_y: { M: 'Man', V: 'Vrouw' },
}

function displayLabelFor(fieldName: string, value: string): string {
  return OPTION_LABELS[fieldName]?.[value] ?? value
}

// ============================================================================
// Help-content per slider — toggle-uitleg via ?-icoon
//
// Structuur per veld:
//   - title: korte titel met formule-context
//   - stand: huidige stand-formattering (functie die state-waarde formatteert)
//   - sections: { header, body }[] — elk een blokje met kop in caps + tekst
//
// Inhoudelijk concept (niet 1-op-1 overgenomen uit eerdere versie):
//   - Wat doet de parameter
//   - Typische waarden / conventies / bron
// ============================================================================

type HelpSection = { header: string; body: string }
type HelpEntry = {
  title: string
  formatStand: (val: number | string) => string
  sections: HelpSection[]
}

const HELP_CONTENT: Record<string, HelpEntry> = {
  r: {
    title: 'Rekenrente (r) — waardering van uw aanspraak',
    formatStand: (v) => `rekenrente r = ${(Number(v) * 100).toFixed(1).replace('.', ',')}%`,
    sections: [
      {
        header: 'Wat doet deze rente?',
        body:
          'De rekenrente maakt uw toekomstige pensioenuitkeringen contant naar vandaag. ' +
          'Hoe hoger de rente, hoe lager de huidige waarde van uw aanspraak — ' +
          'toekomstige euro\'s zijn minder waard zodra ze met meer rente worden teruggebracht. ' +
          'Op scherm 1 bepaalt deze rente de geldwaarde (KV) van uw aanspraak.',
      },
      {
        header: 'Typische waarden',
        body:
          'SSPF rekent met 2%. DNB hanteert een risicovrije rentetermijnstructuur (RTS) ' +
          'die zich doorgaans rond 2–3% beweegt. Deze conservatieve rente reflecteert ' +
          'de zekerheid van uw toegezegde aanspraak; onzekere beleggingsopbrengsten ' +
          'mogen niet vooruit worden ingeprijsd op een al opgebouwd recht.',
      },
    ],
  },
  dg: {
    title: 'Dekkingsgraad — fondsvermogen versus verplichtingen',
    formatStand: (v) => `dekkingsgraad = ${(Number(v) * 100).toFixed(0)}%`,
    sections: [
      {
        header: 'Wat doet de dekkingsgraad?',
        body:
          'De dekkingsgraad geeft aan of het fonds genoeg vermogen heeft om al zijn ' +
          'verplichtingen te betalen. Boven 100% is er een overschot dat bij invaren ' +
          'naar de deelnemers wordt verdeeld via de wettelijke standaardregel. Onder 100% ' +
          'is er een tekort en wordt iedereen naar evenredigheid gekort.',
      },
      {
        header: 'Typische waarden',
        body:
          'Het Minimaal Vereist Eigen Vermogen (MVEV) ligt rond 104–105%. ' +
          'SSPF-aanname voor invaardatum: 115%. Boven 125% nemen fondsen typisch ' +
          'maatregelen tegen overdekking; onder 105% komen indexatie en uitkeringsniveau ' +
          'onder druk.',
      },
    ],
  },
  aftrek: {
    title: 'Aftrek voor reserveringen — wat in collectief beheer blijft',
    formatStand: (v) => `aftrek = ${(Number(v) * 100).toFixed(1).replace('.', ',')}%`,
    sections: [
      {
        header: 'Wat is deze aftrek?',
        body:
          'Een deel van het pensioenvermogen blijft bij invaren in collectief beheer ' +
          'voor reserveringen: compensatie voor wie nadeel ondervindt van de afschaffing ' +
          'van de doorsneesystematiek, een transitiebuffer voor risicodeling, en ' +
          'operationele solvabiliteit. Dat deel komt niet op uw persoonlijk ' +
          'pensioenvermogen.',
      },
      {
        header: 'Typische waarden',
        body:
          'ABN heeft 10% gepubliceerd in haar transitieplan (Pensioenwet-CRM-2026-34). ' +
          'SSPF-aanname: 10%. Andere fondsen variëren tussen 6–15% afhankelijk van de ' +
          'fondsspecifieke transitiebijdrage, compensatieomvang en buffer-keuze.',
      },
    ],
  },
  spreiding: {
    title: 'Spreidingstermijn — verdeling overschot over jaren',
    formatStand: (v) => v === '1000' ? 'oneindig (educatief)' : `${v} jaar`,
    sections: [
      {
        header: 'Wat betekent deze termijn?',
        body:
          'Bij invaren wordt het overschot (boven 100% dekking) niet evenredig over ' +
          'deelnemers verdeeld, maar leeftijdsgewogen via een staircase-functie q(h, N). ' +
          'Hoe langer de termijn N, hoe meer het overschot naar jongere cohorten schuift; ' +
          'bij oneindig wordt de verdeling vrijwel proportioneel aan ieders aanspraak.',
      },
      {
        header: 'Typische waarden',
        body:
          '10 jaar is de wettelijke standaard (Bijlage 2a Regeling Pensioenwet, art. 2). ' +
          'De educatieve oneindig-instelling laat zien hoe groot het ' +
          'leeftijdsongelijkheid-effect is dat specifiek door de 10-jaars-spreiding ' +
          'ontstaat — voor SSPF-doelgroep (67+) is het verschil klein, voor jongere ' +
          'cohorten substantieel.',
      },
    ],
  },
}

export function renderHelp(name: string, currentValue: number | string): string {
  const entry = HELP_CONTENT[name]
  if (!entry) return ''
  const stand = entry.formatStand(currentValue)
  const sections = entry.sections
    .map(
      (s) => `
      <div class="help-section">
        <div class="help-section-hdr">${escapeHtml(s.header)}</div>
        <p>${escapeHtml(s.body)}</p>
      </div>`
    )
    .join('')
  return `
    <button type="button" class="help-icon" data-help-for="${name}" aria-label="Uitleg ${escapeHtml(entry.title)}" aria-expanded="false">?</button>
    <div class="help-content" data-help-content="${name}" hidden>
      <div class="help-title">${escapeHtml(entry.title)}</div>
      <div class="help-stand">Uw huidige stand: <strong>${escapeHtml(stand)}</strong></div>
      ${sections}
    </div>
  `
}

// ============================================================================
// renderInputField — pure renderer voor één deelnemer-veld
//
// Caller-contract:
//   - `f`: FieldInfo uit FIELD_REGISTRY
//   - `deelnemer`: huidige state (M1Deelnemer-vorm)
//   - `labels`: caller-specifieke veld-labels (DEELNEMER_LABELS uit ui.m1 of ui.app)
//
// v3.0.1: 'gemengd' wordt gefilterd uit dropdown-opties (alleen M/V tonen);
// engine accepteert 'gemengd' nog via SCHEMA voor batch-validatie en cohort-proxy.
// ============================================================================

export function renderInputField(
  f: FieldInfo,
  deelnemer: M1Deelnemer,
  labels: Record<string, string>
): string {
  const label = labels[f.name] ?? f.name
  const id = `in-${f.name}`
  const current = (deelnemer as Record<string, unknown>)[f.name]

  let control: string
  if (f.typeLabel === 'ja/nee') {
    const checked = current === true ? 'checked' : ''
    control = `<input type="checkbox" id="${id}" ${checked} data-field="${f.name}">`
  } else if (f.typeLabel.includes(' | ')) {
    // v3.0.1: 'gemengd' is engine-interne fallback (cohort-proxy in M2,
    // SSPF 95/5-prior); niet bedoeld als eindgebruiker-keuze. UI toont alleen
    // bekend-geslacht-opties; engine accepteert 'gemengd' nog steeds via SCHEMA.
    const opts = f.typeLabel.split(' | ').filter((o) => o !== 'gemengd')
    // v3.0.6: bij ≤2 opties radio-knoppen ipv dropdown — directer en mobile-vriendelijker
    if (opts.length <= 2) {
      const radios = opts.map((o) => `
        <label class="radio-inline">
          <input type="radio" name="${id}" data-field="${f.name}" value="${o}" ${o === current ? 'checked' : ''}>
          ${displayLabelFor(f.name, o)}
        </label>`).join('')
      control = `<div class="radio-group-inline" id="${id}">${radios}</div>`
    } else {
      const options = opts.map((o) => `<option value="${o}" ${o === current ? 'selected' : ''}>${displayLabelFor(f.name, o)}</option>`).join('')
      control = `<select id="${id}" data-field="${f.name}">${options}</select>`
    }
  } else {
    const val = current === null || current === undefined ? '' : current
    const placeholder = f.nullable ? 'placeholder="optioneel"' : ''
    control = `<input type="number" id="${id}" value="${val}" ${placeholder} data-field="${f.name}">`
  }

  const disclosure = f.meta.uiDisclosure
    ? `<div class="disclosure">⚠ ${escapeHtml(f.meta.uiDisclosure)}</div>`
    : ''

  // Hide partner-fields if heeftPartner=false
  const partnerField = ['y0', 'x_partner', 'g_y'].includes(f.name)
  const hidden = partnerField && !deelnemer.heeftPartner ? 'style="display:none"' : ''

  return `<div class="field" data-field-row="${f.name}" ${hidden}>
    <label for="${id}">${label}</label>
    ${control}
    ${disclosure}
  </div>`
}
