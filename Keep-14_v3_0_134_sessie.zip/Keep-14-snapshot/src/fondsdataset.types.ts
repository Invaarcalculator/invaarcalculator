/**
 * v3.0.76: Fonds-types — fonds-ONAFHANKELIJK.
 *
 * Build-time-fondsinjectie betekent dat de codebase onder /src/ niet weet
 * welk fonds er gebouwd wordt. Deze file biedt alleen de types die alle
 * fonds-definities moeten respecteren. De daadwerkelijke fonds-data komt
 * uit /fondsen/<id>/fonds.config.ts en wordt via path-alias '~fonds'
 * geïmporteerd door fondsdataset.ts.
 */

import type { M1Parameterset, M2Parameterset } from './schema.v2'

export type { M1Parameterset, M2Parameterset }

/**
 * Cascade-meta voor de "AANWENDING FONDSVERMOGEN BIJ INVAREN"-sectie.
 * Optioneel op fonds-niveau: fondsen zonder onderbouwde plan-cascade tonen
 * deze sectie niet. Alle bedragen in mln €; percentages als fractie.
 */
export type AanwendingsCascade = {
  bijstortLabel: string
  bijstortNote: string
  wettelijkeReservesPct: number
  wettelijkeReservesNote: string
  rdrBedrag: number                    // mln €
  rdrNote: string
  compensatiedepotBedrag: number       // mln €
  compensatiedepotNote: string
  outroTekst: string
  intro?: string
}

export type Fonds = {
  label: string
  /** v3.0.103: korte vorm voor compacte UI-contexten ("Voor wie SSPF-pensioen
   *  ontvangt"). Optioneel; build-script gebruikt 'het fonds' als fallback. */
  shortLabel?: string
  m1: M1Parameterset
  m2: M2Parameterset
  aanwendingsCascade?: AanwendingsCascade
}
