// ============================================================================
// src/ui.sensitivity.ts — Gevoeligheidsgrafiek: aandeel t.o.v. aanspraak als
// functie van dekkingsgraad.
// v3.0.119: nieuwe module, overgeheveld uit prototypes/.
//
// Architectuur:
//   - runSweep(): 501 M2-runs voor DG 100%-150% in stappen van 0.1%
//   - renderChart(): bouwt SVG-grafiek + summary-HTML uit sweep + persoonlijke DG
//   - openSensitivityModal(): wrapper die alles aan elkaar plakt en in modal toont
//
// Bijstort-staffel is hardcoded volgens SSPF-implementatieplan 15-07-2025;
// onder DG 125% wordt bij SSPF niet ingevaren — onder die grens toch
// doorrekenen zonder bijstort, en visueel weergeven als gestippeld
// "hypothetisch" segment.
// ============================================================================

import type { M1Output, M2Output, M1Deelnemer, M1Parameterset, M2Parameterset } from './schema.v2'
import { M2 } from './schema.v2'
import { computeM2 } from './engine.m2'
import { lifeExpectancy, getAG2024 } from './engine.m1'

export type SensitivityPoint = {
  dg: number          // dekkingsgraad als decimaal (1.00 = 100%)
  bijstort: number    // werkgevers-bijdrage in mln €
  aandeel: number     // ppkTotal − KV (in €)
  status: 'hypothetisch' | 'invaring'
}

export type SensitivitySweep = {
  points: SensitivityPoint[]
  KV: number
  persoonlijkeDG: number      // huidige DG-stand van de gebruiker
  persoonlijkAandeel: number  // aandeel bij die DG
}

/**
 * SSPF-bijstort-staffel volgens implementatieplan 15-07-2025.
 * Onder DG 125% geen bijstort omdat dan niet wordt ingevaren.
 */
function bijstortForDG(dg: number): number {
  if (dg < 1.25) return 0
  if (dg < 1.30) return 850
  if (dg < 1.35) return 650
  return 500
}

/**
 * Run 501 M2-evaluaties voor DG 100%-150% in stappen van 0.1%.
 * Houdt alle andere parameters constant op huidige stand.
 */
export function runSweep(
  deelnemer: M1Deelnemer,
  m1Out: M1Output,
  m2Params: M2Parameterset
): SensitivitySweep {
  const ketenInput = {
    KV: m1Out.KV,
    KV_OP: m1Out.KV_OP,
    KV_NP: m1Out.KV_NP,
    cw_star_op: m1Out.cw_star_op,
    cw_star_np: m1Out.cw_star_np,
  }

  const points: SensitivityPoint[] = []
  for (let dgPct = 1000; dgPct <= 1500; dgPct += 1) {
    const dg = dgPct / 1000
    const bijstort = bijstortForDG(dg)
    const status: SensitivityPoint['status'] = dg < 1.25 ? 'hypothetisch' : 'invaring'

    // F = DG × vpvTotal (vpvTotal is fonds-anker, mln €)
    const fondsvermogen = dg * m2Params.vpvTotal

    const params = M2.parameterset.parse({
      ...m2Params,
      dekkingsgraad: dg,
      fondsvermogen,
      bijstort,
    })

    const m2: M2Output = computeM2(deelnemer, ketenInput, params)
    const aandeel = m2.ppkTotal - m1Out.KV

    points.push({ dg, bijstort, aandeel, status })
  }

  // Persoonlijke DG: huidige stand van de gebruiker
  const persoonlijkeDG = m2Params.dekkingsgraad
  // Vind dichtstbijzijnde grid-punt voor de persoonlijke aandeel-uitlezing.
  // Bij DG buiten 100-150%-range tonen we het rand-punt; geen extrapolatie.
  const clampedDG = Math.max(1.00, Math.min(1.50, persoonlijkeDG))
  const persPunt = points.reduce((best, p) =>
    Math.abs(p.dg - clampedDG) < Math.abs(best.dg - clampedDG) ? p : best
  )

  return {
    points,
    KV: m1Out.KV,
    persoonlijkeDG,
    persoonlijkAandeel: persPunt.aandeel,
  }
}

/**
 * Bouw SVG-string voor de gevoeligheidsgrafiek.
 * Y-as: aandeel als % van KV.
 * X-as: DG 100-150%.
 */
function renderSVG(sweep: SensitivitySweep): string {
  const { points, KV, persoonlijkeDG, persoonlijkAandeel } = sweep

  // Dimensies (viewBox-units; schaalt vanzelf naar modal-breedte)
  const W = 760
  const H = 380
  const ML = 80, MR = 30, MT = 20, MB = 50
  const PW = W - ML - MR
  const PH = H - MT - MB

  const X_MIN = 1.00, X_MAX = 1.50
  const xScale = (dg: number) => ML + ((dg - X_MIN) / (X_MAX - X_MIN)) * PW

  // Y-schaal: %-van-KV, afgerond op 5%-stap
  const yPctValues = points.map(p => (p.aandeel / KV) * 100)
  const yMaxPctRaw = Math.max(...yPctValues)
  const yMinPctRaw = Math.min(...yPctValues)
  const yMaxPct = Math.ceil(yMaxPctRaw / 5) * 5
  const yMinPct = Math.floor(yMinPctRaw / 5) * 5
  const yMin = (yMinPct / 100) * KV
  const yMax = (yMaxPct / 100) * KV
  const yScale = (v: number) => MT + PH - ((v - yMin) / (yMax - yMin)) * PH

  let svg = `<svg class="sens-chart" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Lijngrafiek aandeel als percentage van huidige pensioenaanspraak tegen dekkingsgraad">`

  // ── Verticale gridlines bij DG-overgangen ─────────────────────────
  for (const t of [1.25, 1.30, 1.35]) {
    svg += `<line x1="${xScale(t)}" y1="${MT}" x2="${xScale(t)}" y2="${MT + PH}" stroke="#d4cfc7" stroke-width="1" stroke-dasharray="3,3"/>`
  }

  // ── Y-as: grid + labels (% schaal) ────────────────────────────────
  const ySteps = (yMaxPct - yMinPct) / 5
  for (let i = 0; i <= ySteps; i++) {
    const pct = yMinPct + 5 * i
    const v = (pct / 100) * KV
    const y = yScale(v)
    const isZero = pct === 0
    svg += `<line x1="${ML}" y1="${y}" x2="${ML + PW}" y2="${y}" stroke="${isZero ? '#6b7280' : '#e5e3df'}" stroke-width="1" ${isZero ? '' : 'stroke-dasharray="2,3"'}/>`
    svg += `<text x="${ML - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="#6b7280">${pct === 0 ? '0' : pct}</text>`
  }

  // ── X-as: labels ──────────────────────────────────────────────────
  const xTicks = [1.00, 1.05, 1.10, 1.15, 1.20, 1.25, 1.30, 1.35, 1.40, 1.45, 1.50]
  for (const t of xTicks) {
    svg += `<text x="${xScale(t)}" y="${MT + PH + 18}" text-anchor="middle" font-size="11" fill="#6b7280">${(t * 100).toFixed(0)}</text>`
  }
  svg += `<text x="${ML + PW / 2}" y="${MT + PH + 38}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600">Dekkingsgraad / [%]</text>`

  // Y-as label (verticaal)
  const yLabelY = MT + PH / 2
  svg += `<text x="18" y="${yLabelY}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600" transform="rotate(-90, 18, ${yLabelY})">Uw aandeel t.o.v. huidige pensioenaanspraak / [%]</text>`

  // ── Vier polyline-segmenten ───────────────────────────────────────
  const buildSeg = (filterFn: (p: SensitivityPoint) => boolean) =>
    points.filter(filterFn).map(p => `${xScale(p.dg)},${yScale(p.aandeel)}`).join(' ')

  const segHypo = buildSeg(p => p.status === 'hypothetisch')
  const seg1 = buildSeg(p => p.status === 'invaring' && p.dg >= 1.25 && p.dg < 1.30)
  const seg2 = buildSeg(p => p.status === 'invaring' && p.dg >= 1.30 && p.dg < 1.35)
  const seg3 = buildSeg(p => p.status === 'invaring' && p.dg >= 1.35 && p.dg <= 1.50)

  if (segHypo) {
    svg += `<polyline points="${segHypo}" fill="none" stroke="#C07A00" stroke-width="2" stroke-dasharray="4,3" stroke-linejoin="round" stroke-linecap="round" opacity="0.7"/>`
  }
  for (const pts of [seg1, seg2, seg3]) {
    if (pts) svg += `<polyline points="${pts}" fill="none" stroke="#C07A00" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>`
  }

  // Verticale sprong-lijntjes bij overgangen
  for (const t of [1.25, 1.30, 1.35]) {
    const before = points.filter(p => p.dg < t).pop()
    const after = points.find(p => p.dg >= t)
    if (before && after) {
      svg += `<line x1="${xScale(t)}" y1="${yScale(before.aandeel)}" x2="${xScale(t)}" y2="${yScale(after.aandeel)}" stroke="#C07A00" stroke-width="1.5" stroke-dasharray="2,2" opacity="0.7"/>`
    }
  }

  // ── Persoonlijke berekening: blauwe stip ──────────────────────────
  // Alleen tonen als DG binnen weergegeven range valt
  if (persoonlijkeDG >= X_MIN && persoonlijkeDG <= X_MAX) {
    const px = xScale(persoonlijkeDG)
    const py = yScale(persoonlijkAandeel)
    svg += `<circle cx="${px}" cy="${py}" r="6" fill="#1a6db5" stroke="#fff" stroke-width="2"/>`
  }

  svg += '</svg>'
  return svg
}

/**
 * Bouw de volledige modal-body-HTML: desc + svg + legend + summary + meta-note.
 */
export function renderSensitivityHTML(sweep: SensitivitySweep): string {
  const { KV, persoonlijkAandeel } = sweep
  const pct = (persoonlijkAandeel / KV) * 100
  const eurStr = '€ ' + Math.round(persoonlijkAandeel).toLocaleString('nl-NL')
  const pctStr = pct.toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%'

  return `
    <p class="sens-desc">
      De grafiek toont uw aandeel verdeelbaar overschot <strong>als percentage van uw
      huidige pensioenaanspraak</strong>, bij dekkingsgraden tussen 100% en 150%.
      Bij SSPF wordt onder DG 125% niet ingevaren; de <strong>gestippelde curve</strong>
      daar toont hypothetisch wat er zou gebeuren als toch zou worden ingevaren —
      zonder werkgevers-bijdrage zou u in dat scenario vermogen verliezen
      (negatief aandeel onder DG ongeveer 106%). Vanaf 125% komt de werkgevers-bijdrage
      in beeld in drie stappen (€ 850, € 650, € 500 mln); de tredes in de curve
      weerspiegelen die drie stappen.
    </p>

    <div class="sens-chart-container">${renderSVG(sweep)}</div>

    <div class="sens-legend">
      <div class="sens-legend-item"><span class="sens-legend-line"></span> Aandeel t.o.v. huidige pensioenaanspraak — wordt ingevaren (DG ≥ 125%)</div>
      <div class="sens-legend-item"><span class="sens-legend-line dashed"></span> Hypothetisch — wordt bij SSPF niet ingevaren (DG &lt; 125%)</div>
      <div class="sens-legend-item"><span class="sens-legend-dot"></span> Uw persoonlijke berekening</div>
    </div>

    <div class="sens-summary">
      <div class="sens-summary-row">
        <span class="sens-summary-label">Uw aandeel verdeelbaar overschot</span>
        <span class="sens-summary-val">${eurStr}</span>
      </div>
      <div class="sens-summary-row">
        <span class="sens-summary-label">t.o.v. uw huidige pensioenaanspraak</span>
        <span class="sens-summary-val">${pctStr}</span>
      </div>
    </div>

    <p class="sens-meta-note">
      SSPF-implementatieplan 15-07-2025: er wordt ingevaren vanaf DG ≥ 125%, met
      werkgevers-transitiebijdrage € 850 mln (DG 125-130%), € 650 mln (130-135%),
      € 500 mln (≥ 135%). De gestippelde curve onder DG 125% is hypothetisch:
      gerekend zonder werkgevers-bijdrage, omdat onder die grens niet wordt
      ingevaren. Dat het aandeel pas vanaf DG ongeveer 106% positief wordt, komt
      doordat het fonds bij invaren eerst bedragen opzij zet voor wettelijke
      reserves en risicodeling — pas als het fondsvermogen daar bovenuit komt,
      blijft er voor u iets te verdelen over.
    </p>
  `
}

// ============================================================================
// BIJSTORT-GRAFIEK (variant 2): aandeel-delta als functie van bijstort.
//
// v3.0.121: tweede gevoeligheidsgrafiek. X-as bijstort 0-2500 mln,
// linker Y-as +/− aandeel verdeelbaar overschot in k€, rechter Y-as
// jaarpensioen-equivalent in k€/jaar. Eén lijn, DG-onafhankelijk
// (bijstort werkt additief op aandeel). Interactieve tooltip op hover/tap.
// ============================================================================

export type BijstortPoint = {
  bijstort: number   // mln €
  aandeel: number    // ppkTotal − KV (in €)
}

export type BijstortSweep = {
  points: BijstortPoint[]
  KV: number
  KV_OP: number
  pen: number                 // huidig pensioen
  annuiteitFactor: number     // KV / pen, ~13 voor 70j M zonder partner, hoger met partner
  DG: number                  // huidige DG (label-only, niet meer in curve)
  ankerBijstort: number       // huidige slider-stand
  ankerAandeel: number        // aandeel bij anker
}

/**
 * Run 251 M2-evaluaties voor bijstort 0-2500 mln in stappen van 10 mln.
 * Houdt DG en alle andere parameters vast op huidige stand.
 */
export function runBijstortSweep(
  deelnemer: M1Deelnemer,
  m1Out: M1Output,
  m2Params: M2Parameterset
): BijstortSweep {
  const ketenInput = {
    KV: m1Out.KV,
    KV_OP: m1Out.KV_OP,
    KV_NP: m1Out.KV_NP,
    cw_star_op: m1Out.cw_star_op,
    cw_star_np: m1Out.cw_star_np,
  }

  const points: BijstortPoint[] = []
  const fondsvermogen = m2Params.dekkingsgraad * m2Params.vpvTotal

  for (let bijstort = 0; bijstort <= 2500; bijstort += 10) {
    const params = M2.parameterset.parse({
      ...m2Params,
      bijstort,
      fondsvermogen,
    })
    const m2: M2Output = computeM2(deelnemer, ketenInput, params)
    const aandeel = m2.ppkTotal - m1Out.KV
    points.push({ bijstort, aandeel })
  }

  // Anker = huidige slider-stand
  const ankerBijstort = m2Params.bijstort
  // Vind dichtstbijzijnde sweep-punt (snap op 10 mln)
  const snapped = Math.round(ankerBijstort / 10) * 10
  const ankerPunt = points.find(p => p.bijstort === snapped) ?? points[0]

  // Annuïteit-factor: KV / pen (voor jaarpensioen-equivalent op rechter Y-as).
  // v3.0.127: was KV_OP/pen — incorrect bij partner-aanwezigheid omdat KV/pen
  // = ä꜀ + (y0/pen)·ä꜀|ₚ de PP-verplichting al meeneemt (pot-formule:
  // Vermogen = pen·ä꜀ + y0·ä꜀|ₚ). Bij partner ligt KV/pen hoger → realistische
  // jaarequivalent (lager dan eerder).
  const annuiteitFactor = deelnemer.pen > 0 ? m1Out.KV / deelnemer.pen : 0

  return {
    points,
    KV: m1Out.KV,
    KV_OP: m1Out.KV_OP,
    pen: deelnemer.pen,
    annuiteitFactor,
    DG: m2Params.dekkingsgraad,
    ankerBijstort,
    ankerAandeel: ankerPunt.aandeel,
  }
}

/**
 * Bouw SVG-string voor bijstort-grafiek met dubbele Y-as en interactieve tooltip.
 */
function renderBijstortSVG(sweep: BijstortSweep): string {
  const { points, ankerBijstort, ankerAandeel, annuiteitFactor } = sweep

  // Dimensies — rechts-margin extra voor tweede Y-as (80 ipv 30)
  const W = 760, H = 380
  const ML = 80, MR = 80, MT = 20, MB = 50
  const PW = W - ML - MR
  const PH = H - MT - MB

  const X_MIN = 0, X_MAX = 2500
  const xScale = (b: number) => ML + ((b - X_MIN) / (X_MAX - X_MIN)) * PW

  // Y-schaal: delta in k€ t.o.v. anker, afgerond op 20 k€
  const aandeelToDeltaKEur = (a: number) => (a - ankerAandeel) / 1000
  const yDeltas = points.map(p => aandeelToDeltaKEur(p.aandeel))
  const yStep = 20
  const yMaxK = Math.ceil(Math.max(...yDeltas) / yStep) * yStep
  const yMinK = Math.floor(Math.min(...yDeltas) / yStep) * yStep
  const yScale = (v: number) => MT + PH - ((v - yMinK) / (yMaxK - yMinK)) * PH

  let svg = `<svg class="sens-chart" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Lijngrafiek plus- of minverandering van aandeel verdeelbaar overschot in euro's als functie van werkgevers-transitiebijdrage">`

  // ── Y-as LINKS: grid + labels (k€) ────────────────────────────────
  for (let v = yMinK; v <= yMaxK; v += yStep) {
    const y = yScale(v)
    const isZero = v === 0
    svg += `<line x1="${ML}" y1="${y}" x2="${ML + PW}" y2="${y}" stroke="${isZero ? '#6b7280' : '#e5e3df'}" stroke-width="1" ${isZero ? '' : 'stroke-dasharray="2,3"'}/>`
    svg += `<text x="${ML - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="#6b7280">${v > 0 ? '+' : ''}${v}</text>`
  }

  // ── X-as: labels ──────────────────────────────────────────────────
  const xTicks = [0, 500, 1000, 1500, 2000, 2500]
  for (const t of xTicks) {
    svg += `<text x="${xScale(t)}" y="${MT + PH + 18}" text-anchor="middle" font-size="11" fill="#6b7280">${t}</text>`
  }
  svg += `<text x="${ML + PW / 2}" y="${MT + PH + 38}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600">Transitiebijdrage werkgever / [mln €]</text>`

  // Y-as label LINKS (verticaal)
  const yLabelY = MT + PH / 2
  svg += `<text x="18" y="${yLabelY}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600" transform="rotate(-90, 18, ${yLabelY})">+/− aandeel verdeelbaar overschot / [k€]</text>`

  // ── Y-as RECHTS: jaarpensioen-equivalent (k€/jaar) ───────────────
  if (annuiteitFactor > 0) {
    const yMinPerJaar = yMinK / annuiteitFactor
    const yMaxPerJaar = yMaxK / annuiteitFactor
    const rTickMin = Math.ceil(yMinPerJaar)
    const rTickMax = Math.floor(yMaxPerJaar)
    const yScaleRight = (jaarKEur: number) => yScale(jaarKEur * annuiteitFactor)
    for (let v = rTickMin; v <= rTickMax; v++) {
      const y = yScaleRight(v)
      svg += `<line x1="${ML + PW}" y1="${y}" x2="${ML + PW + 4}" y2="${y}" stroke="#6b7280" stroke-width="1"/>`
      svg += `<text x="${ML + PW + 8}" y="${y + 4}" text-anchor="start" font-size="11" fill="#6b7280">${v > 0 ? '+' : ''}${v}</text>`
    }
    const yLabelYRight = MT + PH / 2
    svg += `<text x="${W - 18}" y="${yLabelYRight}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600" transform="rotate(90, ${W - 18}, ${yLabelYRight})">+/− per jaar pensioen / [k€/jaar]</text>`
  }

  // ── De curve ──────────────────────────────────────────────────────
  const lineData = points.map(p => `${xScale(p.bijstort)},${yScale(aandeelToDeltaKEur(p.aandeel))}`).join(' ')
  svg += `<polyline points="${lineData}" fill="none" stroke="#C07A00" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>`

  // ── Blauwe stip op huidige instelling ─────────────────────────────
  svg += `<circle cx="${xScale(ankerBijstort)}" cy="${yScale(0)}" r="6" fill="#1a6db5" stroke="#fff" stroke-width="2"/>`

  // ── Interactieve tooltip (gerendered als data-attributes; init in JS) ─
  // De tooltip-overlay en bijbehorende elementen worden geactiveerd door
  // de wrapper-JS in openBijstortModal nadat de SVG in de DOM staat.
  svg += `<g data-tooltip="true" visibility="hidden">
    <line class="sens-tt-vline" stroke="#666" stroke-width="1" stroke-dasharray="3,3" opacity="0.6"/>
    <line class="sens-tt-hline-l" stroke="#666" stroke-width="1" stroke-dasharray="3,3" opacity="0.6"/>
    <line class="sens-tt-hline-r" stroke="#666" stroke-width="1" stroke-dasharray="3,3" opacity="0.6"/>
    <circle class="sens-tt-dot" r="5" fill="#fff" stroke="#C07A00" stroke-width="2"/>
    <rect class="sens-tt-bg" rx="4" ry="4" fill="#1f2937" opacity="0.92" width="160" height="56"/>
    <text class="sens-tt-title" font-size="11" font-weight="600" fill="#fff"></text>
    <text class="sens-tt-left" font-size="11" fill="#fde68a"></text>
    <text class="sens-tt-right" font-size="11" fill="#fde68a"></text>
  </g>`
  // Transparante overlay voor pointer-events
  svg += `<rect class="sens-tt-overlay" x="${ML}" y="${MT}" width="${PW}" height="${PH}" fill="transparent" style="cursor: crosshair;"/>`

  svg += '</svg>'
  return svg
}

/**
 * Activeer interactieve tooltip op een gerenderde bijstort-grafiek.
 * Aanroepen na innerHTML-injectie, anders zijn de SVG-elementen er nog niet.
 */
export function attachBijstortTooltip(container: HTMLElement, sweep: BijstortSweep): void {
  const svg = container.querySelector('svg.sens-chart') as SVGSVGElement | null
  if (!svg) return
  const overlay = svg.querySelector('.sens-tt-overlay') as SVGRectElement | null
  const tooltipGroup = svg.querySelector('g[data-tooltip]') as SVGGElement | null
  if (!overlay || !tooltipGroup) return

  const vLine = svg.querySelector('.sens-tt-vline') as SVGLineElement
  const hLineL = svg.querySelector('.sens-tt-hline-l') as SVGLineElement
  const hLineR = svg.querySelector('.sens-tt-hline-r') as SVGLineElement
  const dotOnLine = svg.querySelector('.sens-tt-dot') as SVGCircleElement
  const labelBG = svg.querySelector('.sens-tt-bg') as SVGRectElement
  const labelTitle = svg.querySelector('.sens-tt-title') as SVGTextElement
  const labelLeft = svg.querySelector('.sens-tt-left') as SVGTextElement
  const labelRight = svg.querySelector('.sens-tt-right') as SVGTextElement

  // Constanten — moeten overeenkomen met renderBijstortSVG
  const ML = 80, MR = 80, MT = 20, MB = 50
  const W = 760, H = 380
  const PW = W - ML - MR
  const PH = H - MT - MB
  const X_MIN = 0, X_MAX = 2500
  const xScale = (b: number) => ML + ((b - X_MIN) / (X_MAX - X_MIN)) * PW
  const xInverse = (px: number) => X_MIN + ((px - ML) / PW) * (X_MAX - X_MIN)

  const { points, ankerAandeel, annuiteitFactor } = sweep
  const aandeelToDeltaKEur = (a: number) => (a - ankerAandeel) / 1000
  const yDeltas = points.map(p => aandeelToDeltaKEur(p.aandeel))
  const yStep = 20
  const yMaxK = Math.ceil(Math.max(...yDeltas) / yStep) * yStep
  const yMinK = Math.floor(Math.min(...yDeltas) / yStep) * yStep
  const yScale = (v: number) => MT + PH - ((v - yMinK) / (yMaxK - yMinK)) * PH

  function findPoint(bijstort: number): BijstortPoint | undefined {
    const snapped = Math.round(bijstort / 10) * 10
    return points.find(p => p.bijstort === snapped)
  }

  function showTooltip(clientX: number, clientY: number): void {
    const pt = svg!.createSVGPoint()
    pt.x = clientX
    pt.y = clientY
    const ctm = svg!.getScreenCTM()
    if (!ctm) return
    const svgPt = pt.matrixTransform(ctm.inverse())
    const bijstort = xInverse(svgPt.x)
    if (bijstort < X_MIN || bijstort > X_MAX) {
      tooltipGroup!.setAttribute('visibility', 'hidden')
      return
    }
    const pnt = findPoint(bijstort)
    if (!pnt) return
    const deltaKEur = aandeelToDeltaKEur(pnt.aandeel)
    const deltaPerJaar = annuiteitFactor > 0 ? deltaKEur / annuiteitFactor : 0
    const cx = xScale(pnt.bijstort)
    const cy = yScale(deltaKEur)
    vLine.setAttribute('x1', String(cx))
    vLine.setAttribute('x2', String(cx))
    vLine.setAttribute('y1', String(MT + PH))
    vLine.setAttribute('y2', String(cy))
    hLineL.setAttribute('x1', String(ML))
    hLineL.setAttribute('x2', String(cx))
    hLineL.setAttribute('y1', String(cy))
    hLineL.setAttribute('y2', String(cy))
    hLineR.setAttribute('x1', String(cx))
    hLineR.setAttribute('x2', String(ML + PW))
    hLineR.setAttribute('y1', String(cy))
    hLineR.setAttribute('y2', String(cy))
    dotOnLine.setAttribute('cx', String(cx))
    dotOnLine.setAttribute('cy', String(cy))
    const labelW = 160, labelH = 56
    const labelX = cx > ML + PW / 2 ? cx - labelW - 12 : cx + 12
    const labelY = Math.max(MT + 2, Math.min(MT + PH - labelH - 2, cy - labelH / 2))
    labelBG.setAttribute('x', String(labelX))
    labelBG.setAttribute('y', String(labelY))
    labelTitle.setAttribute('x', String(labelX + 8))
    labelTitle.setAttribute('y', String(labelY + 16))
    labelLeft.setAttribute('x', String(labelX + 8))
    labelLeft.setAttribute('y', String(labelY + 32))
    labelRight.setAttribute('x', String(labelX + 8))
    labelRight.setAttribute('y', String(labelY + 48))
    labelTitle.textContent = `Bijdrage € ${pnt.bijstort.toLocaleString('nl-NL')} mln`
    const signL = deltaKEur >= 0 ? '+' : '−'
    const absL = Math.abs(deltaKEur).toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 })
    labelLeft.textContent = `${signL} € ${absL} k vermogen`
    const signR = deltaPerJaar >= 0 ? '+' : '−'
    const absR = Math.abs(deltaPerJaar).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    labelRight.textContent = `${signR} € ${absR} k per jaar`
    tooltipGroup!.setAttribute('visibility', 'visible')
  }
  function hideTooltip(): void {
    tooltipGroup!.setAttribute('visibility', 'hidden')
  }

  overlay.addEventListener('mousemove', (e) => showTooltip(e.clientX, e.clientY))
  overlay.addEventListener('mouseleave', hideTooltip)
  overlay.addEventListener('touchstart', (e: TouchEvent) => {
    if (e.touches.length > 0) {
      showTooltip(e.touches[0].clientX, e.touches[0].clientY)
      e.preventDefault()
    }
  }, { passive: false })
  overlay.addEventListener('touchmove', (e: TouchEvent) => {
    if (e.touches.length > 0) {
      showTooltip(e.touches[0].clientX, e.touches[0].clientY)
      e.preventDefault()
    }
  }, { passive: false })
}

/**
 * Bouw de volledige modal-body-HTML voor bijstort-grafiek.
 */
export function renderBijstortHTML(sweep: BijstortSweep): string {
  const { KV, ankerAandeel } = sweep
  const pct = (ankerAandeel / KV) * 100
  const eurStr = '€ ' + Math.round(ankerAandeel).toLocaleString('nl-NL')
  const pctStr = pct.toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%'
  const factorStr = sweep.annuiteitFactor > 0
    ? '€ ' + Math.round(sweep.annuiteitFactor).toLocaleString('nl-NL')
    : '— (kan niet bepaald worden)'

  return `
    <p class="sens-desc">
      De grafiek toont <strong>hoeveel euro u erbij krijgt of inlevert</strong> als de
      werkgevers-bijdrage hoger of lager zou zijn dan u nu in de calculator hebt
      ingesteld. De blauwe stip markeert uw huidige instelling — daar is de
      wijziging precies € 0. Een hogere bijdrage geeft u extra aandeel, een lagere
      bijdrage minder. <strong>Beweeg uw muis over de grafiek</strong> (of tik op een tablet)
      om de exacte waardes bij elk bijdrage-niveau af te lezen.
    </p>

    <div class="sens-chart-container">${renderBijstortSVG(sweep)}</div>

    <div class="sens-legend">
      <div class="sens-legend-item"><span class="sens-legend-line"></span> Verandering bij andere bijdrage</div>
      <div class="sens-legend-item"><span class="sens-legend-dot"></span> Uw huidige instelling</div>
    </div>

    <div class="sens-summary">
      <div class="sens-summary-row">
        <span class="sens-summary-label">Uw aandeel verdeelbaar overschot</span>
        <span class="sens-summary-val">${eurStr}</span>
      </div>
      <div class="sens-summary-row">
        <span class="sens-summary-label">t.o.v. uw huidige pensioenaanspraak</span>
        <span class="sens-summary-val">${pctStr}</span>
      </div>
    </div>

    <p class="sens-meta-note">
      Linker Y-as toont het verschil in aandeel t.o.v. de huidige werkgevers-bijdrage-stand
      in de calculator. Rechter Y-as is een rekenwiskunde-omrekening, geen voorspelling:
      voor deze deelnemer komt ${factorStr} kapitaal globaal overeen met € 1 jaarpensioen
      levenslang, op basis van AG2024-sterftekansen, huidige rekenrente en — indien van
      toepassing — de reservering voor partnerpensioen. De daadwerkelijke jaarlijkse
      uitkering in het nieuwe pensioenstelsel hangt af van fonds-rendementen, rentestand,
      indexatie en fondsbeleidsbeslissingen; aan dit bedrag kunnen geen rechten worden
      ontleend. Voor referentie: het SSPF-implementatieplan koppelt de bijdrage aan de
      dekkingsgraad — € 500 mln bij DG ≥ 135%, € 650 mln bij 130-135%, € 850 mln bij
      125-130%. Het effect-per-€ is voor alle dekkingsgraden gelijk; deze grafiek is dus
      DG-onafhankelijk en toont alleen het zuivere bijdrage-effect.
    </p>
  `
}

// ============================================================================
// INDEXED-PENSION-GRAFIEK (variant 3): verhoging vs. indexatie over de tijd.
//
// v3.0.125: derde gevoeligheidsgrafiek. X-as huidige leeftijd → ~100 jaar,
// twee scenario's:
//   - Rode lijn: vlak verloop op (pen + jaarequivalent), geen indexatie
//   - Groene lijn: huidig pen × (1+r)^t, geïndexeerd met rekenrente
// Verticale stippel op verwachte sterfleeftijd (lifeExpectancy uit M1-engine).
// Kruispunt waar groene de rode inhaalt analytisch berekend.
// Geen sweep nodig — twee analytische functies.
// ============================================================================

export type IndexedSweep = {
  x0: number                  // huidige leeftijd
  xMax: number                // einde grafiek (typisch 100)
  pen: number                 // huidig jaarpensioen
  jaarequivalent: number      // aandeel / annuiteitFactor
  verhoogd: number            // pen + jaarequivalent
  r: number                   // rekenrente (jaarlijks, decimaal)
  verwachteSterfte: number    // x + e_x + 0,5 uit AG2024
  ageCross: number | null     // leeftijd waar groene rode inhaalt; null als nooit
  KV_OP: number               // voor display in summary
  KV: number                  // voor pct in summary
}

/**
 * Bouw IndexedSweep-data uit calculator-state.
 * @param deelnemer huidige deelnemer-state (x0, pen, g)
 * @param m1Out huidige M1-output (voor KV_OP, KV)
 * @param m2Out huidige M2-output (voor aandeel = ppkTotal - KV)
 * @param m1Params huidige M1-parameterset (voor r, t0, ervaringsSterfte, omega)
 */
export function runIndexedSweep(
  deelnemer: M1Deelnemer,
  m1Out: M1Output,
  m2Out: M2Output,
  m1Params: M1Parameterset
): IndexedSweep {
  const aandeel = m2Out.ppkTotal - m1Out.KV
  // v3.0.127: annuïteit-factor KV/pen ipv KV_OP/pen — bij partner bevat KV
  // de PP-verplichting (KV_NP = y0·ä꜀|ₚ), waardoor KV/pen = ä꜀ + (y0/pen)·ä꜀|ₚ.
  // Dat is de "prijs" van €1 OP-jaarpensioen inclusief reservering voor PP.
  const annuiteitFactor = deelnemer.pen > 0 && m1Out.KV > 0
    ? m1Out.KV / deelnemer.pen
    : 0
  const jaarequivalent = annuiteitFactor > 0 ? aandeel / annuiteitFactor : 0
  const verhoogd = deelnemer.pen + jaarequivalent

  // Verwachte sterfleeftijd via M1-engine: x + e_x + 0,5
  const data = getAG2024()
  const verwachteSterfte = lifeExpectancy(deelnemer.x0, m1Params.t0, deelnemer.g, {
    f: m1Params.ervaringsSterfte ?? 1.0,
    omega: m1Params.omega,
    data,
  })

  // Kruispunt: pen × (1+r)^t = verhoogd  →  t = ln(verhoogd/pen) / ln(1+r)
  // Alleen valid als verhoogd > pen én r > 0
  let ageCross: number | null = null
  if (verhoogd > deelnemer.pen && m1Params.r > 0) {
    const tCross = Math.log(verhoogd / deelnemer.pen) / Math.log(1 + m1Params.r)
    ageCross = deelnemer.x0 + tCross
  }

  return {
    x0: deelnemer.x0,
    xMax: 100,
    pen: deelnemer.pen,
    jaarequivalent,
    verhoogd,
    r: m1Params.r,
    verwachteSterfte,
    ageCross,
    KV_OP: m1Out.KV_OP,
    KV: m1Out.KV,
  }
}

/**
 * Bouw SVG-string voor indexed-pension grafiek.
 */
function renderIndexedSVG(s: IndexedSweep): string {
  const { x0, xMax, pen, verhoogd, r, verwachteSterfte, ageCross } = s

  // Dimensies — geen tweede Y-as, dus rechts-margin kleiner (30 ipv 80)
  const W = 760, H = 380
  const ML = 80, MR = 30, MT = 20, MB = 50
  const PW = W - ML - MR
  const PH = H - MT - MB

  // X-schaal
  const xScale = (age: number) => ML + ((age - x0) / (xMax - x0)) * PW

  // Y-bereik: van pen (start) tot pen × (1+r)^(xMax-x0). Stappen van 20 k€.
  const yStartK = pen / 1000
  const yEndIndexed = (pen * Math.pow(1 + r, xMax - x0)) / 1000
  const yStep = 20
  const yMaxK = Math.ceil(Math.max(yEndIndexed, verhoogd / 1000) / yStep) * yStep
  const yMinK = Math.floor(yStartK / yStep) * yStep
  const yScale = (k: number) => MT + PH - ((k - yMinK) / (yMaxK - yMinK)) * PH

  let svg = `<svg class="sens-chart" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Twee scenario's vergeleken: vlak verloop op verhoogd startbedrag vs. huidig pensioen geïndexeerd, over leeftijd ${x0} tot ${xMax}">`

  // Verticale stippel: verwachte sterfleeftijd
  const xSterfte = xScale(verwachteSterfte)
  svg += `<line x1="${xSterfte}" y1="${MT}" x2="${xSterfte}" y2="${MT + PH}" stroke="#1a6db5" stroke-width="1.5" stroke-dasharray="4,3" opacity="0.6"/>`
  svg += `<text x="${xSterfte}" y="${MT + 12}" text-anchor="middle" font-size="10" fill="#1a6db5" font-weight="600">≈ ${Math.round(verwachteSterfte)}</text>`

  // Y-as grid + labels (elke 20 k€)
  for (let k = yMinK; k <= yMaxK; k += yStep) {
    const y = yScale(k)
    svg += `<line x1="${ML}" y1="${y}" x2="${ML + PW}" y2="${y}" stroke="#e5e3df" stroke-width="1" stroke-dasharray="2,3"/>`
    svg += `<text x="${ML - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="#6b7280">${k}</text>`
  }

  // X-as labels (elke 5 jaar vanaf x0)
  const xTicks: number[] = []
  for (let t = x0; t <= xMax; t += 5) xTicks.push(t)
  if (xTicks[xTicks.length - 1] !== xMax) xTicks.push(xMax)
  for (const t of xTicks) {
    svg += `<text x="${xScale(t)}" y="${MT + PH + 18}" text-anchor="middle" font-size="11" fill="#6b7280">${t}</text>`
  }
  svg += `<text x="${ML + PW / 2}" y="${MT + PH + 38}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600">Uw leeftijd / [jaar]</text>`

  // Y-as label
  const yLabelY = MT + PH / 2
  svg += `<text x="18" y="${yLabelY}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600" transform="rotate(-90, 18, ${yLabelY})">Jaarpensioen / [k€/jaar]</text>`

  // Vlakke lijn (rood, M2-kleur)
  const vlakKEur = verhoogd / 1000
  const vlakPts: string[] = []
  for (let age = x0; age <= xMax; age++) vlakPts.push(`${xScale(age)},${yScale(vlakKEur)}`)
  svg += `<polyline points="${vlakPts.join(' ')}" fill="none" stroke="#D4001A" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>`

  // Geïndexeerde lijn (groen, M1-kleur)
  const idxPts: string[] = []
  for (let age = x0; age <= xMax; age++) {
    const v = (pen * Math.pow(1 + r, age - x0)) / 1000
    idxPts.push(`${xScale(age)},${yScale(v)}`)
  }
  svg += `<polyline points="${idxPts.join(' ')}" fill="none" stroke="#1a8a45" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>`

  // Kruispunt-stip + label (alleen als binnen X-range)
  if (ageCross !== null && ageCross >= x0 && ageCross <= xMax) {
    const cx = xScale(ageCross)
    const cy = yScale(vlakKEur)
    svg += `<circle cx="${cx}" cy="${cy}" r="6" fill="#fff" stroke="#6b7280" stroke-width="1.5"/>`
    svg += `<text x="${cx}" y="${cy - 12}" text-anchor="middle" font-size="11" fill="#6b7280" font-weight="600">${Math.round(ageCross)}</text>`
  }

  svg += '</svg>'
  return svg
}

/**
 * Bouw de volledige modal-body-HTML voor indexed-pension grafiek.
 */
export function renderIndexedHTML(s: IndexedSweep): string {
  const penStr = '€ ' + Math.round(s.pen).toLocaleString('nl-NL')
  const verhoogdStr = '€ ' + Math.round(s.verhoogd).toLocaleString('nl-NL')
  const jaarEqStr = '€ ' + Math.round(s.jaarequivalent).toLocaleString('nl-NL')
  const rPct = (s.r * 100).toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 2 })
  const sterfteStr = s.verwachteSterfte.toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 })

  // Kruispunt-zin alleen tonen als kruispunt bestaat
  const crossText = s.ageCross !== null
    ? `Op enig moment kruisen de twee lijnen — dat is het kantelpunt waarop het geïndexeerde scenario het vlakke scenario inhaalt.`
    : `In dit scenario kruisen de lijnen niet binnen de getoonde leeftijdsperiode.`

  return `
    <p class="sens-desc">
      De grafiek vergelijkt twee scenario's voor uw jaarpensioen. De <strong>rode lijn</strong>
      toont een <strong>vlak verloop</strong> op het verhoogde startbedrag van ${verhoogdStr}/jaar —
      aanname: geen indexatie boven dat bedrag. De <strong>groene lijn</strong> toont het
      <strong>huidige pensioen</strong> van ${penStr}/jaar, geïndexeerd met de rekenrente
      (${rPct}%) als proxy voor de historische SSPF-indexatie. ${crossText}
    </p>

    <div class="sens-chart-container">${renderIndexedSVG(s)}</div>

    <div class="sens-legend">
      <div class="sens-legend-item"><span class="sens-legend-line" style="background: #D4001A;"></span> Scenario: vlak op ${verhoogdStr}/jaar (geen indexatie)</div>
      <div class="sens-legend-item"><span class="sens-legend-line" style="background: #1a8a45;"></span> Scenario: ${penStr}/jaar geïndexeerd met ${rPct}%/jaar</div>
    </div>

    <p class="sens-meta-note">
      Huidig pensioen ${penStr}/jaar, verhoogd scenario ${verhoogdStr}/jaar (= ${penStr} + ${jaarEqStr}
      jaarequivalent uit het aandeel verdeelbaar overschot). Rekenrente ${rPct}% (uit M1-parameters).
      Verwachte sterfleeftijd ${sterfteStr} jaar volgens AG2024-sterftekansen. De omrekening van
      kapitaal naar jaarpensioen houdt — indien van toepassing — rekening met de reservering voor
      partnerpensioen.
      SSPF heeft historisch zijn pensioenen volledig kunnen indexeren; de rekenrente dient hier
      als proxy voor dat indexatie-spoor. <strong>In het nieuwe pensioenstelsel hangt uw werkelijke
      jaarpensioen af van veel meer factoren die in deze grafiek niet zijn gemodelleerd</strong>,
      o.a.: beleggingsbeleid en lifecycle per cohort, solidariteitsreserves, risicodelingsmechanismes,
      toekomstige rente- en inflatie-ontwikkeling, en fondsbeleidsbeslissingen. De werkelijke uitkering
      kan substantieel hoger of lager uitvallen dan beide lijnen. De grafiek is bedoeld als denkkader,
      niet als voorspelling; aan deze projectie kunnen geen rechten worden ontleend.
    </p>
  `
}
