/**
 * M1-engine — implementatie §2.5 formules + §2.7 ρ-fallback-ladder.
 *
 * Direct afgeleid van ENGINE_SPECIFICATIE_v1.md v2.2.9.
 * Contracten: schema.v2.ts M1Deelnemer + M1Parameterset → M1Output.
 */

import type { M1Deelnemer, M1Parameterset, M1Output } from './schema.v2'

// ============================================================================
// AG2024-data (geïnjecteerd via window.__AG2024__ in single-file HTML)
// ============================================================================

export interface AG2024Data {
  metadata: { source: string; ages: number[]; years_embedded: number[] }
  M: Record<string, number[]>  // year → q per age [0..120]
  V: Record<string, number[]>
}

export function getAG2024(): AG2024Data {
  // @ts-expect-error — geïnjecteerd in HTML
  const data = window.__AG2024__ as AG2024Data | undefined
  if (!data) throw new Error('AG2024-data niet gevonden in window.__AG2024__')
  return data
}

/**
 * Haal sterftekans op. §2.5 periode-snapshot: één kolom t₀ voor alle
 * toekomstige leeftijden. Gender: 'M' → mannen-tafel, 'V' → vrouwen-tafel,
 * 'gemengd' → SSPF-weging (placeholder: 95% M / 5% V voor deelnemer,
 * §11.17 v1.9 SSPF-prior).
 */
export function q(
  x: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  data: AG2024Data = getAG2024(),
  genderMix: { M: number; V: number } = { M: 0.95, V: 0.05 }  // SSPF-deelnemer-default
): number {
  const age = Math.floor(x)
  if (age < 0) {
    throw new Error(`Leeftijd ${x} buiten AG2024-bereik [0..120]`)
  }
  // v3.0.18: AG2024-tafel loopt tot leeftijd 120; daarboven is sterven zeker (q=1).
  // Voor de joint-life-cascade in M1 betekent dit dat overleving boven 120 nul is.
  // Dit voorkomt crashes bij hoge x0 (≥83) waar partner-leeftijd in cascade-loop
  // de tafel-grens passeert.
  if (age > 120) return 1.0
  const yearKey = String(t0)
  if (!(yearKey in data.M)) {
    const years = data.metadata.years_embedded
    throw new Error(`AG2024 jaar ${t0} niet geëmbed; bereik: ${years[0]}..${years[years.length - 1]}`)
  }

  if (g === 'M') return data.M[yearKey][age]
  if (g === 'V') return data.V[yearKey][age]
  // gemengd
  return genderMix.M * data.M[yearKey][age] + genderMix.V * data.V[yearKey][age]
}

// ============================================================================
// Overlevingskansen (§2.5)
// ============================================================================

/**
 * t-jaars overlevingskans vanaf leeftijd x.
 *   ℓ^g_{x+t} = ∏_{s=0}^{t-1} (1 − f · q^AG2024_{x+s, t₀, g})
 * f = ervaringssterftefactor (§11.13, v1-placeholder 1.0)
 */
export function survivalProb(
  x: number,
  t: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  f: number,
  data: AG2024Data
): number {
  let p = 1.0
  for (let s = 0; s < t; s++) {
    const qs = f * q(x + s, t0, g, data)
    p *= Math.max(0, 1 - qs)
    if (p < 1e-12) return 0
  }
  return p
}

/**
 * k/m-jaars overlevingskans via lineaire interpolatie tussen jaarlijkse ℓ.
 * Voor sub-jaarlijkse tijdstippen (m>1): interpolate tussen ℓ_{x+⌊k/m⌋} en
 * ℓ_{x+⌊k/m⌋+1} conform §2.5 v1.2 arrears-conventie.
 */
function subYearSurvival(
  x: number,
  k_over_m: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  f: number,
  data: AG2024Data
): number {
  const floorT = Math.floor(k_over_m)
  const frac = k_over_m - floorT
  if (frac === 0) return survivalProb(x, floorT, t0, g, f, data)
  const pFloor = survivalProb(x, floorT, t0, g, f, data)
  const pCeil = survivalProb(x, floorT + 1, t0, g, f, data)
  return pFloor * (1 - frac) + pCeil * frac
}

// ============================================================================
// Annuïteitsfactor (§2.5 v1.2 arrears m=12) — met memoisatie
// ============================================================================

/**
 * Cache voor annuïteitsberekeningen. Key: alle parameters die de uitkomst
 * bepalen. Bij live-input met alleen rente-wijziging voorkomt dit onnodig
 * herberekenen van overlevingskansen.
 */
const _annuityCache = new Map<string, number>()

/**
 * ä(x, r) = (1/m) · Σ_{k=1}^{m·T_eff} (1+π)^{k/m} · _{k/m}p_x · (1+r)^{-k/m}
 * Horizon-cap: T_eff = min(ω−x, 55, t zodat ℓ_{x+t} < 0.001) (§2.5).
 */
export function annuity(
  x: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  const { m, pi, f, omega, data } = opts

  // Memoisatie-key — alle waardes die de uitkomst bepalen
  const key = `${x.toFixed(4)}|${r.toFixed(6)}|${t0}|${g}|${m}|${pi.toFixed(6)}|${f.toFixed(6)}|${omega}`
  const cached = _annuityCache.get(key)
  if (cached !== undefined) return cached

  // T_eff bepalen
  let T_eff = omega - x
  T_eff = Math.min(T_eff, 55)
  // Verder beperken tot waar ℓ < 0.001
  for (let t = 1; t <= T_eff; t++) {
    if (survivalProb(x, t, t0, g, f, data) < 0.001) {
      T_eff = t
      break
    }
  }

  // Som opbouwen (arrears: k=1 tot m·T_eff)
  let sum = 0
  for (let k = 1; k <= m * T_eff; k++) {
    const t = k / m
    const p = subYearSurvival(x, t, t0, g, f, data)
    const indexation = Math.pow(1 + pi, t)
    const discount = Math.pow(1 + r, -t)
    sum += indexation * p * discount
  }
  const result = sum / m

  // Cache beperken tot 256 entries (voorkom geheugenexplosie bij extreme input)
  if (_annuityCache.size > 256) {
    const firstKey = _annuityCache.keys().next().value
    if (firstKey) _annuityCache.delete(firstKey)
  }
  _annuityCache.set(key, result)
  return result
}

// ============================================================================
// v3.0.51: Fractionele-leeftijd ondersteuning via lineaire interpolatie
// ============================================================================
// Onze AG2024-tafel levert q_x op gehele leeftijden. Onze input is sinds v3.0.51
// een geboortedatum (zie ui.app.ts), waaruit we x = (peildatum − geboortedatum)
// / 365.25 als fractie afleiden.
//
// Voor de annuïteit gebruiken we lineaire interpolatie tussen ä(⌊x⌋) en ä(⌈x⌉):
//   ä(x) = (1 − f)·ä(⌊x⌋) + f·ä(⌊x⌋+1)   met f = x − ⌊x⌋
//
// Dit is equivalent aan de constant-force-aanname voor sub-jaarlijkse
// leeftijden — een actuariële standaard die DNB en het AG hanteren bij
// fractionele waarderingen. De fout t.o.v. exacte fractionele AG2024 is
// theoretisch ~0,1% rond x=70 want de annuïteit is bijna lineair in x op
// enkelvoudige jaren.
//
// Voor x exact integer: f=0, dus ä(x) = ä(⌊x⌋). Geheel-jaars-ankers blijven
// daarom bit-identiek.

export function annuityFractional(
  x: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  const xFloor = Math.floor(x)
  const frac = x - xFloor
  if (frac === 0) return annuity(xFloor, r, t0, g, opts)
  const aFloor = annuity(xFloor, r, t0, g, opts)
  const aCeil = annuity(xFloor + 1, r, t0, g, opts)
  return (1 - frac) * aFloor + frac * aCeil
}

// Joint-life — bilinear interpolatie over (x_d, x_p)-paar.
// Bij integer-input is fracD=fracP=0 dus reduceert tot één integer-call,
// numeriek bit-identiek aan de oude implementatie.
export function jointLifeAnnuityFractional(
  x_d: number,
  x_p: number,
  r: number,
  t0: number,
  g_d: 'M' | 'V' | 'gemengd',
  g_p: 'M' | 'V' | 'gemengd',
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
    deelnemerReedsOverleden?: boolean
  }
): number {
  const xdFloor = Math.floor(x_d)
  const xpFloor = Math.floor(x_p)
  const fD = x_d - xdFloor
  const fP = x_p - xpFloor
  if (fD === 0 && fP === 0) {
    return jointLifeAnnuity(xdFloor, xpFloor, r, t0, g_d, g_p, opts)
  }
  const a00 = jointLifeAnnuity(xdFloor,     xpFloor,     r, t0, g_d, g_p, opts)
  const a10 = fD > 0 ? jointLifeAnnuity(xdFloor + 1, xpFloor,     r, t0, g_d, g_p, opts) : a00
  const a01 = fP > 0 ? jointLifeAnnuity(xdFloor,     xpFloor + 1, r, t0, g_d, g_p, opts) : a00
  const a11 = (fD > 0 && fP > 0)
    ? jointLifeAnnuity(xdFloor + 1, xpFloor + 1, r, t0, g_d, g_p, opts)
    : (fD > 0 ? a10 : (fP > 0 ? a01 : a00))
  return (1 - fD) * (1 - fP) * a00
       + fD       * (1 - fP) * a10
       + (1 - fD) * fP       * a01
       + fD       * fP       * a11
}

export function jointLifeAnnuityWithQFractional(
  x_d: number,
  x_p: number,
  r: number,
  t0: number,
  g_d: 'M' | 'V' | 'gemengd',
  g_p: 'M' | 'V' | 'gemengd',
  N: number,
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
    deelnemerReedsOverleden?: boolean
  }
): number {
  const xdFloor = Math.floor(x_d)
  const xpFloor = Math.floor(x_p)
  const fD = x_d - xdFloor
  const fP = x_p - xpFloor
  if (fD === 0 && fP === 0) {
    return jointLifeAnnuityWithQ(xdFloor, xpFloor, r, t0, g_d, g_p, N, opts)
  }
  const a00 = jointLifeAnnuityWithQ(xdFloor,     xpFloor,     r, t0, g_d, g_p, N, opts)
  const a10 = fD > 0 ? jointLifeAnnuityWithQ(xdFloor + 1, xpFloor,     r, t0, g_d, g_p, N, opts) : a00
  const a01 = fP > 0 ? jointLifeAnnuityWithQ(xdFloor,     xpFloor + 1, r, t0, g_d, g_p, N, opts) : a00
  const a11 = (fD > 0 && fP > 0)
    ? jointLifeAnnuityWithQ(xdFloor + 1, xpFloor + 1, r, t0, g_d, g_p, N, opts)
    : (fD > 0 ? a10 : (fP > 0 ? a01 : a00))
  return (1 - fD) * (1 - fP) * a00
       + fD       * (1 - fP) * a10
       + (1 - fD) * fP       * a01
       + fD       * fP       * a11
}

// annuityWithQ-fractioneel — analoog aan annuityFractional, voor cw_star_op
function annuityWithQFractional(
  x: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  N: number,
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  const xFloor = Math.floor(x)
  const frac = x - xFloor
  if (frac === 0) return annuityWithQ(xFloor, r, t0, g, N, opts)
  const aFloor = annuityWithQ(xFloor, r, t0, g, N, opts)
  const aCeil = annuityWithQ(xFloor + 1, r, t0, g, N, opts)
  return (1 - frac) * aFloor + frac * aCeil
}

// lifeExpectancy-fractioneel — voor het rapport
function lifeExpectancyFractional(
  x: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: { f: number; omega: number; data: AG2024Data }
): number {
  const xFloor = Math.floor(x)
  const frac = x - xFloor
  if (frac === 0) return lifeExpectancy(xFloor, t0, g, opts)
  const lFloor = lifeExpectancy(xFloor, t0, g, opts)
  const lCeil = lifeExpectancy(xFloor + 1, t0, g, opts)
  return (1 - frac) * lFloor + frac * lCeil
}


//
//   q(h, N) = min(floor(h)/N, 1)
//
// h: looptijd in jaren (kan sub-jaarlijks zijn bij m=12). Voor t < 1 is floor=0
// dus q=0 — eerste 11 maanden krijgen geen overschot toegewezen onder N=10
// (compatibel met "trapsgewijs jaarlijks stijgend" uit wettekst).
// ============================================================================

export function q_wet(h: number, N: number): number {
  if (N <= 0) return 0
  return Math.min(Math.floor(h) / N, 1)
}

// ============================================================================
// annuityWithQ — wettelijke CW_star = Σ_h q(h,N) · KS_voor(h) · v(h)
//
// Identiek aan annuity() maar met q_wet(t, N)-multiplier in de som. Levert per
// individu de "spreidings-gewogen kapitaalwaarde" zodanig dat:
//
//   ppk(i) = KV(i) + x_fonds · CW_star(i)              (lineariteit, zie §3.5 v3.0)
//
// Aparte cache (_annuityWithQCache) — N is onderdeel van de cache-key.
// ============================================================================

const _annuityWithQCache = new Map<string, number>()

export function annuityWithQ(
  x: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  N: number,
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  const { m, pi, f, omega, data } = opts

  const key = `${x.toFixed(4)}|${r.toFixed(6)}|${t0}|${g}|${N}|${m}|${pi.toFixed(6)}|${f.toFixed(6)}|${omega}`
  const cached = _annuityWithQCache.get(key)
  if (cached !== undefined) return cached

  let T_eff = omega - x
  T_eff = Math.min(T_eff, 55)
  for (let t = 1; t <= T_eff; t++) {
    if (survivalProb(x, t, t0, g, f, data) < 0.001) {
      T_eff = t
      break
    }
  }

  let sum = 0
  for (let k = 1; k <= m * T_eff; k++) {
    const t = k / m
    const qw = q_wet(t, N)
    if (qw === 0) continue
    const p = subYearSurvival(x, t, t0, g, f, data)
    const indexation = Math.pow(1 + pi, t)
    const discount = Math.pow(1 + r, -t)
    sum += qw * indexation * p * discount
  }
  const result = sum / m

  if (_annuityWithQCache.size > 256) {
    const firstKey = _annuityWithQCache.keys().next().value
    if (firstKey) _annuityWithQCache.delete(firstKey)
  }
  _annuityWithQCache.set(key, result)
  return result
}

// ============================================================================
// annuityWithQShifted — wettelijke CW_star voor toekomstige pensioneerder
//
// Voor actieve deelnemer (huidige leeftijd x_now < pensioenleeftijd 65):
// kasstromen lopen vanaf pensionering (h_inv = 65 - x_now jaar in toekomst).
// De wet (Bijlage 2a Regeling Pw art. 2) meet q(h, N) = min(h/N, 1) waar h
// gemeten wordt vanaf het INVAARMOMENT, niet vanaf pensionering. Dus voor
// pre-pensioen-jaren (h = 1..h_inv-1, geen kasstroom) "telt q al door".
//
// Implementatie: zelfde structuur als annuityWithQ maar met h_global = t + shift
// in q_wet, terwijl survival/discount nog steeds op t (vanaf x=65) werken.
//
// Voor x_now ≥ 65 valt shift=0 weg en is het identiek aan annuityWithQ.
//
// v3.0.37: bug-fix Hans-replicatie (zie test_hans_replication.ts).
// ============================================================================

const _annuityWithQShiftedCache = new Map<string, number>()

export function annuityWithQShifted(
  x: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  N: number,
  shift: number,  // h_global = t + shift; voor 27-jr actief: shift=38
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  if (shift === 0) return annuityWithQ(x, r, t0, g, N, opts)

  const { m, pi, f, omega, data } = opts

  const key = `${x.toFixed(4)}|${r.toFixed(6)}|${t0}|${g}|${N}|${shift}|${m}|${pi.toFixed(6)}|${f.toFixed(6)}|${omega}`
  const cached = _annuityWithQShiftedCache.get(key)
  if (cached !== undefined) return cached

  let T_eff = omega - x
  T_eff = Math.min(T_eff, 55)
  for (let t = 1; t <= T_eff; t++) {
    if (survivalProb(x, t, t0, g, f, data) < 0.001) {
      T_eff = t
      break
    }
  }

  let sum = 0
  for (let k = 1; k <= m * T_eff; k++) {
    const t = k / m
    const h_global = t + shift  // q gemeten op globale tijdsas vanaf invaarmoment
    const qw = q_wet(h_global, N)
    if (qw === 0) continue
    const p = subYearSurvival(x, t, t0, g, f, data)
    const indexation = Math.pow(1 + pi, t)
    const discount = Math.pow(1 + r, -t)
    sum += qw * indexation * p * discount
  }
  const result = sum / m

  if (_annuityWithQShiftedCache.size > 256) {
    const firstKey = _annuityWithQShiftedCache.keys().next().value
    if (firstKey) _annuityWithQShiftedCache.delete(firstKey)
  }
  _annuityWithQShiftedCache.set(key, result)
  return result
}

// ============================================================================
// Broken-heart-correctie — §2.5 v2.2.11 + §11.20 bron-onderzoek
//
// Multiplicatieve schok op overlevende-partner-q na deelnemer-overlijden,
// τ = jaren sinds overlijden, lineair dempend over 5 jaar.
//
//   bh(τ, g) = bh₀(g) − (bh₀(g) − 1) · (τ/5)    voor τ ∈ [0, 5]
//            = 1                                  voor τ > 5
//
// Default-parametrisering (placeholder, §11.20 bron-todo AG-2018):
//   bh₀(M) = 1.50  (overlevende man na vrouwelijke partner)
//   bh₀(V) = 1.25  (overlevende vrouw na mannelijke partner)
//   gemengd: gemiddelde 1.375
// ============================================================================

export function brokenHeartFactor(
  tau: number,
  g_partner: 'M' | 'V' | 'gemengd'
): number {
  if (tau >= 5) return 1
  if (tau < 0) return 1
  const bh0 =
    g_partner === 'M' ? 1.50 :
    g_partner === 'V' ? 1.25 :
    1.375 // gemengd: gemiddelde van M en V
  return bh0 - (bh0 - 1) * (tau / 5)
}

/**
 * Joint-life partner-overlevingskans onder bh-schok, gegeven deelnemer-
 * overlijden in sub-interval [k_d-1, k_d]/m. Pre-overlijdens-segment heeft
 * onafhankelijke partner-q; post-segment heeft bh-geschokte partner-q via
 * midpoint-benadering.
 */
function survivalProbBhConditional(
  x_p: number,
  k_d: number,
  k: number,
  m: number,
  t0: number,
  g_p: 'M' | 'V' | 'gemengd',
  f: number,
  data: AG2024Data
): number {
  let p = 1.0
  for (let s = 1; s <= k; s++) {
    const ageOffset = Math.floor((s - 1) / m)
    const q_basis = f * q(x_p + ageOffset, t0, g_p, data)
    let q_eff = q_basis
    if (s > k_d) {
      const tau = (s - k_d - 0.5) / m
      const bh = brokenHeartFactor(Math.max(0, tau), g_p)
      q_eff = Math.min(1, bh * q_basis)
    }
    const q_sub = q_eff / m
    p *= Math.max(0, 1 - q_sub)
    if (p < 1e-12) return 0
  }
  return p
}

/**
 * Joint-life annuïteit ä_{x|y}(r), v2.2.11 §2.5.
 *   ä_{x|y}(r) = (1/m) · Σ_{k=1}^{m·T_eff} (1+π)^{k/m} · _{k/m}q_x ·
 *                                          _{k/m}p_y^{bh} · (1+r)^{−k/m}
 *
 * Numeriek-stabiel via incrementele decompositie over deelnemer-overlijdens-
 * tijdstip k_d. Complexiteit O(m²·T_eff); voor m=12, T_eff=30 ≈ 3600 sub-
 * iteraties. Ingegaan-NP-fallback via deelnemerReedsOverleden-flag.
 */
// ============================================================================
// v3.0.57: Hoog-laag-regeling — tijdelijke annuïteiten ä(x : k) eindigend op k
// ============================================================================
// Gepensioneerden kunnen kiezen voor een hoog-laag-regeling (art. 63 Pw): in
// de eerste t jaar een hoog bedrag, daarna een lager bedrag levenslang. We
// modelleren dit via lineariteit:
//
//   KV_HL = pen_laag · ä(x, ω) + (pen_hoog − pen_laag) · ä(x : k)
//
// waarbij ä(x : k) een "tijdelijke" annuïteit is die alleen kasstromen tot
// leeftijd k telt. Voor k ≤ x is ä(x : k) = 0 (verleden-knip wordt door UI
// geweigerd; engine return 0 als safeguard).
//
// Dezelfde structuur voor q-gewogen (cw_star_op met spreidings-multiplier).
// ============================================================================

const _annuityTempCache = new Map<string, number>()

export function annuityTemporary(
  x: number,
  k: number,                       // eindleeftijd
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  if (k <= x) return 0
  const { m, pi, f, omega, data } = opts
  const key = `${x.toFixed(4)}|${k.toFixed(4)}|${r.toFixed(6)}|${t0}|${g}|${m}|${pi.toFixed(6)}|${f.toFixed(6)}|${omega}`
  const cached = _annuityTempCache.get(key)
  if (cached !== undefined) return cached

  let T_eff = Math.min(k - x, omega - x, 55)
  for (let t = 1; t <= T_eff; t++) {
    if (survivalProb(x, t, t0, g, f, data) < 0.001) {
      T_eff = t
      break
    }
  }

  let sum = 0
  for (let kk = 1; kk <= m * T_eff; kk++) {
    const t = kk / m
    if (x + t > k) break
    const p = subYearSurvival(x, t, t0, g, f, data)
    const indexation = Math.pow(1 + pi, t)
    const discount = Math.pow(1 + r, -t)
    sum += indexation * p * discount
  }
  const result = sum / m

  if (_annuityTempCache.size > 256) {
    const firstKey = _annuityTempCache.keys().next().value
    if (firstKey) _annuityTempCache.delete(firstKey)
  }
  _annuityTempCache.set(key, result)
  return result
}

const _annuityWithQTempCache = new Map<string, number>()

export function annuityWithQTemporary(
  x: number,
  k: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  N: number,
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  if (k <= x) return 0
  const { m, pi, f, omega, data } = opts
  const key = `${x.toFixed(4)}|${k.toFixed(4)}|${r.toFixed(6)}|${t0}|${g}|${N}|${m}|${pi.toFixed(6)}|${f.toFixed(6)}|${omega}`
  const cached = _annuityWithQTempCache.get(key)
  if (cached !== undefined) return cached

  let T_eff = Math.min(k - x, omega - x, 55)
  for (let t = 1; t <= T_eff; t++) {
    if (survivalProb(x, t, t0, g, f, data) < 0.001) {
      T_eff = t
      break
    }
  }

  let sum = 0
  for (let kk = 1; kk <= m * T_eff; kk++) {
    const t = kk / m
    if (x + t > k) break
    const qw = q_wet(t, N)
    if (qw === 0) continue
    const p = subYearSurvival(x, t, t0, g, f, data)
    const indexation = Math.pow(1 + pi, t)
    const discount = Math.pow(1 + r, -t)
    sum += qw * indexation * p * discount
  }
  const result = sum / m

  if (_annuityWithQTempCache.size > 256) {
    const firstKey = _annuityWithQTempCache.keys().next().value
    if (firstKey) _annuityWithQTempCache.delete(firstKey)
  }
  _annuityWithQTempCache.set(key, result)
  return result
}

// Fractional-wrappers: interpolatie over x; k blijft scherp.
export function annuityTemporaryFractional(
  x: number,
  k: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  const xFloor = Math.floor(x)
  const frac = x - xFloor
  if (frac === 0) return annuityTemporary(xFloor, k, r, t0, g, opts)
  const aFloor = annuityTemporary(xFloor, k, r, t0, g, opts)
  const aCeil = annuityTemporary(xFloor + 1, k, r, t0, g, opts)
  return (1 - frac) * aFloor + frac * aCeil
}

export function annuityWithQTemporaryFractional(
  x: number,
  k: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  N: number,
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
  }
): number {
  const xFloor = Math.floor(x)
  const frac = x - xFloor
  if (frac === 0) return annuityWithQTemporary(xFloor, k, r, t0, g, N, opts)
  const aFloor = annuityWithQTemporary(xFloor, k, r, t0, g, N, opts)
  const aCeil = annuityWithQTemporary(xFloor + 1, k, r, t0, g, N, opts)
  return (1 - frac) * aFloor + frac * aCeil
}

const _jointLifeCache = new Map<string, number>()

export function jointLifeAnnuity(
  x_d: number,
  x_p: number,
  r: number,
  t0: number,
  g_d: 'M' | 'V' | 'gemengd',
  g_p: 'M' | 'V' | 'gemengd',
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
    deelnemerReedsOverleden?: boolean
  }
): number {
  const { m, pi, f, omega, data, deelnemerReedsOverleden } = opts

  if (deelnemerReedsOverleden === true) {
    return annuity(x_p, r, t0, g_p, opts)
  }

  // Memoisatie-key — alle waardes die de uitkomst bepalen
  const key = `${x_d.toFixed(4)}|${x_p.toFixed(4)}|${r.toFixed(6)}|${t0}|${g_d}|${g_p}|${m}|${pi.toFixed(6)}|${f.toFixed(6)}|${omega}`
  const cached = _jointLifeCache.get(key)
  if (cached !== undefined) return cached

  let T_eff = omega - x_p
  T_eff = Math.min(T_eff, 55)
  for (let t = 1; t <= T_eff; t++) {
    if (survivalProb(x_p, t, t0, g_p, f, data) < 0.001) {
      T_eff = t
      break
    }
  }
  const T_eff_d = omega - x_d
  T_eff = Math.min(T_eff, T_eff_d + 30)

  const K = m * T_eff
  const dq_x: number[] = new Array(K + 1).fill(0)
  let p_prev = 1.0
  for (let k_d = 1; k_d <= K; k_d++) {
    const t_d = k_d / m
    if (t_d > T_eff_d + 5) {
      dq_x[k_d] = 0
      continue
    }
    const p_curr = subYearSurvival(x_d, t_d, t0, g_d, f, data)
    dq_x[k_d] = Math.max(0, p_prev - p_curr)
    p_prev = p_curr
  }

  // v2.2.11 optimalisatie: pre-compute partner baseline-q-pad om O(K³) → O(K²) te halen.
  // Survival onder bh-conditie wordt opgesplitst in:
  //   - baseline-segment 1..k_d (zonder schok)
  //   - schok-segment k_d+1 .. min(k, k_d+5m) (5-jaars schok-venster)
  //   - post-schok-baseline-segment min(k, k_d+5m)+1 .. k (schok uitgewerkt, baseline-ratio)
  const q_basis_step: number[] = new Array(K + 1).fill(0)
  for (let s = 1; s <= K; s++) {
    const ageOffset = Math.floor((s - 1) / m)
    q_basis_step[s] = f * q(x_p + ageOffset, t0, g_p, data)
  }
  const p_base: number[] = new Array(K + 1).fill(1.0)
  for (let s = 1; s <= K; s++) {
    p_base[s] = p_base[s - 1] * Math.max(0, 1 - q_basis_step[s] / m)
  }
  const SHOCK_WINDOW = 5 * m // 60 maanden bij m=12

  let sum = 0
  for (let k = 1; k <= K; k++) {
    const t = k / m
    let conditionalSurvival = 0
    for (let k_d = 1; k_d <= k; k_d++) {
      if (dq_x[k_d] === 0) continue

      // Baseline-segment 1..k_d
      let p_y_bh = p_base[k_d]
      const shockEnd = Math.min(k, k_d + SHOCK_WINDOW)

      // Schok-segment k_d+1 .. shockEnd
      for (let s = k_d + 1; s <= shockEnd; s++) {
        const tau = (s - k_d - 0.5) / m
        const bh = brokenHeartFactor(Math.max(0, tau), g_p)
        const q_eff = Math.min(1, bh * q_basis_step[s])
        p_y_bh *= Math.max(0, 1 - q_eff / m)
        if (p_y_bh < 1e-12) break
      }

      // Post-schok baseline-ratio
      if (shockEnd < k && p_y_bh > 0) {
        const ratio = p_base[shockEnd] > 0 ? p_base[k] / p_base[shockEnd] : 0
        p_y_bh *= ratio
      }

      conditionalSurvival += dq_x[k_d] * p_y_bh
    }
    const indexation = Math.pow(1 + pi, t)
    const discount = Math.pow(1 + r, -t)
    sum += indexation * conditionalSurvival * discount
  }

  const result = sum / m

  // Cache-eviction (FIFO via Map insertion-order)
  if (_jointLifeCache.size > 256) {
    const firstKey = _jointLifeCache.keys().next().value
    if (firstKey) _jointLifeCache.delete(firstKey)
  }
  _jointLifeCache.set(key, result)
  return result
}

// ============================================================================
// jointLifeAnnuityWithQ — wettelijke CW_star voor NP-aanspraak
//
// Identiek aan jointLifeAnnuity() maar met q_wet(t, N)-multiplier in de
// buitenste sommatie. De broken-heart-correctie en O(K²)-optimalisatie
// werken volledig door; alleen de uiteindelijke kasstroomweging q(h,N) wordt
// extra toegepast. Geen wijziging aan de partner-survival-mechaniek zelf.
//
// Aparte cache (_jointLifeWithQCache); N onderdeel van key.
// ============================================================================

const _jointLifeWithQCache = new Map<string, number>()

export function jointLifeAnnuityWithQ(
  x_d: number,
  x_p: number,
  r: number,
  t0: number,
  g_d: 'M' | 'V' | 'gemengd',
  g_p: 'M' | 'V' | 'gemengd',
  N: number,
  opts: {
    m: number
    pi: number
    f: number
    omega: number
    data: AG2024Data
    deelnemerReedsOverleden?: boolean
  }
): number {
  const { m, pi, f, omega, data, deelnemerReedsOverleden } = opts

  // Ingegaan-NP-fallback: deelnemer reeds overleden → enkel partner-annuïteit
  // met q-weging (geen joint-life meer).
  if (deelnemerReedsOverleden === true) {
    return annuityWithQ(x_p, r, t0, g_p, N, opts)
  }

  const key = `${x_d.toFixed(4)}|${x_p.toFixed(4)}|${r.toFixed(6)}|${t0}|${g_d}|${g_p}|${N}|${m}|${pi.toFixed(6)}|${f.toFixed(6)}|${omega}`
  const cached = _jointLifeWithQCache.get(key)
  if (cached !== undefined) return cached

  let T_eff = omega - x_p
  T_eff = Math.min(T_eff, 55)
  for (let t = 1; t <= T_eff; t++) {
    if (survivalProb(x_p, t, t0, g_p, f, data) < 0.001) {
      T_eff = t
      break
    }
  }
  const T_eff_d = omega - x_d
  T_eff = Math.min(T_eff, T_eff_d + 30)

  const K = m * T_eff
  const dq_x: number[] = new Array(K + 1).fill(0)
  let p_prev = 1.0
  for (let k_d = 1; k_d <= K; k_d++) {
    const t_d = k_d / m
    if (t_d > T_eff_d + 5) {
      dq_x[k_d] = 0
      continue
    }
    const p_curr = subYearSurvival(x_d, t_d, t0, g_d, f, data)
    dq_x[k_d] = Math.max(0, p_prev - p_curr)
    p_prev = p_curr
  }

  const q_basis_step: number[] = new Array(K + 1).fill(0)
  for (let s = 1; s <= K; s++) {
    const ageOffset = Math.floor((s - 1) / m)
    q_basis_step[s] = f * q(x_p + ageOffset, t0, g_p, data)
  }
  const p_base: number[] = new Array(K + 1).fill(1.0)
  for (let s = 1; s <= K; s++) {
    p_base[s] = p_base[s - 1] * Math.max(0, 1 - q_basis_step[s] / m)
  }
  const SHOCK_WINDOW = 5 * m

  let sum = 0
  for (let k = 1; k <= K; k++) {
    const t = k / m
    const qw = q_wet(t, N)
    if (qw === 0) continue
    let conditionalSurvival = 0
    for (let k_d = 1; k_d <= k; k_d++) {
      if (dq_x[k_d] === 0) continue

      let p_y_bh = p_base[k_d]
      const shockEnd = Math.min(k, k_d + SHOCK_WINDOW)

      for (let s = k_d + 1; s <= shockEnd; s++) {
        const tau = (s - k_d - 0.5) / m
        const bh = brokenHeartFactor(Math.max(0, tau), g_p)
        const q_eff = Math.min(1, bh * q_basis_step[s])
        p_y_bh *= Math.max(0, 1 - q_eff / m)
        if (p_y_bh < 1e-12) break
      }

      if (shockEnd < k && p_y_bh > 0) {
        const ratio = p_base[shockEnd] > 0 ? p_base[k] / p_base[shockEnd] : 0
        p_y_bh *= ratio
      }

      conditionalSurvival += dq_x[k_d] * p_y_bh
    }
    const indexation = Math.pow(1 + pi, t)
    const discount = Math.pow(1 + r, -t)
    sum += qw * indexation * conditionalSurvival * discount
  }

  const result = sum / m

  if (_jointLifeWithQCache.size > 256) {
    const firstKey = _jointLifeWithQCache.keys().next().value
    if (firstKey) _jointLifeWithQCache.delete(firstKey)
  }
  _jointLifeWithQCache.set(key, result)
  return result
}

// ============================================================================
// Levensverwachting (curtate + halfjaar-correctie, §2.5)
// ============================================================================

/**
 * lifeExp(x) = x + Σ_{t=1}^{T_eff} ℓ_{x+t} + 0.5
 * Let op: dit is verwachte STERFLEEFTIJD, niet resterende levensverwachting.
 */
export function lifeExpectancy(
  x: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: { f: number; omega: number; data: AG2024Data }
): number {
  const { f, omega, data } = opts
  const T_eff = Math.min(omega - x, 55)
  let sum = 0
  for (let t = 1; t <= T_eff; t++) {
    const p = survivalProb(x, t, t0, g, f, data)
    if (p < 1e-6) break
    sum += p
  }
  return x + sum + 0.5
}

// ============================================================================
// ρ-fallback-ladder (§2.7)
// ============================================================================

/**
 * Bepaal effectieve ρ conform §2.7:
 *   1. Beide uitvoeringskostenJaarlijks + fondsvermogen → Variant-A afleiding
 *   2. Alleen kostenOpslagPct → direct
 *   3. Anders → ultieme default 0.02 (§11.14 v1.5)
 *
 * Variant A: ρ = c_jaar · ä(x, r) met c_jaar = uitvoeringskosten/fondsvermogen
 */
export function resolveRho(
  params: M1Parameterset,
  a_x: number
): { rho: number; route: 'variant-A' | 'direct' | 'default' } {
  const hasVariantA =
    params.uitvoeringskostenJaarlijks !== null && params.fondsvermogen !== null
  if (hasVariantA) {
    const c_jaar =
      (params.uitvoeringskostenJaarlijks as number) /
      (params.fondsvermogen as number)
    return { rho: c_jaar * a_x, route: 'variant-A' }
  }
  if (params.kostenOpslagPct !== null) {
    return { rho: params.kostenOpslagPct, route: 'direct' }
  }
  return { rho: 0.02, route: 'default' }
}

// ============================================================================
// M1-hoofdberekening
// ============================================================================

export function computeM1(
  deelnemer: M1Deelnemer,
  params: M1Parameterset,
  m2Context?: { spreidingN: number }
): M1Output {
  const data = getAG2024()

  const annuityOpts = {
    m: params.m,
    pi: params.pi,
    f: params.ervaringsSterfte,
    omega: params.omega,
    data,
  }

  // Annuïteitsfactoren — fractional wrappers (bit-identiek aan integer
  // wanneer x integer; v3.0.51 fractionele leeftijden via geboortedatum).
  const a_x0 = annuityFractional(deelnemer.x0, params.r, params.t0, deelnemer.g, annuityOpts)

  const heeftPartner = deelnemer.heeftPartner && deelnemer.x_partner !== null
  const a_partner = heeftPartner
    ? annuityFractional(deelnemer.x_partner as number, params.r, params.t0, deelnemer.g_y, annuityOpts)
    : null

  // ρ afleiden — gebruikt ä(x₀, r) als leeftijds-basis (§2.5 "c_jaar · ä(x, r)")
  const { rho: rho_effectief } = resolveRho(params, a_x0)

  // KV_OP — hoog-laag-decompositie via lineariteit (v3.0.57):
  //   KV_OP = pen_laag·ä(x, ω) + (pen_hoog − pen_laag)·ä(x : k)
  // Bij hooglaagActief=false reduceert dit tot pen_hoog·ä(x, ω) zoals voorheen.
  const useHooglaag = deelnemer.hooglaagActief
    && deelnemer.x_knip !== null
    && deelnemer.pen_laag !== null
    && (deelnemer.x_knip as number) > deelnemer.x0
  const a_temp = useHooglaag
    ? annuityTemporaryFractional(
        deelnemer.x0,
        deelnemer.x_knip as number,
        params.r,
        params.t0,
        deelnemer.g,
        annuityOpts
      )
    : 0
  const pen_laag_eff = useHooglaag ? (deelnemer.pen_laag as number) : deelnemer.pen
  const KV_OP = (1 + rho_effectief) * (
    pen_laag_eff * a_x0
    + (deelnemer.pen - pen_laag_eff) * a_temp
  )

  // NP: y₀ bekend of fallback 0.70 × pen (§11.5 v1.8)
  const y0_eff = heeftPartner
    ? (deelnemer.y0 !== null ? deelnemer.y0 : 0.70 * deelnemer.pen)
    : 0

  // §2.5 v2.2.11: NP via joint-life met broken-heart-correctie
  // (vervangt v1.3-bovengrens KV_NP = y₀·ä(x_partner, r))
  const a_jointLife = heeftPartner
    ? jointLifeAnnuityFractional(
        deelnemer.x0,
        deelnemer.x_partner as number,
        params.r,
        params.t0,
        deelnemer.g,
        deelnemer.g_y,
        { ...annuityOpts, deelnemerReedsOverleden: false }
      )
    : null

  const KV_NP = heeftPartner && a_jointLife !== null
    ? (1 + rho_effectief) * y0_eff * a_jointLife
    : 0

  const KV = KV_OP + KV_NP

  // Levensverwachtingen
  const lifeExpOpts = { f: params.ervaringsSterfte, omega: params.omega, data }
  const lifeExp_x0 = lifeExpectancyFractional(deelnemer.x0, params.t0, deelnemer.g, lifeExpOpts)
  const lifeExp_partner = heeftPartner
    ? lifeExpectancyFractional(deelnemer.x_partner as number, params.t0, deelnemer.g_y, lifeExpOpts)
    : null

  // §3.5 v3.0 — CW_star alleen berekenen bij M2-cascade
  // (m2Context aanwezig → spreidingN bekend → wettelijke staircase actief)
  let cw_star_op: number | undefined
  let cw_star_np: number | undefined
  if (m2Context !== undefined) {
    const N = m2Context.spreidingN
    const a_x0_q = annuityWithQFractional(deelnemer.x0, params.r, params.t0, deelnemer.g, N, annuityOpts)
    // v3.0.57: cw_star_op met hoog-laag-decompositie (zelfde lineariteit
    // als KV_OP). Q-gewogen tijdelijke annuïteit voor het hoog-laag-verschil.
    const a_temp_q = useHooglaag
      ? annuityWithQTemporaryFractional(
          deelnemer.x0,
          deelnemer.x_knip as number,
          params.r,
          params.t0,
          deelnemer.g,
          N,
          annuityOpts
        )
      : 0
    cw_star_op = (1 + rho_effectief) * (
      pen_laag_eff * a_x0_q
      + (deelnemer.pen - pen_laag_eff) * a_temp_q
    )

    if (heeftPartner) {
      const a_jl_q = jointLifeAnnuityWithQFractional(
        deelnemer.x0,
        deelnemer.x_partner as number,
        params.r,
        params.t0,
        deelnemer.g,
        deelnemer.g_y,
        N,
        { ...annuityOpts, deelnemerReedsOverleden: false }
      )
      cw_star_np = (1 + rho_effectief) * y0_eff * a_jl_q
    } else {
      cw_star_np = 0
    }
  }

  return {
    KV,
    KV_OP,
    KV_NP,
    a_x0,
    a_partner,
    lifeExp_x0,
    lifeExp_partner,
    rho_effectief,
    ...(cw_star_op !== undefined ? { cw_star_op } : {}),
    ...(cw_star_np !== undefined ? { cw_star_np } : {}),
  }
}
