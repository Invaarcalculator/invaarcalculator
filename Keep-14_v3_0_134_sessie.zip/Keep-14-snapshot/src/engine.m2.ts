/**
 * M2-engine — implementatie §3.5-formules (potje/toedeling).
 *
 * Direct afgeleid van ENGINE_SPECIFICATIE_v1.md v2.2.10.
 * Contracten: schema.v2.ts M1Deelnemer + M2KetenInput + M2Parameterset → M2Output.
 *
 * Belangrijkste keuzes (combi-sessie M2 04-05-2026):
 *   - Model C bundle-aftrek: verdeelbaar = fondsvermogen − vpvAftrekPct·vpvTotal
 *                                          − compensatiedepot − buffer + bijstort
 *   - kvProfile-aanpak voor ν(N) cohort-normalisatie: R9.30-conform met
 *     deelnemer-pen, leeftijd-staffel actieven (<65) vs gepensheerden (≥65).
 *     Dit is een pragmatische schending van §3.6 aanname 1 (gerechtvaardigd
 *     omdat aanname 1 het hoofdpad-individu betreft, niet de tweede-orde
 *     normalisatie ν(N) <0,5%).
 *   - Cohort-gender via SSPF-prior 95/5 (§11.17, v1.9-besluit) voor s̄.
 *   - ppkComp volledig aan ppk_OP (v2.1.2 bronverankerd, art. 150f Pw).
 *   - DEMOGRAFIE_PRESETS overgenomen uit R9.30 (lijn 3344) — generieke
 *     fondstype-templates, niet fonds-specifiek; SSPF kiest 'gesloten'.
 */

import type {
  M1Deelnemer,
  M2KetenInput,
  M2Parameterset,
  M2Output,
  M2Demografie,
  CohortOutcome,
} from './schema.v2'
import {
  type AG2024Data,
  getAG2024,
  survivalProb,
  annuity,
  annuityWithQ,
  annuityWithQShifted,
  jointLifeAnnuity,
  jointLifeAnnuityWithQ,
} from './engine.m1'

// ============================================================================
// Cohort-grenzen — 15 cohorten × 5 jaar over 25-99
// ============================================================================

/**
 * Grenzen tussen cohorten: [25,30), [30,35), ..., [95,100).
 * Conform R9.30 (lijn 3336) en spec §3.4.
 */
export const COHORT_BOUNDS = [
  25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100,
] as const

/**
 * Mid-leeftijden voor ν(N)-cohort-vertegenwoordiging (§3.6 aanname 8).
 * Conform R9.30 dnbNormFactor: floor((bound[i] + bound[i+1] - 1) / 2).
 *   [25..29] → 27, [30..34] → 32, ..., [95..99] → 97
 */
export const COHORT_MIDAGES: readonly number[] = (() => {
  const out: number[] = []
  for (let i = 0; i < COHORT_BOUNDS.length - 1; i++) {
    out.push(Math.floor((COHORT_BOUNDS[i] + COHORT_BOUNDS[i + 1] - 1) / 2))
  }
  return out
})() // [27, 32, 37, 42, 47, 52, 57, 62, 67, 72, 77, 82, 87, 92, 97]

/** Leesbaar label "NN-NN" per cohort. */
export const COHORT_LABELS: readonly string[] = (() => {
  const out: string[] = []
  for (let i = 0; i < COHORT_BOUNDS.length - 1; i++) {
    out.push(`${COHORT_BOUNDS[i]}-${COHORT_BOUNDS[i + 1] - 1}`)
  }
  return out
})() // ['25-29', '30-34', ..., '95-99']

// ============================================================================
// Demografie-presets (overgenomen uit R9.30 lijn 3344-3350)
//
// Absolute aantallen zijn indicatief; ze leveren alleen de vorm (fracties).
// SSPF-default = 'gesloten' (gepensheerden-zwaartepunt 65-89).
// SSPF-specifieke aantallen zijn niet beschikbaar in Keep-9.zip; bron-todo
// parallel aan §11.19 vpvAftrekPct: vervangen via customCounts zonder bump.
// ============================================================================

export const DEMOGRAFIE_PRESETS: Record<string, readonly number[]> = {
  uniform:      [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000],
  grijzend:     [50, 300, 900, 1500, 2000, 2300, 2700, 3400, 3600, 3400, 2900, 1900, 1100, 400, 50],
  gebalanceerd: [600, 1500, 2500, 2900, 3100, 3100, 2900, 2500, 2000, 1500, 1000, 600, 300, 100, 20],
  jong:         [1500, 2800, 3500, 3200, 2500, 1800, 1300, 1000, 800, 600, 400, 250, 120, 40, 10],
  gesloten:     [0, 0, 0, 0, 0, 50, 400, 1500, 2500, 2800, 2200, 1300, 700, 250, 50],
}

/**
 * Resolve demografie naar absolute counts[15] of fractions[15].
 * Bij preset: returnt template-counts (niet geschaald naar N_deelnemers).
 * Bij customCounts: directe array.
 */
export function resolveCohortCounts(d: M2Demografie): readonly number[] {
  if (d.soort === 'preset') {
    const tmpl = DEMOGRAFIE_PRESETS[d.preset]
    if (!tmpl) throw new Error(`Onbekende preset: ${d.preset}`)
    return tmpl
  }
  return d.customCounts
}

/** Cohort-fracties (som = 1). Bij totaal=0 uniform fallback. */
export function getCohortFractions(d: M2Demografie): number[] {
  const counts = resolveCohortCounts(d)
  const total = counts.reduce((s, x) => s + x, 0)
  if (total <= 0) return counts.map(() => 1 / counts.length)
  return counts.map((x) => x / total)
}

// ============================================================================
// DNB-spreidingsfactor s(x, N, g) — §3.5 + §11.17
// ============================================================================

/**
 * s(x, N, g) = (1/N) · Σ_{t=0}^{N-1} ℓ^g_{x+t}
 * met ℓ^g_{x+0} = 1.
 * Speciaal: N=0 → 1 (geen spreiding).
 *
 * Implementatie hergebruikt M1's survivalProb (gender-specifiek, AG2024).
 */
export function dnbShareFactor(
  x: number,
  N: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: { f: number; data: AG2024Data }
): number {
  if (N <= 0) return 1
  let sum = 0
  for (let t = 0; t < N; t++) {
    // survivalProb(x, t=0, ...) returnt per definitie 1.0; OK als startwaarde
    sum += survivalProb(x, t, t0, g, opts.f, opts.data)
  }
  return sum / N
}

// ============================================================================
// Bell-curve (compensatie) — §3.5
// ============================================================================

/** w(x) = exp(−½ · ((x − μ) / σ)²) — Gaussische dichtheid (geen normalisatie). */
export function bellW(x: number, mu: number, sigma: number): number {
  return Math.exp(-0.5 * Math.pow((x - mu) / sigma, 2))
}

/**
 * Demografisch gewogen gemiddelde w̄ over alle leeftijden 25-99.
 * Conform R9.30 ppkCurveSum (lijn 3249): cohort-fractie uniform over de
 * 5 leeftijden per cohort verdeeld, dan Σ(perAge · w(a)) / Σ perAge.
 */
export function wAverage(
  mu: number,
  sigma: number,
  fractions: readonly number[]
): number {
  let weightedSum = 0
  let totalPersons = 0
  for (let i = 0; i < 15; i++) {
    const ageStart = COHORT_BOUNDS[i]
    const ageEnd = COHORT_BOUNDS[i + 1] // exclusive
    const cohortBreedte = ageEnd - ageStart
    const perAge = fractions[i] / cohortBreedte
    for (let a = ageStart; a < ageEnd; a++) {
      weightedSum += perAge * bellW(a, mu, sigma)
      totalPersons += perAge
    }
  }
  return totalPersons > 0 ? weightedSum / totalPersons : 0
}

/** w_rel(x) = w(x) / w̄ — relatief bell-gewicht voor compensatie-toedeling. */
export function wRelative(
  x: number,
  mu: number,
  sigma: number,
  wAvg: number
): number {
  if (wAvg <= 0) return 0
  return bellW(x, mu, sigma) / wAvg
}

// ============================================================================
// kvProfile (§3.5 cohort-normalisatie via R9.30-pragmatiek)
//
// Per-leeftijd-KV ankerprofiel. R9.30-conform (M2-E1=A keuze, combi-sessie):
//   - actieven (25 ≤ a < 65): pen · fractie · ä(65, r, g) · (1+r)^{-(65-a)}
//                              waar fractie = (a-25)/40 (normalisatie-benadering)
//   - gepensioneerden (a ≥ 65): pen · ä(min(a, 99), r, g)
//
// LET OP: dit is een R9.30-conforme schending van §3.6 aanname 1 (we
// projecteren deelnemer-pen over alle cohorten). Aanname 1 betreft het
// individuele hoofdpad (ppkBase per deelnemer); ν(N) is een tweede-orde
// correctie (<0,5%) waar deze pragmatiek aanvaardbaar is. Spec §3.5-formule
// heeft `kv̄_c` als gewicht — alternatief zou aanname-1-strict zijn (kv-factor
// weglaten), maar dat wijkt af van zowel formule als R9.30. v1: behouden.
// ============================================================================

export function kvProfile(
  age: number,
  pen: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  opts: { m: number; pi: number; f: number; omega: number; data: AG2024Data }
): number {
  if (age < 25) return 0
  if (age < 65) {
    const fractie = (age - 25) / 40
    const disc = Math.pow(1 + r, -(65 - age))
    return pen * fractie * annuity(65, r, t0, g, opts) * disc
  }
  return pen * annuity(Math.min(age, 99), r, t0, g, opts)
}

// ============================================================================
// DNB-normalisatiefactor ν(N) — §3.5 + §11.17 (cohort-gemengd via SSPF-prior)
//
//   s̄(x̄_c, N) = w_M^SSPF · s(x̄_c, N, M) + w_V^SSPF · s(x̄_c, N, V)
//   ν(N) = (Σ_c n_c · kv̄_c) / (Σ_c n_c · kv̄_c · s̄(x̄_c, N))
//
// Bij N=0 is geen normalisatie nodig (alle s ≡ 1, ν ≡ 1).
// ============================================================================

/** SSPF-deelnemer-genderweging voor s̄ (§11.17 v1-placeholder 95/5). */
export const SSPF_GENDER_WEGING_DEELNEMER = { M: 0.95, V: 0.05 } as const

export function dnbNormFactor(
  N: number,
  fractions: readonly number[],
  pen: number,
  r: number,
  t0: number,
  opts: { m: number; pi: number; f: number; omega: number; data: AG2024Data },
  sspfWeging: { M: number; V: number } = SSPF_GENDER_WEGING_DEELNEMER
): number {
  if (N <= 0) return 1

  let total = 0
  let weighted = 0
  const factorOpts = { f: opts.f, data: opts.data }

  for (let i = 0; i < 15; i++) {
    const midage = COHORT_MIDAGES[i]
    const kvBar = kvProfile(midage, pen, r, t0, 'gemengd', opts) // gemengd voor cohort-mid
    // s̄(x̄_c, N) — SSPF-gewogen gender-mix voor cohort-niveau
    const sM = dnbShareFactor(midage, N, t0, 'M', factorOpts)
    const sV = dnbShareFactor(midage, N, t0, 'V', factorOpts)
    const sBar = sspfWeging.M * sM + sspfWeging.V * sV

    total += fractions[i] * kvBar
    weighted += fractions[i] * kvBar * sBar
  }
  return weighted > 0 ? total / weighted : 1
}

// ============================================================================
// §3.5 v3.0 — Wet-canonieke spreidings-mechaniek (bijlage 2a Regeling Pw art. 2)
//
// Vervangt de R9.30-DNB-formule (sFactor·ν(N)) door de wettelijke standaardregel:
//
//   q(h, N) = min(floor(h)/N, 1)
//   KS_voor(i, h) = kasstroom-vector individu i op looptijd h
//   CW_voor(i)    = Σ_h KS_voor(i,h) · v(h)         = KV(i)         (per definitie M1)
//   CW_star(i)    = Σ_h q(h,N) · KS_voor(i,h) · v(h)                (M1: cw_star_op/np)
//
//   CW_voor_fonds = Σ_c n_c · CW_voor_c              (cohort-sommatie via proxy)
//   CW_star_fonds = Σ_c n_c · CW_star_c              (cohort-sommatie via proxy)
//   x_fonds       = (M − CW_voor_fonds) / CW_star_fonds
//
// Per individu (lineariteit):
//   ppk(i)   = KV(i)   + x_fonds · CW_star(i)
//   ppk_OP   = KV_OP   + x_fonds · cw_star_op
//   ppk_NP   = KV_NP   + x_fonds · cw_star_np
//
// SSPF-cohort-niveau gebruikt kvProfile als proxy-deelnemer per cohort-midage
// (M2-E1=A keuze blijft staan: actieven <65 / gepensheerden ≥65). cwStarProfile
// is de q-gewogen analogon. Beide gebruiken SSPF-genderweging voor cohort-mix
// (§11.17 v1.9-besluit, 95% M / 5% V).
// ============================================================================

/**
 * cwStarProfile — proxy-CW_star per cohort-midage (analoog aan kvProfile).
 *
 * Voor actieven (<65): aanspraak fractie · pen, ingaand bij 65, q gemeten vanaf
 * pensionering. Disconto vanaf nu (tijd 0). De annuityWithQ-aanroep met x=65
 * geeft Σ_k q(k/m, N) · ä(65)-stromen; we vermenigvuldigen met (1+r)^{-(65-a)}
 * om het naar nu te disconteren. Subtiel: q(h,N) wordt hier gemeten t.o.v.
 * pensioneringsmoment, niet t.o.v. nu — dat is conform wet-conventie waar h
 * de looptijd vanaf invaardatum is. We benaderen dit door h = (65-a) + h_pen
 * te projecteren; voor a=47 betekent dit dat alle pensioenstromen al onder
 * q=1 vallen onder N=10 (omdat 65-47=18 > 10). Voor a=62 zit de eerste
 * pensioenstroom op h=3, dus q=0.3 onder N=10.
 *
 * Voor gepensheerden (≥65): annuityWithQ direct, h gemeten vanaf nu.
 *
 * BEKEND TEKORTKOMING: voor actieven projecteren we q-gewicht naar pensionering
 * via discount-factor maar zonder voor-pensionering-overlevingskans. Dit is
 * R9.30-pragmatiek (zelfde als kvProfile). Bij M3-bouw kan dit verfijnd worden
 * met preretirement-survival; voor M2-only ν(N)-equivalent <0,5% impact.
 */
export function cwStarProfile(
  age: number,
  pen: number,
  r: number,
  t0: number,
  g: 'M' | 'V' | 'gemengd',
  N: number,
  opts: { m: number; pi: number; f: number; omega: number; data: AG2024Data }
): number {
  if (age < 25 || N <= 0) return 0
  if (age < 65) {
    // Actieve deelnemer: pensioneert op 65, kasstromen vanaf h_inv = 65-age jaar.
    // v3.0.37 BUG-FIX: q(h, N) wordt gemeten vanaf invaartijdstip (h_global =
    // t + shift met shift = 65-age), NIET gereset op pensioenmoment.
    // Dit is wettelijk consistent met Bijlage 2a Pw art. 2 en reproduceert
    // Hans-Haringa-modelresultaat (zie test_hans_replication.ts).
    //
    // Voorheen: annuityWithQ(65, N_eff = N - (65-age)) — dit reset q-trapezium
    // op leeftijd 65 ipv te continuïteren vanaf invaartijdstip. Voor jongeren
    // gaf dat te kleine cw_star, te hoge x_fonds, en te hoge opslag voor
    // pensioengerechtigden onder N=∞.
    const yearsToRetirement = 65 - age
    const fractie = (age - 25) / 40
    const disc = Math.pow(1 + r, -yearsToRetirement)
    return pen * fractie * annuityWithQShifted(65, r, t0, g, N, yearsToRetirement, opts) * disc
  }
  // Gepensheerde: h vanaf nu = h vanaf pensionering, geen shift nodig
  return pen * annuityWithQ(Math.min(age, 99), r, t0, g, N, opts)
}

/**
 * computeFondsXStar — wettelijke schalingsfactor x_fonds.
 *
 * Sommeert over cohorten via proxy-deelnemer (kvProfile, cwStarProfile met
 * SSPF-genderweging) om CW_voor_fonds en CW_star_fonds te berekenen, en
 * levert daaruit x_fonds = (M − CW_voor_fonds) / CW_star_fonds.
 *
 * Belangrijk: vpvTotal (= fondsvermogen / DG) is per definitie gelijk aan
 * de "echte" CW_voor_fonds; de cohort-sommatie levert een proxy-CW_voor_fonds
 * dat hier alleen gebruikt wordt om CW_star_fonds te schatten via de ratio
 * CW_star_proxy / CW_voor_proxy. Dit voorkomt dubbele-aanname-stapeling
 * (proxy-pen × demografie kan vpvTotal niet exact reproduceren omdat
 * SSPF-aanspraken niet uniform zijn).
 *
 * Returnt: { vpvTotal, M, x_star, cw_voor_proxy, cw_star_proxy, ratio }
 *   waarbij ratio = cw_star_proxy / cw_voor_proxy als fonds-karakteristiek R.
 */
export function computeFondsXStar(
  fondsvermogen_eur: number,
  vpvTotal: number,
  vpvAftrekPct: number,
  compensatiedepot_eur: number,
  buffer_eur: number,
  bijstort_eur: number,
  fractions: readonly number[],
  N_deelnemers: number,
  spreidingN: number,
  pen: number,
  r: number,
  t0: number,
  engineOpts: { m: number; pi: number; f: number; omega: number; data: AG2024Data },
  sspfWeging: { M: number; V: number } = SSPF_GENDER_WEGING_DEELNEMER
): {
  M: number
  x_star: number
  cw_voor_proxy: number
  cw_star_proxy: number
  ratio: number
} {
  // M = beschikbaar vermogen voor standaardregel = fondsvermogen − bestemmings-
  // reserveringen (model C bundle). Conform §3.5 v2.2.10 met v3.0-mapping:
  // de wet noemt dit "M" (art. 3 bijlage 2a); onze previous "verdeelbaar" was
  // M − vpvTotal. Hier aangehouden: M = beschikbaar voor heel-CW.
  const M =
    fondsvermogen_eur
    - vpvAftrekPct * vpvTotal
    - compensatiedepot_eur
    - buffer_eur
    + bijstort_eur

  // Cohort-sommatie via proxy-deelnemer (M2-E1=A keuze, R9.30-pragmatiek).
  // SSPF-genderweging op cohort-mix-niveau.
  //
  // v3.0.37: NP-component toegevoegd. Hans-Haringa-observatie 06-05-2026:
  // er wordt ÉÉN persoonlijk pensioenvermogen ingevaren, niet OP en NP apart.
  // De wettelijke fonds-noemer (vpvTotal) bevat al alle aanspraken inclusief
  // NP. Daarom moet ratio = cw_star/cw_voor ook OP+NP omvatten, anders
  // ontstaat dimensieconflict tussen teller (individu OP+NP) en noemer (fonds
  // OP-only). Aanname proxy-deelnemer: 100% gehuwd, partner 3j jonger, ander
  // geslacht, NP-aandeel 0,7 (typisch UPO; SSPF doet 70%). Geen partnerfractie
  // nodig — het gaat om de tijd-structuur van de fonds-CW, niet om het
  // partnerfractie-aantal.
  //
  // Performance: proxy gebruikt m=1 (jaarlijks ipv maandelijks). Verschil in
  // fonds-ratio is <0,1% maar reduceert de joint-life K² loop met factor 144.
  const NP_AANDEEL_PROXY = 0.7
  const PARTNER_LFTD_VERSCHIL = 3
  const proxyOpts = { ...engineOpts, m: 1 }
  const partnerOpts = { ...proxyOpts, deelnemerReedsOverleden: false }

  let cw_voor_proxy = 0
  let cw_star_proxy = 0
  for (let i = 0; i < 15; i++) {
    const midage = COHORT_MIDAGES[i]
    const nc = fractions[i] * N_deelnemers

    // OP-component, per gender (proxyOpts: m=1 voor snelheid)
    const kvM = kvProfile(midage, pen, r, t0, 'M', proxyOpts)
    const kvV = kvProfile(midage, pen, r, t0, 'V', proxyOpts)
    const cwsM = cwStarProfile(midage, pen, r, t0, 'M', spreidingN, proxyOpts)
    const cwsV = cwStarProfile(midage, pen, r, t0, 'V', spreidingN, proxyOpts)

    // NP-component via joint-life. Partner ander-geslacht, 3j jonger.
    // M-deelnemer → V-partner, V-deelnemer → M-partner.
    const xp = Math.max(25, midage - PARTNER_LFTD_VERSCHIL)
    // Voor proxy: pen=NP_AANDEEL · OP_pen (typisch UPO-ratio)
    const npPen = pen * NP_AANDEEL_PROXY
    const npM = npPen * jointLifeAnnuity(midage, xp, r, t0, 'M', 'V', partnerOpts)
    const npV = npPen * jointLifeAnnuity(midage, xp, r, t0, 'V', 'M', partnerOpts)
    const npStarM = npPen * jointLifeAnnuityWithQ(midage, xp, r, t0, 'M', 'V', spreidingN, partnerOpts)
    const npStarV = npPen * jointLifeAnnuityWithQ(midage, xp, r, t0, 'V', 'M', spreidingN, partnerOpts)

    // SSPF-gewogen cohort-niveau totalen (OP + NP)
    const kvBar = sspfWeging.M * (kvM + npM) + sspfWeging.V * (kvV + npV)
    const cwsBar = sspfWeging.M * (cwsM + npStarM) + sspfWeging.V * (cwsV + npStarV)

    cw_voor_proxy += nc * kvBar
    cw_star_proxy += nc * cwsBar
  }

  // Ratio R = CW_star_fonds / CW_voor_fonds — fonds-karakteristiek (zie chat
  // 05-05-2026: "fonds-karakteristiek per (preset, sterftetafel, N)").
  const ratio = cw_voor_proxy > 0 ? cw_star_proxy / cw_voor_proxy : 0

  // Wettelijke schalingsfactor: gebruik vpvTotal (= "echte" CW_voor_fonds via
  // dekkingsgraad-definitie) en CW_star_fonds geschat als ratio · vpvTotal.
  // Dit ontkoppelt de proxy-aanname van de absolute schaal en behoudt de
  // SSPF-data-anker-property dat vpvTotal exact is.
  const cw_star_fonds_estimated = ratio * vpvTotal
  const x_star =
    cw_star_fonds_estimated > 0 ? (M - vpvTotal) / cw_star_fonds_estimated : 0

  return { M, x_star, cw_voor_proxy, cw_star_proxy, ratio }
}

// ============================================================================
// CohortOutcomes — §3.4 deepdive-array
//
// Per-cohort aggregaten met sommatie-verifieerbaarheidshaken:
//   Σ_c surplusBijdrage_c = ppkSurplus_fonds-equivalent  (voor cross-check)
//   Σ_c compBijdrage_c = compensatiedepot                (bell-curve normalisatie)
//
// surplusBijdrage_c = (n_c · kv̄_c / vpvTotal) · surplus · s̄(x̄_c, N) · ν(N)
// compBijdrage_c    = compensatiedepot · (n_c · w(x̄_c)) / Σ_d (n_d · w(x̄_d))
// kvAvg_c           = kv̄_c (per cohort), null als n=0
// ============================================================================

export function computeCohortOutcomes(
  fractions: readonly number[],
  N_deelnemers: number,
  surplus: number,
  vpvTotal: number,
  spreidingN: number,
  compensatiedepot: number,
  compensatieMu: number,
  compensatieSigma: number,
  pen: number,
  r: number,
  t0: number,
  opts: { m: number; pi: number; f: number; omega: number; data: AG2024Data },
  nu: number,
  sspfWeging: { M: number; V: number } = SSPF_GENDER_WEGING_DEELNEMER
): CohortOutcome[] {
  const factorOpts = { f: opts.f, data: opts.data }

  // Pre-compute n_c · w(x̄_c) per cohort voor compBijdrage-normalisatie.
  // We gebruiken aantal-niveau (n_c · w(midage)) i.p.v. per-leeftijd-uniform-
  // verdeeld omdat per-cohort-aggregaat de juiste eenheid is voor cohortOutcomes.
  let bellTotalCohorts = 0
  const nWBell: number[] = []
  for (let i = 0; i < 15; i++) {
    const nc = fractions[i] * N_deelnemers
    const w = bellW(COHORT_MIDAGES[i], compensatieMu, compensatieSigma)
    const product = nc * w
    nWBell.push(product)
    bellTotalCohorts += product
  }

  const out: CohortOutcome[] = []
  for (let i = 0; i < 15; i++) {
    const midage = COHORT_MIDAGES[i]
    const nc = fractions[i] * N_deelnemers
    const kvBar = kvProfile(midage, pen, r, t0, 'gemengd', opts)

    // surplusBijdrage: cohort-aandeel via spreidings + normalisatie
    let surplusBijdrage = 0
    if (surplus > 0 && vpvTotal > 0) {
      const sM = dnbShareFactor(midage, spreidingN, t0, 'M', factorOpts)
      const sV = dnbShareFactor(midage, spreidingN, t0, 'V', factorOpts)
      const sBar = sspfWeging.M * sM + sspfWeging.V * sV
      // n_c · kv̄_c / vpvTotal · surplus · sBar · ν geeft fonds-totaal aandeel cohort
      surplusBijdrage = (nc * kvBar / vpvTotal) * surplus * sBar * nu
    }

    // compBijdrage: cohort-aandeel via bell-curve
    const compBijdrage =
      bellTotalCohorts > 0
        ? compensatiedepot * (nWBell[i] / bellTotalCohorts)
        : 0

    out.push({
      range: COHORT_LABELS[i],
      midage,
      n: Math.round(nc),
      kvAvg: nc > 0 ? kvBar : null,
      surplusBijdrage,
      compBijdrage,
    })
  }
  return out
}

// ============================================================================
// M2-hoofdberekening v2.x R9.30 — DEPRECATED, behouden voor regressie (Knelpunt G)
//
// Deze functie implementeert de R9.30-DNB-formule (sFactor·ν(N)) zoals tot v2.2.13
// gebruikt. De wettelijke standaardregel (bijlage 2a Regeling Pw art. 2) heeft
// een fundamenteel andere structuur — zie computeM2 (v3.0) als productie-pad.
// LEGACY blijft voor regressie-vergelijking tegen oude ankers (M1 € 808.815,
// M2 € 852.481 onder v1.3-bovengrens; M1 € 543.096, M2 € 572.166 onder v2.2.11).
// Niet aanroepen in productie-pad; gemarkeerd voor v3.0 audit-only-gebruik.
// ============================================================================

export function computeM2_R930_LEGACY(
  deelnemer: M1Deelnemer,
  ketenInput: M2KetenInput,
  params: M2Parameterset
): M2Output {
  const data = getAG2024()

  if (params.fondsvermogen === null) {
    throw new Error('§3.3/§3.8 — fondsvermogen mag in M2 niet null zijn')
  }
  // EENHEID-CONVERSIE: §3.3-tabel zegt "in mln euro" voor fondsvermogen,
  // compensatiedepot, buffer, bijstort. M1-output KV is in euro. Voor
  // consistente uitkomst (ppk in euro per persoon) converteren we mln€→€
  // bij engine-entry (× 1e6). Output is dan dimensieloos consistent met M1.
  const fondsvermogen = params.fondsvermogen * 1e6
  const compensatiedepotEur = params.compensatiedepot * 1e6
  const bufferEur = params.buffer * 1e6
  const bijstortEur = params.bijstort * 1e6

  // §3.5 Fondsbalans-decompositie (v2.2.10 Model C) — alle in euro.
  // v3.0.94: vpvTotal komt nu uit params.vpvTotal (anker), niet meer afgeleid
  // uit fondsvermogen/dekkingsgraad. Fallback naar F/DG bij vpvTotal=0 voor
  // backward-compat met v3.0.93-fixtures (smoke.test, etc).
  const vpvTotal = params.vpvTotal > 0
    ? params.vpvTotal * 1e6
    : fondsvermogen / params.dekkingsgraad
  const verdeelbaar =
    fondsvermogen
    - params.vpvAftrekPct * vpvTotal
    - compensatiedepotEur
    - bufferEur
    + bijstortEur

  // §3.5 baseRatio + surplus
  const baseRatio = vpvTotal > 0 ? Math.min(1, verdeelbaar / vpvTotal) : 0
  const surplus = Math.max(0, verdeelbaar - vpvTotal)

  // KV-decompositie uit M1 (via M2KetenInput)
  const KV = ketenInput.KV
  const KV_OP = ketenInput.KV_OP
  const KV_NP = ketenInput.KV_NP

  // Engine-opts voor annuïteiten en sterftekansen
  const engineOpts = {
    m: params.m,
    pi: params.pi,
    f: params.ervaringsSterfte,
    omega: params.omega,
    data,
  }
  const factorOpts = { f: params.ervaringsSterfte, data }

  // sFactor(x₀, g) — deelnemer, gender-specifiek
  const sFactor_x0 = dnbShareFactor(
    deelnemer.x0,
    params.spreidingN,
    params.t0,
    deelnemer.g,
    factorOpts
  )

  // sFactor(x_p, g_y) — partner, gender-specifiek; null als geen partner
  const heeftPartner = deelnemer.heeftPartner && deelnemer.x_partner !== null
  const sFactor_partner = heeftPartner
    ? dnbShareFactor(
        deelnemer.x_partner as number,
        params.spreidingN,
        params.t0,
        deelnemer.g_y,
        factorOpts
      )
    : 0

  // Demografie & cohort-normalisatie ν(N)
  const fractions = getCohortFractions(params.demografie)
  const nu = dnbNormFactor(
    params.spreidingN,
    fractions,
    deelnemer.pen,
    params.r,
    params.t0,
    engineOpts
  )

  // Bell-curve gemiddelde + relatief gewicht voor deelnemer
  const wAvg = wAverage(params.compensatieMu, params.compensatieSigma, fractions)
  const wRel = wRelative(deelnemer.x0, params.compensatieMu, params.compensatieSigma, wAvg)

  // §3.5 ppkBase
  const ppkBase = KV * baseRatio

  // §3.5 ppkSurplus — bottom-up som (v2.1.1 definitie)
  const ppk_OP_surplus =
    vpvTotal > 0
      ? (KV_OP / vpvTotal) * surplus * sFactor_x0 * nu
      : 0
  const ppk_NP_surplus =
    heeftPartner && vpvTotal > 0
      ? (KV_NP / vpvTotal) * surplus * sFactor_partner * nu
      : 0
  const ppkSurplus = ppk_OP_surplus + ppk_NP_surplus

  // §3.5 ppkComp — alleen deelnemer; volledig aan OP (§3.6 aanname 11)
  const ppkComp =
    params.N_deelnemers > 0
      ? (compensatiedepotEur / params.N_deelnemers) * wRel
      : 0

  // §3.5 ppkTotal
  const ppkTotal = ppkBase + ppkSurplus + ppkComp

  // §3.5 OP/NP-decompositie (v2.1.1 sluitingscontrole exact)
  const fractie_OP = KV > 0 ? KV_OP / KV : 0
  const fractie_NP = KV > 0 ? KV_NP / KV : 0
  const ppk_OP = ppkBase * fractie_OP + ppk_OP_surplus + ppkComp
  const ppk_NP = ppkBase * fractie_NP + ppk_NP_surplus // geen NP-comp

  // §3.4 buffer-aandeel (M2→M3-input) — in euro
  const bufferAandeel =
    vpvTotal > 0 ? bufferEur * (KV / vpvTotal) : 0

  // §3.4 cohortOutcomes — deepdive-array; bedragen in euro
  const cohortOutcomes = computeCohortOutcomes(
    fractions,
    params.N_deelnemers,
    surplus,
    vpvTotal,
    params.spreidingN,
    compensatiedepotEur,
    params.compensatieMu,
    params.compensatieSigma,
    deelnemer.pen,
    params.r,
    params.t0,
    engineOpts,
    nu
  )

  // §11.12 phiDerived — null in standalone-modus (geen V_x^Wtp uit M4)
  const phiDerived = null

  return {
    ppkBase,
    ppkSurplus,
    ppkComp,
    ppkTotal,
    ppk_OP,
    ppk_NP,
    bufferAandeel,
    cohortOutcomes,
    vpvTotal,
    verdeelbaar,
    phiDerived,
  }
}

// ============================================================================
// M2-hoofdberekening v3.0 — wet-canonieke standaardregel (bijlage 2a Regeling Pw)
//
// Implementeert de wettelijke formule:
//   ppk(i) = KV(i) + x_fonds · CW_star(i) + ppkComp(i)
// waarbij:
//   - KV(i) en CW_star(i) per individu uit M1 (cw_star vereist m2Context-aanroep)
//   - x_fonds via computeFondsXStar (cohort-sommatie + fondsbalans)
//   - ppkComp via bell-curve over compensatiedepot, volledig naar OP (§3.6 a.11)
//
// OP/NP-decompositie via lineariteit:
//   ppk_OP = KV_OP + x_fonds · cw_star_op + ppkComp     (alle compensatie naar OP)
//   ppk_NP = KV_NP + x_fonds · cw_star_np
//   som    = KV + x*·(cw_star_op + cw_star_np) + ppkComp = ppkTotal  (exact)
//
// Output-velden behouden v2.x-namen voor backward-compat in UI/SCHEMA:
//   ppkBase    = KV   (CW_voor; "het deel zonder fonds-overschot")
//   ppkSurplus = x_fonds · (cw_star_op + cw_star_np)  (individueel surplus-aandeel)
//   ppkComp    = compensatiedepot via bell-curve
//   ppkTotal   = ppkBase + ppkSurplus + ppkComp
// ============================================================================

export function computeM2(
  deelnemer: M1Deelnemer,
  ketenInput: M2KetenInput,
  params: M2Parameterset
): M2Output {
  const data = getAG2024()

  if (params.fondsvermogen === null) {
    throw new Error('§3.3/§3.8 — fondsvermogen mag in M2 niet null zijn')
  }
  // EENHEID-CONVERSIE: §3.3-tabel zegt "in mln euro" voor fondsvermogen,
  // compensatiedepot, buffer, bijstort. M1-output KV is in euro. Voor
  // consistente uitkomst (ppk in euro per persoon) converteren we mln€→€
  // bij engine-entry (× 1e6). Output is dan dimensieloos consistent met M1.
  const fondsvermogen = params.fondsvermogen * 1e6
  const compensatiedepotEur = params.compensatiedepot * 1e6
  const bufferEur = params.buffer * 1e6
  const bijstortEur = params.bijstort * 1e6

  // §3.5 fondsbalans-decompositie (Model C bundle, v2.2.10 ongewijzigd)
  // v3.0.94: vpvTotal als fonds-anker uit params (zie computeM2_R930_LEGACY).
  const vpvTotal = params.vpvTotal > 0
    ? params.vpvTotal * 1e6
    : fondsvermogen / params.dekkingsgraad

  // KV-decompositie + cw_star uit M1 (via M2KetenInput, v3.0 verplicht)
  const KV = ketenInput.KV
  const KV_OP = ketenInput.KV_OP
  const KV_NP = ketenInput.KV_NP
  const cw_star_op = ketenInput.cw_star_op
  const cw_star_np = ketenInput.cw_star_np

  const engineOpts = {
    m: params.m,
    pi: params.pi,
    f: params.ervaringsSterfte,
    omega: params.omega,
    data,
  }

  // Demografie + fondsschalingsfactor x* (wet-canoniek, art. 3 bijlage 2a)
  const fractions = getCohortFractions(params.demografie)
  const fondsX = computeFondsXStar(
    fondsvermogen,
    vpvTotal,
    params.vpvAftrekPct,
    compensatiedepotEur,
    bufferEur,
    bijstortEur,
    fractions,
    params.N_deelnemers,
    params.spreidingN,
    deelnemer.pen,
    params.r,
    params.t0,
    engineOpts
  )
  const x_fonds = fondsX.x_star
  const M_beschikbaar = fondsX.M

  // ppkBase = KV (CW_voor); "verdeelbaar" voor backward-compat: M − vpvTotal
  // (= surplus_euros onder DG>1; negatief onder tekort)
  const verdeelbaar = M_beschikbaar - vpvTotal

  // Individueel surplus-aandeel (lineariteit): x_fonds · (cw_star_op + cw_star_np)
  const ppkSurplus_OP = x_fonds * cw_star_op
  const ppkSurplus_NP = x_fonds * cw_star_np
  const ppkSurplus = ppkSurplus_OP + ppkSurplus_NP

  // ppkComp — onveranderd t.o.v. v2.x (bell-curve, deelnemer-only naar OP)
  const wAvg = wAverage(params.compensatieMu, params.compensatieSigma, fractions)
  const wRel = wRelative(deelnemer.x0, params.compensatieMu, params.compensatieSigma, wAvg)
  const ppkComp =
    params.N_deelnemers > 0
      ? (compensatiedepotEur / params.N_deelnemers) * wRel
      : 0

  // ppkBase = KV (per definitie wet-canoniek; was KV·baseRatio onder R9.30)
  const ppkBase = KV
  const ppkTotal = ppkBase + ppkSurplus + ppkComp

  // OP/NP-decompositie via lineariteit
  const ppk_OP = KV_OP + ppkSurplus_OP + ppkComp
  const ppk_NP = KV_NP + ppkSurplus_NP

  // §3.4 buffer-aandeel (M2→M3-input) — in euro, ongewijzigd
  const heeftPartner = deelnemer.heeftPartner && deelnemer.x_partner !== null
  const bufferAandeel =
    vpvTotal > 0 ? bufferEur * (KV / vpvTotal) : 0

  // §3.4 cohortOutcomes v3.0 — surplusBijdrage_c via x_fonds en cohort-CW_star
  const cohortOutcomes = computeCohortOutcomes_v3(
    fractions,
    params.N_deelnemers,
    x_fonds,
    params.spreidingN,
    compensatiedepotEur,
    params.compensatieMu,
    params.compensatieSigma,
    deelnemer.pen,
    params.r,
    params.t0,
    engineOpts
  )

  // §11.12 phiDerived — null in standalone-modus (geen V_x^Wtp uit M4)
  const phiDerived = null

  return {
    ppkBase,
    ppkSurplus,
    ppkComp,
    ppkTotal,
    ppk_OP,
    ppk_NP,
    bufferAandeel,
    cohortOutcomes,
    vpvTotal,
    verdeelbaar,
    phiDerived,
  }
}

/**
 * computeCohortOutcomes_v3 — wet-canonieke versie.
 *
 * Per cohort:
 *   surplusBijdrage_c = x_fonds · (n_c · cwStar_proxy_c)  in euro fonds-totaal
 *   compBijdrage_c    = compensatiedepot · (n_c · w(midage)) / Σ_d (n_d · w_d)
 *   kvAvg_c           = kv̄_c (proxy via kvProfile, SSPF-genderweging)
 *
 * Sommatie-verifieerbaarheid: Σ_c surplusBijdrage_c = x_fonds · cw_star_proxy_fonds
 * ≈ surplus_euros (bij M=DG·CW_voor, vpvTotal-gecalibreerd via ratio R).
 */
export function computeCohortOutcomes_v3(
  fractions: readonly number[],
  N_deelnemers: number,
  x_fonds: number,
  spreidingN: number,
  compensatiedepot_eur: number,
  compensatieMu: number,
  compensatieSigma: number,
  pen: number,
  r: number,
  t0: number,
  opts: { m: number; pi: number; f: number; omega: number; data: AG2024Data },
  sspfWeging: { M: number; V: number } = SSPF_GENDER_WEGING_DEELNEMER
): CohortOutcome[] {
  // Bell-curve-totaal voor compensatie-normalisatie
  let bellTotalCohorts = 0
  const nWBell: number[] = []
  for (let i = 0; i < 15; i++) {
    const nc = fractions[i] * N_deelnemers
    const w = bellW(COHORT_MIDAGES[i], compensatieMu, compensatieSigma)
    const product = nc * w
    nWBell.push(product)
    bellTotalCohorts += product
  }

  const out: CohortOutcome[] = []
  for (let i = 0; i < 15; i++) {
    const midage = COHORT_MIDAGES[i]
    const nc = fractions[i] * N_deelnemers

    // SSPF-gewogen kvBar voor kvAvg-rapportage
    const kvM = kvProfile(midage, pen, r, t0, 'M', opts)
    const kvV = kvProfile(midage, pen, r, t0, 'V', opts)
    const kvBar = sspfWeging.M * kvM + sspfWeging.V * kvV

    // SSPF-gewogen cwStarBar voor surplusBijdrage
    const cwsM = cwStarProfile(midage, pen, r, t0, 'M', spreidingN, opts)
    const cwsV = cwStarProfile(midage, pen, r, t0, 'V', spreidingN, opts)
    const cwsBar = sspfWeging.M * cwsM + sspfWeging.V * cwsV

    const surplusBijdrage = x_fonds * (nc * cwsBar)
    const compBijdrage =
      bellTotalCohorts > 0
        ? compensatiedepot_eur * (nWBell[i] / bellTotalCohorts)
        : 0

    out.push({
      range: COHORT_LABELS[i],
      midage,
      n: Math.round(nc),
      kvAvg: nc > 0 ? kvBar : null,
      surplusBijdrage,
      compBijdrage,
    })
  }
  return out
}
