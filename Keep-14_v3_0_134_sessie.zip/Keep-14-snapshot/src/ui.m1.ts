/**
 * UI-renderer voor scherm 1 (casual) + audit-scherm M1-sectie.
 *
 * Model D conform HANDOFF_SCHEMA_M1:
 *   - Casual scherm 1: alleen `display: 'hoofdpad'` velden
 *   - Audit-scherm M1-sectie: decompositie + deepdive + parameter-audit + diagnose
 *
 * Renderer leest uit FIELD_REGISTRY; geen hardcoded veld-lijsten.
 */

import { z } from 'zod'
import {
  M1,
  FIELD_REGISTRY,
  fieldsByDisplay,
  fieldsWithDisclosure,
  type FieldMeta,
} from './schema.v2'
import {
  type FieldInfo,
  escapeHtml,
  renderInputField,
} from './ui.shared'
import { computeM1 } from './engine.m1'
import { SSPF_M1_PLACEHOLDER } from './fondsdataset'
import type { M1Deelnemer, M1Parameterset, M1Output } from './schema.v2'

// ============================================================================
// Labels — casual gebruikers-vriendelijke tekst
// ============================================================================

const DEELNEMER_LABELS: Record<string, string> = {
  x0: 'Uw leeftijd',
  pen: 'Jaarlijks bruto ouderdomspensioen (€)',
  g: 'Uw geslacht',
  heeftPartner: 'Heeft u een partnerpensioen?',
  y0: 'Jaarlijks bruto nabestaandenpensioen (€)',
  x_partner: 'Leeftijd partner',
  g_y: 'Geslacht partner',
}

const OUTPUT_LABELS: Record<string, string> = {
  KV: 'Huidige waarde van uw aanspraak',
  KV_OP: 'waarvan eigen ouderdomspensioen',
  KV_NP: 'waarvan nabestaandenpensioen',
  a_x0: 'Annuïteitsfactor deelnemer ä(x₀, r)',
  a_partner: 'Annuïteitsfactor partner ä(x_partner, r)',
  lifeExp_x0: 'Verwachte sterfleeftijd deelnemer',
  lifeExp_partner: 'Verwachte sterfleeftijd partner',
  rho_effectief: 'Effectieve kostenopslag ρ',
}

const PARAM_LABELS: Record<string, string> = {
  r: 'Rekenrente',
  sterftekansTabelId: 'Sterftekans-tabel',
  t0: 'Projectiejaar AG2024',
  ervaringsSterfte: 'Ervaringssterfte f',
  m: 'Betalingsfrequentie',
  annuiteitsconventie: 'Annuïteitsconventie',
  pi: 'Indexatie π (waardering)',
  fondsvermogen: 'Fondsvermogen (mln €)',
  uitvoeringskostenJaarlijks: 'Uitvoeringskosten/jaar (mln €)',
  kostenOpslagPct: 'Kostenopslag ρ (direct)',
  omega: 'Eindleeftijd ω',
}

// ============================================================================
// Type-inspectie van Zod-schemas
// ============================================================================

function unwrap(schema: z.ZodTypeAny): z.ZodTypeAny {
  let inner: z.ZodTypeAny = schema
  while (
    inner instanceof z.ZodOptional ||
    inner instanceof z.ZodDefault ||
    inner instanceof z.ZodNullable
  ) {
    inner = inner._def.innerType
  }
  return inner
}

function describeType(schema: z.ZodTypeAny): string {
  const inner = unwrap(schema)
  if (inner instanceof z.ZodNumber) return 'getal'
  if (inner instanceof z.ZodBoolean) return 'ja/nee'
  if (inner instanceof z.ZodString) return 'tekst'
  if (inner instanceof z.ZodEnum) return inner._def.values.join(' | ')
  if (inner instanceof z.ZodLiteral) return String(inner._def.value)
  if (inner instanceof z.ZodUnion) {
    return inner._def.options.map((o: z.ZodTypeAny) => describeType(o)).join(' | ')
  }
  return 'onbekend'
}

function getDefault(schema: z.ZodTypeAny): unknown {
  let inner: z.ZodTypeAny = schema
  while (inner instanceof z.ZodOptional || inner instanceof z.ZodNullable) {
    inner = inner._def.innerType
  }
  if (inner instanceof z.ZodDefault) {
    const def = inner._def.defaultValue
    return typeof def === 'function' ? def() : def
  }
  return undefined
}

function isNullable(schema: z.ZodTypeAny): boolean {
  let inner: z.ZodTypeAny = schema
  while (inner instanceof z.ZodOptional || inner instanceof z.ZodDefault) {
    inner = inner._def.innerType
  }
  return inner instanceof z.ZodNullable
}

function collectFields(
  zodObj: z.ZodTypeAny,
  pathPrefix: string
): FieldInfo[] {
  const obj =
    zodObj instanceof z.ZodEffects ? zodObj.innerType() : zodObj
  if (!(obj instanceof z.ZodObject)) return []
  const shape = obj.shape
  const out: FieldInfo[] = []
  for (const [name, fieldSchema] of Object.entries(shape)) {
    const fullPath = `${pathPrefix}.${name}`
    const reg = FIELD_REGISTRY.find((f) => f.path === fullPath)
    if (!reg) continue
    out.push({
      name,
      path: fullPath,
      meta: reg.meta,
      typeLabel: describeType(fieldSchema as z.ZodTypeAny),
      default: getDefault(fieldSchema as z.ZodTypeAny),
      nullable: isNullable(fieldSchema as z.ZodTypeAny),
    })
  }
  return out
}

// ============================================================================
// State-management (in-memory, geen storage)
// ============================================================================

interface AppState {
  deelnemer: {
    x0: number
    pen: number
    g: 'M' | 'V' | 'gemengd'
    heeftPartner: boolean
    y0: number | null
    x_partner: number | null
    g_y: 'M' | 'V' | 'gemengd'
  }
  parameters: M1Parameterset
  view: 'casual' | 'audit'
  lastOutput?: M1Output
  lastError?: string
}

const state: AppState = {
  deelnemer: {
    x0: 67,
    pen: 30000,
    g: 'M',
    heeftPartner: true,
    y0: 21000,
    x_partner: 65,
    g_y: 'V',
  },
  parameters: { ...SSPF_M1_PLACEHOLDER },
  view: 'casual',
}

// ============================================================================
// Render helpers
// ============================================================================

function euro(n: number, decimals = 0): string {
  return '€ ' + n.toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

function num(n: number | null, decimals = 2): string {
  if (n === null || !Number.isFinite(n)) return '—'
  return n.toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

function pct(n: number, decimals = 2): string {
  return (n * 100).toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }) + '%'
}

// ============================================================================
// Input-renderer (deelnemer, casual) — wrapper rond gedeelde renderer
// v3.0.2: implementatie verhuisd naar src/ui.shared.ts; deze wrapper geeft
// module-state (deelnemer + labels) door als parameter.
// ============================================================================

function renderField(f: FieldInfo): string {
  return renderInputField(f, state.deelnemer, DEELNEMER_LABELS)
}

// ============================================================================
// Casual scherm 1
// ============================================================================

function renderCasual(): string {
  const deelnemerFields = collectFields(M1.deelnemer, 'M1.deelnemer')
  const casualInputs = deelnemerFields
    .filter((f) => f.meta.display === 'hoofdpad')
    .map(renderField)
    .join('\n')

  let output = ''
  if (state.lastError) {
    output = `<div class="error">Fout bij berekening: ${escapeHtml(state.lastError)}</div>`
  } else if (state.lastOutput) {
    const o = state.lastOutput
    output = `
      <div class="kpi-card">
        <div class="kpi-label">Huidige waarde van uw pensioenaanspraak</div>
        <div class="kpi-value">${euro(o.KV)}</div>
        ${o.KV_NP > 0 ? `<div class="kpi-breakdown">
          Eigen ouderdomspensioen: ${euro(o.KV_OP)}<br>
          Partnerpensioen: ${euro(o.KV_NP)}
        </div>` : ''}
      </div>
      <div class="meta-note">
        Verwachte sterfleeftijd: ${num(o.lifeExp_x0, 1)} jaar.
        ${o.lifeExp_partner !== null ? `Partner: ${num(o.lifeExp_partner, 1)} jaar.` : ''}
        Rekenrente ${pct(state.parameters.r)}.
      </div>
    `
  }

  return `
    <div class="pane casual">
      <h2>Wat is uw pensioen nu waard?</h2>
      <p class="intro">Vul uw gegevens van het UPO in. De calculator berekent de huidige kapitaalwaarde van uw aanspraak.</p>

      <div class="form">
        ${casualInputs}
      </div>

      <div class="rente-control">
        <label for="in-r">Rekenrente (experimenteer met dit getal): ${pct(state.parameters.r)}</label>
        <input type="range" id="in-r" min="-1" max="6" step="0.1" value="${(state.parameters.r * 100).toFixed(1)}">
      </div>

      <div class="output">
        ${output}
      </div>
    </div>
  `
}

// ============================================================================
// Audit-scherm M1-sectie
// ============================================================================

function renderOutputRow(
  name: string,
  value: unknown,
  meta: FieldMeta
): string {
  const label = OUTPUT_LABELS[name] ?? name
  let formatted: string
  if (typeof value === 'number') {
    formatted = name.startsWith('KV') ? euro(value) : num(value, name.startsWith('lifeExp') ? 2 : 3)
  } else if (value === null) {
    formatted = '—'
  } else {
    formatted = String(value)
  }
  const disclosureMark = meta.uiDisclosure
    ? ` <span class="info" title="${escapeHtml(meta.uiDisclosure)}">ⓘ</span>`
    : ''
  const spec = `<span class="specref">${escapeHtml(meta.specRef)}</span>`
  return `<tr class="display-${meta.display}"><td>${label}${disclosureMark}</td><td class="num">${formatted}</td><td>${spec}</td></tr>`
}

function renderAudit(): string {
  const outputFields = collectFields(M1.output, 'M1.output')
  const parametersetFields = collectFields(M1.parameterset, 'M1.parameterset')
  const disclosureFields = fieldsWithDisclosure().filter((f) => f.meta.module === 'M1')

  if (!state.lastOutput) {
    return `<div class="pane audit"><p>Geen berekeningsresultaat beschikbaar.</p></div>`
  }

  const o = state.lastOutput as Record<string, unknown>

  const decompositionRows = outputFields
    .filter((f) => ['decompositie', 'deepdive', 'diagnose'].includes(f.meta.display))
    .map((f) => renderOutputRow(f.name, o[f.name], f.meta))
    .join('\n')

  const parameterRows = parametersetFields
    .map((f) => {
      const current = (state.parameters as Record<string, unknown>)[f.name]
      const displayVal = current === null ? '(niet gezet)' : String(current)
      const disclosure = f.meta.uiDisclosure
        ? `<div class="disclosure-inline">⚠ ${escapeHtml(f.meta.uiDisclosure)}</div>`
        : ''
      return `<tr>
        <td><code>${PARAM_LABELS[f.name] ?? f.name}</code></td>
        <td>${escapeHtml(f.typeLabel)}</td>
        <td class="num">${escapeHtml(displayVal)}</td>
        <td><span class="specref">${escapeHtml(f.meta.specRef)}</span></td>
        <td>${disclosure || ''}</td>
      </tr>`
    })
    .join('\n')

  const disclosureList = disclosureFields
    .map((f) => `<li><code>${f.path}</code> — ${escapeHtml(f.meta.uiDisclosure || '')}</li>`)
    .join('\n')

  return `
    <div class="pane audit">
      <h2>Audit-scherm — Module 1 (huidige waarde)</h2>

      <h3>Decompositie, deepdive en diagnose (output-contract §2.4)</h3>
      <table>
        <thead><tr><th>Grootheid</th><th class="num">Waarde</th><th>Spec</th></tr></thead>
        <tbody>${decompositionRows}</tbody>
      </table>

      <h3>Parameterset (§2.3 + §2.7)</h3>
      <table>
        <thead><tr><th>Parameter</th><th>Type</th><th class="num">Waarde</th><th>Spec</th><th>Noot</th></tr></thead>
        <tbody>${parameterRows}</tbody>
      </table>

      <h3>UI-disclosure-eisen (spec-verankerd)</h3>
      <ul class="disclosure-list">
        ${disclosureList}
      </ul>

      <div class="meta-note">
        Rij-kleuren: <span style="background:#fafafa;padding:2px 6px">decompositie</span>
        <span style="background:#f2f2f2;padding:2px 6px;color:#666">deepdive</span>
        <span style="background:#fff0f0;padding:2px 6px;color:#884444">diagnose</span>.
        Gegenereerd uit SCHEMA v2.0 M1-block metadata (${FIELD_REGISTRY.filter(f => f.meta.module === 'M1').length} M1-velden geregistreerd).
      </div>
    </div>
  `
}

// ============================================================================
// Main render + event handling
// ============================================================================

function recompute(): void {
  try {
    const parsedDeelnemer = M1.deelnemer.parse(state.deelnemer)
    const parsedParams = M1.parameterset.parse(state.parameters)
    state.lastOutput = computeM1(parsedDeelnemer, parsedParams)
    state.lastError = undefined
  } catch (err) {
    state.lastError = err instanceof Error ? err.message : String(err)
    state.lastOutput = undefined
  }
}

/**
 * Bouw alleen het output-HTML (KPI-card) op basis van state.lastOutput.
 * Voor snelle updates bij input-wijzigingen zonder de hele DOM te herbouwen.
 */
function renderOutputOnly(): string {
  if (state.lastError) {
    return `<div class="error">Fout bij berekening: ${escapeHtml(state.lastError)}</div>`
  }
  if (!state.lastOutput) return ''
  const o = state.lastOutput
  return `
    <div class="kpi-card">
      <div class="kpi-label">Huidige waarde van uw pensioenaanspraak</div>
      <div class="kpi-value">${euro(o.KV)}</div>
      ${o.KV_NP > 0 ? `<div class="kpi-breakdown">
        Eigen ouderdomspensioen: ${euro(o.KV_OP)}<br>
        Partnerpensioen: ${euro(o.KV_NP)}
      </div>` : ''}
    </div>
    <div class="meta-note">
      Verwachte sterfleeftijd: ${num(o.lifeExp_x0, 1)} jaar.
      ${o.lifeExp_partner !== null ? `Partner: ${num(o.lifeExp_partner, 1)} jaar.` : ''}
      Rekenrente ${pct(state.parameters.r)}.
    </div>
  `
}

/**
 * Update alleen de .output-container in-place. Geen veld-rebind,
 * geen DOM-restructuring. Voor live-input-reactie.
 */
function updateOutputInPlace(): void {
  const outputEl = document.querySelector('.output')
  if (outputEl) {
    outputEl.innerHTML = renderOutputOnly()
  }
  // Update rente-slider-label ook
  const renteLabel = document.querySelector('.rente-control label')
  if (renteLabel) {
    renteLabel.textContent = `Rekenrente (experimenteer met dit getal): ${pct(state.parameters.r)}`
  }
}

/**
 * Toggle visibility van partner-velden zonder volledige re-render.
 */
function updatePartnerVisibility(): void {
  const partnerFields = ['y0', 'x_partner', 'g_y']
  for (const name of partnerFields) {
    const row = document.querySelector(`[data-field-row="${name}"]`) as HTMLElement | null
    if (row) {
      row.style.display = state.deelnemer.heeftPartner ? '' : 'none'
    }
  }
}

/**
 * Korte "flash"-animatie op KV-waarde bij Enter of blur-bevestiging.
 * Geeft visuele feedback dat de input geaccepteerd is.
 */
function flashKPI(): void {
  const card = document.querySelector('.kpi-card') as HTMLElement | null
  if (!card) return
  // Restart animatie: class verwijderen, forceer reflow, class toevoegen
  card.classList.remove('flash')
  void card.offsetWidth  // trigger reflow
  card.classList.add('flash')
}

function render(): void {
  const app = document.getElementById('app')
  if (!app) return

  const toggle = `
    <div class="view-toggle">
      <button class="${state.view === 'casual' ? 'active' : ''}" data-view="casual">
        Scherm 1 (eenvoudig)
      </button>
      <button class="${state.view === 'audit' ? 'active' : ''}" data-view="audit">
        Audit-scherm (voor professionals)
      </button>
    </div>
  `

  app.innerHTML = toggle + (state.view === 'casual' ? renderCasual() : renderAudit())
  attachHandlers()
}

// Debounce helper
function debounce<F extends (...args: never[]) => void>(fn: F, ms: number): F {
  let t: ReturnType<typeof setTimeout> | null = null
  return ((...args: Parameters<F>) => {
    if (t) clearTimeout(t)
    t = setTimeout(() => fn(...args), ms)
  }) as F
}

function attachHandlers(): void {
  document.querySelectorAll('[data-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.view = (btn as HTMLElement).dataset.view as 'casual' | 'audit'
      render()
    })
  })

  // Debounced recompute voor typ-intensieve velden (pen, y0, x_partner numerics)
  let debouncePending: ReturnType<typeof setTimeout> | null = null
  const scheduleRecompute = () => {
    if (debouncePending) clearTimeout(debouncePending)
    debouncePending = setTimeout(() => {
      debouncePending = null
      recompute()
      updateOutputInPlace()
    }, 150)
  }
  const immediateRecompute = () => {
    if (debouncePending) {
      clearTimeout(debouncePending)
      debouncePending = null
    }
    recompute()
    updateOutputInPlace()
    flashKPI()
  }

  document.querySelectorAll('[data-field]').forEach((el) => {
    el.addEventListener('input', (e) => {
      const target = e.target as HTMLInputElement | HTMLSelectElement
      const field = target.dataset.field as keyof AppState['deelnemer']
      const raw = target instanceof HTMLInputElement && target.type === 'checkbox'
        ? target.checked
        : target.value
      let val: unknown = raw
      if (typeof raw === 'string' && target instanceof HTMLInputElement && target.type === 'number') {
        val = raw === '' ? null : Number(raw)
      }
      ;(state.deelnemer as Record<string, unknown>)[field] = val

      // Partner-toggle: onmiddellijk DOM-visibility bijwerken
      if (field === 'heeftPartner') {
        updatePartnerVisibility()
        recompute()
        updateOutputInPlace()
        return
      }

      // Selects (gender, g_y) reageren direct; numerics gaan via debounce
      if (target instanceof HTMLSelectElement) {
        recompute()
        updateOutputInPlace()
        return
      }

      scheduleRecompute()
    })

    // Enter op numerieke input: doorbreek debounce + KV-flash bevestiging
    el.addEventListener('keydown', (e) => {
      const ke = e as KeyboardEvent
      if (ke.key === 'Enter') {
        ke.preventDefault()  // geen form-submit
        immediateRecompute()
      }
    })

    // Blur op numerieke input: ook bevestigen (tab-weg of klik buiten)
    el.addEventListener('blur', () => {
      if (debouncePending) {
        immediateRecompute()
      }
    })
  })

  const renteSlider = document.getElementById('in-r') as HTMLInputElement | null
  if (renteSlider) {
    // Slider kan snel bewegen; throttle via rAF voor soepel sleepgedrag
    let rafPending = false
    renteSlider.addEventListener('input', () => {
      state.parameters = { ...state.parameters, r: Number(renteSlider.value) / 100 }
      if (!rafPending) {
        rafPending = true
        requestAnimationFrame(() => {
          rafPending = false
          recompute()
          updateOutputInPlace()
        })
      }
    })
  }
}

// ============================================================================
// Init
// ============================================================================

export function init(): void {
  recompute()
  render()
}

// Auto-start in browser
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
}
