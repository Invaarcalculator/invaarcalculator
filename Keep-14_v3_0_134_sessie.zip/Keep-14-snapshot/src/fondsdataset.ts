/**
 * v3.0.76: Fondsdata-bridge.
 *
 * Build-time-fondsinjectie:
 *   - Types staan in fondsdataset.types.ts (fonds-onafhankelijk)
 *   - Concrete data komt uit /fondsen/<id>/fonds.config.ts
 *   - Build-script injecteert het juiste pad via path-alias '~fonds'
 *
 * Voor backward-compat (zoveel mogelijk bestaande UI-code blijft werken)
 * exporteren we óók een FONDSEN-record en FondsId-type. Die zijn nu
 * trivialiteit — één entry — maar laten code die `Object.keys(FONDSEN)`
 * doet onveranderd lopen.
 *
 * Voor een tweede fonds bouw je een aparte HTML-build:
 *   npx tsx build.calc.ts --fonds=abn → /mnt/user-data/outputs/calculator.html
 * Twee fondsen tegelijk in één HTML wordt expliciet niet meer ondersteund.
 */

import { FONDS } from '~fonds'
import type {
  Fonds,
  AanwendingsCascade,
  M1Parameterset,
  M2Parameterset,
} from './fondsdataset.types'

export type { Fonds, AanwendingsCascade, M1Parameterset, M2Parameterset }

// FONDS-export (canoniek vanaf v3.0.76)
export { FONDS }

// v3.0.76 backward-compat: bestaande UI-code gebruikt FONDSEN-registry,
// state.fondsKeuze en SSPF_M1/M2_PLACEHOLDER. Onderstaande exports houden
// die code lopend zonder veranderingen. In latere refactor-stap kunnen
// deze symbolen worden verwijderd ten gunste van directe FONDS-import.
export type FondsId = 'sspf'   // pseudo-id; build levert altijd één fonds
export const FONDSEN: Record<FondsId, Fonds> = { sspf: FONDS }
export const SSPF_M1_PLACEHOLDER: M1Parameterset = FONDS.m1
export const SSPF_M2_PLACEHOLDER: M2Parameterset = FONDS.m2
