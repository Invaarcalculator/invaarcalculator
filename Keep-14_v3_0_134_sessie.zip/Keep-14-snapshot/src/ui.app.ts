/**
 * UI-orkestratie: gebundelde calculator (scherm 1 + scherm 2 scrollend) + audit.
 *
 * Architectuur (combi-sessie M2 04-05-2026, S-UI-1=ii-a, S-UI-2=β, β6=split):
 *   - State: één AppState met deelnemer + parameters_m1 + parameters_m2 + outputs
 *   - Cascade: bij elke input-wijziging recompute eerst M1 dan M2
 *   - Scherm-layout: scrollend (boven M1, daaronder M2), niet tabs
 *   - View-toggle: Casual (gebundeld scherm 1+2) / Audit (M1-secties + M2-secties)
 *
 * Hergebruikt geen functies uit ui.m1.ts (single-export init() niet bruikbaar);
 * implementeert eigen render-pad voor scherm 1's input-form en KV-KPI omdat de
 * gebundelde layout een andere DOM-structuur heeft. Audit-scherm wijst zelf
 * naar M1 en M2 audit-renders.
 */

import { z } from 'zod'
import {
  M1,
  M2,
  FIELD_REGISTRY,
  fieldsByDisplay,
  fieldsWithDisclosure,
  type FieldMeta,
} from './schema.v2'
import type {
  M1Deelnemer,
  M1Parameterset,
  M1Output,
  M2Parameterset,
  M2Output,
} from './schema.v2'
import { computeM1 } from './engine.m1'
import { computeM2 } from './engine.m2'
import { FONDS } from './fondsdataset'
import {
  renderM2KPI,
  renderM2Sliders,
  applyM2SliderInput,
} from './ui.m2'
import {
  type FieldInfo,
  escapeHtml,
  renderInputField,
  helpIcon,
} from './ui.shared'
import { runSweep, renderSensitivityHTML, runBijstortSweep, renderBijstortHTML, attachBijstortTooltip, runIndexedSweep, renderIndexedHTML } from './ui.sensitivity'

// ============================================================================
// Labels
// ============================================================================

const DEELNEMER_LABELS: Record<string, string> = {
  x0: 'Uw leeftijd',
  pen: 'Jaarlijks bruto ouderdomspensioen (€)',
  g: 'Uw geslacht',
  heeftPartner: 'Heeft u een partnerpensioen?',
  y0: 'Jaarlijks bruto nabestaandenpensioen (€)',
  x_partner: 'Leeftijd partner',
  g_y: 'Geslacht partner',
  hooglaagActief: 'Heeft u een hoog-laag-uitkering?',
}

// ============================================================================
// Type-inspectie helpers
// ============================================================================

function unwrap(schema: z.ZodTypeAny): z.ZodTypeAny {
  let inner: z.ZodTypeAny = schema
  while (
    inner instanceof z.ZodOptional ||
    inner instanceof z.ZodDefault ||
    inner instanceof z.ZodNullable
  ) {
    inner = inner._def.innerType
  }
  return inner
}

function describeType(schema: z.ZodTypeAny): string {
  const inner = unwrap(schema)
  if (inner instanceof z.ZodNumber) return 'getal'
  if (inner instanceof z.ZodBoolean) return 'ja/nee'
  if (inner instanceof z.ZodString) return 'tekst'
  if (inner instanceof z.ZodEnum) return inner._def.values.join(' | ')
  if (inner instanceof z.ZodLiteral) return String(inner._def.value)
  if (inner instanceof z.ZodUnion) {
    return inner._def.options.map((o: z.ZodTypeAny) => describeType(o)).join(' | ')
  }
  return 'onbekend'
}

function getDefault(schema: z.ZodTypeAny): unknown {
  let inner: z.ZodTypeAny = schema
  while (inner instanceof z.ZodOptional || inner instanceof z.ZodNullable) {
    inner = inner._def.innerType
  }
  if (inner instanceof z.ZodDefault) {
    const def = inner._def.defaultValue
    return typeof def === 'function' ? def() : def
  }
  return undefined
}

function isNullable(schema: z.ZodTypeAny): boolean {
  let inner: z.ZodTypeAny = schema
  while (inner instanceof z.ZodOptional || inner instanceof z.ZodDefault) {
    inner = inner._def.innerType
  }
  return inner instanceof z.ZodNullable
}

function collectFields(zodObj: z.ZodTypeAny, pathPrefix: string): FieldInfo[] {
  const obj = zodObj instanceof z.ZodEffects ? zodObj.innerType() : zodObj
  if (!(obj instanceof z.ZodObject)) return []
  const shape = obj.shape
  const out: FieldInfo[] = []
  for (const [name, fieldSchema] of Object.entries(shape)) {
    const fullPath = `${pathPrefix}.${name}`
    const reg = FIELD_REGISTRY.find((f) => f.path === fullPath)
    if (!reg) continue
    out.push({
      name,
      path: fullPath,
      meta: reg.meta,
      typeLabel: describeType(fieldSchema as z.ZodTypeAny),
      default: getDefault(fieldSchema as z.ZodTypeAny),
      nullable: isNullable(fieldSchema as z.ZodTypeAny),
    })
  }
  return out
}

// ============================================================================
// State
// ============================================================================

interface AppState {
  deelnemer: {
    x0: number              // afgeleide cache; bron-of-truth is dob (v3.0.51)
    pen: number
    g: 'M' | 'V' | 'gemengd'
    heeftPartner: boolean
    y0: number | null
    x_partner: number | null
    g_y: 'M' | 'V' | 'gemengd'
    // v3.0.51: geboortedatums (ISO string yyyy-mm-dd). x0 / x_partner worden
    // hieruit afgeleid bij elke recompute. Default-waarden corresponderen met
    // x0=70, x_partner=65 op peildatum 2026-05-08, zodat bestaande integer-
    // ankers exact behouden blijven.
    dob: string             // bv. '1956-05-08' → x0 ≈ 70 op 2026-05-08
    dob_partner: string | null
    // v3.0.57: hoog-laag-regeling (art. 63 Pw). pen wordt in dat geval
    // het hoge bedrag; pen_laag is het lage bedrag; dob_knip is de datum
    // waarop de overstap plaatsvindt (x_knip afgeleid). UI weigert
    // dob_knip ≤ peildatum (verleden-knip).
    hooglaagActief: boolean
    pen_laag: number | null
    x_knip: number | null
    dob_knip: string | null
  }
  parameters_m1: M1Parameterset
  parameters_m2: M2Parameterset
  // v3.0.79: Aanwendings-cascade als eerste-klas state-sectie. Componenten
  // (wettelijk %, RDR-bedrag, compdepot-bedrag) waren tot v3.0.78 alleen in
  // fonds.aanwendingsCascade als display-meta. Nu zijn ze runtime-bewerkbaar
  // via M1/2-pane. Bij elke recompute wordt parameters_m2.vpvAftrekPct
  // hieruit afgeleid (UI aggregeert; engine ontvangt scalar zoals voorheen).
  cascadeOverrides: {
    wettelijkeReservesPct: number    // bv. 0.02
    rdrBedrag: number                // mln €
    compensatiedepotBedrag: number   // mln €
  }
  lastM1?: M1Output
  lastM2?: M2Output
  lastM1Error?: string
  lastM2Error?: string
}

// v3.0.51: bereken fractionele leeftijd uit geboortedatum + peildatum.
// Gebruikt 365.25 dagen/jaar voor schrikkeljaar-correctie.
// Snap-to-integer: bij frac > 0.998 of < 0.002 wordt afgerond naar geheel
// jaar — dat lost de 365.25-quasi-integer-edge op (bv. 1956-05-08 → 2026-05-08
// geeft 69.9986 wat conceptueel 70 is, want exact 70 verjaardagen verstreken).
function ageFromDob(dob: string, peildatum: string): number {
  const dobMs = Date.parse(dob)
  const peilMs = Date.parse(peildatum)
  if (!Number.isFinite(dobMs) || !Number.isFinite(peilMs)) return 70
  const diffDays = (peilMs - dobMs) / (1000 * 60 * 60 * 24)
  const ageRaw = diffDays / 365.25
  const ageFloor = Math.floor(ageRaw)
  const frac = ageRaw - ageFloor
  if (frac > 0.998) return ageFloor + 1
  if (frac < 0.002) return ageFloor
  return ageRaw
}

// Peildatum = vandaag (Date-object bij elke pagina-load). Engine-cache werkt
// op gefloorde leeftijden dus geen verspild rekenwerk bij dagelijkse updates.
// Ankers in tests pinnen we via een fixed-DOB die op de huidige peildatum
// exact 70 oplevert via snap-to-integer (frac > 0,998 → integer).
const PEILDATUM = new Date().toISOString().slice(0, 10)

// v3.0.52: helper voor default-DOB die exact `years` jaar oud is op PEILDATUM
// (vandaag). Garandeert dat default-leeftijden 70/65 ongeacht de runtime-datum
// hetzelfde blijven en de ankers dus stabiel zijn.
function dobForExactAge(years: number, peildatum: string): string {
  const peil = new Date(peildatum)
  const dob = new Date(peil)
  dob.setFullYear(peil.getFullYear() - years)
  return dob.toISOString().slice(0, 10)
}

const state: AppState = {
  deelnemer: {
    x0: 70,
    pen: 100000,
    g: 'M',
    // v3.0.95: default heeftPartner=false; partner-velden zijn null. Bij eerste
    // activering (dropdown naar Ja) hydrateert de UI redelijke defaults (y0=70k,
    // x_partner=65, g_y='V', dob_partner = 65j vanaf peildatum).
    heeftPartner: false,
    y0: null,
    x_partner: null,
    g_y: 'V',
    // v3.0.52: default-DOBs derived van huidige peildatum, niet hardcoded.
    // dobForExactAge(70, vandaag) → exact 70 jaar oud nu, ongeacht run-datum.
    dob: dobForExactAge(70, PEILDATUM),
    dob_partner: null,
    // v3.0.57: hoog-laag default uit. Bij eerste activering vult UI redelijke
    // defaults in (pen_laag = 80% van pen, dob_knip = vandaag + 10 jaar).
    hooglaagActief: false,
    pen_laag: null,
    x_knip: null,
    dob_knip: null,
  },
  parameters_m1: { ...FONDS.m1 },
  parameters_m2: { ...FONDS.m2 },
  // v3.0.79: cascade-componenten geïnitialiseerd vanuit FONDS-defaults.
  cascadeOverrides: {
    wettelijkeReservesPct: FONDS.aanwendingsCascade?.wettelijkeReservesPct ?? 0.02,
    rdrBedrag: FONDS.aanwendingsCascade?.rdrBedrag ?? 0,
    compensatiedepotBedrag: FONDS.aanwendingsCascade?.compensatiedepotBedrag ?? 0,
  },
}

// ============================================================================
// Format helpers
// ============================================================================

function euro(n: number, decimals = 0): string {
  return '€ ' + n.toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

function num(n: number | null, decimals = 2): string {
  if (n === null || !Number.isFinite(n)) return '—'
  return n.toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

function pct(n: number, decimals = 2): string {
  return (n * 100).toLocaleString('nl-NL', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }) + '%'
}

// ============================================================================
// Cascade compute M1 → M2
// ============================================================================

function recompute(): void {
  // v3.0.79: aggregatie cascade-componenten naar één engine-scalar
  // vpvAftrekPct. State.parameters_m2.{fondsvermogen, bijstort} worden direct
  // door UI-sliders gemuteerd; wettelijk%/RDR/compdepot via cascadeOverrides.
  // De engine ziet vpvAftrekPct als één getal; UI verzorgt de aggregatie.
  //   vpvAftrekPct = wettelijk% + (RDR + compdepot) / vpv
  // v3.0.94: vpv komt nu uit vpvTotal-anker (mln→eur via *1e6 niet nodig hier
  // omdat RDR/compdepot ook in mln staan; cascade-rekenwerk blijft mln-mln).
  const m2 = state.parameters_m2
  const co = state.cascadeOverrides
  const vpv = m2.vpvTotal > 0 ? m2.vpvTotal : m2.fondsvermogen / m2.dekkingsgraad
  m2.vpvAftrekPct = co.wettelijkeReservesPct + (co.rdrBedrag + co.compensatiedepotBedrag) / vpv

  // v3.0.51: derive fractionele leeftijden uit geboortedatums.
  // dob is bron-of-truth; x0 / x_partner zijn cache-velden voor het schema.
  state.deelnemer.x0 = ageFromDob(state.deelnemer.dob, PEILDATUM)
  state.deelnemer.x_partner = state.deelnemer.heeftPartner && state.deelnemer.dob_partner
    ? ageFromDob(state.deelnemer.dob_partner, PEILDATUM)
    : null
  // v3.0.57: x_knip = leeftijd van deelnemer op de knip-datum (= x0 + jaren-tot-knip).
  // Validatie: dob_knip > peildatum (anders ligt knip in verleden, M2 pauseert).
  let knipInPastBlock = false
  if (state.deelnemer.hooglaagActief && state.deelnemer.dob_knip) {
    if (state.deelnemer.dob_knip > PEILDATUM) {
      const peilMs = Date.parse(PEILDATUM)
      const knipMs = Date.parse(state.deelnemer.dob_knip)
      const jarenTotKnip = (knipMs - peilMs) / (1000 * 60 * 60 * 24 * 365.25)
      state.deelnemer.x_knip = state.deelnemer.x0 + jarenTotKnip
    } else {
      state.deelnemer.x_knip = null
      knipInPastBlock = true
    }
  } else {
    // hooglaagActief=true zonder dob_knip → toggle net aangezet maar default
    // is nog niet doorgekomen. Niet als verleden-knip behandelen; M2 draait
    // door op pen_laag-fallback (= deelnemer.pen).
    state.deelnemer.x_knip = null
  }

  // M2 parameterset éérst valideren — we hebben spreidingN nodig voor M1's
  // m2Context-aanroep (v3.0 wet-canoniek). Bij M2-validatie-falen draait M1
  // toch standalone (zonder cw_star); M2 wordt dan niet aangeroepen.
  let m2ContextN: number | undefined
  let p2Validated: ReturnType<typeof M2.parameterset.parse> | undefined
  try {
    p2Validated = M2.parameterset.parse(state.parameters_m2)
    m2ContextN = p2Validated.spreidingN
  } catch {
    // M2-validatie faalt; M1 standalone zonder m2Context
  }

  // M1 — met m2Context indien M2-params geldig zijn (v3.0 cw_star-levering)
  try {
    const d = M1.deelnemer.parse(state.deelnemer)
    const p1 = M1.parameterset.parse(state.parameters_m1)
    state.lastM1 = m2ContextN !== undefined
      ? computeM1(d, p1, { spreidingN: m2ContextN })
      : computeM1(d, p1)
    state.lastM1Error = undefined
  } catch (err) {
    state.lastM1Error = err instanceof Error ? err.message : String(err)
    state.lastM1 = undefined
    state.lastM2 = undefined
    state.lastM2Error = undefined
    return // Geen M2-cascade als M1 faalde
  }

  // M2-cascade — vereist v3.0 cw_star-velden uit M1
  if (p2Validated === undefined) {
    state.lastM2Error = 'M2-parameters ongeldig (zie audit-log)'
    state.lastM2 = undefined
    return
  }
  // v3.0.57: pauseer M2 als hoog-laag aan staat met verleden-knip
  if (knipInPastBlock) {
    state.lastM2Error = 'Knip-datum ligt in het verleden — corrigeer de hoog-laag-instellingen.'
    state.lastM2 = undefined
    return
  }
  try {
    const d = M1.deelnemer.parse(state.deelnemer)
    const k = M2.ketenInput.parse({
      KV: state.lastM1!.KV,
      KV_OP: state.lastM1!.KV_OP,
      KV_NP: state.lastM1!.KV_NP,
      cw_star_op: state.lastM1!.cw_star_op ?? 0,
      cw_star_np: state.lastM1!.cw_star_np ?? 0,
    })
    state.lastM2 = computeM2(d, k, p2Validated)
    state.lastM2Error = undefined
  } catch (err) {
    state.lastM2Error = err instanceof Error ? err.message : String(err)
    state.lastM2 = undefined
  }
}

// ============================================================================
// Render — scherm 1 deelnemer-input (deel van casual gebundeld)
// ============================================================================

// v3.0.2: implementatie verhuisd naar src/ui.shared.ts; deze wrapper geeft
// module-state (deelnemer + labels) door als parameter.
function renderField(f: FieldInfo): string {
  return renderInputField(f, state.deelnemer, DEELNEMER_LABELS)
}

function renderM1KPI(): string {
  if (state.lastM1Error) {
    return `<div class="error">Fout bij M1-berekening: ${escapeHtml(state.lastM1Error)}</div>`
  }
  if (!state.lastM1) return ''
  const o = state.lastM1
  return `
    <div class="kpi-card kpi-m1">
      <div class="kpi-label">Huidige waarde van uw pensioenaanspraak</div>
      <div class="kpi-value">${euro(o.KV)}</div>
      ${o.KV_NP > 0 ? `<div class="kpi-breakdown">
        <div class="kpi-sub">
          <div class="kpi-sub-label">Eigen ouderdomspensioen</div>
          <div class="kpi-sub-value">${euro(o.KV_OP)}</div>
        </div>
        <div class="kpi-sub">
          <div class="kpi-sub-label">Partnerpensioen</div>
          <div class="kpi-sub-value">${euro(o.KV_NP)}</div>
        </div>
      </div>` : ''}
    </div>
  `
}

// ============================================================================
// Help-content (v3.0.13) — modal-popups voor velden waar uitleg waarde toevoegt.
// Per veld een functie die dynamisch de huidige stand inleest.
// ============================================================================

// v3.0.38: HelpSection ondersteunt nu naast prose-body ook een rijen-tabel
// voor parameter-overzichten per fonds (kolom "Aanpasbaar?" in de UI).
// v3.0.45: derde variant — een aanwendings-cascade (input + aftrekposten →
// uitkomst), gebruikt om de aanwending van het fondsvermogen bij invaren
// transparant te maken (impl.plan §5.5).
type HelpRow = {
  label: string
  value: string
  adjustable: boolean       // true = via UI-slider/-radio aanpasbaar; false = vast (fondsparameter)
  note?: string             // korte aanvullende info (bv. waar de slider staat)
}
type CascadeRow = {
  kind: 'input' | 'plus' | 'minus' | 'subtotal' | 'total'
  label: string
  value: string             // reeds geformatteerd (bv. '€ 26.000 mln' of '~ 2,0%')
  note?: string             // bv. wettelijke verwijzing
}
type HelpSection =
  | { heading: string; body: string }
  | { heading: string; rows: HelpRow[]; intro?: string }
  | { heading: string; cascade: CascadeRow[]; intro?: string; outro?: string }
  | { heading: string; tableHeaders: string[]; tableRows: string[][]; intro?: string; outro?: string }
type HelpContent = { title: string; currentValue?: string; sections: HelpSection[]; footerLink?: { key: string; label: string } }

// v3.0.38: builder voor fonds-parameter-overzicht. Toont per module welke
// parameters het fonds bepaalt en welke daarvan via de UI aanpasbaar zijn.
// Module 1 = KV-berekening; Module 2 = PPV-berekening na invaren.
// v3.0.75: module-niveau-helper voor euro-formattering zonder valuta-prefix
// (€ symbool wordt apart getoond). Hergebruikt door vpvAftrekPct-modal.
// v3.0.95: buildFondsHelp + buildAanwendingsCascadeBlock zijn verhuisd naar
// ui.audit-report.ts sectie 4 "Fondsparameters". Het fonds-modal in M1 is
// vervangen door dezelfde tabel in het audit-rapport, bereikbaar via de
// "Audit-rapport"-knop.
const eur = (n: number) => n.toLocaleString('nl-NL')

// v3.0.77: één fonds-help-entry, geen id-suffix meer (build-time-injectie
// betekent één fonds per build).
// v3.0.95: 'fonds'-entry verwijderd; fonds-info staat nu in audit-rapport.
const HELP_CONTENT: Record<string, () => HelpContent> = {
  x0: () => ({
    title: 'Uw geboortedatum',
    currentValue: `Uw huidige stand: ${state.deelnemer.x0} jaar`,
    sections: [
      {
        heading: 'WAT VULT U IN?',
        body: 'Vul uw geboortedatum in. Uw leeftijd wordt hieruit afgeleid en gebruikt in de berekening.',
      },
    ],
  }),
  pen: () => ({
    title: 'Uw pensioen',
    currentValue: `Uw huidige stand: € ${Math.round(state.deelnemer.pen).toLocaleString('nl-NL')} per jaar`,
    sections: [
      {
        heading: 'WAAR VINDT U DIT OP UW UPO?',
        body: 'Bij SSPF onder de vraag "Hoeveel pensioen krijgt u?". Daar staat: "U krijgt vanaf [datum] zolang u leeft € … bruto per jaar". Dat bedrag vult u hier in.',
      },
    ],
  }),
  x_partner: () => ({
    title: 'Geboortedatum partner',
    currentValue: `Uw huidige stand: ${state.deelnemer.x_partner ?? 0} jaar`,
    sections: [
      {
        heading: 'WAT VULT U IN?',
        body: 'Vul de geboortedatum van uw partner in. De leeftijd van uw partner wordt hieruit afgeleid.',
      },
    ],
  }),
  y0: () => ({
    title: 'Partnerpensioen na uw overlijden',
    currentValue: `Uw huidige stand: € ${Math.round(state.deelnemer.y0 ?? 0).toLocaleString('nl-NL')} per jaar`,
    sections: [
      {
        heading: 'WAAR VINDT U DIT OP UW UPO?',
        body: 'Bij SSPF onder de vraag "Wat krijgen uw eventuele partner en eventuele kinderen als u overlijdt?". Daar staat: "Als u overlijdt, krijgt uw partner van ons: vanaf uw overlijden zolang hij/zij leeft € … bruto per jaar". Dat bedrag vult u hier in.',
      },
    ],
  }),
  r: () => ({
    title: 'Rekenrente',
    currentValue: `Uw huidige stand: ${pct(state.parameters_m1.r)}`,
    sections: [
      {
        heading: 'WAT DOET DE REKENRENTE?',
        body: 'De rekenrente bepaalt hoe toekomstige pensioenuitkeringen worden teruggerekend naar een waarde van vandaag. Bij een hogere rekenrente wordt de huidige waarde van uw aanspraak lager: \u00E9\u00E9n euro pensioen volgend jaar wordt dan met een grotere korting teruggerekend. Bij een lagere rekenrente is uw aanspraak vandaag meer waard.',
      },
      {
        heading: 'WAT KUNT U INSTELLEN?',
        body: 'Verschuif de slider om een rekenrente te kiezen tussen 0% en 5%.',
      },
    ],
  }),
  dekkingsgraad: () => ({
    title: 'Dekkingsgraad',
    currentValue: `Uw huidige stand: ${pct(state.parameters_m2.dekkingsgraad, 1)}`,
    sections: [
      {
        heading: 'WAT KUNT U INSTELLEN?',
        body: 'Verschuif de slider om een dekkingsgraad te kiezen tussen 100% en 170%.',
      },
    ],
  }),
  vpvAftrekPct: () => ({
    title: 'Aftrek voor reserveringen',
    sections: [
      {
        heading: 'VERVANGEN DOOR M1/2-PANE',
        body: 'De aftrek-componenten staan nu zichtbaar in de cascade-tabel "Wat is er te verdelen?". Schuif daar de drie componenten (wettelijke reserves, risicodelingsreserve, compensatiedepot) om hun effect op uw persoonlijk pensioenvermogen te zien.',
      },
    ],
  }),
  spreidingN: () => ({
    title: 'Spreidingstermijn',
    currentValue: `Uw huidige stand: ${state.parameters_m2.spreidingN >= 1000 ? 'oneindig' : state.parameters_m2.spreidingN + ' jaar'}`,
    sections: [
      {
        heading: 'WAT DOET DE SPREIDINGSTERMIJN?',
        body: 'De spreidingstermijn bepaalt hoe het verdeelbare overschot bij invaren over de deelnemers wordt verdeeld. De wettelijke standaard (Bijlage 2a Regeling Pensioenwet) is 10 jaar: het overschot wordt uitgesmeerd over de komende tien jaar, waardoor jongere deelnemers naar verhouding meer ontvangen dan oudere; zij hebben immers een langere verwachte uitkeringshorizon waarop het overschot kan landen. Bij levenslang krijgen alle deelnemers het overschot proportioneel naar hun aanspraak, zonder extra cohort-opslag. Voor pensioengerechtigden valt het persoonlijk pensioenvermogen onder levenslang doorgaans lager uit dan onder de 10-jaars standaard; voor jongere cohorten geldt het omgekeerde.',
      },
      {
        heading: 'WAT KUNT U INSTELLEN?',
        body: 'Kies tussen 10 jaar of levenslang.',
      },
    ],
  }),
  bijstort: () => ({
    title: 'Transitiebijdrage werkgever',
    currentValue: `Uw huidige stand: € ${state.parameters_m2.bijstort.toLocaleString('nl-NL')} mln`,
    sections: [
      {
        heading: 'WAT IS DIT?',
        body: 'De transitiebijdrage is een eenmalige storting van de werkgever bij invaren, als compensatie voor het vervallen van de sponsorgarantie. Dit bedrag verhoogt het fondsvermogen vóór de aftrek voor reserves en compensatie, en werkt daarmee door in het verdeelbaar overschot.',
      },
      {
        heading: 'HOE HOOG IS HET BEDRAG?',
        body: 'Volgens het SSPF-implementatieplan van 15-07-2025 hangt het bedrag af van de dekkingsgraad op het invaarmoment: bij DG ≥ 135% € 500 mln, bij DG 130–135% € 650 mln, bij DG 125–130% € 850 mln. Hoe lager de dekkingsgraad, hoe hoger de transitiebijdrage — de werkgever vult meer aan als het fonds er minder ruim voor staat.',
      },
      {
        heading: 'LET OP',
        body: 'Deze calculator past het bedrag niet automatisch aan wanneer u de dekkingsgraad-slider verschuift. De standaardwaarde € 500 mln hoort bij de huidige SSPF-DG (≥ 135%). Schuif desgewenst de transitiebijdrage-slider handmatig naar het bedrag dat bij de door u gekozen DG hoort.',
      },
    ],
  }),
  jaarequivalent: () => ({
    title: 'Per jaar pensioen levenslang',
    sections: [
      {
        heading: 'WAT BETEKENT DIT BEDRAG?',
        body: 'Het bedrag is een rekenwiskunde-omrekening: uw aandeel verdeelbaar overschot, vertaald naar een jaarlijkse uitkering op basis van uw verwachte levensduur (volgens AG2024-sterftekansen) en de huidige rekenrente. Het is een wiskundig equivalent, geen toezegging.',
      },
      {
        heading: 'EN ALS U EEN PARTNER HEEFT?',
        body: 'Het persoonlijk pensioenvermogen wordt na uw overlijden gebruikt om partnerpensioen te financieren. Bij de omrekening wordt die verplichting meegenomen: hetzelfde vermogen moet zowel uw OP-uitkering dragen zolang u leeft, als het PP-uitkering aan uw partner ná uw overlijden. Daardoor ligt het jaarbedrag lager dan zonder partner — dit is geen verlies maar de reservering voor uw partner.',
      },
      {
        heading: 'WAT GEBEURT ER MET HET PARTNERPENSIOEN BIJ INVAREN?',
        body: 'Bij invaren wordt het persoonlijk pensioenvermogen via de standaardregel (Bijlage 2a Regeling Pensioenwet) verhoogd of verlaagd ten opzichte van uw huidige aanspraak. SSPF kiest in zijn implementatieplan voor een levenslange spreiding van het verdeelbare overschot. Het gevolg: een verhoging van het persoonlijk vermogen werkt proportioneel door op zowel uw ouderdomspensioen als het partnerpensioen voor uw partner ná uw overlijden. Bij bijvoorbeeld een verhoging van 30% groeit zowel uw OP-uitkering als de aanspraak op partnerpensioen voor uw partner met circa 30%. Onder de wettelijke standaardspreiding van 10 jaar zou deze proportionaliteit niet exact gelden; de keuze van SSPF voor levenslange spreiding is dus bepalend.',
      },
      {
        heading: 'WAT BETEKENT "LEVENSLANG"?',
        body: 'Levenslang is geen vaste sterfdatum, maar een statistische verwachting. Als u langer leeft dan gemiddeld, krijgt u dit bedrag toch elk jaar — dat wordt collectief gefinancierd door deelnemers die korter leven. Als u eerder overlijdt, stopt de uitkering bij overlijden (tenzij er een partner-pensioen is).',
      },
      {
        heading: 'GEEN RECHTEN TE ONTLENEN',
        body: 'De daadwerkelijke jaarlijkse uitkering in het nieuwe pensioenstelsel hangt af van fonds-rendementen, rentestand, indexatie en fondsbeleidsbeslissingen. Aan dit bedrag kunnen geen rechten worden ontleend.',
      },
    ],
  }),
  hooglaag: () => ({
    title: 'Hoog-laag-uitkering',
    sections: [
      {
        heading: 'WAT VULT U IN?',
        body: 'Bij "Pensioen tot knip" vult u het hoge bedrag in dat u nu nog ontvangt. Bij "Pensioen na knip" het bedrag dat u na de overstap krijgt. Bij "Datum waarop pensioen wijzigt" de datum die op uw UPO staat. Als die datum al voorbij is, zet de toggle uit en vul alleen het lage bedrag in als pensioen.',
      },
    ],
  }),
  privacy: () => ({
    title: 'Privacy',
    sections: [
      {
        heading: 'GEEN INVOER VERLAAT UW BROWSER',
        body: 'Deze tool werkt volledig lokaal in uw browser. Uw invoer (leeftijd, jaarpensioen, partnergegevens, en alle andere parameters die u aanpast) wordt niet verstuurd naar een server, niet opgeslagen, niet gedeeld met derden, en niet gebruikt voor analyse of profilering. De berekeningen vinden plaats in JavaScript-code die met de webpagina is meegestuurd; sluiten van het tabblad of de browser wist alle gegevens.',
      },
      {
        heading: 'GEEN COOKIES, GEEN TRACKING',
        body: 'De tool plaatst geen cookies, gebruikt geen webanalyse, en bevat geen externe tracking-scripts.',
      },
      {
        heading: 'HOSTING VIA GITHUB PAGES',
        body: 'Deze tool wordt gehost via GitHub Pages (een dienst van GitHub, Inc., onderdeel van Microsoft). Bij het ophalen van de pagina door uw browser legt GitHub standaard HTTP-server-gegevens vast \u2014 IP-adres, gebruikte browser, tijdstip van bezoek, opgevraagde bestanden \u2014 voor beveiligings- en infrastructuurdoeleinden. Dit gebeurt buiten invloed van de auteur. Voor het privacy-beleid van GitHub: https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement.',
      },
      {
        heading: 'VOOR DE INHOUDELIJKE VERANTWOORDING',
        body: 'Deze pagina beschrijft alleen wat met uw invoer gebeurt. Voor de inhoudelijke verantwoording van de tool \u2014 wat hij wel en niet kan, hoe hij tot stand is gekomen, op welke aannames hij berust, welke bronnen zijn gebruikt, en wat de bekende afwijkingen zijn ten opzichte van de werkelijke SSPF-uitkomst \u2014 zie de knop "Verantwoording" rechtsboven op het hoofdscherm.',
      },
    ],
    footerLink: { key: 'verantwoording', label: 'Open Verantwoording' },
  }),
  uitleg: () => ({
    title: 'Uitleg',
    sections: [
      {
        heading: '',
        body: 'De Wet toekomst pensioenen (Wtp) hervormt het Nederlandse pensioenstelsel. Uw huidige pensioenrecht wordt omgezet naar een persoonlijk pensioenvermogen op uw naam, dat na invaren meebeweegt met de beleggingsresultaten van uw fonds.',
      },
      {
        heading: 'VOOR WIE IS DEZE REKENTOOL?',
        body: `Voor wie ${FONDS.shortLabel ?? ''}-pensioen ontvangt na de AOW-leeftijd. Wie nog werkt, vervroegd pensioen tot de AOW heeft, of een aanspraak heeft die nog niet uitkeert, valt buiten deze berekening.`,
      },
      {
        heading: 'WAT BEREKENT DEZE REKENTOOL?',
        body: 'De rekentool laat zien wat invaren voor u zou betekenen op het invaarmoment zelf. U ziet twee bedragen: uw huidige pensioenaanspraak (de waarde vandaag van uw lopende pensioen) en uw persoonlijk pensioenvermogen na invaren (wat hiervan aan u zou worden toebedeeld volgens de wettelijke standaardregel). Hoe uw jaarlijkse uitkering zich na invaren ontwikkelt, zit nog niet in deze versie.',
      },
      {
        heading: 'WAT KUNT U HIER DOEN?',
        body: 'U vult uw gegevens uit het Uniform Pensioenoverzicht (UPO) in: leeftijd, geslacht, bruto jaarpensioen en eventueel partnergegevens. Heeft u nu een hoog-laag-uitkering \u2014 een tijdelijk hoger pensioen tot een afgesproken knip-datum, daarna een lager bedrag levenslang \u2014 vul dan ook het lage bedrag en de knip-datum in. De fondsparameters staan al op de actuele waarden, dus na invoer van uw UPO-gegevens bent u meteen klaar. Wilt u onderzoeken hoe gevoelig uw uitkomst is voor verschillende aannames, dan verschuift u de fondsparameters via de sliders om bijvoorbeeld een andere dekkingsgraad te beproeven. Een Reset-knop verschijnt zodra u afwijkt van de fonds-uitgangswaarden.',
      },
    ],
  }),
  verantwoording: () => ({
    title: `Verantwoording bij de Invaarcalculator (versie ${RELEASE_VERSION})`,
    sections: [
      // ─── §1 ───
      {
        heading: '1. WAT IS DEZE TOOL EN WAT IS HET NIET?',
        body: 'Deze Invaarcalculator is een onafhankelijk, niet door Stichting Shell Pensioenfonds (SSPF) erkend of gevalideerd reken-instrument dat poogt de orde van grootte zichtbaar te maken van de invaareffecten voor een SSPF-deelnemer onder de Wet toekomst pensioenen (Wtp). De tool implementeert de wettelijke standaardregel (Bijlage 2a Regeling Pensioenwet) op basis van uitsluitend publiek beschikbare bronnen en redelijke aannames waar publieke informatie ontbreekt. De uitkomsten zijn per definitie niet identiek aan wat SSPF voor u individueel berekent. SSPF beschikt over niet-publieke gegevens (uw werkelijke aanspraak in de pensioenadministratie, fondsspecifieke uitvoeringskeuzes uit de actuariële en bedrijfstechnische nota (ABTN), de definitieve dekkingsgraad op invaardatum, de exacte populatiesamenstelling, eventuele afwijkingen van de standaardregel die in het transitieplan zijn vastgelegd) waar deze tool geen toegang toe heeft. Aan de uitkomsten kunnen geen rechten worden ontleend. Voor uw werkelijke invaarpositie zijn alleen de transitiebrief en de definitieve berekening van SSPF zelf maatgevend.',
      },
      // ─── §2 ───
      {
        heading: '2. DOOR WIE EN WAAROM IS DEZE TOOL GEMAAKT?',
        body: 'Deze tool is ontwikkeld door drs. ing. H. Haringa (Innovation Nestor) als publiek en onafhankelijk studieproject. De aanleiding ligt in de SSPF-transitie naar de Wtp en de constatering dat fondsleden \u2014 gepensioneerden, actieven en slapers \u2014 geen instrument tot hun beschikking hebben om de fondscommunicatie zelfstandig te toetsen.',
      },
      {
        heading: 'DE AANLEIDING',
        body: 'Op 14 april 2026 stemde de Algemene Ledenvergadering (ALV) van Voeks (vereniging van Shell-gepensioneerden) over een ledenmotie "Toetsbare onderbouwing van een aantoonbaar toereikende en evenwichtige transitiebijdrage als compensatie voor het vervallen van de sponsorgarantie". De motie werd verworpen (41 voor, 64 tegen). De inhoudelijke kern bleef daarmee onbeantwoord: een kwantitatieve onderbouwing van de hoogte van de aangeboden transitiebijdrage \u2014 bezien tegen de waarde van de vervallende sponsorgarantie \u2014 is publiek niet beschikbaar. Fondsleden worden geacht een ingrijpend en onomkeerbaar besluit te accepteren zonder zelf over een toetsmiddel te beschikken.',
      },
      {
        heading: 'EEN BREDERE OBSERVATIE',
        body: 'Bijna geen enkel Nederlands pensioenfonds biedt zijn deelnemers op het moment van invaren een "digital twin" \u2014 een interactief reken-instrument waarmee deelnemers de invaareffecten op hun eigen situatie kunnen verkennen. De rekenmethodiek uit Bijlage 2a Regeling Pensioenwet is publiek beschreven; de individuele uitwerking blijft voor de deelnemer een zwarte doos waarvan alleen de eindstand zichtbaar wordt \u2014 en pas n\u00e1 de transitie definitief. Dat dwingt deelnemers in een passieve positie: vertrouwen op het fonds, of accepteren zonder verificatie. Voor een transitie van deze omvang \u2014 waarbij het renterisico, beleggingsrisico en levensduurrisico goeddeels van fonds naar deelnemer verschuift \u2014 is dat een onbevredigende situatie. Deze tool is een eerste poging die leemte voor SSPF-deelnemers te dichten.',
      },
      {
        heading: 'WAARTOE DE TOOL DIENT \u2014 TYPE VRAGEN DIE ERMEE ONDERBOUWD KUNNEN WORDEN',
        body: 'De auteur heeft de tool zelf gebruikt als rekenkundige onderbouwing voor drie documenten gericht aan SSPF respectievelijk De Nederlandsche Bank (DNB). Het eerste is een zienswijze aan DNB van 1 september 2025 over het wegvallen van de Shell-sponsorgarantie en de ontoereikendheid van de Shell-bijdrage als afkoop daarvan. Het tweede is een vragenbrief aan SSPF van 2 mei 2026 met vijf kwantitatieve vragen over de keuze voor een levenslange spreidingsperiode in plaats van de wettelijke standaard van tien jaar (hoofdstuk 5.6 van het implementatieplan). Die vragenbrief verzoekt om vergelijkende doorrekening van transitiemaatstaven, kwantificering van de buffer-toedeling per cohort, het effect op de Shell-bijdrage onder beide spreidingsregimes, uitsplitsing naar deelnemersgroepen, en de vraag of de risicodelingsreserve (RDR) feitelijk fungeert als compensatie voor het lagere bufferaandeel. Het derde document is een aanvullende zienswijze aan DNB van 2 mei 2026 met drie verzoeken: om de wettelijke tweeledige onderbouwingsplicht voor afwijking van de standaard spreidingstermijn te toetsen, om het ontbreken van een vergelijkende kwantitatieve onderbouwing te betrekken bij de invaartoetsing, en om de evenwichtige belangenafweging voor de spreidingstermijnkeuze zelfstandig te toetsen. Deze documenten zijn opvraagbaar via het e-mailadres in de footer van deze tool. Zij illustreren welk soort vragen met deze calculator inhoudelijk kan worden voorbereid: niet "wat wordt mijn precieze uitkering" \u2014 dat blijft voorbehouden aan SSPF \u2014 maar "is de orde van grootte plausibel, en welke parameterkeuzes verklaren het verschil tussen mijn verwachting en het fondsresultaat". Voor een bredere achtergrond bij de problematiek die deze tool aan de orde stelt, zie ook het publieke LinkedIn-artikel van de auteur: "Communicatie Stichting Shell Pensioenfonds (SSPF) over transitie roept ergernis op" (9 februari 2026), via https://www.linkedin.com/pulse/communicatie-stichting-shell-pensioenfonds-sspf-over-roept-haringa-2yxee. Dit artikel beschrijft het patroon van eenrichtings-communicatie dat de directe aanleiding vormde voor het bouwen van een onafhankelijk reken-instrument.',
      },
      {
        heading: 'HOE DE TOOL TOT STAND IS GEKOMEN',
        body: 'Code, modelspecificatie, helpteksten en deze verantwoording zijn iteratief tot stand gekomen in dialoog met meerdere generatieve-AI-assistenten en bronnen: Anthropic Claude (diverse versies, waaronder eerdere generaties Sonnet en Opus en de huidige Claude 4-familie tot en met Opus 4.7) \u2014 primair voor TypeScript-implementatie van rekenkern en UI, modelspecificatie-redactie en architectuurkeuzes; Anthropic Claude Excel-add-in \u2014 voor controleberekeningen in een rekenblad en parallelle handberekeningen; PensioenGPT (custom GPT beschikbaar binnen ChatGPT) \u2014 voor domeinspecifieke navigatie van Pensioenwet, Bijlage 2a en transitieplan-praktijk; Mistral \u2014 voor afstemming en kruiscontrole van interpretaties; diverse browser-gebaseerde AI-assistenten \u2014 voor losse onderzoeksvragen en bronverificatie. Het gebruik van AI-assistenten betekent dat de auteur de wiskundige uitwerking, code en tekst kritisch heeft beoordeeld, maar dat aanwezigheid van fouten \u2014 in interpretatie van de Pensioenwet, in actuariële formules, in code, of in numerieke uitkomsten \u2014 niet kan worden uitgesloten en op een aantal punten statistisch waarschijnlijk is. Daarbij geldt dat verschillende AI-assistenten op identieke vragen niet altijd identieke antwoorden geven; waar mogelijk is met meerdere bronnen gecontroleerd, maar absolute zekerheid is daarmee niet bereikt. De tool is bewust open-source en transparant; de modelspecificatie en broncode zijn meegeleverd zodat onafhankelijke verificatie mogelijk is. De broncode is publiek beschikbaar via https://github.com/Invaarcalculator/invaarcalculator.git; de tool zelf wordt gehost via GitHub Pages (zie de Privacy-link in de footer voor de implicaties daarvan). De tool is niet beoordeeld door een gecertificeerde actuaris, niet getoetst door SSPF, niet getoetst door DNB, en niet voorzien van een vergunning van de Autoriteit Financiële Markten (AFM) voor financieel advies. De tool geeft geen persoonlijk financieel advies en is niet bedoeld als grondslag voor financiële beslissingen.',
      },
      // ─── §3 ───
      {
        heading: '3. HOE ONTSTAAT DE AFWIJKING TUSSEN CALCULATOR EN WERKELIJKHEID?',
        body: 'De afwijking tussen wat deze calculator berekent en wat SSPF voor u individueel zal berekenen, heeft drie hoofdoorzaken die zich op verschillende schermen anders uiten.',
      },
      {
        heading: 'OORZAAK A \u2014 AANNAMES WAAR PUBLIEKE INFORMATIE ONTBREEKT',
        body: 'Voor onder meer de ervaringssterftefactor, de exacte populatiesamenstelling van het deelnemersbestand, de uitvoering van de bundle-aftrekcascade (de afsplitsingen voorafgaand aan toepassing van de standaardregel) en de eventuele toepassing van een "zachte landing" voor pensioengerechtigden gebruikt de tool plausibele aannames op basis van publieke gegevens van het Centraal Bureau voor de Statistiek (CBS), sectorvergelijkingen en de publieke SSPF-presentatie van 14 april 2026 en het implementatieplan. De werkelijke ABTN van SSPF bevat hier specifiekere waarden waar de tool geen toegang toe heeft.',
      },
      {
        heading: 'OORZAAK B \u2014 VEREENVOUDIGINGEN TEN OPZICHTE VAN EEN VOLLEDIGE UITVOERINGSPRAKTIJK',
        body: 'Niet gemodelleerd zijn onder andere: stochastische scenario-analyse (goed/mediaan/slecht-weerscenario\'s), de rendementsdynamiek na invaren met vijfjaars-spreiding van schokken zoals voorzien in de Wtp, de leeftijdsafhankelijke beleggingsmix (lifecycle), de dempingswerking van de risicodelingsreserve (RDR) na invaren, het exacte moment van de invaardatum (1 januari 2027) versus de peildatum van de dekkingsgraad die in de tool wordt gehanteerd, en de zogenoemde 67%-randvoorwaarde uit artikel 150n lid 4 Pensioenwet (Pw) die de toedeling tussen cohorten beperkt.',
      },
      {
        heading: 'OORZAAK C \u2014 UW EIGEN INPUT',
        body: 'Leeftijd, jaarpensioen, eventueel hoog-laag-bedragen, partner-aanwezigheid en partner-leeftijd vult u zelf in. Als deze afwijken van uw werkelijke Uniform Pensioenoverzicht (UPO) of pensioenadministratie, dan klopt de berekening voor uw werkelijke situatie niet \u2014 ook al doet de tool wiskundig wat hij hoort te doen. Vergelijk uw invoer daarom vooraf met uw UPO.',
      },
      // ─── §4 ───
      {
        heading: '4. IMPLICATIES PER SCHERM EN BRONNEN VAN ONNAUWKEURIGHEID',
        body: 'Onderstaand wordt per uitvoerblok in de calculator aangegeven welke parameters de uitkomst het sterkst beïnvloeden en welke onzekerheidsbronnen actief zijn. Er worden bewust geen harde foutmarges genoemd. Dat zou valse precisie suggereren, want voor de meeste uitkomsten is geen empirische kalibratie tegen werkelijke SSPF-uitkomsten beschikbaar \u2014 die uitkomsten worden immers pas zichtbaar in de individuele transitiebrieven na invaardatum. In plaats daarvan kan de gebruiker zelf de gevoeligheid verkennen: via sliders en invoervelden voor parameters waarbij de gebruiker zelf de waarde kiest (leeftijd, jaarpensioen, partner-aanwezigheid, partner-leeftijd en partnerpensioen, hoog-laag-regeling, rekenrente, en in het tweede pane de cascade-componenten); via de keuzelijst "Spreidingstermijn" in het derde pane (keuze tussen "10 jaar" en "Oneindig"); en via drie knoppen onderaan die een grafische visualisatie tonen ("Verhoging vs. indexatie" voor het tijdspad van uw uitkering; "Effect dekkingsgraad" en "Effect werkgevers-bijdrage" als doorlopen over een parameterbereik), plus een vierde knop "Modelspecificatie" die een PDF-rapport opent met de formele uitwerking van het rekenmodel.',
      },
      {
        heading: 'STARTSITUATIE EN RESET',
        body: 'Bij eerste opening van de tool zijn alle parameters ingesteld op de SSPF-standaardwaarden: deelnemer 70 jaar man, jaarpensioen \u20ac 100.000, geen partner; fondsvermogen \u20ac 26.000 mln, dekkingsgraad 136,1%, bijstort \u20ac 500 mln, spreidingstermijn "Oneindig". U vult uw eigen gegevens in het bovenste pane in. De fondsparameters in het pane "Tekort of overschot" staan op de actuele SSPF-waarden. Zodra een fondsparameter afwijkt van de SSPF-standaardwaarde verschijnt in de header van dat pane een "Bewerkt"-label met een Reset-knop, waarmee alle cascade-componenten met één klik terug naar de fondsuitgangswaarden gaan. De uitvoerblokken worden hieronder besproken in dezelfde volgorde als zij in de calculator verschijnen.',
      },
      {
        heading: 'PANE "UW HUIDIGE PENSIOENAANSPRAAK"',
        body: 'Dit pane bevat de invoervelden voor uw persoonlijke gegevens en toont onderaan de huidige waarde van uw aanspraak, opgebouwd uit ouderdomspensioen en, indien van toepassing, partnerpensioen. Wiskundig is dit het meest robuuste blok: de annuïteits-mechaniek volgt rechtstreeks uit de AG2024-prognosetafel van het Koninklijk Actuarieel Genootschap (KAG) en de gekozen disconteringsvoet. De belangrijkste onzekerheidsbron is de ervaringssterfte-factor (in dit model 0,90, onderbouwd op CBS-gegevens voor het SSPF-inkomensprofiel maar zonder publiek beschikbare fondsspecifieke validatie); een lagere factor zou de waarde verhogen. De tweede onzekerheidsbron is de vlakke rekenrente versus de werkelijke rentetermijnstructuur (RTS) per looptijd zoals gepubliceerd door DNB. Voor een individu met correcte invoer is dit blok robuust in orde-van-grootte; absolute kalibratie tegen SSPF-administratie is niet mogelijk omdat die niet publiek is. De rekenrente is via de slider direct aanpasbaar voor wie de RTS-gevoeligheid wil verkennen.',
      },
      {
        heading: 'PANE "TEKORT OF OVERSCHOT"',
        body: 'Dit pane toont de cascade waarmee het beschikbare fondsvermogen na afsplitsing van wettelijke en bestemmingsreserves leidt tot het verdeelbare overschot dat via de standaardregel over deelnemers wordt verdeeld. De dominante onzekerheidsbron is de bundle-aftrekcascade zelf: het transitieplan beschrijft de bestemmingen (wettelijke reserves, RDR, compensatiedepot), maar niet de exacte allocatiebedragen op invaardatum. De tool gebruikt voor de cascade-componenten de waarden die SSPF in de publieke communicatie noemt (wettelijke reserves 2%, RDR \u20ac 500 mln, compensatiedepot \u20ac 400 mln), maar deze kunnen op de werkelijke invaardatum (1 januari 2027) afwijken van de stand die nu in de tool is opgenomen. Een tweede onzekerheidsbron is de dekkingsgraad zelf: de tool gebruikt de stand eind februari 2026 (136,1%); de werkelijke invaardekkingsgraad ligt op invaardatum vast. Beide onzekerheden zijn via de sliders in dit pane direct te verkennen; afwijkingen van de fondsstandaardwaarde zijn terug te zetten via de Reset-knop die dan verschijnt.',
      },
      {
        heading: 'PANE "UW PERSOONLIJK PENSIOENVERMOGEN NA INVAREN"',
        body: 'Dit pane toont in drie gekleurde regels onder elkaar hoe het persoonlijk pensioenvermogen tot stand komt, plus daaronder een regel die het jaarpensioen-equivalent aangeeft. Eerste regel (groen, "Uw huidige pensioenaanspraak"): identiek aan de uitkomst van het eerste pane; herhaald hier als startwaarde. Tweede regel (amber, "Uw aandeel verdeelbaar overschot"): toont wat aan uw huidige aanspraak wordt toegevoegd; per definitie het verschil van twee onzekere getallen, en daarmee relatief het meest gevoelig voor onnauwkeurigheid. Voor kleine verdeelbare overschotten kan een kleine absolute afwijking in één van beide invoergetallen een grote relatieve afwijking in het aandeel opleveren. Bij negatief saldo verandert het label naar "Uw aandeel verdeelbaar tekort". Derde regel (rood, "Uw persoonlijk pensioenvermogen", totaal na invaren): erft de onzekerheid van de twee voorgaande regels en voegt één modelaanname toe \u2014 de keuze van spreidingstermijn (de tool implementeert de keuze van SSPF voor levenslang via de keuzelijst-optie "Oneindig"). Een aanvullende structurele onzekerheid is de cohort-demografie: de tool gebruikt een voorinstelling "gesloten"; werkelijke SSPF-aantallen zijn niet publiek.',
      },
      {
        heading: 'JAARPENSIOEN-EQUIVALENT-REGEL',
        body: 'De regel onder de drie gekleurde regels ("\u2248 + \u20ac X extra ... per jaar pensioen levenslang") erft de onzekerheid van het aandeel verdeelbaar overschot en voegt één modelaanname toe: proportionele doorwerking van ouderdomspensioen en partnerpensioen onder de keuze van SSPF voor levenslange spreiding. Onder de wettelijke standaardspreiding van tien jaar zou deze proportionaliteit niet exact gelden (zie helptekst van dit veld en \u00a79 van de Modelspecificatie); de keuze van SSPF maakt de aanname robuust binnen de SSPF-context. Het helptekst-icoon naast deze regel bevat verdere uitleg over hoe het partnerpensioen meestijgt bij verhoging van het persoonlijk pensioenvermogen.',
      },
      {
        heading: 'KNOP "VERHOGING VS. INDEXATIE" (EERSTE KNOP)',
        body: 'Opent een pedagogische "wat-als"-grafiek. Toont de vlakke "ingevroren" uitkering na invaren versus een hypothetische voortzetting met indexatie. De werkelijke uitkeringspaden onder de Wtp zijn variabel (rendement, levensverwachting, solidariteits- of risicodelingsreserve-werking, lifecycle-mix per cohort) en niet door deze grafiek te voorspellen. Gebruik de grafiek strikt qua richting \u2014 voor het verkrijgen van inzicht in het kruispunt waarboven indexatie de vlakke uitkering inhaalt, niet als kwantitatieve voorspelling.',
      },
      {
        heading: 'KNOP "EFFECT DEKKINGSGRAAD" (TWEEDE KNOP)',
        body: 'Toont de gevoeligheid van het persoonlijk pensioenvermogen voor de invaardekkingsgraad over een doorlooptraject. De helling van de curve volgt direct uit de mechaniek van de standaardregel en is wiskundig hard; de absolute uitlees-waarden erven de onzekerheid van "Uw persoonlijk pensioenvermogen". Gebruik primair de helling, niet de absolute waarden.',
      },
      {
        heading: 'KNOP "EFFECT WERKGEVERS-BIJDRAGE" (DERDE KNOP)',
        body: 'De bijstort is door de gebruiker zelf in te stellen via slider in het tweede pane (0\u20132500 mln). De grafiek toont correct het effect van die specifieke bijstort op het persoonlijk pensioenvermogen. De staffel uit implementatieplan \u00a75.5 (\u20ac 500m bij dekkingsgraad \u2265135%, \u20ac 650m bij 130\u2013135%, \u20ac 850m bij 125\u2013130%) is bewust niet automatisch gekoppeld aan de dekkingsgraad-slider \u2014 de gebruiker stelt zelf de combinatie dekkingsgraad/bijstort in die hij/zij wil modelleren. Bij correcte handmatige invoer is de grafiek zowel qua richting als kwantitatief informatief.',
      },
      {
        heading: 'KNOP "MODELSPECIFICATIE" (VIERDE KNOP)',
        body: 'Opent een PDF met de formele uitwerking van wat de calculator doet \u2014 niet wat SSPF doet. Heeft zelf geen bandbreedte; geeft daarentegen de gebruiker (of een derde \u2014 actuaris, lid van het verantwoordingsorgaan, journalist) de mogelijkheid om de implementatie regel voor regel te toetsen.',
      },
      {
        heading: 'ONAFHANKELIJKE VERIFICATIE VIA ABN AMRO PENSIOENFONDS',
        body: `Een concreet referentiepunt voor de plausibiliteit van de calculator-uitkomsten is de vergelijking met publieke deelnemerscommunicatie van ABN AMRO Pensioenfonds (hierna: ABN). ABN heeft in zijn transitieplan (17 oktober 2024) en implementatieplan (22 september 2025) per leeftijdscohort en dekkingsgraad een transparant overzicht van invaareffecten gepubliceerd; deze cijfers zijn tevens opgenomen in de uitspraak van het College voor de Rechten van de Mens d.d. 4 maart 2026 (oordeelnummer 2026-34). ABN hanteert de wettelijke standaardspreidingstermijn van tien jaar. Onderstaande twee tabellen tonen voor pensioengerechtigden bij invaardekkingsgraad 135% de procentuele verhoging van het persoonlijk pensioenvermogen op transitiedatum, berekend met de productie-rekenkern van deze calculator (versie ${RELEASE_VERSION}). Tabel A vergelijkt een scenario zonder partner met de publieke cohort-cijfers van ABN; Tabel B toont dezelfde berekening met partner volgens de SSPF-standaardwaarden.`,
      },
      {
        heading: 'TABEL A \u2014 ZONDER PARTNER (VERGELIJKBAAR MET ABN-PUBLIEKE COHORT-CIJFERS)',
        tableHeaders: ['Leeftijd', 'ABN spreiding 10 jaar (publiek)', 'SSPF spreiding 10 jaar (rekenkern)', 'SSPF spreiding oneindig (rekenkern, keuze SSPF)', '\u0394 10 \u2192 oneindig'],
        tableRows: [
          ['65 jaar', '24%', '+29,7%', '+28,8%', '\u22120,9 pp'],
          ['75 jaar', '20%', '+24,4%', '+19,5%', '\u22124,9 pp'],
          ['85 jaar', '17%', '+16,1%', '+11,3%', '\u22124,8 pp'],
          ['95 jaar', '12%', '+8,7%', '+5,9%', '\u22122,8 pp'],
        ],
      },
      {
        heading: 'TABEL B \u2014 MET PARTNER (VROUW 3J JONGER, PARTNERPENSIOEN \u20ac 70.000)',
        tableHeaders: ['Leeftijd', 'Partner', 'SSPF spreiding 10 jaar (rekenkern)', 'SSPF spreiding oneindig (rekenkern, keuze SSPF)', '\u0394 10 \u2192 oneindig'],
        tableRows: [
          ['65 jaar', '62V', '+31,8%', '+34,2%', '+2,4 pp'],
          ['75 jaar', '72V', '+27,8%', '+24,3%', '\u22123,5 pp'],
          ['85 jaar', '82V', '+20,5%', '+15,0%', '\u22125,4 pp'],
          ['95 jaar', '92V', '+11,8%', '+8,0%', '\u22123,7 pp'],
        ],
      },
      {
        heading: 'DRIE OBSERVATIES BIJ DEZE CIJFERS \u2014 LEERZAME WAARDE VAN DE TOOL',
        body: 'Eerste observatie: in de vergelijking zonder partner (Tabel A) komt de SSPF-rekenkern voor jongere pensioencohorten hoger uit dan ABN (+5,7 pp bij 65 jaar, +4,4 pp bij 75 jaar), is nagenoeg gelijk bij 85 jaar, en komt lager uit bij 95 jaar (\u22123,3 pp). Dat afwijkende patroon \u2014 geen uniforme over- of onderschatting \u2014 is verklaarbaar door fondsspecifieke parameters waarop SSPF en ABN substantieel verschillen: SSPF heeft een kleinere bundle-aftrek (cascade-gewogen 6,71% versus de door ABN gerapporteerde circa 10%) plus een transitiebijdrage van \u20ac 500 mln die ABN niet kent in deze vorm. Voor oudere cohorten domineren demografie en spreidingsmechaniek. Tweede observatie: in Tabel A is het effect van spreiding 10 jaar \u2192 spreiding oneindig leeftijdsafhankelijk: bijna verwaarloosbaar bij 65 jaar (\u22120,9 pp), groter rond 75\u201385 jaar (circa \u22125 pp), kleiner bij 95 jaar (\u22122,8 pp). Het zwaartepunt van het nadeel ligt bij de cohorten waar de SSPF-pensioenverplichting concentreert (75\u201385 jarigen). Derde observatie \u2014 de "verrassing": in Tabel B met partner draait het teken om voor het jongste cohort: voor een 65-jarige met 62-jarige partner geeft spreiding oneindig een hogere opslag dan spreiding 10 jaar (+2,4 pp voordeel in plaats van nadeel). Verklaring: het zwaartepunt van de partnerpensioen-kasstromen ligt ver in de toekomst (15 tot 30 jaar \u2014 periode waarin de partner nog leeft na overlijden van de gepensioneerde). Onder spreiding 10 jaar wordt die kasstroom volledig meegenomen in de aanpassing; onder spreiding oneindig fractioneel \u2014 maar de schalingsfactor is dan navenant hoger om hetzelfde fondsvermogen te verdelen. Voor lange horizonnen \u2014 die een jonge partner garandeert \u2014 werkt spreiding oneindig dan netto gunstig uit. Deze derde observatie illustreert de leerzame waarde van de tool: de claim dat "alle pensioengerechtigden worden benadeeld door de spreidingskeuze" is een te simpele samenvatting; de werkelijkheid is leeftijds- en partnersituatie-afhankelijk.',
      },
      {
        heading: 'TOT SLOT BIJ DEZE VERGELIJKING',
        body: 'Het feit dat ABN een dergelijke transparante cohort-tabel überhaupt publiek heeft gemaakt, terwijl SSPF cohort-specifieke doorrekeningen niet beschikbaar stelt aan zijn deelnemers, raakt de kern van het probleem dat deze tool aan de orde stelt. Een fondsdeelnemer bij ABN kan zonder hulpmiddelen zien wat hij of zij ongeveer kan verwachten; een SSPF-deelnemer is voor diezelfde informatie aangewezen op een onafhankelijke reconstructie zoals deze calculator.',
      },
      // ─── §5 ───
      {
        heading: '5. WAT U WEL UIT DEZE TOOL KUNT HALEN',
        body: 'Ondanks de in \u00a73 en \u00a74 benoemde beperkingen biedt de tool naar de mening van de auteur drie soorten waarde. Eerste waarde \u2014 begrip van de mechaniek: de tool toont wat de standaardregel uit Bijlage 2a Regeling Pensioenwet doet, welke parameters daarin een rol spelen, en hoe dekkingsgraad, transitiebijdrage en spreidingstermijn op elkaar inwerken. Een SSPF-deelnemer die anders alleen een eindbedrag in een transitiebrief zou zien, kan met deze tool zelfstandig nagaan welke stappen dat eindbedrag opbouwen. Tweede waarde \u2014 gevoeligheidsbesef: de drie visualisatie-knoppen, in combinatie met de sliders in de drie panes, laten zien aan welke parameters de uitkomst gevoelig is en aan welke niet. Derde waarde \u2014 gespreksvoorbereiding: met een richtindicatie van de orde van grootte kan de gebruiker het gesprek aangaan met SSPF, met collega\'s, in het verantwoordingsorgaan, in de ALV van Voeks of een andere belangenvereniging, of in correspondentie met DNB. De tool helpt om gerichte vragen te formuleren over de keuzes die SSPF in het transitie- en implementatieplan heeft gemaakt \u2014 niet om die keuzes te bestrijden zonder feitelijke basis, maar om ze toetsbaar te maken. Bij elk van deze drie soorten waarde geldt dat de tool een hulpmiddel is om vragen scherper te stellen, niet om ze definitief te beantwoorden.',
      },
      // ─── §6 ───
      {
        heading: '6. WAT U EXPLICIET NIET UIT DEZE TOOL KUNT HALEN',
        body: 'De tool is niet ontworpen voor andere pensioenfondsen dan SSPF. Binnen de SSPF-context geldt het volgende. De tool geeft geen voorspelling van uw werkelijke pensioenuitkering per maand of jaar na invaren \u2014 die wordt bepaald door SSPF op basis van de definitieve invaardekkingsgraad, de werkelijke fondsbalans op invaardatum, en uw individuele aanspraak zoals geregistreerd in de pensioenadministratie. Evenmin levert de tool een voorspelling over het verloop van uw pensioen in de tijd. Voor een bezwaarprocedure biedt de tool geen onderbouwing: onder de Wtp is een individueel bezwaarrecht tegen invaren wettelijk niet voorzien; de besluitvorming is collectief via sociale partners en het fondsbestuur, met toetsing door DNB op evenwichtigheid voor groepen, niet voor individuen. Wel kan de tool dienen als rekenkundige onderbouwing voor een zienswijze richting DNB of een vraag aan het fondsbestuur. Een grondslag voor financiële planning of individuele beslissingen omtrent eerder stoppen met werken, partnerverlof, aanvullende verzekeringen of fiscale optimalisatie wordt evenmin geboden. Voor dat soort beslissingen zijn de transitiebrief van SSPF, persoonlijk financieel advies van een gecertificeerd adviseur, en (waar relevant) overleg met uw werkgever of een belastingadviseur de juiste bronnen. Niet inbegrepen is informatie over de evenwichtigheidstoets die SSPF tussen verschillende cohorten heeft uitgevoerd. Die toets vereist toegang tot transitiematen (netto profijt per cohort, pensioenverwachting in goed-mediaan-slechtweer-scenario\'s, gemiddelde kortingskans over 15 jaar) die in het implementatieplan zijn opgenomen voor de SSPF-gekozen spreiding maar niet vergelijkend zijn doorgerekend voor andere parameterkeuzes \u2014 een aspect dat in de zienswijze aan DNB van 2 mei 2026 uitdrukkelijk wordt gevraagd. Tot slot ontbreekt informatie over fondskeuzes die buiten de standaardregel vallen, zoals de zogenoemde "zachte landing" of egalisatie-correctie binnen het cohort gepensioneerden, de exacte toepassing van de 67%-randvoorwaarde uit artikel 150n lid 4 Pensioenwet, en de wijze waarop de RDR na invaren wordt aangewend ter demping van kortingen.',
      },
      // ─── §7 ───
      {
        heading: '7. BRONNEN EN VERSIES',
        body: 'Wet- en regelgeving: de Wtp (Staatsblad 2023, 217), de Pensioenwet zoals gewijzigd door de Wtp, het Besluit uitvoering Pensioenwet en Wet verplichte beroepspensioenregeling (specifiek artikel 46 lid 2), de Regeling Pensioenwet en Wet verplichte beroepspensioenregeling met name Bijlage 2a (de "standaardregel"; laatstelijk gewijzigd Staatscourant 2025, 15094), en de Q&A "Onderbouwing spreidingstermijn standaardregel" gepubliceerd door DNB op 23 juni 2025. Toezichts- en sectordocumenten: de DNB-factsheet "Omrekenmethoden en aanwenden vermogen pensioenfonds bij invaren", het servicedocument van de Pensioenfederatie over nabestaandenpensioen onder de Wtp, en de KAG-prognosetafels AG2024 (publicatie 12 september 2024). SSPF-specifieke documenten: het transitieplan, het op 15 juli 2025 vastgestelde Wtp-implementatieplan SSPF, de SSPF-presentatie van 14 april 2026, en het SSPF-jaarverslag 2024. Niet-publieke documenten waar SSPF wel over beschikt en die de tool niet kan benutten: de ABTN, de individuele pensioenadministratie per deelnemer, en de cohort-specifieke transitiematen. Vergelijkende bronnen: het ABN AMRO Pensioenfonds-transitieplan van 17 oktober 2024, het ABN AMRO Pensioenfonds-implementatieplan van 22 september 2025, en de uitspraak van het College voor de Rechten van de Mens van 4 maart 2026 (oordeelnummer 2026-34). Analyses en commentaar: Willis Towers Watson, "Uiteenlopende invullingen van de eerbiediging van partnerpensioen" in Pensioen Update (februari 2025); Ortec Finance, "De standaardmethode voor invaren wordt de norm" en "Spreidingsperiode bij toepassing standaardmethode"; diverse publieke transitie-communicaties van Nederlandse pensioenfondsen (Pensioenfonds Zorg en Welzijn, PMT, bpfBOUW, PME, ABP en andere) ten behoeve van vergelijking. Versies en peildatums: de calculator-versie en de bouwdatum staan onderaan elk scherm. De rekenkern krijgt een nieuwe versie bij elke wijziging; de modelspecificatie (toegankelijk via de knop "Modelspecificatie") volgt dezelfde versionering. De ingebedde modelspecificatie-PDF wordt periodiek bijgewerkt en kan tijdelijk een versie achterlopen op de UI. De peildatum voor SSPF-fondsgegevens (dekkingsgraad 136,1%, fondsvermogen \u20ac 26.000 mln) is eind februari 2026. De werkelijke invaardatum is per 1 januari 2027; de calculator-uitkomsten zijn een momentopname die op invaardatum afwijkt naarmate de dekkingsgraad of fondsbalans zich in de tussentijd anders ontwikkelt.',
      },
      // ─── §8 ───
      {
        heading: '8. CONTACT EN FEEDBACK',
        body: 'Voor inhoudelijke opmerkingen, ontdekte fouten of suggesties voor verbetering kunt u contact opnemen via het e-mailadres in de footer van deze tool. De auteur waardeert correcties, parameter-bronverwijzingen en gevoeligheidsanalyses die de tool verder kunnen verbeteren, en stelt updates van de tool in het vooruitzicht zodra significante nieuwe publieke informatie beschikbaar komt \u2014 bijvoorbeeld na de DNB-uitspraak over de SSPF-invaarmelding, of na publicatie van de individuele transitiebrieven aan SSPF-deelnemers per 1 januari 2027. Voor uw eigen pensioenvragen, vragen over uw werkelijke aanspraak, of bezwaren tegen onderdelen van uw transitie verwijst de auteur naar SSPF, via de kanalen die het fonds zelf aanwijst. Deze tool is geen vervanging van SSPF-communicatie en biedt geen mogelijkheid om individuele dossiers te behandelen. De drie documenten en het LinkedIn-artikel zoals genoemd in \u00a72 zijn opvraagbaar via hetzelfde e-mailadres.',
      },
    ],
  }),
}

// helpIcon-renderer importeert uit ui.shared (gedeeld met ui.m2.ts)

// ============================================================================
// Render — casual scherm 1 + 2
// ============================================================================

function renderCasual(): string {
  const deelnemerFields = collectFields(M1.deelnemer, 'M1.deelnemer')
  // v3.0.11: x0 (leeftijd) en pen (pensioen) renderen we als sliders in een
  // eigen 2-koloms grid bovenaan; de rest blijft normale form-velden.
  // v3.0.12: ook y0 (partnerpensioen), x_partner (partner-leeftijd) en g_y
  // (partner-geslacht) krijgen een eigen partner-block met sliders, hidden
  // wanneer heeftPartner=false.
  // v3.0.58: g (deelnemer-geslacht) uit casualInputs filteren — hoort bij
  // geboortedatum (sterftekansen-context), wordt onder de date-input gerenderd.
  // v3.0.60: pen_laag en x_knip eveneens filteren — die worden door het
  // hooglaag-block gerenderd, niet door de generieke schema-render. Eerder
  // verschenen ze als "PEN_LAAG / X_KNIP optioneel"-form-velden onderaan.
  // v3.0.69: heeftPartner ook filteren — wordt apart als Ja/Nee-radio
  // gerenderd direct boven het partner-block (i.p.v. checkbox in form).
  const partnerFieldNames = new Set([
    'x0', 'pen', 'y0', 'x_partner', 'g_y', 'hooglaagActief', 'g',
    'pen_laag', 'x_knip', 'heeftPartner',
  ])
  const casualInputs = deelnemerFields
    .filter((f) => f.meta.display === 'hoofdpad')
    .filter((f) => !partnerFieldNames.has(f.name))
    .map(renderField)
    .join('\n')

  const eurFmt = (n: number) => '€ ' + Math.round(n).toLocaleString('nl-NL')

  // v3.0.52: leeftijd verplaatst van label-strong (kleurenthema rood)
  // naar caption onder de date-input. Voegt expliciet "Leeftijd:"-label
  // toe en kleurt neutraal (txt2 i.p.v. red).
  // v3.0.53: date-input naast label op één regel (zoals pen/DG-stand).
  const ageX0 = state.deelnemer.x0
  const ageX0Years = Math.floor(ageX0)
  const ageX0Months = Math.floor((ageX0 - ageX0Years) * 12)
  const leeftijdPensioenSliders = `
    <div class="slider-pair">
      <div class="slider-control">
        <label for="in-dob" class="slider-label-stand">
          <span>Uw geboortedatum</span>
          <span class="dob-wrap">
            <input type="date" id="in-dob" data-field="dob" class="dob-input"
                   min="1920-01-01" max="${PEILDATUM}"
                   value="${state.deelnemer.dob}">
          </span>
        </label>
        <div class="field-inline-radio" data-field-row="g">
          <label for="in-g" class="inline-radio-label">Geslacht</label>
          <select id="in-g" class="dropdown-pill" data-field="g">
            <option value="M" ${state.deelnemer.g === 'M' ? 'selected' : ''}>Man</option>
            <option value="V" ${state.deelnemer.g === 'V' ? 'selected' : ''}>Vrouw</option>
          </select>
        </div>
        <div class="age-caption" data-age-for="in-dob">
          Leeftijd: ${ageX0Years} jaar${ageX0Months ? ` ${ageX0Months} mnd` : ''}
        </div>
        <div class="lifeexp-caption" data-lifeexp-for="in-dob">
          ${state.lastM1 ? `Verwachte sterfleeftijd: ${num(state.lastM1.lifeExp_x0, 1)} jaar` : ''}
        </div>
        <div class="field-inline-radio" data-field-row="hooglaag">
          <label for="in-hooglaag" class="inline-radio-label">Hoog-laag-uitkering</label>
          <select id="in-hooglaag" class="dropdown-pill" data-field="hooglaagActief">
            <option value="false" ${state.deelnemer.hooglaagActief ? '' : 'selected'}>Nee</option>
            <option value="true" ${state.deelnemer.hooglaagActief ? 'selected' : ''}>Ja</option>
          </select>
        </div>
      </div>
      <div class="slider-control">
        <label for="in-pen" class="slider-label-stand">
          <span><span data-pen-label>${state.deelnemer.hooglaagActief ? 'Pensioen tot knip' : 'U krijgt zolang u leeft'}</span></span>
          <strong>${eurFmt(state.deelnemer.pen)}</strong>
        </label>
        <input type="range" id="in-pen" data-field="pen"
               min="0" max="200000" step="500"
               value="${state.deelnemer.pen}">
        <div class="slider-markers">
          <span class="marker-min">€ 0</span>
          <span class="marker-mid">€ 100.000</span>
          <span class="marker-max">€ 200.000</span>
        </div>
      </div>
    </div>
  `

  // v3.0.12: partner-block — twee sliders + dropdown, allemaal hidden wanneer geen partner
  // v3.0.51: x_partner slider → geboortedatum-input
  // v3.0.99: heeftPartner-dropdown verhuisd naar binnen partnerBlock; child-
  // velden in een .partner-fields wrapper die [hidden] krijgt wanneer
  // heeftPartner=false. partnerBlock zelf blijft altijd zichtbaar (toggle).
  const partnerFieldsHidden = state.deelnemer.heeftPartner ? '' : ' hidden'
  const xPartnerVal = state.deelnemer.x_partner ?? 65
  const xPartnerYears = Math.floor(xPartnerVal)
  const xPartnerMonths = Math.floor((xPartnerVal - xPartnerYears) * 12)
  const dobPartner = state.deelnemer.dob_partner ?? '1961-05-08'
  const y0 = state.deelnemer.y0 ?? Math.round(state.deelnemer.pen * 0.7)
  const partnerBlock = `
    <div class="partner-block" data-partner-block>
      <div class="field-inline-radio" data-field-row="heeftPartner">
        <label for="in-heeftPartner" class="inline-radio-label">Heeft u een partnerpensioen?</label>
        <select id="in-heeftPartner" class="dropdown-pill" data-field="heeftPartner">
          <option value="false" ${state.deelnemer.heeftPartner ? '' : 'selected'}>Nee</option>
          <option value="true" ${state.deelnemer.heeftPartner ? 'selected' : ''}>Ja</option>
        </select>
      </div>
      <div class="partner-fields"${partnerFieldsHidden}>
      <div class="slider-pair" data-field-row="x_partner">
        <div class="slider-control">
          <label for="in-dob-partner" class="slider-label-stand">
            <span>Geboortedatum partner</span>
            <span class="dob-wrap">
              <input type="date" id="in-dob-partner" data-field="dob_partner" class="dob-input"
                     min="1920-01-01" max="${PEILDATUM}"
                     value="${dobPartner}">
            </span>
          </label>
          <div class="field-inline-radio" data-field-row="g_y">
            <label for="in-g_y" class="inline-radio-label">Geslacht</label>
            <select id="in-g_y" class="dropdown-pill" data-field="g_y">
              <option value="M" ${state.deelnemer.g_y === 'M' ? 'selected' : ''}>Man</option>
              <option value="V" ${state.deelnemer.g_y === 'V' ? 'selected' : ''}>Vrouw</option>
            </select>
          </div>
          <div class="age-caption" data-age-for="in-dob-partner">
            Leeftijd: ${xPartnerYears} jaar${xPartnerMonths ? ` ${xPartnerMonths} mnd` : ''}
          </div>
          <div class="lifeexp-caption" data-lifeexp-for="in-dob-partner">
            ${state.lastM1 && state.lastM1.lifeExp_partner !== null ? `Verwachte sterfleeftijd: ${num(state.lastM1.lifeExp_partner, 1)} jaar` : ''}
          </div>
        </div>
        <div class="slider-control" data-field-row="y0">
          <label for="in-y0" class="slider-label-stand">
            <span>Uw partner krijgt na uw overlijden</span>
            <strong>${eurFmt(y0)}</strong>
          </label>
          <input type="range" id="in-y0" data-field="y0"
                 min="0" max="200000" step="500"
                 value="${y0}">
          <div class="slider-markers">
            <span class="marker-min">€ 0</span>
            <span class="marker-mid">€ 100.000</span>
            <span class="marker-max">€ 200.000</span>
          </div>
        </div>
      </div>
      </div>
    </div>
  `

  const renteSliderHtml = `
    <div class="rente-control slider-control">
      <label for="in-r" class="slider-label-stand">
        <span>Rekenrente ${helpIcon('r')}</span>
        <strong>${pct(state.parameters_m1.r)}</strong>
      </label>
      <input type="range" id="in-r"
             min="0" max="5" step="0.1"
             value="${state.parameters_m1.r * 100}">
      <div class="slider-markers">
        <span class="marker-min">0%</span>
        <span class="marker-mid">2,5%</span>
        <span class="marker-max">5%</span>
      </div>
    </div>
  `

  // M2-blok: alleen als M2-output beschikbaar
  let m2Block: string
  if (state.lastM2Error) {
    m2Block = `<div class="pane casual pane-m2">
      <h2>Uw persoonlijk pensioenvermogen na invaren</h2>
      <div class="error">Er ging iets mis bij de berekening: ${escapeHtml(state.lastM2Error)}</div>
    </div>`
  } else if (state.lastM1 && state.lastM2 && state.parameters_m2.fondsvermogen !== null) {
    const m2KPI = renderM2KPI(
      state.lastM1,
      state.lastM2,
      state.deelnemer.pen
    )
    const m2Sliders = renderM2Sliders(state.parameters_m2)
    m2Block = `
      <div class="pane casual pane-m2">
        <h2>Uw persoonlijk pensioenvermogen na invaren</h2>
        ${m2Sliders}
        <div class="m2-output">${m2KPI}</div>
      </div>
    `
  } else {
    m2Block = `<div class="pane casual pane-m2">
      <h2>Uw persoonlijk pensioenvermogen na invaren</h2>
      <p>Vul eerst de gegevens hierboven in.</p>
    </div>`
  }

  // v3.0.79: M1/2-pane "Wat is er te verdelen?". Cascade-tabel met inline-
  // sliders voor 5 componenten (fondsvermogen, bijstort, wettelijk%, RDR,
  // compdepot) plus DG (verhuist hierheen vanuit M2). Per slider een
  // afwijking-marker als de waarde van fonds-default afwijkt; reset-knop
  // onderaan om alles naar defaults terug te zetten.
  const co = state.cascadeOverrides
  const cf = FONDS.aanwendingsCascade
  const m2sf = FONDS.m2
  const m2s = state.parameters_m2
  const fondsvermogenAfwijkt = m2s.fondsvermogen !== m2sf.fondsvermogen
  const bijstortAfwijkt = m2s.bijstort !== m2sf.bijstort
  const dgAfwijkt = m2s.dekkingsgraad !== m2sf.dekkingsgraad
  const wettelijkAfwijkt = cf ? co.wettelijkeReservesPct !== cf.wettelijkeReservesPct : false
  const rdrAfwijkt = cf ? co.rdrBedrag !== cf.rdrBedrag : false
  const compdepotAfwijkt = cf ? co.compensatiedepotBedrag !== cf.compensatiedepotBedrag : false
  const ergensAfwijking = fondsvermogenAfwijkt || bijstortAfwijkt || dgAfwijkt
                       || wettelijkAfwijkt || rdrAfwijkt || compdepotAfwijkt

  // afgeleide getallen — v3.0.83: nieuwe cascade-volgorde
  //   Eerst vpv-aftrek (= 100% verplichtingen weggenomen op basis van DG),
  //   dan tekort/overschot, dan plussen en minnen, dan verdeelbaar overschot.
  // M = totaal-verdeelbaar (vpv + verdeelbaar overschot) blijft onveranderd
  // engine-input via vpvAftrekPct in recompute(). De cascade-presentatie is
  // hier alleen visueel anders gepresenteerd.
  // v3.0.94: vpvDisplay uit vpvTotal-anker.
  const vpvDisplay = m2s.vpvTotal > 0 ? m2s.vpvTotal : m2s.fondsvermogen / m2s.dekkingsgraad
  const tekortOverschot = m2s.fondsvermogen - vpvDisplay   // bruto, vóór reserves
  const wettelijkEur = co.wettelijkeReservesPct * vpvDisplay
  const verdeelbaarOverschot = tekortOverschot + m2s.bijstort
                              - wettelijkEur - co.rdrBedrag - co.compensatiedepotBedrag
  const isTekort = tekortOverschot < 0
  const isOverschotNegatief = verdeelbaarOverschot < 0

  const afwijkMarker = (afwijkt: boolean) =>
    afwijkt ? '<span class="afwijk-marker" title="Afwijking van fonds-default">●</span>' : ''

  const m12Block = `
    <div class="pane casual pane-m12">
      <h2>Tekort of overschot${ergensAfwijking ? ` <span class="pane-afwijk-banner">Bewerkt</span><button type="button" class="reset-cascade-btn" id="reset-cascade-btn">Reset</button>` : ''}</h2>

      <div class="cascade-table">
        <div class="cascade-row cascade-input">
          <div class="cascade-label">Fondsvermogen ${afwijkMarker(fondsvermogenAfwijkt)}</div>
          <div class="cascade-val"><strong>€ ${eur(m2s.fondsvermogen)} mln</strong></div>
          <input type="range" class="cascade-slider" data-co="fondsvermogen"
                 min="20000" max="32000" step="100" value="${m2s.fondsvermogen}">
          <div class="slider-markers cascade-markers">
            <span class="marker-min">€ 20.000 mln</span>
            <span class="marker-mid">€ 26.000 mln</span>
            <span class="marker-max">€ 32.000 mln</span>
          </div>
        </div>
        <div class="cascade-row cascade-context">
          <div class="cascade-label">Dekkingsgraad ${afwijkMarker(dgAfwijkt)}</div>
          <div class="cascade-val"><strong>${pct(m2s.dekkingsgraad, 1)}</strong></div>
          <input type="range" class="cascade-slider" data-co="dekkingsgraad"
                 min="1.00" max="1.70" step="0.01" value="${m2s.dekkingsgraad}">
          <div class="slider-markers cascade-markers">
            <span class="marker-min">100%</span>
            <span class="marker-mid">136%</span>
            <span class="marker-max">170%</span>
          </div>
        </div>
        <div class="cascade-row cascade-minus">
          <div class="cascade-label">− Pensioenverplichtingen (vpv)</div>
          <div class="cascade-val"><strong>€ ${eur(Math.round(vpvDisplay))} mln</strong></div>
        </div>
        <div class="cascade-row cascade-subtotal ${isTekort ? 'cascade-negatief' : ''}">
          <div class="cascade-label">= ${isTekort ? 'Tekort' : 'Overschot'}</div>
          <div class="cascade-val"><strong>${isTekort ? '−' : ''} € ${eur(Math.abs(Math.round(tekortOverschot)))} mln</strong></div>
        </div>
        <div class="cascade-row cascade-plus">
          <div class="cascade-label">+ Transitiebijdrage werkgever ${helpIcon('bijstort')} ${afwijkMarker(bijstortAfwijkt)}</div>
          <div class="cascade-val"><strong>€ ${eur(m2s.bijstort)} mln</strong></div>
          <input type="range" class="cascade-slider" data-co="bijstort"
                 min="0" max="2500" step="50" value="${m2s.bijstort}">
          <div class="slider-markers cascade-markers">
            <span class="marker-min">€ 0</span>
            <span class="marker-mid">€ 1.250 mln</span>
            <span class="marker-max">€ 2.500 mln</span>
          </div>
        </div>
        <div class="cascade-row cascade-minus">
          <div class="cascade-label">− Wettelijke reserves ${afwijkMarker(wettelijkAfwijkt)}</div>
          <div class="cascade-val"><strong>${pct(co.wettelijkeReservesPct, 1)} (€ ${eur(Math.round(wettelijkEur))} mln)</strong></div>
          <input type="range" class="cascade-slider" data-co="wettelijkeReservesPct"
                 min="0" max="0.05" step="0.001" value="${co.wettelijkeReservesPct}">
          <div class="slider-markers cascade-markers">
            <span class="marker-min">0%</span>
            <span class="marker-mid">2,5%</span>
            <span class="marker-max">5%</span>
          </div>
        </div>
        <div class="cascade-row cascade-minus">
          <div class="cascade-label">− Risicodelingsreserve ${afwijkMarker(rdrAfwijkt)}</div>
          <div class="cascade-val"><strong>€ ${eur(co.rdrBedrag)} mln</strong></div>
          <input type="range" class="cascade-slider" data-co="rdrBedrag"
                 min="0" max="1500" step="50" value="${co.rdrBedrag}">
          <div class="slider-markers cascade-markers">
            <span class="marker-min">€ 0</span>
            <span class="marker-mid">€ 750 mln</span>
            <span class="marker-max">€ 1.500 mln</span>
          </div>
        </div>
        <div class="cascade-row cascade-minus">
          <div class="cascade-label">− Compensatiedepot ${afwijkMarker(compdepotAfwijkt)}</div>
          <div class="cascade-val"><strong>€ ${eur(co.compensatiedepotBedrag)} mln</strong></div>
          <input type="range" class="cascade-slider" data-co="compensatiedepotBedrag"
                 min="0" max="1000" step="50" value="${co.compensatiedepotBedrag}">
          <div class="slider-markers cascade-markers">
            <span class="marker-min">€ 0</span>
            <span class="marker-mid">€ 500 mln</span>
            <span class="marker-max">€ 1.000 mln</span>
          </div>
        </div>
        <div class="cascade-row cascade-total ${isOverschotNegatief ? 'cascade-negatief' : ''}">
          <div class="cascade-label">= ${isOverschotNegatief ? 'Verdeelbaar tekort' : 'Verdeelbaar overschot'}</div>
          <div class="cascade-val"><strong>${isOverschotNegatief ? '−' : ''} € ${eur(Math.abs(Math.round(verdeelbaarOverschot)))} mln</strong></div>
        </div>
      </div>
    </div>
  `

  // v3.0.77: build-time-fondsinjectie betekent altijd één fonds; multi-fonds-
  // render is uit deze codebase verdwenen omdat een tweede fonds een aparte
  // build krijgt.
  // v3.0.95: "Mijn pensioenfonds"-pane verwijderd; fondsnaam staat in topline
  // header (v3.0.102+), fonds-parameters in audit-rapport sectie 4.

  // v3.0.57: hoog-laag-block. Toggle (Ja/Nee radio-pair) + bij Ja een
  // pen_laag-slider en geboortedatum-knip. Verleden-knip (dob_knip ≤ vandaag)
  // toont waarschuwing en pauzeert M2 (in recompute zet x_knip op null).
  const hl = state.deelnemer
  const hlActive = hl.hooglaagActief
  const dobKnipDefault = (() => {
    const peil = new Date(PEILDATUM)
    peil.setFullYear(peil.getFullYear() + 10)
    return peil.toISOString().slice(0, 10)
  })()
  const dobKnipVal = hl.dob_knip ?? dobKnipDefault
  const penLaagVal = hl.pen_laag ?? Math.round(hl.pen * 0.8 / 500) * 500
  // v3.0.57: leeftijd op knip = x0 + (knipdatum - peildatum) jaren.
  // Niet ageFromDob, want die assumeert dob in verleden.
  const knipDateForAge = hl.dob_knip ?? dobKnipDefault
  const jarenTotKnip = (Date.parse(knipDateForAge) - Date.parse(PEILDATUM)) / (1000 * 60 * 60 * 24 * 365.25)
  const knipAgeRaw = hl.x0 + jarenTotKnip
  const knipY = Math.floor(knipAgeRaw)
  const knipM = Math.floor((knipAgeRaw - knipY) * 12)
  const knipInPast = hl.dob_knip !== null && (hl.x_knip === null) && hl.hooglaagActief
  // v3.0.63: toggle is verplaatst naar de DOB-kolom (onder geslacht-radio).
  // hlBlock is nu enkel het uitklap-paneel met pen_laag + dob_knip; verschijnt
  // wanneer state.deelnemer.hooglaagActief=true.
  const hlBlock = `
    <div class="hooglaag-fields"${hlActive ? '' : ' style="display:none"'}>
      <div class="slider-pair">
        <div class="slider-control">
          <label for="in-pen-laag" class="slider-label-stand">
            <span>Pensioen ná knip</span>
            <strong>${eurFmt(penLaagVal)}</strong>
          </label>
          <input type="range" id="in-pen-laag" data-field="pen_laag"
                 min="0" max="200000" step="500"
                 value="${penLaagVal}">
          <div class="slider-markers">
            <span class="marker-min">€ 0</span>
            <span class="marker-mid">€ 100.000</span>
            <span class="marker-max">€ 200.000</span>
          </div>
        </div>
        <div class="slider-control">
          <label for="in-dob-knip" class="slider-label-stand">
            <span>Datum waarop pensioen wijzigt</span>
            <span class="dob-wrap">
              <input type="date" id="in-dob-knip" data-field="dob_knip" class="dob-input"
                     min="${PEILDATUM}" max="2099-12-31"
                     value="${dobKnipVal}">
            </span>
          </label>
          <div class="age-caption" data-age-for="in-dob-knip">
            ${knipInPast
              ? '<span class="hooglaag-warn">Knip-datum ligt in het verleden — vul het bedrag dat u nu ontvangt in als pensioen en zet hoog-laag uit.</span>'
              : `Leeftijd op knip: ${knipY} jaar${knipM ? ` ${knipM} mnd` : ''}`}
          </div>
        </div>
      </div>
    </div>
  `

  return `
    <div class="pane casual pane-m1">
      <h2>Uw huidige pensioenaanspraak</h2>
      ${leeftijdPensioenSliders}
      ${hlBlock}
      ${partnerBlock}
      ${renteSliderHtml}
      <div class="output">${renderM1KPI()}</div>
    </div>
    ${m12Block}
    ${m2Block}
    <div class="pane casual pane-actions">
      <button type="button" id="indexed-btn" class="action-btn">
        Verhoging vs. indexatie
      </button>
      <button type="button" id="sensitivity-btn" class="action-btn">
        Effect dekkingsgraad
      </button>
      <button type="button" id="bijstort-btn" class="action-btn">
        Effect werkgevers-bijdrage
      </button>
      <button type="button" id="modelspec-btn" class="action-btn">
        Modelspecificatie
      </button>
    </div>
  `
}

// ============================================================================
// Help-modal: open/sluit en render
// ============================================================================

function openHelpModal(key: string): void {
  const builder = HELP_CONTENT[key]
  if (!builder) return
  const content = builder()
  const overlay = document.getElementById('help-modal-overlay')
  const titleEl = document.getElementById('help-modal-title')
  const bodyEl = document.getElementById('help-modal-body')
  if (!overlay || !titleEl || !bodyEl) return

  titleEl.textContent = content.title
  let html = ''
  if (content.currentValue) {
    html += `<p class="help-modal-current">${escapeHtml(content.currentValue)}</p>`
  }
  for (const sec of content.sections) {
    if (sec.heading) {
      html += `<h3 class="help-modal-section-h">${escapeHtml(sec.heading)}</h3>`
    }
    if ('rows' in sec) {
      // v3.0.38: tabulaire weergave van fondsparameters met "Aanpasbaar?"-kolom
      if (sec.intro) {
        html += `<p class="help-modal-section-body">${escapeHtml(sec.intro)}</p>`
      }
      html += `<table class="help-modal-params"><thead><tr><th scope="col">Parameter</th><th scope="col">Waarde</th><th scope="col">Aanpasbaar?</th></tr></thead><tbody>`
      for (const row of sec.rows) {
        const adj = row.adjustable
          ? `<span class="adj-yes" aria-label="Aanpasbaar">✓ ${escapeHtml(row.note ?? 'via UI')}</span>`
          : `<span class="adj-no" aria-label="Vast">· ${escapeHtml(row.note ?? 'Vast (fondsparameter)')}</span>`
        html += `<tr><td>${escapeHtml(row.label)}</td><td class="num">${escapeHtml(row.value)}</td><td>${adj}</td></tr>`
      }
      html += `</tbody></table>`
    } else if ('cascade' in sec) {
      // v3.0.45: aanwendings-cascade — visualiseert de keten-formule
      // (input + plus → subtotal − minus → total) met sign-prefix.
      if (sec.intro) {
        html += `<p class="help-modal-section-body">${escapeHtml(sec.intro)}</p>`
      }
      html += `<table class="help-modal-cascade"><tbody>`
      const signFor = (kind: CascadeRow['kind']): string => {
        if (kind === 'plus') return '+'
        if (kind === 'minus') return '−'
        if (kind === 'subtotal') return '='
        if (kind === 'total') return '='
        return ''
      }
      for (const row of sec.cascade) {
        const sign = signFor(row.kind)
        const noteHtml = row.note ? `<div class="casc-note">${escapeHtml(row.note)}</div>` : ''
        html += `<tr class="casc-${row.kind}"><td class="casc-sign">${sign}</td><td class="casc-label">${escapeHtml(row.label)}${noteHtml}</td><td class="casc-val num">${escapeHtml(row.value)}</td></tr>`
      }
      html += `</tbody></table>`
      if (sec.outro) {
        html += `<p class="help-modal-section-body casc-outro">${escapeHtml(sec.outro)}</p>`
      }
    } else if ('tableRows' in sec) {
      // v3.0.130: simpele tabel met headers + rijen, voor disclaimer-tabellen
      // (ABN-vergelijking). Alle cellen worden geëscaped.
      if (sec.intro) {
        html += `<p class="help-modal-section-body">${escapeHtml(sec.intro)}</p>`
      }
      html += `<table class="help-modal-simpletable"><thead><tr>`
      for (const h of sec.tableHeaders) {
        html += `<th scope="col">${escapeHtml(h)}</th>`
      }
      html += `</tr></thead><tbody>`
      for (const row of sec.tableRows) {
        html += `<tr>`
        for (const cell of row) {
          html += `<td>${escapeHtml(cell)}</td>`
        }
        html += `</tr>`
      }
      html += `</tbody></table>`
      if (sec.outro) {
        html += `<p class="help-modal-section-body">${escapeHtml(sec.outro)}</p>`
      }
    } else {
      html += `<p class="help-modal-section-body">${escapeHtml(sec.body)}</p>`
    }
  }
  // v3.0.131: optionele footer-link naar andere modal (bv. Privacy → Verantwoording)
  if (content.footerLink) {
    html += `<div class="help-modal-footer-link"><button type="button" class="help-modal-link-btn" data-help-link="${escapeHtml(content.footerLink.key)}">${escapeHtml(content.footerLink.label)} \u2192</button></div>`
  }
  bodyEl.innerHTML = html
  overlay.style.display = 'flex'
  // Focus de close-knop voor toetsenbord-toegankelijkheid
  const closeBtn = document.getElementById('help-modal-close') as HTMLButtonElement | null
  closeBtn?.focus()
}

function closeHelpModal(): void {
  const overlay = document.getElementById('help-modal-overlay')
  if (overlay) overlay.style.display = 'none'
}

// v3.0.119: gevoeligheidsgrafiek-modal. Hergebruikt overlay-patroon van help-
// modal maar eigen container vanwege wijdere grafiek-viewport (max-width 800px
// ipv 520px voor help-modal). v3.0.121: zelfde modal-container hergebruikt voor
// bijstort-grafiek; modal-titel en body verschillen per grafiek-type.
function openSensitivityModal(sweep: ReturnType<typeof runSweep>): void {
  const overlay = document.getElementById('sensitivity-modal-overlay')
  const titleEl = document.getElementById('sensitivity-modal-title')
  const bodyEl = document.getElementById('sensitivity-modal-body')
  if (!overlay || !bodyEl) return
  if (titleEl) titleEl.textContent = 'Hoe verandert uw aandeel met de dekkingsgraad?'
  bodyEl.innerHTML = renderSensitivityHTML(sweep)
  overlay.style.display = 'flex'
}

// v3.0.121: bijstort-modal. Zelfde container, andere titel + body.
// Activeert tooltip-handlers ná innerHTML-injectie omdat SVG-elementen
// pas dan in de DOM staan.
function openBijstortModal(sweep: ReturnType<typeof runBijstortSweep>): void {
  const overlay = document.getElementById('sensitivity-modal-overlay')
  const titleEl = document.getElementById('sensitivity-modal-title')
  const bodyEl = document.getElementById('sensitivity-modal-body')
  if (!overlay || !bodyEl) return
  if (titleEl) titleEl.textContent = 'Wat levert een hogere of lagere werkgevers-bijdrage op?'
  bodyEl.innerHTML = renderBijstortHTML(sweep)
  overlay.style.display = 'flex'
  // Activeer interactieve tooltip ná DOM-injectie
  attachBijstortTooltip(bodyEl, sweep)
}

// v3.0.125: indexed-modal. Zelfde container, andere titel + body.
// Geen tooltip-handlers — grafiek is statisch, twee analytische curves.
function openIndexedModal(sweep: ReturnType<typeof runIndexedSweep>): void {
  const overlay = document.getElementById('sensitivity-modal-overlay')
  const titleEl = document.getElementById('sensitivity-modal-title')
  const bodyEl = document.getElementById('sensitivity-modal-body')
  if (!overlay || !bodyEl) return
  if (titleEl) titleEl.textContent = 'Hoe verhoudt de verhoging zich tot indexatie over de tijd?'
  bodyEl.innerHTML = renderIndexedHTML(sweep)
  overlay.style.display = 'flex'
}

function closeSensitivityModal(): void {
  const overlay = document.getElementById('sensitivity-modal-overlay')
  if (overlay) overlay.style.display = 'none'
}

// v3.0.17: event-delegation — één click-handler op document, vangt zowel
// statische .help-icon (top-line) als dynamische (sliders/velden in #app).
// Wordt eenmalig in init() opgezet via attachGlobalHelpHandler.
let helpHandlerAttached = false
function attachGlobalHelpHandler(): void {
  if (helpHandlerAttached) return
  helpHandlerAttached = true
  document.addEventListener('click', (e) => {
    const target = e.target as HTMLElement
    // v3.0.22: vang zowel .help-icon (vraagteken-knoppen) als andere
    // knoppen met data-help-attribuut (bv. tekst-knop "Uitleg")
    // v3.0.131: ook data-help-link voor cross-modal-navigatie (Privacy → Verantwoording)
    const linkBtn = target.closest('[data-help-link]') as HTMLElement | null
    if (linkBtn) {
      e.preventDefault()
      e.stopPropagation()
      const key = linkBtn.dataset.helpLink
      if (key) openHelpModal(key)
      return
    }
    const btn = (target.closest('.help-icon') || target.closest('[data-help]')) as HTMLElement | null
    if (!btn) return
    e.preventDefault()
    e.stopPropagation()
    const key = btn.dataset.help
    if (key) openHelpModal(key)
  })
}

function attachHelpHandlers(): void {
  // v3.0.17: vervangen door attachGlobalHelpHandler in init(); deze functie
  // blijft een no-op voor backwards-compat met bestaande aanroepen vanuit render.
}

// ============================================================================
// Top-level render
// ============================================================================

function render(): void {
  const app = document.getElementById('app')
  if (!app) return

  // v3.0.92: audit is geen aparte view meer; toegankelijk via "Audit-rapport"-
  // knop in de pane-actions die een print-rapport opent (parallel aan
  // "Mijn rapport"). Geen view-toggle, geen toegangscode meer.
  // v3.0.109: persoonlijk- én actuarieel-overzicht-knoppen verwijderd uit
  // pane-actions; alleen "Modelspecificatie" resteert. ui.print.ts en
  // ui.audit-report.ts zijn nu unreachable code maar nog wel in src/ aanwezig
  // (cleanup pending).
  app.innerHTML = renderCasual() + renderFooter()
  attachHandlers()
}

// In-place updates voor performance
function updateOutputsInPlace(): void {
  const m1OutEl = document.querySelector('.pane-m1 .output')
  if (m1OutEl) m1OutEl.innerHTML = renderM1KPI()

  // v3.0.93: verwachte sterfleeftijd-captions onder DOB-inputs.
  // Sterfleeftijd hangt van leeftijd + geslacht af; herberekend door M1.
  const lifeExpDeelnemer = document.querySelector('[data-lifeexp-for="in-dob"]')
  if (lifeExpDeelnemer) {
    lifeExpDeelnemer.textContent = state.lastM1
      ? `Verwachte sterfleeftijd: ${num(state.lastM1.lifeExp_x0, 1)} jaar`
      : ''
  }
  const lifeExpPartner = document.querySelector('[data-lifeexp-for="in-dob-partner"]')
  if (lifeExpPartner) {
    lifeExpPartner.textContent = state.lastM1 && state.lastM1.lifeExp_partner !== null
      ? `Verwachte sterfleeftijd: ${num(state.lastM1.lifeExp_partner, 1)} jaar`
      : ''
  }

  const m2OutEl = document.querySelector('.pane-m2 .m2-output')
  if (m2OutEl && state.lastM1 && state.lastM2 && state.parameters_m2.fondsvermogen !== null) {
    m2OutEl.innerHTML = renderM2KPI(
      state.lastM1,
      state.lastM2,
      state.deelnemer.pen
    )
  } else if (m2OutEl && state.lastM2Error) {
    m2OutEl.innerHTML = `<div class="error">Fout bij M2: ${escapeHtml(state.lastM2Error)}</div>`
  }

  // Rente-slider label (live update na slider-input)
  const renteStrong = document.querySelector('.rente-control label.slider-label-stand strong')
  if (renteStrong) {
    renteStrong.textContent = pct(state.parameters_m1.r)
  }

  // v3.0.11: Leeftijd + pensioen-slider labels (live update)
  const x0Strong = document.querySelector('label[for="in-x0"] strong')
  if (x0Strong) {
    x0Strong.textContent = state.deelnemer.x0 + ' jaar'
  }
  const penStrong = document.querySelector('label[for="in-pen"] strong')
  if (penStrong) {
    penStrong.textContent = '€ ' + Math.round(state.deelnemer.pen).toLocaleString('nl-NL')
  }
  // v3.0.12: partner-slider labels
  const xpStrong = document.querySelector('label[for="in-x_partner"] strong')
  if (xpStrong) {
    xpStrong.textContent = (state.deelnemer.x_partner ?? 0) + ' jaar'
  }
  const y0Strong = document.querySelector('label[for="in-y0"] strong')
  if (y0Strong) {
    y0Strong.textContent = '€ ' + Math.round(state.deelnemer.y0 ?? 0).toLocaleString('nl-NL')
  }

  // M2-slider labels (in-place text update)
  const dgLabel = document.querySelector('label[for="m2-dekkingsgraad"] strong')
  if (dgLabel) {
    dgLabel.textContent = pct(state.parameters_m2.dekkingsgraad, 1)
  }
  const aftrLabel = document.querySelector('label[for="m2-vpvaftrekpct"] strong')
  if (aftrLabel) {
    // v3.0.38: NL-decimaalkomma (was toFixed(1) → "6.0%"; nu toLocaleString → "6,0%")
    aftrLabel.textContent =
      (state.parameters_m2.vpvAftrekPct * 100).toLocaleString('nl-NL', {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1,
      }) + '%'
  }
  // v3.0.27: spreidingN-stand-label (radio-group, niet-slider)
  // v3.0.110: dropdown ipv radio-group → toont waarde zelf, geen aparte
  // stand-label meer nodig; updater verwijderd.
}

function updatePartnerVisibility(): void {
  // v3.0.99: niet meer de hele partner-block verbergen — die bevat de
  // heeftPartner-dropdown die altijd zichtbaar moet zijn. In plaats daarvan
  // de .partner-fields wrapper [hidden] toggelen.
  const fields = document.querySelector('.partner-fields') as HTMLElement | null
  if (fields) {
    if (state.deelnemer.heeftPartner) {
      fields.removeAttribute('hidden')
    } else {
      fields.setAttribute('hidden', '')
    }
  }
}

function flashKPI(): void {
  // Flash beide KPI-cards (M1 + M2) bij Enter-bevestiging
  document.querySelectorAll('.kpi-card').forEach((card) => {
    const el = card as HTMLElement
    el.classList.remove('flash')
    void el.offsetWidth
    el.classList.add('flash')
  })
}

// ============================================================================
// Event handlers
// ============================================================================

function attachHandlers(): void {
  // rAF-fallback voor environments zonder requestAnimationFrame (jsdom-tests).
  const raf = typeof requestAnimationFrame !== 'undefined'
    ? requestAnimationFrame
    : (cb: FrameRequestCallback) => setTimeout(() => cb(0), 16) as unknown as number

  // v3.0.13: help-modal-knoppen
  attachHelpHandlers()

  // Debounced recompute
  let debouncePending: ReturnType<typeof setTimeout> | null = null
  const scheduleRecompute = () => {
    if (debouncePending) clearTimeout(debouncePending)
    debouncePending = setTimeout(() => {
      debouncePending = null
      recompute()
      updateOutputsInPlace()
    }, 150)
  }
  const immediateRecompute = () => {
    if (debouncePending) {
      clearTimeout(debouncePending)
      debouncePending = null
    }
    recompute()
    updateOutputsInPlace()
    flashKPI()
  }

  // Deelnemer-velden
  // v3.0.58: bind ook 'change' naast 'input'. Reden: Safari (en sommige
  // andere browsers) vuren 'input' niet altijd betrouwbaar voor radio-
  // wijzigingen, waardoor de hooglaagActief-toggle van Ja → Nee in echte
  // browser-context niet altijd werkt. 'change' vuurt wel, en de extra
  // call is goedkoop omdat scheduleRecompute debounced is.
  document.querySelectorAll('[data-field]').forEach((el) => {
    const handler = (e: Event) => {
      const target = e.target as HTMLInputElement | HTMLSelectElement
      const field = target.dataset.field as keyof AppState['deelnemer']
      const raw = target instanceof HTMLInputElement && target.type === 'checkbox'
        ? target.checked
        : target.value
      let val: unknown = raw
      if (typeof raw === 'string' && target instanceof HTMLInputElement && (target.type === 'number' || target.type === 'range')) {
        val = raw === '' ? null : Number(raw)
      }
      // v3.0.57: hooglaagActief is een Ja/Nee-keuze (value="true"/"false")
      // v3.0.69: heeftPartner ook (was checkbox).
      // v3.0.96: ook HTMLSelectElement-pad: Ja/Nee staan nu in een
      // dropdown-pill (was radio-pair).
      if ((field === 'hooglaagActief' || field === 'heeftPartner')
          && (target instanceof HTMLSelectElement
              || (target instanceof HTMLInputElement && target.type === 'radio'))) {
        val = raw === 'true'
      }
      ;(state.deelnemer as Record<string, unknown>)[field] = val

      if (field === 'heeftPartner') {
        // v3.0.96 partner-hydrate-fix: bij toggle naar true partner-velden
        // hydrateren vanuit null-defaults (zie default-state v3.0.95). Zonder
        // hydrate zou de partner-engine op null-leeftijd crashen.
        if (state.deelnemer.heeftPartner) {
          if (state.deelnemer.y0 === null) state.deelnemer.y0 = Math.round(state.deelnemer.pen * 0.7 / 500) * 500
          if (state.deelnemer.x_partner === null) state.deelnemer.x_partner = 65
          if (state.deelnemer.dob_partner === null) {
            state.deelnemer.dob_partner = dobForExactAge(65, PEILDATUM)
          }
        }
        updatePartnerVisibility()
        recompute()
        render()
        return
      }
      if (field === 'hooglaagActief') {
        // Toon/verberg hoog-laag fields in plaats van re-render
        const block = document.querySelector('.hooglaag-fields') as HTMLElement | null
        if (block) block.style.display = state.deelnemer.hooglaagActief ? '' : 'none'
        // v3.0.62: pen-label live aanpassen aan toggle-stand.
        const penLabel = document.querySelector('[data-pen-label]')
        if (penLabel) {
          penLabel.textContent = state.deelnemer.hooglaagActief
            ? 'Pensioen tot knip'
            : 'U krijgt zolang u leeft'
        }
        // Bij eerste activering vul defaults in als state nog null is
        if (state.deelnemer.hooglaagActief) {
          if (state.deelnemer.pen_laag === null) {
            state.deelnemer.pen_laag = Math.round(state.deelnemer.pen * 0.8 / 500) * 500
            const slider = document.getElementById('in-pen-laag') as HTMLInputElement | null
            if (slider) slider.value = String(state.deelnemer.pen_laag)
            const strong = document.querySelector('label[for="in-pen-laag"] strong')
            if (strong) strong.textContent = '€ ' + Math.round(state.deelnemer.pen_laag).toLocaleString('nl-NL')
          }
          if (state.deelnemer.dob_knip === null) {
            const peil = new Date(PEILDATUM)
            peil.setFullYear(peil.getFullYear() + 10)
            state.deelnemer.dob_knip = peil.toISOString().slice(0, 10)
            const dobEl = document.getElementById('in-dob-knip') as HTMLInputElement | null
            if (dobEl) dobEl.value = state.deelnemer.dob_knip
          }
        }
        recompute()
        updateOutputsInPlace()
        return
      }

      if (target instanceof HTMLSelectElement) {
        recompute()
        updateOutputsInPlace()
        return
      }

      // v3.0.6: radio-input (gender) ook immediate, geen debounce
      if (target instanceof HTMLInputElement && target.type === 'radio') {
        recompute()
        updateOutputsInPlace()
        return
      }

      // v3.0.51: date-input behoudt string-waarde; afgeleide leeftijd-label
      // wordt direct bijgewerkt voor zachte feedback (zonder recompute).
      // v3.0.52: leeftijd-caption staat nu onder de input ipv in label-strong.
      // v3.0.57: dob_knip krijgt eigen caption-tekst ("Leeftijd op knip") en
      // toont waarschuwing wanneer datum in verleden ligt.
      if (target instanceof HTMLInputElement && target.type === 'date') {
        ;(state.deelnemer as Record<string, unknown>)[field] = raw
        const caption = document.querySelector(`[data-age-for="${target.id}"]`)
        if (caption) {
          if (field === 'dob_knip') {
            // v3.0.57: leeftijd op knip = x0 + (knipdatum − peildatum) jaren.
            const inPast = String(raw) <= PEILDATUM
            if (inPast) {
              caption.innerHTML = '<span class="hooglaag-warn">Knip-datum ligt in het verleden — vul het bedrag dat u nu ontvangt in als pensioen en zet hoog-laag uit.</span>'
            } else {
              const jaren = (Date.parse(String(raw)) - Date.parse(PEILDATUM)) / (1000 * 60 * 60 * 24 * 365.25)
              const knipAge = state.deelnemer.x0 + jaren
              const knipY = Math.floor(knipAge)
              const knipM = Math.floor((knipAge - knipY) * 12)
              caption.textContent = `Leeftijd op knip: ${knipY} jaar${knipM ? ` ${knipM} mnd` : ''}`
            }
          } else {
            const newAge = ageFromDob(String(raw), PEILDATUM)
            const ageY = Math.floor(newAge)
            const ageM = Math.floor((newAge - ageY) * 12)
            caption.textContent = `Leeftijd: ${ageY} jaar${ageM ? ` ${ageM} mnd` : ''}`
          }
        }
        scheduleRecompute()
        return
      }

      // v3.0.11/12: range-slider toont stand direct boven slider (geen debounce-vertraging op visuele label)
      if (target instanceof HTMLInputElement && target.type === 'range') {
        const strong = document.querySelector(`label[for="${target.id}"] strong`)
        if (strong) {
          if (field === 'x0') strong.textContent = state.deelnemer.x0 + ' jaar'
          else if (field === 'pen') strong.textContent = '€ ' + Math.round(state.deelnemer.pen).toLocaleString('nl-NL')
          else if (field === 'x_partner') strong.textContent = (state.deelnemer.x_partner ?? 0) + ' jaar'
          else if (field === 'y0') strong.textContent = '€ ' + Math.round(state.deelnemer.y0 ?? 0).toLocaleString('nl-NL')
          else if (field === 'pen_laag') strong.textContent = '€ ' + Math.round(state.deelnemer.pen_laag ?? 0).toLocaleString('nl-NL')
        }
      }

      scheduleRecompute()
    }
    el.addEventListener('input', handler)
    el.addEventListener('change', handler)

    el.addEventListener('keydown', (e) => {
      const ke = e as KeyboardEvent
      if (ke.key === 'Enter') {
        ke.preventDefault()
        immediateRecompute()
      }
    })

    el.addEventListener('blur', () => {
      if (debouncePending) {
        immediateRecompute()
      }
    })
  })

  // Rente-slider (M1)
  const renteSlider = document.getElementById('in-r') as HTMLInputElement | null
  if (renteSlider) {
    let rafPending = false
    renteSlider.addEventListener('input', () => {
      state.parameters_m1 = { ...state.parameters_m1, r: Number(renteSlider.value) / 100 }
      if (!rafPending) {
        rafPending = true
        raf(() => {
          rafPending = false
          recompute()
          updateOutputsInPlace()
        })
      }
    })
  }

  // M2-sliders (alleen spreidingN nog over; v3.0.79 verhuisde DG+aftrek)
  document.querySelectorAll('[data-m2field]').forEach((el) => {
    const slider = el as HTMLInputElement
    let rafPending = false
    slider.addEventListener('input', () => {
      const field = slider.dataset.m2field as string
      state.parameters_m2 = applyM2SliderInput(state.parameters_m2, field, slider.value)
      if (!rafPending) {
        rafPending = true
        raf(() => {
          rafPending = false
          recompute()
          updateOutputsInPlace()
        })
      }
    })
  })

  // v3.0.79: Cascade-sliders in M1/2-pane. Vijf componenten (fondsvermogen,
  // bijstort, wettelijkeReservesPct, rdrBedrag, compensatiedepotBedrag) plus
  // dekkingsgraad. Eerste twee + DG zijn parameters_m2-velden; de drie
  // cascade-componenten zitten in state.cascadeOverrides.
  document.querySelectorAll('[data-co]').forEach((el) => {
    const slider = el as HTMLInputElement
    slider.addEventListener('input', () => {
      const field = slider.dataset.co as string
      const num = Number(slider.value)
      if (!Number.isFinite(num)) return
      if (field === 'fondsvermogen' || field === 'bijstort' || field === 'dekkingsgraad') {
        ;(state.parameters_m2 as Record<string, unknown>)[field] = num
        // v3.0.94: F en DG bewegen in tandem rond vpvTotal-anker.
        //   F-slider → DG = F / vpvTotal
        //   DG-slider → F = DG × vpvTotal
        // vpvTotal blijft constant gedurende UI-interactie.
        const anker = state.parameters_m2.vpvTotal
        if (anker > 0) {
          if (field === 'fondsvermogen') {
            state.parameters_m2.dekkingsgraad = num / anker
          } else if (field === 'dekkingsgraad') {
            state.parameters_m2.fondsvermogen = num * anker
          }
        }
      } else if (field === 'wettelijkeReservesPct' || field === 'rdrBedrag' || field === 'compensatiedepotBedrag') {
        ;(state.cascadeOverrides as Record<string, unknown>)[field] = num
      } else {
        return
      }
      // Volledig opnieuw renderen: cascade-tabel toont afgeleide waardes
      // (M, opgehoogd, wettelijkeur) die met meerdere componenten meebewegen,
      // plus afwijking-markers per slider en banner op de pane-h2. Een in-place
      // update zou veel selectors vergen; volledige re-render is robuuster.
      recompute()
      render()
    })
  })

  // Reset-knop
  document.addEventListener('click', (e) => {
    const t = e.target as HTMLElement
    if (t?.id === 'reset-cascade-btn') {
      state.parameters_m2.fondsvermogen = FONDS.m2.fondsvermogen
      state.parameters_m2.bijstort = FONDS.m2.bijstort
      state.parameters_m2.dekkingsgraad = FONDS.m2.dekkingsgraad
      const cf = FONDS.aanwendingsCascade
      if (cf) {
        state.cascadeOverrides.wettelijkeReservesPct = cf.wettelijkeReservesPct
        state.cascadeOverrides.rdrBedrag = cf.rdrBedrag
        state.cascadeOverrides.compensatiedepotBedrag = cf.compensatiedepotBedrag
      }
      recompute()
      render()
    }
  })

  // v3.0.77: fonds-keuze-radios verwijderd — build-time-fondsinjectie betekent
  // één fonds per build. Geen runtime fondswissel nodig.
}

// ============================================================================
// Footer (v3.0.3 publiek-release)
// ============================================================================

const RELEASE_VERSION = '3.0.134'
// v3.0.38: build-time injectie via esbuild `define` in build.calc.ts.
// Was hardcoded ('05-05-2026') en liep daardoor altijd achter op de werkelijke
// release-datum. Nu stempelt elke build automatisch de bouwdatum (dd-mm-yyyy).
declare const __BUILD_DATE__: string
const RELEASE_DATE = typeof __BUILD_DATE__ !== 'undefined' ? __BUILD_DATE__ : 'dev'

function renderFooter(): string {
  return `
    <footer class="site-footer">
      <p class="footer-contact">
        Vragen of opmerkingen: <a href="mailto:hans@invaarcalculator.nl">hans@invaarcalculator.nl</a>
        · <a href="#" class="footer-link" data-help="privacy">Privacy</a>
      </p>
      <p class="footer-meta">
        Release ${RELEASE_VERSION} · ${RELEASE_DATE} ·
        <a href="https://creativecommons.org/licenses/by-nc/4.0/" target="_blank" rel="noopener">CC BY-NC 4.0</a> ·
        <a href="https://innovation-nestor.godaddysites.com" target="_blank" rel="noopener">Innovation Nestor</a>
      </p>
    </footer>
  `
}

// ============================================================================
// Init
// ============================================================================

export function init(): void {
  // v3.0.13: help-modal globale event-handlers (één keer; modal-DOM wordt
  // hergebruikt over re-renders)
  if (typeof document !== 'undefined') {
    const overlay = document.getElementById('help-modal-overlay')
    const closeBtn = document.getElementById('help-modal-close')
    overlay?.addEventListener('click', (e) => {
      // Klik op overlay-achtergrond zelf (niet op de inhoud) sluit modal
      if (e.target === overlay) closeHelpModal()
    })
    closeBtn?.addEventListener('click', closeHelpModal)
    // v3.0.119: zelfde handlers voor sensitivity-modal
    const sensOverlay = document.getElementById('sensitivity-modal-overlay')
    const sensCloseBtn = document.getElementById('sensitivity-modal-close')
    sensOverlay?.addEventListener('click', (e) => {
      if (e.target === sensOverlay) closeSensitivityModal()
    })
    sensCloseBtn?.addEventListener('click', closeSensitivityModal)
    document.addEventListener('keydown', (e) => {
      if ((e as KeyboardEvent).key === 'Escape') {
        closeHelpModal()
        closeSensitivityModal()
      }
    })
    // v3.0.17: event-delegation voor alle .help-icon-knoppen (statisch + dynamisch)
    attachGlobalHelpHandler()

    // v3.0.41: print-knop opent browser-PDF-dialoog met actuele resultaten.
    // v3.0.92: ook audit-rapport-knop voor technische uitvoer (parallel pad).
    // v3.0.109: persoonlijk- en actuarieel-overzicht-knoppen verwijderd.
    // Alleen modelspec-knop resteert als download-actie.
    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement
      // v3.0.119: Gevoeligheidsgrafiek-knop opent modal met DG-sweep voor
      // huidige deelnemer. Sweep loopt elke klik vers (geen cache) — 501 M2-
      // runs duren in browser typisch <1 sec.
      if (target?.id === 'sensitivity-btn') {
        if (!state.lastM1 || state.lastM1Error) {
          alert('Vul eerst geldige deelnemer-gegevens in.')
          return
        }
        try {
          const sweep = runSweep(state.deelnemer, state.lastM1, state.parameters_m2)
          openSensitivityModal(sweep)
        } catch (err) {
          console.error('Sensitivity-sweep gefaald:', err)
          alert('Kon gevoeligheidsgrafiek niet maken: ' + (err instanceof Error ? err.message : 'onbekende fout'))
        }
        return
      }
      // v3.0.121: Bijstort-grafiek knop — tweede gevoeligheidsgrafiek,
      // toont aandeel-delta als functie van werkgevers-bijdrage (0-2500 mln).
      // 251 M2-runs, DG vast op huidige stand; lineaire curve, dubbele Y-as.
      if (target?.id === 'bijstort-btn') {
        if (!state.lastM1 || state.lastM1Error) {
          alert('Vul eerst geldige deelnemer-gegevens in.')
          return
        }
        try {
          const sweep = runBijstortSweep(state.deelnemer, state.lastM1, state.parameters_m2)
          openBijstortModal(sweep)
        } catch (err) {
          console.error('Bijstort-sweep gefaald:', err)
          alert('Kon bijstort-grafiek niet maken: ' + (err instanceof Error ? err.message : 'onbekende fout'))
        }
        return
      }
      // v3.0.125: Indexed-grafiek knop — derde gevoeligheidsgrafiek,
      // toont vlak verhoogd pensioen vs. geïndexeerd huidig pensioen over
      // resterende leeftijd. Geen sweep (twee analytische functies).
      // Vereist zowel M1- als M2-resultaten.
      if (target?.id === 'indexed-btn') {
        if (!state.lastM1 || !state.lastM2 || state.lastM1Error || state.lastM2Error) {
          alert('Vul eerst geldige deelnemer-gegevens in.')
          return
        }
        try {
          const sweep = runIndexedSweep(state.deelnemer, state.lastM1, state.lastM2, state.parameters_m1)
          openIndexedModal(sweep)
        } catch (err) {
          console.error('Indexed-sweep gefaald:', err)
          alert('Kon verhoging-vs-indexatie-grafiek niet maken: ' + (err instanceof Error ? err.message : 'onbekende fout'))
        }
        return
      }
      // v3.0.107: Modelspecificatie-knop opent de geïnjecteerde PDF
      // (window.__MODELSPEC_PDF__, base64-gecodeerd door build.calc.ts).
      // Strategie: Blob URL → trigger download met versie-genaamde filename.
      // Voorkomt browser-PDF-viewer-edge-cases (bv. mobiel Safari opent niet
      // inline) en geeft de gebruiker een file om te bewaren/archiveren.
      if (target?.id === 'modelspec-btn') {
        const btn = target as HTMLButtonElement
        const originalLabel = btn.textContent ?? ''
        try {
          // @ts-expect-error — geïnjecteerd door build.calc.ts
          const pdfBase64 = window.__MODELSPEC_PDF__ as string | undefined
          if (!pdfBase64) {
            throw new Error('window.__MODELSPEC_PDF__ niet gevonden')
          }
          btn.disabled = true
          btn.textContent = 'Modelspecificatie wordt voorbereid…'

          // base64 → Uint8Array → Blob (atob + char-code-loop is standaard
          // browser-pad; geen Buffer in browser-context).
          const binary = atob(pdfBase64)
          const bytes = new Uint8Array(binary.length)
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i)
          }
          const blob = new Blob([bytes], { type: 'application/pdf' })
          const url = URL.createObjectURL(blob)

          // Tijdelijk anchor-element voor download (Safari-compatibel).
          const a = document.createElement('a')
          a.href = url
          a.download = `Modelspecificatie_Invaarcalculator_v${RELEASE_VERSION}.pdf`
          document.body.appendChild(a)
          a.click()
          document.body.removeChild(a)
          // URL.revokeObjectURL na korte vertraging zodat de download
          // gegarandeerd is gestart (Chrome/Firefox racen anders).
          setTimeout(() => URL.revokeObjectURL(url), 1000)
        } catch (err) {
          console.error('[modelspec] fout bij openen modelspecificatie:', err)
          alert('Kan de Modelspecificatie-PDF niet openen. Zie de browserconsole (F12) voor details.')
        } finally {
          btn.disabled = false
          btn.textContent = originalLabel
        }
      }
    })
  }

  recompute()
  render()
}

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
}
