/**
 * SCHEMA v2.0 — WTP-pensioencalculator
 *
 * Direct afgeleid van ENGINE_SPECIFICATIE_v1.md v2.2.7.
 * Bron-waarheid: de spec. Bij tegenstrijdigheid tussen dit bestand en de spec
 * wint de spec; dit bestand wordt gepatcht met spec-paragraaf-verwijzing.
 *
 * Versie-regel (uit PROMPT_nieuwe_chat §2.8):
 *   v2.0    — eerste stabiele versie
 *   v2.0.1+ — patches/verduidelijkingen binnen SCHEMA
 *   v2.1+   — minor bij wezenlijke structuur-aanpassing o.b.v. implementatie-leren
 *
 * Datum: 23-04-2026 21:54 (Europe/Amsterdam)
 * Spec-referentie: v2.2.9 (t₀ verplaatst M1 §2.2 → §2.3)
 * Huidige inhoud: infrastructuur + M1-block (scherm 1).
 * Licentie: CC BY-NC 4.0
 */

import { z } from 'zod'

// ============================================================================
// INFRASTRUCTUUR — display-metadata, uiDisclosure, spec-ref
// ============================================================================

/**
 * Display-klasse per veld (vier casual-schermen + audit-scherm, Model D).
 *
 *  - hoofdpad         : getoond op een van de vier casual-schermen (§1.1)
 *  - decompositie     : uitsplitsing, alleen audit-scherm
 *  - deepdive         : tussenresultaat voor zelf-controle, alleen audit-scherm
 *  - parameter-audit  : fondsparameterset-input met herkomst-verwijzing
 *  - diagnose         : coherentie-checks, v2-paden-status, sluitingscontroles
 */
export type Display =
  | 'hoofdpad'
  | 'decompositie'
  | 'deepdive'
  | 'parameter-audit'
  | 'diagnose'

/**
 * Metadata per veld. specRef is verplicht (audit-traceerbaarheid naar spec);
 * uiDisclosure is optioneel (alleen waar de spec een disclosure-eis stelt).
 */
export interface FieldMeta {
  display: Display
  specRef: string          // bv. '§2.3 actief v1.8' of '§2.2 + §2.5 + §11.5'
  uiDisclosure?: string    // bv. '§2.2 — UI toont waarschuwing bij gemengd voor bekend-geslacht'
  module: 'M1' | 'M2' | 'M3' | 'M4' | 'shared'
}

/**
 * Parallelle metadata-registry per Zod-schema-instantie.
 *
 * Rationale voor WeakMap i.p.v. schema-property:
 *   - Zod-schemas blijven clean Zod (geen custom prototype-vervuiling)
 *   - Garbage collection werkt automatisch
 *   - Iteratie via Array.from(FIELD_META.entries()) voor audit-scherm-generatie
 *     vereist expliciete tracking (zie FIELD_REGISTRY hieronder)
 */
const FIELD_META = new WeakMap<z.ZodTypeAny, FieldMeta>()

/**
 * Flat registry: houdt volgorde en naam bij voor audit-scherm-generatie.
 * Gevuld door F() bij elke veld-definitie. WeakMap alleen is niet iterable.
 */
export const FIELD_REGISTRY: Array<{
  path: string           // 'M1.deelnemer.x0' of 'M1.parameterset.r'
  schema: z.ZodTypeAny
  meta: FieldMeta
}> = []

/**
 * F(schema, meta, path) — veld-wrapper die metadata registreert.
 *
 * Gebruik:
 *   x0: F(z.number().min(0).max(120),
 *         { display: 'hoofdpad', module: 'M1', specRef: '§2.2 actief v1' },
 *         'M1.deelnemer.x0')
 *
 * Zod-gedrag onveranderd: .parse(), z.infer<>, .describe() werken normaal.
 */
function F<T extends z.ZodTypeAny>(schema: T, meta: FieldMeta, path: string): T {
  FIELD_META.set(schema, meta)
  FIELD_REGISTRY.push({ path, schema, meta })
  return schema
}

/** Lookup helper — voor audit-scherm en JSON-Schema-export later. */
export function getMeta(schema: z.ZodTypeAny): FieldMeta | undefined {
  return FIELD_META.get(schema)
}

// ============================================================================
// SHARED ENUMS
// ============================================================================

/**
 * Geslacht (§2.2 v1.7). `gemengd` is fallback bij onbekend/anders,
 * populatie-gewogen per leeftijd (§2.5). UI toont waarschuwing bij
 * `gemengd` voor bekend-geslacht gebruik.
 */
export const GenderSchema = z.enum(['M', 'V', 'gemengd'])
export type Gender = z.infer<typeof GenderSchema>

/**
 * Regeling (§9 + §11.2 v1.1). Top-level keuze; M4 ziet alleen SPR/FPR
 * (clean/hybride-sub-selector is M3-intern, §9).
 */
export const RegelingSchema = z.enum(['FPR', 'SPR-clean', 'SPR-hybride'])
export type Regeling = z.infer<typeof RegelingSchema>

/**
 * Annuïteitsconventie (§7.3 + §11.4 v1.2). Uniform arrears m=12
 * cross-module is hard consistency-requirement; `due` alleen als
 * debug-referentie voor R9.30-migratie (§2.5).
 *
 * v2.0 SCHEMA-lock: alleen `'arrears'` geldig als dataset-waarde.
 * De enum-notatie in spec §2.3 noemt conceptueel twee vormen, maar
 * §7.3-consistentie-eis beperkt v2.0 tot één geldige waarde. `due`
 * blijft bereikbaar als engine-interne debug-flag (niet via dataset).
 * Heropening naar enum vergt spec-patch + SCHEMA minor-bump.
 */
export const AnnuiteitsconventieSchema = z.literal('arrears')
export type Annuiteitsconventie = z.infer<typeof AnnuiteitsconventieSchema>

/**
 * Betalingsfrequentie (§2.3 actief v1.2 + §7.3 + §11.4).
 * Uniform m=12 cross-module (maandbasis conform fondsuitbetalingspraktijk).
 *
 * v2.0 SCHEMA-lock: alleen `12` geldig als dataset-waarde.
 * De enum-notatie in spec §2.3 noemt `{1, 4, 12}` als conceptuele opties,
 * maar §7.3-consistentie-eis beperkt v2.0 tot één geldige waarde. Kwartaal-
 * of jaarbasis (m=4, m=1) zou cross-module inconsistentie veroorzaken.
 * Heropening naar enum vergt spec-patch + SCHEMA minor-bump.
 */
export const MSchema = z.literal(12)
export type M = z.infer<typeof MSchema>

/**
 * Sterftetafel-identifier (§2.3 actief v1.7; §11.16).
 * v2.0: alleen AG2024 (R9.30 Q-tabel gedeprecieerd v1.7).
 * Upgrade-pad: extra tafel-ID's mogelijk zonder structuur-wijziging.
 */
export const SterftekansTabelIdSchema = z.enum(['AG2024'])
export type SterftekansTabelId = z.infer<typeof SterftekansTabelIdSchema>

// ============================================================================
// MODULE 1 — HUIDIGE WAARDE  (scherm 1)
// ============================================================================
//
// Vraag (§2.1): Wat is mijn huidige pensioenaanspraak waard, gegeven mijn
// leeftijd en een gekozen rekenrente? Aanspraak = OP + NP (v1.3).
//
// Uitvoer (§2.4): KV_OP, KV_NP, KV totaal + annuïteitsfactoren per leven
// + levensverwachtingen. Regime-agnostisch.
// ============================================================================

// ----------------------------------------------------------------------------
// §2.2 Invoerschema — deelnemer
// ----------------------------------------------------------------------------

export const M1DeelnemerSchema = z.object({
  x0: F(
    z.number().min(0).max(120)
      .describe('§2.2 actief v1 — leeftijd deelnemer op peildatum (fractioneel toegestaan)'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 actief v1' },
    'M1.deelnemer.x0'
  ),

  pen: F(
    z.number().nonnegative()
      .describe('§2.2 actief v1 — jaarlijks bruto ingegaan OP in euro'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 actief v1' },
    'M1.deelnemer.pen'
  ),

  g: F(
    GenderSchema.default('M')
      .describe('§2.2 actief v1.7 — geslacht deelnemer; M/V activeert AG2024-tafel per geslacht. v3.0.1: default M (was \'gemengd\'); \'gemengd\' is engine-interne cohort-proxy, geen eindgebruiker-keuze (zie §11.16 v3.0.1).'),
    {
      display: 'hoofdpad',
      module: 'M1',
      specRef: '§2.2 actief v1.7 + §11.16 v3.0.1',
      // v3.0.5: uiDisclosure verwijderd. De v3.0.1-tekst was spec-documentatie
      // ("UI toont alleen M/V; gemengd is engine-fallback") en verscheen ten
      // onrechte als ⚠-warning onder de dropdown bij eindgebruikers. Die info
      // is voor de eindgebruiker irrelevant; hij ziet gewoon M/V en kiest.
    },
    'M1.deelnemer.g'
  ),

  heeftPartner: F(
    z.boolean().default(false)
      .describe('§2.2 actief v1.3 — of er een NP-aanspraak is; bij false worden onderstaande partner-velden genegeerd'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 actief v1.3' },
    'M1.deelnemer.heeftPartner'
  ),

  // Voorwaardelijk verplicht bij heeftPartner=true; fallback-regel in refine.
  y0: F(
    z.number().nonnegative().nullable().default(null)
      .describe('§2.2 actief v1.3 — jaarlijks bruto NP-aanspraak in euro. Verplicht als heeftPartner=true en bekend; anders fallback 70% van pen (§11.5 v1.8 bevestigd)'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 actief v1.3 + §11.5 v1.8' },
    'M1.deelnemer.y0'
  ),

  x_partner: F(
    z.number().min(0).max(120).nullable().default(null)
      .describe('§2.2 actief v1.3 — leeftijd partner op peildatum; verplicht als heeftPartner=true'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 actief v1.3' },
    'M1.deelnemer.x_partner'
  ),

  g_y: F(
    GenderSchema.default('M')
      .describe('§2.2 actief v1.7 — geslacht partner; identiek behandeld als g. v3.0.1: default M (was \'gemengd\'); zie §11.16 v3.0.1.'),
    {
      display: 'hoofdpad',
      module: 'M1',
      specRef: '§2.2 actief v1.7 + §11.16 v3.0.1',
      // v3.0.5: uiDisclosure verwijderd; zie commentaar bij `g`-veld hierboven.
    },
    'M1.deelnemer.g_y'
  ),

  // v3.0.57: hoog-laag-regeling (art. 63 Pw). Optioneel; default uit.
  // pen interpreteren we als "hoog-bedrag" wanneer hooglaagActief=true.
  hooglaagActief: F(
    z.boolean().default(false)
      .describe('§2.2 v3.0.57 — true als deelnemer een hoog-laag-regeling heeft. UI weigert combinatie x_knip ≤ x0 (verleden-knip).'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 v3.0.57' },
    'M1.deelnemer.hooglaagActief'
  ),

  pen_laag: F(
    z.number().nonnegative().nullable().default(null)
      .describe('§2.2 v3.0.57 — jaarlijks bruto OP in euro ná de knip. Verplicht als hooglaagActief=true; anders genegeerd.'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 v3.0.57' },
    'M1.deelnemer.pen_laag'
  ),

  x_knip: F(
    z.number().min(0).max(120).nullable().default(null)
      .describe('§2.2 v3.0.57 — leeftijd waarop de knip plaatsvindt (fractioneel toegestaan, afgeleid uit dob_knip in UI). Moet > x0 zijn anders 0-aftrek (validatie in UI).'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.2 v3.0.57' },
    'M1.deelnemer.x_knip'
  ),
}).superRefine((data, ctx) => {
  // §2.2 + §11.5: heeftPartner=true → x_partner verplicht; y₀ optioneel met fallback 0.70·pen
  if (data.heeftPartner) {
    if (data.x_partner === null) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['x_partner'],
        message: '§2.2 — x_partner is verplicht als heeftPartner=true',
      })
    }
    // y0 mag null blijven: engine past §2.7 fallback toe (y₀ = 0.70 · pen)
  }
  // §2.2: heeftPartner=false → partner-velden worden genegeerd (geen hard refuse, wel documentair)
})

export type M1Deelnemer = z.infer<typeof M1DeelnemerSchema>

// ----------------------------------------------------------------------------
// FONDS-PARAMETERSET — top-level schema met gedeelde fondsparameters
//
// (B-hybride architectuur, beslissing combi-sessie M2 04-05-2026.)
//
// Deze top-level schema declareert parameters die door 2+ modules worden
// gebruikt — één bron-van-waarheid voor cross-module-consistentie:
//   - r, sterftekansTabelId, t0, ervaringsSterfte, m, annuiteitsconventie,
//     pi, omega: gebruikt door M1, M3, M4 (afhankelijk van module-rol)
//   - fondsvermogen: M1 (§2.7 ρ-ladder), M2 (§3.3 primair)
//
// Per-module ParametersetSchema's worden afgeleid via .pick() (subset van
// shared) en eventueel uitgebreid met module-specifieke velden via .extend().
// Voor M1 betekent dit:
//   M1ParametersetSchema = FondsParametersetSchema.pick({...9 shared}).extend({
//     uitvoeringskostenJaarlijks, kostenOpslagPct,  // §2.7-ladder M1-only
//   }).superRefine(...)
//
// FIELD_REGISTRY-paths van shared velden gebruiken 'fonds.parameterset.<naam>';
// module-specifieke extensies behouden 'M<n>.parameterset.<naam>'.
// fieldsByDisplay('M1', ...) toont automatisch beide groepen (shared + M1).
// ----------------------------------------------------------------------------

export const FondsParametersetSchema = z.object({
  // --- Discontering (§11.3 drie velden structureel; UI-slider-koppeling v2.1) ---
  r: F(
    z.number().min(-0.05).max(0.15).default(0.02)
      .describe('§2.3 actief v1 — rekenrente voor discontering; SSPF-default 2% (v1.8). UI-primaire rente-slider koppelt aan M3-proj en M4-i; ontkoppeling via geavanceerd-toggle (§11.3 v2.1)'),
    { display: 'parameter-audit', module: 'shared', specRef: '§2.3 actief v1 + §11.3 v2.1' },
    'fonds.parameterset.r'
  ),

  // --- Sterftetafel (§11.16 AG2024 v1.7) ---
  sterftekansTabelId: F(
    SterftekansTabelIdSchema.default('AG2024')
      .describe('§2.3 actief v1.7 — officiële AG2024-prognosetafel (KAG 12-09-2024); vervangt R9.30-Q-tabel (§11.16). q_{x,t,g}-waardes worden uit tabel-ID geresolved door engine; niet inline in dataset'),
    {
      display: 'parameter-audit',
      module: 'shared',
      specRef: '§2.3 actief v1.7 + §11.16',
      uiDisclosure: '§11.16 v1.7 — gender-activering: M/V keuze geeft tafel per geslacht; gemengd is populatie-gewogen fallback met SSPF 95/5-prior (§11.17)',
    },
    'fonds.parameterset.sterftekansTabelId'
  ),

  // --- Projectiejaar AG2024-kolom (v2.2.9: verplaatst van deelnemer naar parameterset voor M1↔M3-symmetrie) ---
  t0: F(
    z.number().int().min(2022).max(2200).default(2026)
      .describe('§2.3 actief v1.7 (verplaatst v2.2.9) — projectiejaar voor AG2024-kolomselectie; M1 gebruikt periode-snapshot (zelfde kolom voor alle toekomstige leeftijden, §2.5). Cohort-variant is M4-gedrag (§5.5.2, §5.12.7). Parallel aan M3 §4.3'),
    {
      display: 'parameter-audit',
      module: 'shared',
      specRef: '§2.3 actief v1.7 + v2.2.9',
      uiDisclosure: '§5.12.7 v2.2.0 — periode-snapshot M1-3 vs cohort M4 als methodische asymmetrie; <1% verschil',
    },
    'fonds.parameterset.t0'
  ),

  // --- Ervaringssterfte (§11.13 v1.4) ---
  // v2.0: scalar. Map-vorm (leeftijds- of gender-afhankelijk) is v2-uitbreidingspad.
  ervaringsSterfte: F(
    z.number().min(0.5).max(1.5).default(1.0)
      .describe('§2.3 actief v1.5 — multiplicatieve ervaringssterftefactor f op q (q_fonds = f · q_AG2024). v3.0.90: SSPF-default 0,90 (conservatief midpoint voor hoog-opgeleide top-inkomensquintiel; bron CBS levensverwachting naar inkomen 2019/2022). Vlak; v2-uitbreidingspad voor leeftijds-/gender-afhankelijke vorm zie §11.13.'),
    { display: 'parameter-audit', module: 'shared', specRef: '§2.3 actief v1.5 + §11.13' },
    'fonds.parameterset.ervaringsSterfte'
  ),

  // --- Betalingsfrequentie (§11.4 v1.2 + §7.3 arrears m=12 uniform cross-module; v2.0 SCHEMA-lock) ---
  m: F(
    MSchema.default(12)
      .describe('§2.3 actief v1.2 + §7.3 cross-module-lock — uniform maandbasis; v2.0 enige geldige waarde is 12. Conceptuele enum {1,4,12} uit §2.3 is SCHEMA-beperkt tot één waarde door §7.3 hard-consistentie-eis. Heropening naar enum vergt spec-patch + SCHEMA minor-bump'),
    { display: 'parameter-audit', module: 'shared', specRef: '§2.3 actief v1.2 + §7.3 + §11.4' },
    'fonds.parameterset.m'
  ),

  annuiteitsconventie: F(
    AnnuiteitsconventieSchema.default('arrears')
      .describe('§2.3 actief v1.2 + §7.3 cross-module-lock — uniform arrears; v2.0 enige geldige waarde is "arrears". Conceptuele enum {due, arrears} uit §2.3 is SCHEMA-beperkt tot één waarde door §7.3 hard-consistentie-eis. `due` blijft engine-intern bereikbaar als R9.30-migratie-debug-flag (§2.5), niet via dataset'),
    { display: 'parameter-audit', module: 'shared', specRef: '§2.3 actief v1.2 + §7.3 + §11.4' },
    'fonds.parameterset.annuiteitsconventie'
  ),

  // --- Indexatie op aanspraak tijdens waardering (§11.15 v1.6) ---
  // v2.0: scalar. Vector-vorm (tijdsafhankelijke indexatie-vector) is v2-uitbreidingspad.
  pi: F(
    z.number().min(-0.05).max(0.10).default(0.0)
      .describe('§2.3 actief v1.6 — indexatie π op aanspraak tijdens waardering. Waarde 0 als bewust anker: scherm 1 = kale papieren aanspraak (§1.1, §11.15). Scherm 4 toont indexatie-effect onder DB vs WTP als pedagogische payload'),
    {
      display: 'parameter-audit',
      module: 'shared',
      specRef: '§2.3 actief v1.6 + §11.15 + §1.1',
      uiDisclosure: '§11.15 v1.6 — π=0 is bewust anker voor M1; M4 gebruikt π^DB/π^Wtp als regime-specifieke projectie-aannames',
    },
    'fonds.parameterset.pi'
  ),

  // --- Fondsvermogen (M1 §2.7 ρ-ladder + M2 §3.3 primair gebruik) ---
  fondsvermogen: F(
    z.number().positive().nullable().default(null)
      .describe('§2.3/§2.7/§3.3 — fondsvermogen in mln euro. M1: alleen voor ρ-afleiding (fallback-ladder §2.7), nullable. M2: primair gebruik (§3.3), zal in M2-view non-nullable + .positive() worden via .extend()-refine'),
    { display: 'parameter-audit', module: 'shared', specRef: '§2.7 + §3.3' },
    'fonds.parameterset.fondsvermogen'
  ),

  // --- Eindleeftijd sterftetafel (§2.3 actief v1) ---
  omega: F(
    z.number().int().min(100).max(120).default(120)
      .describe('§2.3 actief v1 — eindleeftijd ω voor annuïteitsafsluiting en horizon-cap (§2.5). AG2024 dekt tot 120'),
    { display: 'parameter-audit', module: 'shared', specRef: '§2.3 actief v1' },
    'fonds.parameterset.omega'
  ),
})

export type FondsParameterset = z.infer<typeof FondsParametersetSchema>

// ----------------------------------------------------------------------------
// §2.3 Invoerschema — fondsparameterset (M1-view)
//
// .pick() van alle 9 shared velden + .extend() met M1-specifieke ρ-ladder-
// bronvelden (uitvoeringskostenJaarlijks, kostenOpslagPct). De superRefine
// kan zowel shared (fondsvermogen) als M1-specifieke velden inspecteren.
// ----------------------------------------------------------------------------

export const M1ParametersetSchema = FondsParametersetSchema.pick({
  r: true,
  sterftekansTabelId: true,
  t0: true,
  ervaringsSterfte: true,
  m: true,
  annuiteitsconventie: true,
  pi: true,
  fondsvermogen: true,
  omega: true,
}).extend({
  // --- Kostenopslag ρ (§11.14 v1.5) — M1-only ρ-ladder-bronvelden ---
  // ρ is NIET direct een SCHEMA-veld met vaste waarde; engine past fallback-ladder toe (§2.7):
  //   (1) c_jaar = uitvoeringskostenJaarlijks / fondsvermogen → ρ = c_jaar · ä(x, r)
  //   (2) kostenOpslagPct direct
  //   (3) ultieme default 0.02
  uitvoeringskostenJaarlijks: F(
    z.number().nonnegative().nullable().default(null)
      .describe('§2.7 fallback-ladder stap 1 — jaarlijkse uitvoeringskosten in mln euro; activeert Variant-A-afleiding ρ = (uitvoeringskosten/fondsvermogen) · ä(x, r) als beide aanwezig (§11.14 v1.5)'),
    { display: 'parameter-audit', module: 'M1', specRef: '§2.7 + §11.14 v1.5' },
    'M1.parameterset.uitvoeringskostenJaarlijks'
  ),

  kostenOpslagPct: F(
    z.number().min(0).max(0.15).nullable().default(null)
      .describe('§2.7 fallback-ladder stap 2 — directe kostenopslag-fractie als cumulatieve multiplier op KV; alleen gebruikt als stap 1 niet beschikbaar is. Ultieme default (stap 3) = 0.02 bij beide null (§11.14 bewuste afwijking §12.5)'),
    {
      display: 'parameter-audit',
      module: 'M1',
      specRef: '§2.7 + §11.14 v1.5',
      uiDisclosure: '§11.14 v1.5 — ultieme default ρ=0.02 wijkt bewust af van spec-met-reserveringen-principe (§12.5): ρ=0 zou "rijk rekenen"; publieke calculator moet kostenverschil verwachting vs realisatie zichtbaar maken',
    },
    'M1.parameterset.kostenOpslagPct'
  ),
}).superRefine((data, ctx) => {
  // §2.7 fallback-ladder: stap 1 vereist BEIDE uitvoeringskostenJaarlijks + fondsvermogen.
  // Als alleen één aanwezig is → engine kan stap 1 niet toepassen, zakt door naar stap 2/3.
  // Dit is geen fout; alleen documentair signaal via warn.
  const heeftUitvkosten = data.uitvoeringskostenJaarlijks !== null
  const heeftFondsverm = data.fondsvermogen !== null
  if (heeftUitvkosten && !heeftFondsverm) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['fondsvermogen'],
      message:
        '§2.7 — uitvoeringskostenJaarlijks aanwezig maar fondsvermogen ontbreekt; ρ-afleiding Variant-A kan niet worden toegepast, engine valt terug op kostenOpslagPct of default 0.02',
    })
  }
})

export type M1Parameterset = z.infer<typeof M1ParametersetSchema>

// ----------------------------------------------------------------------------
// §2.4 Output
// ----------------------------------------------------------------------------

export const M1OutputSchema = z.object({
  KV: F(
    z.number().nonnegative()
      .describe('§2.4 — totale kapitaalwaarde = KV_OP + KV_NP'),
    { display: 'hoofdpad', module: 'M1', specRef: '§2.4' },
    'M1.output.KV'
  ),

  KV_OP: F(
    z.number().nonnegative()
      .describe('§2.4 — kapitaalwaarde eigen OP-aanspraak in euro; (1+ρ) · pen · ä(x₀, r)'),
    { display: 'decompositie', module: 'M1', specRef: '§2.4 + §2.5' },
    'M1.output.KV_OP'
  ),

  KV_NP: F(
    z.number().nonnegative()
      .describe('§2.4 — kapitaalwaarde NP-aanspraak in euro; (1+ρ) · y₀ · ä(x_partner, r). 0 als heeftPartner=false'),
    {
      display: 'decompositie',
      module: 'M1',
      specRef: '§2.4 + §2.5 + §2.6 + §11.5',
      uiDisclosure: '§2.10 + §5.12.3 v2.2.3 — latent NP (deelnemer leeft nog): KV_NP is bovengrens o.b.v. onafhankelijke levens; joint-life met broken-heart-factor is gekoppelde v2-reservering M1/M3/M4',
    },
    'M1.output.KV_NP'
  ),

  a_x0: F(
    z.number().nonnegative()
      .describe('§2.4 — annuïteitsfactor deelnemer ä(x₀, r); arrears m=12 (§2.5 + §7.3)'),
    { display: 'deepdive', module: 'M1', specRef: '§2.4 + §2.5' },
    'M1.output.a_x0'
  ),

  a_partner: F(
    z.number().nonnegative().nullable()
      .describe('§2.4 — annuïteitsfactor partner ä(x_partner, r); null als geen partner'),
    { display: 'deepdive', module: 'M1', specRef: '§2.4 + §2.5' },
    'M1.output.a_partner'
  ),

  lifeExp_x0: F(
    z.number().positive()
      .describe('§2.4 — verwachte sterfleeftijd deelnemer onder gebruikte tafel (niet resterende levensverwachting); curtate + halfjaar-correctie (§2.5)'),
    { display: 'deepdive', module: 'M1', specRef: '§2.4 + §2.5' },
    'M1.output.lifeExp_x0'
  ),

  lifeExp_partner: F(
    z.number().positive().nullable()
      .describe('§2.4 — verwachte sterfleeftijd partner; null als geen partner'),
    { display: 'deepdive', module: 'M1', specRef: '§2.4 + §2.5' },
    'M1.output.lifeExp_partner'
  ),

  // Effectief gebruikte ρ (afgeleid via §2.7 fallback-ladder); blootgesteld voor audit.
  rho_effectief: F(
    z.number().min(0).max(0.15)
      .describe('§2.7 — effectief gebruikte kostenopslag ρ na toepassing fallback-ladder (Variant-A afleiding, direct override, of default 0.02). Blootgesteld als deepdive-veld voor audit (§11.14)'),
    { display: 'diagnose', module: 'M1', specRef: '§2.7 + §11.14' },
    'M1.output.rho_effectief'
  ),

  // §3.5 v3.0 — wettelijke spreidings-mechaniek (bijlage 2a Regeling Pw art. 2).
  // Optioneel: alleen aanwezig wanneer M1 in cascade met M2 is aangeroepen
  // (computeM1 met m2Context-argument). Bij scherm-1-standalone-modus blijven
  // ze undefined. Levert per individu de "spreidings-gewogen kapitaalwaarde"
  // CW_star = Σ_h q(h,N) · KS_voor(h) · v(h), zodat M2 de wet-canonieke formule
  // ppk(i) = KV(i) + x_fonds · CW_star(i) lineair kan toepassen.
  cw_star_op: F(
    z.number().nonnegative().optional()
      .describe('§3.5 v3.0 — spreidings-gewogen CW van OP-aanspraak: Σ_h q(h,N)·KS_OP(h)·v(h). Aanwezig alleen bij M2-cascade (m2Context).'),
    { display: 'deepdive', module: 'M1', specRef: '§2.4 + §3.5 v3.0' },
    'M1.output.cw_star_op'
  ),

  cw_star_np: F(
    z.number().nonnegative().optional()
      .describe('§3.5 v3.0 — spreidings-gewogen CW van NP-aanspraak: Σ_h q(h,N)·KS_NP(h)·v(h). Joint-life met broken-heart bij heeftPartner=true; 0 als geen partner. Aanwezig alleen bij M2-cascade.'),
    { display: 'deepdive', module: 'M1', specRef: '§2.4 + §3.5 v3.0' },
    'M1.output.cw_star_np'
  ),
})

export type M1Output = z.infer<typeof M1OutputSchema>

// ============================================================================
// MODULE 2 — POTJE (§3)
//
// Toedelingsengine: verdeelt het verdeelbare fondsvermogen op basis van
// persoonlijke KV, fondsdekkingsgraad, DNB-spreidingsmethode en Gaussische
// compensatie-curve. Spec §3.5 v2.2.10 (Model C bundle-aftrek):
//   verdeelbaar = fondsvermogen − vpvAftrekPct·vpvTotal
//                 − compensatiedepot − buffer + bijstort
//
// SCHEMA-architectuur (v2.0 M2-block, combi-sessie 04-05-2026):
//   - M2KetenInputSchema (S1-keuze ii): expliciet schema dat documenteert
//     WELKE M1-output-velden M2 leest (KV, KV_OP, KV_NP). Geen UPO-invoer,
//     geen aparte FIELD_REGISTRY-entries (M1Output-velden zijn al
//     geregistreerd); dient als type-anker voor engine-signature en
//     pattern-template voor M3/M4-keten-input. Spec §3.2 stelt: M2 ontvangt
//     deelnemer-gegevens via keten van M1 — engine-signature is
//     computeM2(d: M1Deelnemer, k: M2KetenInput, p: M2Parameterset).
//   - M2ParametersetSchema: .pick() van alle 9 shared velden (M2 doet eigen
//     annuïteits-berekeningen voor kvProfile/ν(N)/s(x,N,g) — zelfde fonds-
//     parameters als M1 nodig) + .extend() met 12 M2-specifieke velden,
//     superRefine voor §3.8 hard-rejects en v2.2.10 legacy/bundle-conflict.
//   - M2OutputSchema: 11 velden inclusief cohortOutcomes-array (15 vaste
//     cohorten 25-99/5jr) en phiDerived nullable (§11.12). Twee sluitings-
//     controles via superRefine: ppk_OP+ppk_NP=ppkTotal (v2.1.1) en
//     ppkBase+ppkSurplus+ppkComp=ppkTotal (§3.4), beide tolerantie 1e-6.
// ============================================================================

// ----------------------------------------------------------------------------
// §3.2 Keten-input — M2 leest uit M1-output (knelpunt S1, combi-sessie M2)
//
// Pure documentatie-schema: documenteert welke velden van M1Output M2 effectief
// leest. Geen FIELD_REGISTRY-registratie omdat M1Output deze velden al registreert
// (`M1.output.KV`, `M1.output.KV_OP`, `M1.output.KV_NP`); dubbel registreren
// zou audit-scherm-generatie verwarren. Wel een type-export (M2KetenInput)
// voor engine-signature en latere M3/M4-pattern-spiegeling.
//
// Engine-signature voor M2: computeM2(d: M1Deelnemer, k: M2KetenInput,
//                                     p: M2Parameterset): M2Output
// ----------------------------------------------------------------------------

export const M2KetenInputSchema = z.object({
  KV: z.number().nonnegative()
    .describe('§3.2 + §2.4 — totale KV uit M1 (= KV_OP + KV_NP). Primaire input voor §3.5 v3.0 ppk-formule (KV als CW_voor per individu)'),
  KV_OP: z.number().nonnegative()
    .describe('§3.2 + §2.4 — KV_OP uit M1; OP-component voor §3.5 v3.0 lineaire OP-decompositie ppk_OP = KV_OP + x*·cw_star_op'),
  KV_NP: z.number().nonnegative()
    .describe('§3.2 + §2.4 — KV_NP uit M1; 0 indien heeftPartner=false. NP-component voor §3.5 v3.0 ppk_NP = KV_NP + x*·cw_star_np'),
  cw_star_op: z.number().nonnegative()
    .describe('§3.2 + §3.5 v3.0 — spreidings-gewogen CW van OP-aanspraak uit M1. Wettelijk: Σ_h q(h,N)·KS_OP(h)·v(h). M1 levert dit via m2Context-flag.'),
  cw_star_np: z.number().nonnegative()
    .describe('§3.2 + §3.5 v3.0 — spreidings-gewogen CW van NP-aanspraak uit M1. Joint-life met broken-heart bij heeftPartner=true; 0 als geen partner.'),
}).superRefine((data, ctx) => {
  // Sluitingscontrole: KV_OP + KV_NP = KV (engine-anker, v2.1.1 ppk-sluitings-
  // controle vereist consistente KV-decompositie als startwaarde).
  const sum = data.KV_OP + data.KV_NP
  const relDiff = data.KV === 0 ? 0 : Math.abs(sum - data.KV) / data.KV
  if (relDiff > 1e-6) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['KV'],
      message: `§3.2 keten-anker — KV_OP (${data.KV_OP}) + KV_NP (${data.KV_NP}) = ${sum} ≠ KV (${data.KV}); relatief verschil ${relDiff.toExponential(3)} > 1e-6. M1 moet KV-decompositie consistent leveren`,
    })
  }
})

export type M2KetenInput = z.infer<typeof M2KetenInputSchema>

// ----------------------------------------------------------------------------
// §3.3 Demografie — discriminated union (knelpunt A1, combi-sessie M2)
//
// Spec §3.3 + §3.8: exact één van `preset` (enum) OR `customCounts` (vector
// lengte 15). SCHEMA-formaat-keuze: discriminated union met `soort`-tag —
// type-narrowing werkt, runtime-validatie sluit op type-laag, parse-fouten
// blijven leesbaar. Tag `soort` is SCHEMA-laag-toevoeging, niet in spec-
// tabel; dit is analoog aan knelpunt 1 M1-sessie (F-wrapper als SCHEMA-laag).
//
// Preset-enum-waardes overgenomen uit R9.30-DEMOGRAFIE_PRESETS (lijn 3344) —
// generieke fondstype-templates, niet fonds-specifiek. De feitelijke aantallen
// zijn "indicatief; ze leveren alleen de vorm (fracties)" (R9.30-comment 3341).
//   - 'uniform'       — gelijke spreiding 25-99 (debug/sanity, geen fonds-realisme)
//   - 'grijzend'      — Grijzend bedrijfsfonds (R9.30-default; piek 55-69)
//   - 'gebalanceerd'  — Gebalanceerd fonds (piek 35-54)
//   - 'jong'          — Jong/groeiend fonds (piek 30-44)
//   - 'gesloten'      — Gesloten fonds (geen actieven; piek 65-89; SSPF-natuurlijke
//                       keuze als gesloten gepensheerden-fonds)
// SSPF-specifieke cohort-aantallen zijn niet gevonden in Keep-9.zip; default
// 'gesloten' tot Hans expliciete SSPF-data aanlevert (zie §11.19-stijl bron-todo).
// Bij SSPF-data kan customCounts[15] direct worden gevuld zonder enum-uitbreiding.
// ----------------------------------------------------------------------------

export const M2DemografiePresetSchema = z.enum(['uniform', 'grijzend', 'gebalanceerd', 'jong', 'gesloten'])
export type M2DemografiePreset = z.infer<typeof M2DemografiePresetSchema>

export const M2DemografieSchema = z.discriminatedUnion('soort', [
  z.object({
    soort: z.literal('preset'),
    preset: M2DemografiePresetSchema,
  }),
  z.object({
    soort: z.literal('customCounts'),
    customCounts: z
      .array(z.number().nonnegative())
      .length(15, '§3.3/§3.8 — customCounts moet exact 15 elementen hebben (cohorten 25-29 .. 95-99 per 5 jaar)'),
  }),
])
export type M2Demografie = z.infer<typeof M2DemografieSchema>

// ----------------------------------------------------------------------------
// §3.3 Invoerschema — fondsparameterset (M2-view)
//
// .pick(fondsvermogen) van shared (in M2 vereist non-null, afgedwongen via
// superRefine) + .extend() met M2-specifieke velden conform §3.3 v2.2.10:
//   - dekkingsgraad, compensatiedepot, vpvAftrekPct (v2.2.10 actief),
//     overigeReserves (deprecated v2.2.10), operationeleReserveringPct
//     (deprecated v2.2.10), bijstort, N_deelnemers, spreidingN (CRM-2026-34
//     uiDisclosure), compensatieMu, compensatieSigma, buffer, demografie.
//   - φ(x) als gereserveerd v1-veld blijft uit SCHEMA v2.0 (impliciet via
//     §3.5-formule); upgrade-pad via SCHEMA minor-bump bij heroverweging.
//
// superRefine implementeert §3.8 hard-rejects:
//   1. fondsvermogen non-null (overschrijft shared nullable() voor M2)
//   2. dekkingsgraad ∈ [0.5, 2.0]
//   3. v2.2.10 bundle-conflict: legacy-velden vs vpvAftrekPct waarschuwing
// ----------------------------------------------------------------------------

export const M2ParametersetSchema = FondsParametersetSchema.pick({
  // Alle 9 shared velden — M2 doet annuïteits-berekeningen (kvProfile, ν(N),
  // s(x,N,g)) die identieke discontering/sterfte/horizon-config nodig hebben
  // als M1. Dezelfde set als M1.parameterset.pick() — fondsbreedte-consistent.
  r: true,
  sterftekansTabelId: true,
  t0: true,
  ervaringsSterfte: true,
  m: true,
  annuiteitsconventie: true,
  pi: true,
  fondsvermogen: true,
  omega: true,
}).extend({
  // --- Dekkingsgraad (§3.3 actief) ---
  dekkingsgraad: F(
    z.number().min(0.5).max(2.0)
      .describe('§3.3 actief — dekkingsgraad als fractie, typisch 1,0-1,5; hard reject buiten [0.5, 2.0] (§3.8)'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 + §3.8' },
    'M2.parameterset.dekkingsgraad'
  ),

  // --- vpvTotal (§3.3 v3.0.94 actief — anker-grootheid voor F+DG-tandem) ---
  // v3.0.94 architectuur: vpvTotal (totale technische voorziening) is voortaan
  // fonds-anker uit data, niet meer afgeleid uit F/DG. F en DG worden in tandem
  // gehouden rond dit anker (F = DG × vpvTotal). Default 0 = backward-compat
  // sentinel: engine valt terug op F/DG-afleiding voor fixtures zonder anker.
  vpvTotal: F(
    z.number().nonnegative().default(0)
      .describe('§3.3 v3.0.94 actief — totale technische voorziening in mln euro (fonds-anker). Bij waarde > 0 gebruikt engine deze direct als vpvTotal; bij 0 valt engine terug op fondsvermogen / dekkingsgraad voor backward-compat met v3.0.93-fixtures.'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 v3.0.94' },
    'M2.parameterset.vpvTotal'
  ),

  // --- Compensatiedepot (§3.3 actief; v2.1.2 bronverankerd; v2.2.10 apart van vpvAftrekPct-bundle) ---
  compensatiedepot: F(
    z.number().nonnegative().default(0)
      .describe('§3.3 actief — compensatiedepot in mln euro; v2.2.10 expliciet apart van vpvAftrekPct-bundle (Model C) om bell-curve-input behouden te houden. Bij ABN-bron als referentie eerst decomposeren in vpvAftrekPct(zonder-comp) + compensatiedepot(apart) — zie §3.10 dubbele-administratie-noot'),
    {
      display: 'parameter-audit',
      module: 'M2',
      specRef: '§3.3 + §3.10 v2.2.10',
      uiDisclosure: '§3.10 v2.1.2/v2.2.10 — compensatie is wettelijk voor actieven met gemiste toekomstige opbouw (art. 150f Pw + DNB Q&A juni 2025). SSPF-gepensioneerden vallen strikt buiten DRS-doelgroep; bell-tail bijdrage is numeriek klein maar conceptueel onjuist. v1 reproduceert R9.30; herbeoordelen bij latere release-ronde',
    },
    'M2.parameterset.compensatiedepot'
  ),

  // --- vpvAftrekPct (§3.3 v2.2.10 actief; bundle-aftrek conform ABN-praktijk) ---
  vpvAftrekPct: F(
    z.number().min(0).max(0.30).default(0.10)
      .describe('§3.3 v2.2.10 actief — bundle-aftrek-fractie van vpvTotal voor VEV + operationele reserve + solidariteitsreserve + inhaalindexatie (alles behalve compensatiedepot). Default 0,10 ABN-conservatief; SSPF-bron-todo §11.19. Verdeelbaar-formule: fondsvermogen − vpvAftrekPct·vpvTotal − compensatiedepot − buffer + bijstort'),
    {
      display: 'parameter-audit',
      module: 'M2',
      specRef: '§3.3 + §3.5 + §11.19 v2.2.10',
      uiDisclosure: '§3.10 v2.2.10 — ABN-publicatie als hoofdbron (transitieplan 17-10-2024 + implementatieplan 22-09-2025; geverifieerd via CRM-2026-34 bundle-toelichting DG-115/125/135). LET OP: ABN\'s 0,10 bevat compensatiedepot wél en is voor gemengd-leeftijds-fonds gekalibreerd; SSPF (gesloten, alleen gepensioneerden) heeft andere bundle-samenstelling. Klakkeloos overnemen → compensatie dubbel telt of verkeerd kalibreert',
    },
    'M2.parameterset.vpvAftrekPct'
  ),

  // --- overigeReserves (§3.3 deprecated v2.2.10 — backward-compat) ---
  overigeReserves: F(
    z.number().nonnegative().default(0)
      .describe('§3.3 DEPRECATED v2.2.10 — overige reserveringen in mln euro. Behouden voor backward-compat met v2.1.x-datasets; v2.2.10-engine leest dit veld niet meer (vervangen door vpvAftrekPct-bundle). Bij gelijktijdig gevuld én vpvAftrekPct gevuld: superRefine-waarschuwing'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 deprecated v2.2.10' },
    'M2.parameterset.overigeReserves'
  ),

  // --- operationeleReserveringPct (§3.3 deprecated v2.2.10 — backward-compat) ---
  operationeleReserveringPct: F(
    z.number().nonnegative().default(0.02)
      .describe('§3.3 DEPRECATED v2.2.10 — operationele reservering als fractie van fondsvermogen (legacy grondslag). Behouden voor backward-compat met v2.1.x-datasets; v2.2.10-engine leest dit veld niet meer (vervangen door vpvAftrekPct-bundle, grondslag-shift naar vpv). Bij gelijktijdig gevuld én vpvAftrekPct gevuld: superRefine-waarschuwing'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 deprecated v2.2.10' },
    'M2.parameterset.operationeleReserveringPct'
  ),

  // --- bijstort (§3.3 actief) ---
  bijstort: F(
    z.number().nonnegative().default(0)
      .describe('§3.3 actief — werkgeversbijdrage in mln euro bij transitie; toegevoegd aan verdeelbaar (§3.5)'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 + §3.5' },
    'M2.parameterset.bijstort'
  ),

  // --- N_deelnemers (§3.3 actief; verplicht voor ppkComp-normalisatie) ---
  N_deelnemers: F(
    z.number().int().positive()
      .describe('§3.3 actief — totaal aantal deelnemers voor cohort-normalisatie ν(N) en compensatie-deler. Hard reject ≤ 0 (§3.8: deling-door-nul in ppkComp)'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 + §3.8' },
    'M2.parameterset.N_deelnemers'
  ),

  // --- spreidingN (§3.3 actief; CRM-2026-34 + §11.21 v3.0 uiDisclosure) ---
  spreidingN: F(
    z.number().int().min(0).max(1000).default(10)
      .describe('§3.3 actief — wettelijke spreidingstermijn in jaren (bijlage 2a Regeling Pensioenwet art. 2 lid 1). Default 10. Range [0, 1000]: 10 = wettelijke standaard, 1000 = proxy voor oneindige spreiding (educatieve N=∞-vergelijking, §11.21 v3.0). Tussenwaarden onderbouwbaar onder art. 2 lid 3 (kortere altijd toegestaan, langere alleen bij DG > 100%).'),
    {
      display: 'parameter-audit',
      module: 'M2',
      specRef: '§3.3 + §3.8 + §3.6 aanname 13 + §11.21 v3.0',
      uiDisclosure: 'Wettelijke spreidingstermijn 10 jaar (bijlage 2a Regeling Pw art. 2). CRM-2026-34 (04-03-2026): 10-jaars termijn levert indirect leeftijdsonderscheid op — oudste gepensioneerden ontvangen op transitiedatum typisch minder dan de helft van wat actieve deelnemers ontvangen — maar is objectief gerechtvaardigd. Wettelijke uitwijkmogelijkheid art. 2 lid 3 alleen onder voorwaarden. v3.0 (§11.21, 05-05-2026): N=1000 als proxy voor oneindige spreiding maakt de leeftijdsongelijkheid bijna verdwijnen — verdeling wordt bijna proportioneel aan KV. Verschil N=10 vs N=1000 toont educatief hoeveel van de leeftijdsongelijkheid specifiek aan de stylering van indexatie-blootstelling toegeschreven kan worden.',
    },
    'M2.parameterset.spreidingN'
  ),

  // --- compensatieMu, compensatieSigma (§3.3 actief; bell-curve parameters) ---
  compensatieMu: F(
    z.number().min(20).max(80).default(55)
      .describe('§3.3 actief — leeftijd-middelpunt μ Gaussische compensatie-curve. Default 55 (mid-carrière). Bereik [20,80] als sanity-check'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 + §3.5' },
    'M2.parameterset.compensatieMu'
  ),

  compensatieSigma: F(
    z.number().positive().default(8)
      .describe('§3.3 actief — standaardafwijking σ compensatie-curve. Default 8. Hard reject σ ≤ 0 (§3.8)'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 + §3.8' },
    'M2.parameterset.compensatieSigma'
  ),

  // --- buffer (§3.3 actief; M2→M3-koppeling) ---
  buffer: F(
    z.number().nonnegative().default(0)
      .describe('§3.3 actief — RDR-buffer in mln euro; afgezonderd van verdeelbaar voor M3-demping (§4.3 v2.1.6). M2-output buffer-aandeel = buffer · (KV_totaal / vpvTotal). SSPF-design: eenmalige RDR-buffer bij invaren'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 + §3.10 buffer-koppeling' },
    'M2.parameterset.buffer'
  ),

  // --- demografie (§3.3 actief; discriminated union — knelpunt A1) ---
  demografie: F(
    M2DemografieSchema
      .describe('§3.3 actief — populatieverdeling over 15 cohorten (25-29 .. 95-99 per 5 jr). Discriminated union: exact één van preset (enum SSPF/CBS-NL/uniform) OF customCounts (vector lengte 15). Geen fallback — hard reject ontbreken (§3.7). Preset-enum is v2.0 SCHEMA-laag-keuze; bron-onderbouwde definitieve set in latere SCHEMA minor-bump'),
    { display: 'parameter-audit', module: 'M2', specRef: '§3.3 + §3.7 + §3.8' },
    'M2.parameterset.demografie'
  ),
}).superRefine((data, ctx) => {
  // §3.8 hard reject: fondsvermogen mag in M2 niet null zijn (shared nullable
  // is voor M1's §2.7 ρ-ladder; M2 vereist primaire bron).
  if (data.fondsvermogen === null) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['fondsvermogen'],
      message: '§3.3/§3.8 — fondsvermogen is verplicht non-null voor M2 (primair input voor §3.5 verdeelbaar-formule)',
    })
  }

  // §3.10 v2.2.10 bundle-conflict-waarschuwing: legacy-velden ingevuld én
  // vpvAftrekPct ook ingevuld → engine gebruikt v2.2.10-bundle, legacy-veld
  // wordt genegeerd. Documentair signaal, geen hard reject (datasets in
  // migratie krijgen vrije baan; expliciete legacy=0 is geldige opt-out).
  const vpvActief = data.vpvAftrekPct !== undefined && data.vpvAftrekPct > 0
  const legacyOverigActief = data.overigeReserves !== undefined && data.overigeReserves > 0
  const legacyOperActief = data.operationeleReserveringPct !== undefined && data.operationeleReserveringPct !== 0.02
  if (vpvActief && (legacyOverigActief || legacyOperActief)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['vpvAftrekPct'],
      message:
        '§3.10 v2.2.10 — vpvAftrekPct én legacy-velden (overigeReserves/operationeleReserveringPct) gelijktijdig gevuld: v2.2.10-engine gebruikt vpvAftrekPct-bundle en negeert legacy. Voor schone migratie: zet legacy-velden op default (0 resp. 0.02) of expliciet 0',
    })
  }

  // §3.8 demografie consistency check: discriminated union dwingt al exact-
  // één-van af op type-niveau; lengte 15 ook al via .length(). Geen extra
  // refine nodig.
})

export type M2Parameterset = z.infer<typeof M2ParametersetSchema>

// ----------------------------------------------------------------------------
// §3.4 Output — cohortOutcome shape
//
// Spec §3.4 zegt: "array, per cohort (25-29, 30-34, ..., 95-99) aggregaten
// voor deepdive-weergave". Spec is bewust vaag — implementatie-keuze. v2.0
// SCHEMA-laag-definitie van cohort-aggregaat-velden. Vaste array-lengte 15
// (cohorten 25-29 .. 95-99 per 5 jaar) conform demografie.customCounts-eis.
//
// Veldselectie (S2-keuze combi-sessie M2 04-05-2026): aparte velden voor
// `surplusBijdrage` en `compBijdrage` zodat sommatie-verificatie direct
// mogelijk is (Σ_c surplusBijdrage_c = ppkSurplus, Σ_c compBijdrage_c =
// ppkComp). `kvAvg` (gemiddelde KV per cohort) i.p.v. `kvTotaal`-som omdat
// gemiddelde direct vergelijkbaar is met deelnemer-eigen KV op audit.
// ----------------------------------------------------------------------------

export const CohortOutcomeSchema = z.object({
  range: z.string().regex(/^\d{2}-\d{2}$/,
    '§3.4 — cohort-bereik-label moet "NN-NN" formaat hebben (bv "25-29")')
    .describe('§3.4 — leesbare cohort-label, bv "25-29" of "95-99"'),
  midage: z.number().int().min(27).max(97)
    .describe('§3.4 + §3.6 aanname 8 — middel-leeftijd voor ν(N) cohort-vertegenwoordiging; 5-jaars cohort 25-29 → midage 27, 95-99 → midage 97'),
  n: z.number().int().nonnegative()
    .describe('§3.4 — aantal deelnemers in cohort (uit demografie.customCounts of preset)'),
  kvAvg: z.number().nonnegative().nullable()
    .describe('§3.4 — gemiddelde KV per deelnemer in cohort (mln euro). Null bij n=0 om delings-degeneratie te vermijden. Audit-vergelijkbaar met deelnemer-eigen KV'),
  surplusBijdrage: z.number().nonnegative()
    .describe('§3.4 + §3.5 — diagnostisch fonds-niveau cohort-aandeel: (n_c · kv̄_c / vpvTotal) · surplus · s̄(x̄_c, N) · ν(N). LET OP: dit is GEEN sommatie-haak naar individuele ppkSurplus (=cohort-c-aandeel/n_c gericht op één deelnemer); Σ_c surplusBijdrage_c geeft fonds-equivalent surplus-toedeling, niet eigen ppkSurplus. Persoonlijke ppkSurplus = (KV/vpvTotal)·surplus·sFactor(x₀,g)·ν, los van dit cohort-veld'),
  compBijdrage: z.number().nonnegative()
    .describe('§3.4 + §3.5 — cohort-aandeel in compensatiedepot via bell-curve: compensatiedepot · (n_c · w(x̄_c)) / Σ_d (n_d · w(x̄_d)). DIT veld IS direct verifieerbaar: Σ_c compBijdrage_c = compensatiedepot exact (bell-curve normalisatie, mits N_deelnemers > 0)'),
})
export type CohortOutcome = z.infer<typeof CohortOutcomeSchema>

// ----------------------------------------------------------------------------
// §3.4 Output — M2 (11 velden + drie sluitingscontroles)
// ----------------------------------------------------------------------------

export const M2OutputSchema = z.object({
  // --- Drie ppk-componenten + totaal (§3.4 + §3.5) ---
  ppkBase: F(
    z.number().nonnegative()
      .describe('§3.4 + §3.5 — dekking-deel: KV_totaal · min(1, verdeelbaar/vpvTotal). Bij volledige dekking gaat hele vpv-aandeel mee; bij onderdekking pro-rata'),
    { display: 'decompositie', module: 'M2', specRef: '§3.4 + §3.5 + §3.6 aanname 2' },
    'M2.output.ppkBase'
  ),

  ppkSurplus: F(
    z.number().nonnegative()
      .describe('§3.4 + §3.5 — overschot-deel via DNB-spreidingsmethode; bottom-up som ppk_OP_surplus + ppk_NP_surplus elk met eigen sFactor (Notatie-noot v2.1.1). Nul bij dekkingsgraad ≤ 100%'),
    { display: 'decompositie', module: 'M2', specRef: '§3.4 + §3.5 + §3.6 aanname 3 + v2.1.1' },
    'M2.output.ppkSurplus'
  ),

  ppkComp: F(
    z.number().nonnegative()
      .describe('§3.4 + §3.5 — compensatie-deel via Gaussische bell-curve (compensatieMu, compensatieSigma) over alle cohorten 25-99; volledig aan OP toegewezen (§3.6 aanname 11, v2.1.2 bronverankerd)'),
    {
      display: 'decompositie',
      module: 'M2',
      specRef: '§3.4 + §3.5 + §3.6 aanname 11 + v2.1.2',
      uiDisclosure: '§3.10 v2.1.2/v2.2.10 — bell-curve verdeelt compensatie over hele populatie 25-99; SSPF-gepensioneerden vallen strikt buiten DRS-compensatie-doelgroep (art. 150f Pw + DNB Q&A juni 2025); v1 reproduceert R9.30-gedrag, bell-tail-bijdrage numeriek klein',
    },
    'M2.output.ppkComp'
  ),

  ppkTotal: F(
    z.number().nonnegative()
      .describe('§3.4 + §3.5 — som van de drie componenten over KV_totaal: ppkBase + ppkSurplus + ppkComp. Sluitingscontrole afgedwongen via superRefine'),
    { display: 'hoofdpad', module: 'M2', specRef: '§3.4 + §3.5' },
    'M2.output.ppkTotal'
  ),

  // --- OP/NP-decompositie (§3.4 + §11.18 + v2.1.1/v2.1.2) ---
  ppk_OP: F(
    z.number().nonnegative()
      .describe('§3.4 + §11.18 — OP-deel van ppkTotal, geoormerkt binnen één persoonlijk pensioenvermogen. Proportioneel aan KV_OP/KV_totaal voor base; gender-specifieke s(x₀,N,g) voor surplus; volledig ppkComp toegewezen aan OP (v2.1.1/v2.1.2)'),
    { display: 'decompositie', module: 'M2', specRef: '§3.4 + §11.18 + v2.1.1' },
    'M2.output.ppk_OP'
  ),

  ppk_NP: F(
    z.number().nonnegative()
      .describe('§3.4 + §11.18 — NP-deel van ppkTotal; proportioneel aan KV_NP/KV_totaal voor base; gender-specifieke s(x_partner,N,g_y) voor surplus; geen ppkComp-component (v2.1.1/v2.1.2). Nul indien heeftPartner=false'),
    { display: 'decompositie', module: 'M2', specRef: '§3.4 + §11.18 + v2.1.1' },
    'M2.output.ppk_NP'
  ),

  // --- Buffer-aandeel (§3.4; M2→M3-input) ---
  bufferAandeel: F(
    z.number().nonnegative()
      .describe('§3.4 — naar module 3: buffer · (KV_totaal / vpvTotal). RDR-buffer-doorgift voor M3 demping (§4.3 v2.1.6)'),
    { display: 'decompositie', module: 'M2', specRef: '§3.4 + §3.10 buffer-koppeling' },
    'M2.output.bufferAandeel'
  ),

  // --- CohortOutcomes (§3.4; deepdive-array) ---
  cohortOutcomes: F(
    z.array(CohortOutcomeSchema).length(15,
      '§3.4 — vaste 15 cohorten (25-29 .. 95-99 per 5 jaar)'),
    { display: 'deepdive', module: 'M2', specRef: '§3.4 + §3.5' },
    'M2.output.cohortOutcomes'
  ),

  // --- Diagnostische velden (§3.4; deepdive/diagnose) ---
  vpvTotal: F(
    z.number().positive()
      .describe('§3.4 + §3.5 — totale technische voorziening = fondsvermogen / dekkingsgraad'),
    { display: 'deepdive', module: 'M2', specRef: '§3.4 + §3.5' },
    'M2.output.vpvTotal'
  ),

  verdeelbaar: F(
    z.number()
      .describe('§3.4 + §3.5 v2.2.10 — verdeelbaar fondsvermogen na bundle-aftrek: fondsvermogen − vpvAftrekPct·vpvTotal − compensatiedepot − buffer + bijstort. Kan negatief zijn als reserveringen overschrijden (§3.8 waarschuwing)'),
    { display: 'deepdive', module: 'M2', specRef: '§3.4 + §3.5 v2.2.10' },
    'M2.output.verdeelbaar'
  ),

  phiDerived: F(
    z.number().nonnegative().nullable()
      .describe('§3.4 + §11.1 v1.1 + v2.1.3 — afgeleide toedelingsfactor ppkTotal / V_x^Wtp_totaal indien V_x^Wtp_totaal beschikbaar uit M4; null als niet beschikbaar (§11.12 Optie 1 v2.1.3 + v2.2.7 bevestigd). Decoratief: geen invloed op ppkTotal. Geen component-varianten in v1'),
    { display: 'diagnose', module: 'M2', specRef: '§3.4 + §11.1 + §11.12 v2.1.3' },
    'M2.output.phiDerived'
  ),
}).superRefine((data, ctx) => {
  // Sluitingscontrole 1 (v2.1.1 exact): ppk_OP + ppk_NP = ppkTotal
  // Tolerantie 1e-6 (relatief) wegens floating-point. Bij DG=1, KV~800k:
  // 1e-6 levert toleratie ~0.80 mln in ppk-eenheden.
  const opNpSum = data.ppk_OP + data.ppk_NP
  const opNpRelDiff = data.ppkTotal === 0 ? 0 : Math.abs(opNpSum - data.ppkTotal) / Math.abs(data.ppkTotal)
  if (opNpRelDiff > 1e-6) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['ppkTotal'],
      message: `§3.4 + v2.1.1 sluitingscontrole — ppk_OP (${data.ppk_OP}) + ppk_NP (${data.ppk_NP}) = ${opNpSum} ≠ ppkTotal (${data.ppkTotal}); relatief verschil ${opNpRelDiff.toExponential(3)} > 1e-6`,
    })
  }

  // Sluitingscontrole 2 (§3.4): ppkBase + ppkSurplus + ppkComp = ppkTotal
  // Zelfde tolerantie.
  const componentSum = data.ppkBase + data.ppkSurplus + data.ppkComp
  const compRelDiff = data.ppkTotal === 0 ? 0 : Math.abs(componentSum - data.ppkTotal) / Math.abs(data.ppkTotal)
  if (compRelDiff > 1e-6) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['ppkTotal'],
      message: `§3.4 sluitingscontrole — ppkBase (${data.ppkBase}) + ppkSurplus (${data.ppkSurplus}) + ppkComp (${data.ppkComp}) = ${componentSum} ≠ ppkTotal (${data.ppkTotal}); relatief verschil ${compRelDiff.toExponential(3)} > 1e-6`,
    })
  }

  // Sluitingscontrole 3 (§3.4): heeftPartner=false impliceert ppk_NP = 0
  // Deze controle hangt af van M1Deelnemer-context die hier niet beschikbaar
  // is; engine moet dit afdwingen vóór parse(). SCHEMA controleert alleen
  // de structurele non-negative-eis (al via z.number().nonnegative()).
})

export type M2Output = z.infer<typeof M2OutputSchema>

// ============================================================================
// EXPORT — samenvattend
// ============================================================================

export const M1 = {
  deelnemer: M1DeelnemerSchema,
  parameterset: M1ParametersetSchema,
  output: M1OutputSchema,
} as const

/**
 * M2 (potje, §3) — engine signature met expliciete keten-input:
 *   computeM2(d: M1Deelnemer, k: M2KetenInput, p: M2Parameterset): M2Output
 * M2KetenInputSchema documenteert KV/KV_OP/KV_NP-doorgift uit M1.
 */
export const M2 = {
  ketenInput: M2KetenInputSchema,
  parameterset: M2ParametersetSchema,
  output: M2OutputSchema,
  demografie: M2DemografieSchema,
  cohortOutcome: CohortOutcomeSchema,
} as const

// ----------------------------------------------------------------------------
// AUDIT-HELPERS — voor audit-scherm-generatie (Model D)
// ----------------------------------------------------------------------------

/**
 * Alle velden van een module, gefilterd op display-klasse(s).
 *
 * Shared-velden (module='shared', gedefinieerd in FondsParametersetSchema)
 * verschijnen automatisch in elke module-audit-sectie. Bij expliciete
 * fieldsByDisplay('shared', ...) krijg je uitsluitend shared-velden.
 */
export function fieldsByDisplay(
  module: FieldMeta['module'],
  displays: Display[]
): typeof FIELD_REGISTRY {
  return FIELD_REGISTRY.filter((f) => {
    if (!displays.includes(f.meta.display)) return false
    if (module === 'shared') return f.meta.module === 'shared'
    return f.meta.module === module || f.meta.module === 'shared'
  })
}

/** Alle velden met uiDisclosure-eis (voor audit-scherm disclosure-sectie). */
export function fieldsWithDisclosure(): typeof FIELD_REGISTRY {
  return FIELD_REGISTRY.filter((f) => f.meta.uiDisclosure !== undefined)
}
