/**
 * M2-engine regressie-test. Pendant van test_engine.ts (M1).
 *
 * Doel: vaststellen numeriek anker voor SSPF-default-scenario,
 * sluitingscontroles verifiëren, gevoeligheids-puntmetingen.
 */

// Injecteer AG2024 via globale window-proxy vóór imports
import * as fs from 'fs'
import * as path from 'path'
import { fileURLToPath } from 'url'
// v3.0.38: relatief pad t.o.v. dit bestand zodat restore-locatie niet uitmaakt
// (was hardcoded /home/claude/keep9/ag2024.json — brak in nieuwe sessies).
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const ag2024Data = JSON.parse(
  fs.readFileSync(path.resolve(__dirname, '../ag2024.json'), 'utf-8')
)
// @ts-expect-error — window-proxy voor node
globalThis.window = { __AG2024__: ag2024Data }

import { M1, M2 } from './schema.v2'
import { computeM1 } from './engine.m1'
import {
  computeM2,
  dnbShareFactor,
  dnbNormFactor,
  bellW,
  wAverage,
  wRelative,
  getCohortFractions,
  getAG2024 as _getAG,
} from './engine.m2'
import { getAG2024 } from './engine.m1'
import { SSPF_M1_PLACEHOLDER, SSPF_M2_PLACEHOLDER } from './fondsdataset'

// Avoid linter complaint about unused imports
void _getAG

console.log('=== M2-engine regressie-test ===\n')

// ============================================================================
// Test M2-1: dnbShareFactor — gender-verschil
// ============================================================================
console.log('Test M2-1: dnbShareFactor s(67, 10, g)')
const data = getAG2024()
const sM = dnbShareFactor(67, 10, 2026, 'M', { f: 1.0, data })
const sV = dnbShareFactor(67, 10, 2026, 'V', { f: 1.0, data })
const sMix = dnbShareFactor(67, 10, 2026, 'gemengd', { f: 1.0, data })
console.log(`  s(67, 10, M)       = ${sM.toFixed(4)}`)
console.log(`  s(67, 10, V)       = ${sV.toFixed(4)}`)
console.log(`  s(67, 10, gemengd) = ${sMix.toFixed(4)}`)
console.log(`  V > M (V leeft langer): ${sV > sM ? '✓' : '✗'}`)
console.log()

// ============================================================================
// Test M2-2: bell-curve gevoeligheid bij μ=55, σ=8
// ============================================================================
console.log('Test M2-2: bellW + wRelative voor verschillende leeftijden')
const fractions_gesloten = getCohortFractions({
  soort: 'preset',
  preset: 'gesloten',
})
const wAvg = wAverage(55, 8, fractions_gesloten)
console.log(`  w̄ (gesloten preset, μ=55, σ=8) = ${wAvg.toFixed(4)}`)
for (const x of [30, 45, 55, 67, 80]) {
  const w = bellW(x, 55, 8)
  const wR = wRelative(x, 55, 8, wAvg)
  console.log(`  x=${x}: w(x)=${w.toFixed(4)}, w_rel(x)=${wR.toFixed(4)}`)
}
console.log()

// ============================================================================
// Test M2-3: ν(N) cohort-normalisatie voor SSPF-default
// ============================================================================
console.log('Test M2-3: ν(N) voor gesloten preset')
const nu = dnbNormFactor(
  10,
  fractions_gesloten,
  30000, // pen
  0.02,  // r
  2026,
  { m: 12, pi: 0, f: 1.0, omega: 120, data }
)
console.log(`  ν(10, pen=€30k, r=2%) = ${nu.toFixed(4)}`)
console.log(`  Verwachting ν > 1 (correctie omhoog), tweede-orde (~1.0-1.1)`)
console.log()

// ============================================================================
// Test M2-4: Volledige M2-berekening — SSPF-default scenario
// ============================================================================
console.log('Test M2-4: M2 — 67-jarige man, €30k, geen partner, SSPF-defaults')
const deelnemer1 = M1.deelnemer.parse({ x0: 67, pen: 30000, g: 'M' })
const m1params = M1.parameterset.parse(SSPF_M1_PLACEHOLDER)
// v3.0.28: SSPF_M2_PLACEHOLDER.dekkingsgraad is bijgewerkt van 1.15 naar 1.35
// (SSPF-publicatie 31-03-2026); engine-anker-tests forceren expliciet DG=1.15
// voor regression-baseline-stabiliteit (€464.822 / €574.369 ongewijzigd).
const m2params = M2.parameterset.parse({ ...SSPF_M2_PLACEHOLDER, dekkingsgraad: 1.15 })
// v3.0: M1 met m2Context voor cw_star-levering aan M2
const m1out = computeM1(deelnemer1, m1params, { spreidingN: m2params.spreidingN })

const ketenInput1 = M2.ketenInput.parse({
  KV: m1out.KV,
  KV_OP: m1out.KV_OP,
  KV_NP: m1out.KV_NP,
  cw_star_op: m1out.cw_star_op ?? 0,
  cw_star_np: m1out.cw_star_np ?? 0,
})
const out1 = computeM2(deelnemer1, ketenInput1, m2params)

const fmt = (x: number) =>
  '€ ' + x.toLocaleString('nl-NL', { maximumFractionDigits: 0 })
const fmtMln = (x: number) => (x / 1).toFixed(2) + ' mln'

console.log(`  KV (M1)           = ${fmt(m1out.KV)}`)
console.log(`  fondsvermogen     = ${(m2params.fondsvermogen as number).toFixed(0)} mln € (= ${((m2params.fondsvermogen as number) * 1e6 / 1e9).toFixed(2)} mrd €)`)
console.log(`  vpvTotal          = ${(out1.vpvTotal / 1e6).toFixed(0)} mln €`)
console.log(`  verdeelbaar       = ${(out1.verdeelbaar / 1e6).toFixed(0)} mln €  (${(out1.verdeelbaar / ((m2params.fondsvermogen as number) * 1e6) * 100).toFixed(1)}% van fondsvermogen)`)
console.log(`  surplus           = ${(Math.max(0, out1.verdeelbaar - out1.vpvTotal) / 1e6).toFixed(0)} mln €`)
console.log(`  baseRatio         = ${Math.min(1, out1.verdeelbaar / out1.vpvTotal).toFixed(4)}  (gecapt op 1)`)
console.log(`  ppkBase           = ${fmt(out1.ppkBase)}  (${(out1.ppkBase / m1out.KV * 100).toFixed(1)}% van KV)`)
console.log(`  ppkSurplus        = ${fmt(out1.ppkSurplus)}`)
console.log(`  ppkComp           = ${fmt(out1.ppkComp)}  (compensatiedepot=0 → 0)`)
console.log(`  ppkTotal          = ${fmt(out1.ppkTotal)}`)
console.log(`  ppk_OP            = ${fmt(out1.ppk_OP)}`)
console.log(`  ppk_NP            = ${fmt(out1.ppk_NP)}`)
console.log(`  bufferAandeel     = ${fmt(out1.bufferAandeel)}  (buffer=0 → 0)`)
console.log()

// Sluitingscontroles handmatig
const sumComps = out1.ppkBase + out1.ppkSurplus + out1.ppkComp
const sumOPNP = out1.ppk_OP + out1.ppk_NP
console.log(`  Sluitingscontrole 1: ppkBase+Surplus+Comp = ${fmt(sumComps)} ≈ ppkTotal ${fmt(out1.ppkTotal)}`)
console.log(`  Sluitingscontrole 2: ppk_OP + ppk_NP      = ${fmt(sumOPNP)} ≈ ppkTotal ${fmt(out1.ppkTotal)}`)
console.log()

// ============================================================================
// Test M2-5: Met partner — NP-aandeel verschijnt
// ============================================================================
console.log('Test M2-5: M2 — 67M, partner V 65, y₀=€21k, SSPF-defaults')
const deelnemer2 = M1.deelnemer.parse({
  x0: 67, pen: 30000, g: 'M',
  heeftPartner: true, y0: 21000, x_partner: 65, g_y: 'V',
})
const m1out2 = computeM1(deelnemer2, m1params, { spreidingN: m2params.spreidingN })
const ketenInput2 = M2.ketenInput.parse({
  KV: m1out2.KV,
  KV_OP: m1out2.KV_OP,
  KV_NP: m1out2.KV_NP,
  cw_star_op: m1out2.cw_star_op ?? 0,
  cw_star_np: m1out2.cw_star_np ?? 0,
})
const out2 = computeM2(deelnemer2, ketenInput2, m2params)
console.log(`  KV (M1)         = ${fmt(m1out2.KV)} (waarvan KV_NP = ${fmt(m1out2.KV_NP)})`)
console.log(`  ppkTotal        = ${fmt(out2.ppkTotal)}`)
console.log(`  ppk_OP          = ${fmt(out2.ppk_OP)}`)
console.log(`  ppk_NP          = ${fmt(out2.ppk_NP)} (${(out2.ppk_NP / out2.ppkTotal * 100).toFixed(1)}% van totaal)`)
console.log(`  Sluitingscontrole: |ppk_OP+ppk_NP - ppkTotal| = ${Math.abs(out2.ppk_OP + out2.ppk_NP - out2.ppkTotal).toExponential(3)}`)
console.log()

// ============================================================================
// Test M2-6: dekkingsgraad-gevoeligheid (DG=1.05, 1.15, 1.25, 1.35)
// ============================================================================
console.log('Test M2-6: dekkingsgraad-gevoeligheid')
console.log('  DG    | verdeelbaar%  | ppkBase     | ppkSurplus  | ppkTotal')
for (const dg of [1.05, 1.15, 1.25, 1.35]) {
  const p = M2.parameterset.parse({ ...SSPF_M2_PLACEHOLDER, dekkingsgraad: dg })
  const o = computeM2(deelnemer1, ketenInput1, p)
  const verdPct = (o.verdeelbaar / ((p.fondsvermogen as number) * 1e6) * 100).toFixed(1)
  console.log(`  ${dg.toFixed(2)}  | ${verdPct.padStart(6)}%       | ${fmt(o.ppkBase).padStart(11)} | ${fmt(o.ppkSurplus).padStart(11)} | ${fmt(o.ppkTotal).padStart(10)}`)
}
console.log()

// ============================================================================
// Test M2-7: vpvAftrekPct-gevoeligheid (SSPF 0,06 vs ABN-default 0,10)
// ============================================================================
console.log('Test M2-7: vpvAftrekPct-gevoeligheid (Hans noemde "wel eens 6%")')
console.log('  vpvAftrek | verdeelbaar | ppkTotal       | %-verschil')
const baseline = computeM2(deelnemer1, ketenInput1, m2params)
for (const vap of [0.06, 0.08, 0.10, 0.12]) {
  const p = M2.parameterset.parse({ ...SSPF_M2_PLACEHOLDER, vpvAftrekPct: vap })
  const o = computeM2(deelnemer1, ketenInput1, p)
  const pct = ((o.ppkTotal / baseline.ppkTotal - 1) * 100).toFixed(2)
  console.log(`  ${(vap * 100).toFixed(0).padStart(2)}%       | ${(o.verdeelbaar / 1e6).toFixed(0)} mln €  | ${fmt(o.ppkTotal).padStart(13)}  | ${pct}%`)
}
console.log()

// ============================================================================
// Test M2-8: cohortOutcomes — sommatie-verifieerbaarheid
// ============================================================================
console.log('Test M2-8: cohortOutcomes sommatie-verifieerbaarheid')
const sumSurplus = out1.cohortOutcomes.reduce((s, c) => s + c.surplusBijdrage, 0)
const sumComp = out1.cohortOutcomes.reduce((s, c) => s + c.compBijdrage, 0)
console.log(`  Σ surplusBijdrage_c = ${(sumSurplus / 1e6).toFixed(2)} mln €`)
console.log(`  Σ compBijdrage_c    = ${(sumComp / 1e6).toFixed(4)} mln € (moet = compensatiedepot=${m2params.compensatiedepot} mln €)`)
console.log(`  Verifieerbaarheid Σcomp = compensatiedepot? ${Math.abs(sumComp / 1e6 - m2params.compensatiedepot) < 1e-6 ? '✓' : '✗ (' + Math.abs(sumComp / 1e6 - m2params.compensatiedepot).toExponential(3) + ')'}`)
console.log()

// ============================================================================
// Test M2-9: cohort-overzicht (audit-deepdive-preview)
// ============================================================================
console.log('Test M2-9: cohortOutcomes voor SSPF-default scenario (deepdive)')
console.log('  cohort | midage | n     | kvAvg (€)   | surplus (€)   | comp (€)')
for (const c of out1.cohortOutcomes) {
  const kvStr = c.kvAvg !== null ? c.kvAvg.toLocaleString('nl-NL', { maximumFractionDigits: 0 }).padStart(10) : '     ----'
  const surStr = c.surplusBijdrage.toLocaleString('nl-NL', { maximumFractionDigits: 0 }).padStart(13)
  const compStr = c.compBijdrage.toLocaleString('nl-NL', { maximumFractionDigits: 0 }).padStart(8)
  console.log(`  ${c.range.padEnd(6)} | ${c.midage.toString().padStart(6)} | ${c.n.toString().padStart(5)} | ${kvStr}  | ${surStr}  | ${compStr}`)
}
console.log()

// ============================================================================
// Test M2-10: zero-coverage edge case (DG < 1, x* negatief)
// v3.0 wet-canoniek: bij onderdekking is x_fonds negatief, ppkSurplus negatief
// (gespreide korting); ppkBase = KV blijft, ppkTotal < KV.
// ============================================================================
console.log('Test M2-10: edge case DG=0.85 (onderdekking)')
const params_under = M2.parameterset.parse({ ...SSPF_M2_PLACEHOLDER, dekkingsgraad: 0.85 })
const out_under = computeM2(deelnemer1, ketenInput1, params_under)
console.log(`  verdeelbaar = ${(out_under.verdeelbaar / 1e6).toFixed(1)} mln € (negatief = tekort)`)
console.log(`  ppkBase = ${fmt(out_under.ppkBase)} (= KV onder v3.0)`)
console.log(`  ppkSurplus = ${fmt(out_under.ppkSurplus)} (negatief onder v3.0 = gespreide korting via x* < 0)`)
console.log(`  ppkTotal = ${fmt(out_under.ppkTotal)} (< KV bij onderdekking)`)
console.log(`  Sluitingscontrole: |ppk_OP+ppk_NP - ppkTotal| = ${Math.abs(out_under.ppk_OP + out_under.ppk_NP - out_under.ppkTotal).toExponential(3)}`)
console.log()

console.log('=== Alle M2-tests uitgevoerd ===')
