/**
 * v3.0.41 — Print/PDF-rapport (browser-native).
 *
 * Bouwt een verborgen <div id="print-report"> uit de huidige state. Verschijnt
 * alleen in print-context (CSS @media print) zodat de gebruiker via de browser
 * "Afdrukken / Opslaan als PDF" een nette weergave krijgt:
 *
 *   1. Kop: invoerdatum, gekozen fonds, ingevulde UPO-gegevens
 *   2. Resultaten: KV (M1) + PPV (M2) met OP/NP-decompositie en sliders-stand
 *   3. Fondsparameters: M1- en M2-tabellen (analoog aan fonds-?-modal)
 *   4. Formules-appendix: wettelijke formules uit Bijlage 2a Pw + bron
 *   5. Disclaimer
 *
 * Privacy: alle data blijft client-side; window.print() opent de browser-PDF.
 *
 * Geen em-dashes (Werkafspraak v3.0.40).
 */

import type { M1Output, M2Output } from './schema.v2'
import { FONDS } from './fondsdataset'
import { escapeHtml } from './ui.shared'

interface PrintInput {
  deelnemer: {
    x0: number
    pen: number
    g: 'M' | 'V' | 'gemengd'
    heeftPartner: boolean
    y0: number | null
    x_partner: number | null
    g_y: 'M' | 'V' | 'gemengd'
  }
  parameters_m1: { r: number; [k: string]: unknown }
  parameters_m2: { dekkingsgraad: number; vpvAftrekPct: number; spreidingN: number; [k: string]: unknown }
  lastM1?: M1Output
  lastM2?: M2Output
  releaseVersion: string
  releaseDate: string
}

const eur = (n: number): string =>
  '\u20AC ' + Math.round(n).toLocaleString('nl-NL')
const pct = (n: number, d = 2): string =>
  (n * 100).toLocaleString('nl-NL', { minimumFractionDigits: d, maximumFractionDigits: d }) + '%'
const num = (n: number): string => n.toLocaleString('nl-NL')

const GESLACHT_LABEL: Record<string, string> = { M: 'man', V: 'vrouw', gemengd: 'gemengd' }

/**
 * Genereer de print-rapport-HTML. Wordt geïnjecteerd in #print-report.
 * v3.0.77: fondsKeuze-parameter weg; FONDS wordt direct geïmporteerd.
 */
export function buildPrintReportHtml(input: PrintInput): string {
  const { deelnemer, parameters_m1: p1, parameters_m2: p2,
          lastM1, lastM2, releaseVersion, releaseDate } = input
  const fonds = FONDS
  const m1f = fonds.m1
  const m2f = fonds.m2

  const today = new Date()
  const dd = String(today.getDate()).padStart(2, '0')
  const mm = String(today.getMonth() + 1).padStart(2, '0')
  const yyyy = today.getFullYear()
  const printDate = `${dd}-${mm}-${yyyy}`

  // === Sectie 1: kop + invoer ===
  const partnerRows = deelnemer.heeftPartner && deelnemer.y0 !== null && deelnemer.x_partner !== null
    ? `
        <tr><td>Leeftijd partner</td><td class="num">${num(deelnemer.x_partner)} jaar</td></tr>
        <tr><td>Geslacht partner</td><td class="num">${escapeHtml(GESLACHT_LABEL[deelnemer.g_y] ?? deelnemer.g_y)}</td></tr>
        <tr><td>Jaarlijks bruto nabestaandenpensioen</td><td class="num">${eur(deelnemer.y0)}</td></tr>
      `
    : `<tr><td>Partnerpensioen</td><td class="num">geen</td></tr>`

  const sectie1 = `
    <header class="pr-header">
      <h1>Invaarcalculator&reg; persoonlijk overzicht</h1>
      <p class="pr-subtitle">Voor wie pensioen ontvangt na de AOW-leeftijd</p>
      <p class="pr-meta">
        Datum afdruk: ${escapeHtml(printDate)}<br>
        Gekozen pensioenfonds: ${escapeHtml(fonds.label)}<br>
        Versie: ${escapeHtml(releaseVersion)} (build ${escapeHtml(releaseDate)})
      </p>
    </header>

    <section class="pr-section">
      <h2>1. Uw invoer</h2>
      <table class="pr-table">
        <tbody>
          <tr><td>Leeftijd</td><td class="num">${num(deelnemer.x0)} jaar</td></tr>
          <tr><td>Geslacht</td><td class="num">${escapeHtml(GESLACHT_LABEL[deelnemer.g] ?? deelnemer.g)}</td></tr>
          <tr><td>Jaarlijks bruto ouderdomspensioen</td><td class="num">${eur(deelnemer.pen)}</td></tr>
          ${partnerRows}
        </tbody>
      </table>
    </section>
  `

  // === Sectie 2: resultaten (v3.0.108: vereenvoudigd, geen OP/NP-splitsing) ===
  let sectie2 = `<section class="pr-section"><h2>2. Resultaten</h2>`

  if (lastM1) {
    sectie2 += `
      <h3>Module 1: Uw huidige pensioenaanspraak</h3>
      <table class="pr-table">
        <tbody>
          <tr><td>Huidige waarde van uw pensioenaanspraak (KV)</td><td class="num strong">${eur(lastM1.KV)}</td></tr>
          <tr><td>Toegepaste rekenrente</td><td class="num">${pct(p1.r)}</td></tr>
        </tbody>
      </table>
    `
  } else {
    sectie2 += `<p class="pr-error">Module 1 leverde geen resultaat (zie de invoer).</p>`
  }

  if (lastM2) {
    const verdeelbaarPct = lastM2.vpvTotal > 0
      ? (lastM2.verdeelbaar / (m2f.fondsvermogen * 1e6))
      : 0
    const spreidingLabel = p2.spreidingN >= 1000 ? 'oneindig (levenslang)' : `${p2.spreidingN} jaar`
    sectie2 += `
      <h3>Module 2: Uw persoonlijk pensioenvermogen na invaren</h3>
      <table class="pr-table">
        <tbody>
          <tr><td>Persoonlijk pensioenvermogen totaal (PPV)</td><td class="num strong">${eur(lastM2.ppkTotal)}</td></tr>
          <tr><td>Verdeelbaar fondsvermogen (M)</td><td class="num">${eur(lastM2.verdeelbaar)} (${pct(verdeelbaarPct)} van fondsvermogen)</td></tr>
        </tbody>
      </table>

      <h3>Door u gekozen sliderwaarden</h3>
      <table class="pr-table">
        <tbody>
          <tr><td>Dekkingsgraad</td><td class="num">${((p2.dekkingsgraad as number) * 100).toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%</td></tr>
          <tr><td>Aftrek voor reserveringen</td><td class="num">${pct(p2.vpvAftrekPct, 1)}</td></tr>
          <tr><td>Spreidingstermijn</td><td class="num">${escapeHtml(spreidingLabel)}</td></tr>
        </tbody>
      </table>
    `
  } else {
    sectie2 += `<p class="pr-error">Module 2 leverde geen resultaat.</p>`
  }
  sectie2 += `</section>`

  // === Sectie 3: gebruikte fondsparameters ===
  const sectie3 = `
    <section class="pr-section pr-pagebreak">
      <h2>3. Gebruikte fondsparameters</h2>
      <p class="pr-intro">
        Onderstaande parameters zijn vastgesteld door het fondsbestuur op basis van het transitieplan en de wet- en regelgeving (Pensioenwet, Bijlage 2a Regeling Pensioenwet, DNB-rentetermijnstructuur, AG-prognosetafels). De waarden in de kolom &laquo;huidige stand&raquo; geven de instellingen weer waarmee de berekening hierboven is uitgevoerd.
      </p>

      <h3>Module 1 parameters</h3>
      <table class="pr-table">
        <thead><tr><th>Parameter</th><th>Huidige stand</th></tr></thead>
        <tbody>
          <tr><td>Rekenrente (r)</td><td class="num">${pct(p1.r)} (door u aanpasbaar)</td></tr>
          <tr><td>Sterftetafel</td><td class="num">${escapeHtml(m1f.sterftekansTabelId)}</td></tr>
          <tr><td>Peiljaar (t&#8320;)</td><td class="num">${num(m1f.t0)}</td></tr>
          <tr><td>Indexatie (&pi;)</td><td class="num">${pct(m1f.pi)}</td></tr>
          <tr><td>Uitkeringsfrequentie (m)</td><td class="num">${num(m1f.m)} keer per jaar</td></tr>
          <tr><td>Annu&iuml;teitsconventie</td><td class="num">${escapeHtml(m1f.annuiteitsconventie)}</td></tr>
          <tr><td>Eindleeftijd (&omega;)</td><td class="num">${num(m1f.omega)} jaar</td></tr>
          <tr><td>Ervaringssterfte</td><td class="num">${m1f.ervaringsSterfte.toFixed(2)}</td></tr>
        </tbody>
      </table>

      <h3>Module 2 parameters</h3>
      <table class="pr-table">
        <thead><tr><th>Parameter</th><th>Huidige stand</th></tr></thead>
        <tbody>
          <tr><td>Dekkingsgraad</td><td class="num">${((p2.dekkingsgraad as number) * 100).toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}% (door u aanpasbaar)</td></tr>
          <tr><td>Aftrek voor reserveringen</td><td class="num">${pct(p2.vpvAftrekPct, 1)} (door u aanpasbaar)</td></tr>
          <tr><td>Spreidingstermijn (N)</td><td class="num">${p2.spreidingN >= 1000 ? 'oneindig' : p2.spreidingN + ' jaar'} (door u aanpasbaar)</td></tr>
          <tr><td>Fondsvermogen</td><td class="num">${num(m2f.fondsvermogen)} mln euro</td></tr>
          <tr><td>Compensatiedepot</td><td class="num">${num(m2f.compensatiedepot)} mln euro</td></tr>
          <tr><td>Bijstort</td><td class="num">${num(m2f.bijstort)} mln euro</td></tr>
          <tr><td>Aantal deelnemers</td><td class="num">${num(m2f.N_deelnemers)}</td></tr>
          <tr><td>Demografie</td><td class="num">${m2f.demografie.soort === 'preset' ? 'preset ' + m2f.demografie.preset : 'maatwerk'}</td></tr>
        </tbody>
      </table>
    </section>
  `

  // === Sectie 4: disclaimer (v3.0.108: formules-appendix verwijderd) ===
  const sectie5 = `
    <section class="pr-section pr-disclaimer">
      <h2>4. Disclaimer</h2>
      <p>Deze berekening is een indicatie op basis van de invoer die u heeft opgegeven en de op het moment van afdrukken geldende fondsparameters. De werkelijke waarde van uw pensioenaanspraak en uw persoonlijk pensioenvermogen na invaren wordt vastgesteld door uw pensioenfonds en kan afwijken van de uitkomst in dit rapport. Aan deze berekening kunnen geen rechten worden ontleend.</p>
      <p>De Invaarcalculator&reg; verwerkt uw invoer uitsluitend in uw eigen browser. Er worden geen gegevens verstuurd, opgeslagen of gedeeld met derden.</p>
    </section>
  `

  return sectie1 + sectie2 + sectie3 + sectie5
}

/**
 * Vul #print-report met de actuele state en open de browser-print-dialoog.
 *
 * v3.0.42: drie robuustheidsverbeteringen:
 *   1. Console-logging zodat diagnose mogelijk is bij "knop doet niets"-rapport
 *   2. Visuele feedback op de knop ("Rapport wordt voorbereid...") want het
 *      build- en render-proces duurt enkele honderden ms en de gebruiker mag
 *      niet denken dat de klik genegeerd is
 *   3. window.print() in een setTimeout(..., 50) zodat Safari/iOS de DOM-update
 *      eerst afmaakt voordat het print-dialoog opent. Zonder die delay kan
 *      Safari de print stil overslaan omdat de event-handler te lang loopt.
 */
export function triggerPrint(input: PrintInput): void {
  console.info('[print] triggerPrint aangeroepen')
  const target = document.getElementById('print-report')
  if (!target) {
    console.error('[print] #print-report element niet gevonden in DOM')
    alert('Kan rapport niet genereren: print-target ontbreekt in de DOM. Probeer de pagina te herladen.')
    return
  }

  const btn = document.getElementById('print-report-btn') as HTMLButtonElement | null
  const originalLabel = btn?.textContent ?? ''
  if (btn) {
    btn.disabled = true
    btn.textContent = 'Rapport wordt voorbereid...'
  }

  try {
    const html = buildPrintReportHtml(input)
    target.innerHTML = html
    console.info(`[print] rapport gerenderd (${html.length} chars), open print-dialoog...`)
  } catch (err) {
    console.error('[print] fout bij genereren rapport:', err)
    if (btn) {
      btn.disabled = false
      btn.textContent = originalLabel
    }
    alert('Kan het rapport niet genereren. Zie de browserconsole (F12) voor details.')
    return
  }

  // v3.0.108: vul dynamische @page bottom-right met versie + actuele
  // datum+tijd. Deze CSS-regel overschrijft of vult aan op de statische
  // @page-regels uit het HTML-template (modelspec-PDF-stijl).
  const footerStyle = document.getElementById('print-footer-dynamic') as HTMLStyleElement | null
  if (footerStyle) {
    const now = new Date()
    const dd = String(now.getDate()).padStart(2, '0')
    const mm = String(now.getMonth() + 1).padStart(2, '0')
    const yyyy = now.getFullYear()
    const hh = String(now.getHours()).padStart(2, '0')
    const mi = String(now.getMinutes()).padStart(2, '0')
    const ts = `${dd}-${mm}-${yyyy} ${hh}:${mi}`
    // \\2014 = em-dash, vooraf-gespatieerd om visueel te matchen met top-left
    footerStyle.textContent = `@media print {
      @page {
        @bottom-right {
          content: "v${input.releaseVersion}  \\2014  ${ts}";
          font-family: Georgia, "Times New Roman", serif;
          font-size: 9pt;
          color: #444;
          border-top: 0.4pt solid #888;
          padding-top: 2mm;
          vertical-align: top;
        }
      }
    }`
  }

  // setTimeout 50ms: laat de browser de DOM-update commit voordat het modale
  // print-dialoog opent. Lost een bekende Safari/iOS-quirk op waarbij print()
  // synchroon vanuit een click-handler soms genegeerd wordt.
  window.setTimeout(() => {
    try {
      window.print()
      console.info('[print] window.print() teruggekeerd')
    } catch (err) {
      console.error('[print] window.print() faalde:', err)
      alert('Print-dialoog kan niet geopend worden. Zie de browserconsole voor details.')
    } finally {
      if (btn) {
        btn.disabled = false
        btn.textContent = originalLabel
      }
    }
  }, 50)
}
