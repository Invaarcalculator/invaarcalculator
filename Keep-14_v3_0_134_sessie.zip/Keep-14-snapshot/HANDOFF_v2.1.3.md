# WTP-PENSIOENCALCULATOR — HANDOFF ENGINE SPEC v2.1.3

Datum: 23-04-2026 14:50
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Licentie: CC BY-NC 4.0

Dit document markeert de afronding van de **scherm-2-spec-sessie** (23-04-2026) en geeft de volgende sessie een schone start. Het vervangt niet `HANDOFF_v2.1.md` (scherm-1-handoff) maar bouwt erop voort; beide documenten samen beschrijven de stand van zaken voor scherm 1 én scherm 2.

---

## KERN IN ÉÉN ALINEA

Op 23-04-2026 13:40 werd de scherm-1-spec afgerond (v2.1). In dezelfde dag zijn drie scherm-2-interne open punten stap-voor-stap behandeld en gesloten: (1) exacte ppkSurplus-OP/NP-splitsingsformule, (2) ppkComp dubbeling-check (bronverankerd), (3) phiDerived-referentie bij OP/NP-splitsing en §11.12 standalone-fallback. Drie patches (v2.1.1, v2.1.2, v2.1.3) hebben de scherm-2-structuur sluitend gemaakt zonder numerieke wijziging. Spec-omvang groeide van 1674 naar 1704 regels. Drie oorspronkelijk als scherm-2-aanpalend gelabelde punten (§11.6 bufferTrigger, §11.7 correlatie rente-inflatie, §11.8 lifecycle-rente) zijn bewust doorgeschoven naar scherm-3-sessie; zij zijn semantisch M3-parameters. Scherm 2 is daarmee volledig af en klaar voor uitbreiding naar scherm 3.

---

## STAND VAN ZAKEN — SPEC v2.1.3

**Hoofdbestand:** `ENGINE_SPECIFICATIE_v1.md` (1704 regels).

**Voltooide scherm-2-besluiten (drie, chronologisch):**

| Patch | Punt | Datum | Kern |
|---|---|---|---|
| v2.1.1 | ppkSurplus-OP/NP-splitsing | 14:12 | Optie A1: actuarieel bottom-up, één ν(N) met SSPF-deelnemer-weging. `ppkSurplus := ppk_OP_surplus + ppk_NP_surplus`. Sluitingscontrole exact. Nieuwe aanname 12 (§3.6) |
| v2.1.2 | ppkComp dubbeling-check | 14:28 | Optie A bevestigd, wettelijk verankerd. Bronnenonderzoek (art. 150f Pw, DNB Q&A, FRP 2024/622, ABP-transitieplan) bevestigt: compensatie uitsluitend voor actieve deelnemers → `ppkComp` volledig naar OP |
| v2.1.3 | phiDerived-granulariteit + §11.12 | 14:44 | Optie A: alleen totaal-scalar in v1, geen component-varianten. §11.12 Optie 1 (null-fallback) formeel bevestigd. Rationale: ankerzuiverheid M2↔M4 |

**Totaal gesloten besluiten over beide sessies:** 15 (12 scherm-1, 3 scherm-2).

**Bewust geparkeerd in scherm-2-sessie:**
- **Aanpalende kwestie bell-curve-toepasbaarheid voor gepensioneerden** (uit bronnenonderzoek v2.1.2). SSPF-doelpubliek valt strikt genomen buiten DRS-compensatie-doelgroep, maar v1 reproduceert R9.30-gedrag conform §12.5. Notitie staat in §3.10 voor latere overweging.

---

## ACTIEVE WERKAFSPRAKEN

Behouden uit `HANDOFF_v2.1.md`, bevestigd werkend in scherm-2-sessie:

1. **Narratief kompas (§1.1)** — drie momenten × vier schermen, ankerfunctie bij identieke aannames. Elk scherm-2-besluit is hieraan getoetst: patch v2.1.1 behoudt ankerfunctie `ppkTotal ↔ V_x^Wtp_totaal`; patch v2.1.3 versterkt die brug door geen component-varianten te maken die M2-primair aan M4-secundair zouden koppelen.

2. **Educatieve leidraad** — verborgen dimensies zichtbaar maken. Patch v2.1.1 houdt bewust het gender-verschil op partner-leven zichtbaar in `ppk_NP` via eigen `sFactor(x_p, g_y)`.

3. **Spec-met-reserveringen-principe (§12.5)** — v1-defaults reproduceren R9.30-gedrag. Patch v2.1.3 respecteert dit door component-varianten uitdrukkelijk upgrade-pad-klaar te maken (zonder ze in v1 uit te rollen). Parkering van bell-curve-kwestie voor gepensioneerden is ook hiermee consistent.

4. **Stap-voor-stap-methode** — elk open punt apart, probleem/opties/aanbeveling/besluit/patch, geen bulk. Gewerkt.

5. **SSPF-prior voor fallbacks** — gender-weging 95/5 deelnemer, 5/95 partner-gegeven-M. Patch v2.1.1's aanname 12 verankert dat ν(N) uniform deze deelnemer-weging gebruikt; partner-specifieke ν is v2-pad.

6. **Timestamp-conventie** — `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`. Consequent gehanteerd in alle drie patches.

7. **Bronhoudbaarheid boven snelheid** — placeholders expliciet gelabeld. Patch v2.1.2 voegt toe dat sommige *aannames* nu bronverankerd zijn (wettelijke verwijzingen in §3.6 aanname 11), naast de eerder geparkeerde *data-placeholders* (f, ρ, SSPF-weging).

8. **Bronnenonderzoek voor normatieve kwesties** — nieuw expliciet in scherm-2-sessie via pad-1-beslissing: Hans koos voor bronverificatie vóór besluit, en dat heeft Optie A voor ppkComp bevestigd en tegelijk de aanpalende gepensioneerden-kwestie zichtbaar gemaakt. Houdbaar als patroon voor toekomstige kwesties waar juridisch-normatieve bronnen bestaan.

---

## KRITIEKE ARCHITECTUUR — STRUCTUREEL VASTGELEGD

Deze keuzes moeten bij elke volgende sessie paraat zijn. Scherm-2-aanvullingen op de HANDOFF_v2.1-lijst zijn **vetgedrukt**.

### Module-structuur

- **M1** = huidige waarde: levert `KV_OP`, `KV_NP`, `KV` totaal + annuïteitsfactoren per leven + levensverwachtingen
- **M2** = potje: levert `ppkBase + ppkSurplus + ppkComp = ppkTotal`, met **geoormerkte subcomponenten `ppk_OP` en `ppk_NP`** (v2.0)
  - **`ppkSurplus` is *definitionally* de som `ppk_OP_surplus + ppk_NP_surplus` (v2.1.1)**
  - **`ppkComp` gaat volledig naar OP, wettelijk verankerd (v2.1.2)**
  - **Sluitingscontrole `ppk_OP + ppk_NP = ppkTotal` is exact (v2.1.1)**
  - **`phiDerived` alleen op totaal, geen component-varianten (v2.1.3)**
- **M3** = uitkeringsbenadering: levert pad + onzekerheidsbanden, gebruikt `ppkTotal` en heeft interne NP-schakel bij overlijden deelnemer (detailimplementatie openstaand)
- **M4** = waardevergelijking: docx-spec overgenomen, V_DB vs V_Wtp cohort-correct op AG2024; OP/NP-breakdown blijft presentatie-laag in v1

### Sterftetafel

Ongewijzigd t.o.v. HANDOFF_v2.1: AG2024 per geslacht, M1-3 periode-snapshot t₀=2026, M4 cohort, gender verplicht in UI met SSPF-weging 95/5 als fallback.

### Rente

Ongewijzigd: één UI-slider (default 2%) voor discontering; ontkoppelings-toggle voor power-user; `μ` apart.

### Annuïteitsconventie

Ongewijzigd: uniform arrears m=12 in alle modules.

### NP-regime

Ongewijzigd: NP mee-ingevaren, geoormerkt binnen één persoonlijk pensioenvermogen. **v2.1.1 bevestigt dat de geoormerkte splitsing exact sluit** (ppk_OP + ppk_NP = ppkTotal, geen restfractie).

### Compensatie-regime (nieuw expliciet v2.1.2)

- **ppkComp volledig naar OP**, wettelijk verankerd (art. 150f lid 1 Pw; DNB Q&A juni 2025; FRP 2024/622 Sdu; ABP-transitieplan 2024)
- **NP-opbouw is risicobasis** bij actieven, conceptueel niet vatbaar voor "gemiste inkoop"
- **Aanpalende kwestie bell-curve-toepasbaarheid voor gepensioneerden geparkeerd** in §3.10 voor publieke-release-ronde

### Brug M2↔M4 (nieuw expliciet v2.1.3)

- **`phiDerived = ppkTotal / V_x^Wtp_totaal`** als één decoratief anker
- Geen `phiDerived_OP` of `phiDerived_NP` in v1
- `null`-fallback in standalone-M2-modus (geen M4)
- Upgrade-pad component-varianten als M4's OP/NP-breakdown promoveert tot berekeningslaag in v2

---

## OPEN BESLISPUNTEN VOOR SCHERM 3

Drie scherm-2-aanpalende punten zijn bewust doorgeschoven; ze zijn semantisch M3:

1. **§11.6 BufferTrigger-default.** Voorlopig Optie 1 (effR < inf, conform R9.30). Definitieve keuze vereist SSPF-reglement-check en SCHEMA-veld `bufferTriggerRule`. Raakt M2 alleen indirect via `buffer`-aandeel; M3 is de werkelijke beslissingslaag.
2. **§11.7 Correlatie rente-inflatie.** Voorlopig Optie 1 (ρ=0). M3-stochastisch-parameter; geen M2-relevantie.
3. **§11.8 Lifecycle-rente.** Voorlopig Optie 1 (vlak). `rtsCurve`-veld in FONDS_DATASET is gereserveerd (null). Past bij lifecycle-beleggingsafbouw in M3.

Eerder uit HANDOFF_v2.1 gepubliceerde scherm-3-punten:

4. **Cross-punt 3**: gender in `ä(x, proj)` voor U₀. Triviaal — doorwerking van v1.7-besluit.
5. **NP-schakel mechaniek**: hoe wordt de latent-NP-dekking uit ppk_NP geactiveerd bij overlijden deelnemer in projectie? §11.18 Follow-up bullet 2.
6. **§11.9 Plot-horizon** — UI-ronde, niet scherm-3-blokkerend.

---

## OPEN BESLISPUNTEN VOOR SCHERM 4

Ongewijzigd t.o.v. HANDOFF_v2.1:

- **Cross-punt 5**: cohort-correct M4 versus periode-snapshot M1 — <1% verschil.
- M4-specifieke reviewpunten uit §5.12 docx-spec.
- **Nieuw agendapunt v2.1.3**: M4's OP/NP-breakdown van presentatie- naar berekeningslaag promoveren? Als dat in v2 gebeurt, heropent §11.12 Optie 4 (phiDerived-component-varianten) in M2.

---

## DATA-TODO'S VOOR HANS (NIET-BLOKKEREND)

Ongewijzigd t.o.v. HANDOFF_v2.1:

1. SSPF-specifieke `f`-waarde (Implementatieplan/jaarverslag) → vervangt placeholder 1,0.
2. SSPF uitvoeringskosten per jaar → activeert Variant-A-afleiding voor ρ, vervangt 0,02-placeholder.
3. SSPF M/V-verdeling per cohort → vervangt 95/5-placeholder.
4. AG2024 populatie-data voor NL-neutrale weging.
5. Q-tafel herkomst documentatie (bevestigd als fout).

---

## COHERENTIE-CHECK UITGEVOERD BIJ AFRONDING

Tijdens handoff-voorbereiding zijn twee structurele controles uitgevoerd:

1. **Patch-volgorde en changelog-integriteit**. Tussentijds is ontdekt dat de str_replace-operaties voor v2.1.2 en v2.1.3 de voorgaande changelog-entries hadden overschreven (spec-body was intact, top-changelog miste v2.1.1 en v2.1.2). Hersteld: alle vijf v2.x-entries (v2.0, v2.1, v2.1.1, v2.1.2, v2.1.3) staan nu compleet in het changelog-blok onderaan de metadata.
2. **Formule-consistentie §3.5**. `ppkTotal = ppkBase + ppkSurplus + ppkComp` en `ppk_OP + ppk_NP = ppkTotal` zijn beide gecontroleerd; ppkComp zit volledig in ppk_OP per §3.5-formule, dus geen dubbeltelling in de sluitingscontrole.

---

## VOLGENDE-SESSIE-AANPAK (VOORSTEL)

1. **Start**: lees `ENGINE_SPECIFICATIE_v1.md` v2.1.3 volledig door, met focus op §1.1 (narratief kompas), §4 (module 3), §11.6–11.9 (scherm-3-open punten), §11.18 Follow-up (NP-schakel M3).
2. **Context-injectie**: lees zowel `HANDOFF_v2.1.md` (scherm 1) als `HANDOFF_v2.1.3.md` (dit document, scherm 2).
3. **Eerste inventarisatie**: scherm-3-open-punten in één compact overzicht.
4. **Werkwijze**: stap-voor-stap, identiek aan scherm-1- en scherm-2-methode.
5. **Versiebump-regel**: patch (v2.1.4, v2.1.5…) voor kleine beslissingen; minor (v2.2) voor structuurveranderingen binnen scherm 3; major (v3.0) alleen bij fundamentele herordening.
6. **Breekpunt**: na scherm-3-voltooiing HANDOFF maken (zelfde stijl) voordat scherm 4 of SCHEMA v2 wordt begonnen.

---

## BRONBESTANDEN — COMPLETE INVENTARIS

Volgende sessie heeft deze bestanden nodig:

**Van deze sessie nieuw:**
- `ENGINE_SPECIFICATIE_v1.md` (v2.1.3, 1704 regels) — normatieve spec
- `HANDOFF_v2.1.3.md` (dit document) — scherm-2-handoff

**Van scherm-1-sessie behouden:**
- `HANDOFF_v2.1.md` — scherm-1-handoff (context voor hele traject)

**Eerder opgeleverd (onveranderd):**
- `ARCHITECTUUR_v1.md` — leidend architectuur-document
- `DESIGN_engine_v0.md` — reverse-engineering R9.30 engine
- `calculator_specificatie.docx` — M4-docx-spec
- `SCHEMA_v1.md` — huidige SCHEMA (wordt v2)
- `STRATEGY_R9.30.md` — strategische context
- `HANDOFF_R9.30.md` — technische handoff code (ander track)
- `21-04-2026_2216.html` — R9.30 werkbestand (code baseline)

**Externe data:**
- `AG2024.xlsx` — AG2024 gemodelleerde prognose-sterftekansen per geslacht
- `51490-Data_AG2024.xlsx` — AG2024 brondata

---

## AFSLUITENDE NOTITIE

Scherm 2 is systematisch doorgenomen zoals scherm 1: drie open punten, drie besluiten, drie patches, allen aan het narratief kompas getoetst. Het proces heeft één normatieve kwestie (ppkComp-OP/NP) bronhoudbaar afgesloten via expliciete verwijzing naar wet en DNB-guidance, en één aanpalende kwestie (bell-curve voor gepensioneerden) bewust geparkeerd met notitie — beide zijn kwaliteitsverhogend ten opzichte van status quo. Tussentijdse coherentie-check heeft een patch-administratie-fout hersteld voordat de handoff werd opgeleverd. Scherm 3 kan starten met een bronwaarheid die op drie plaatsen exacter is dan v2.1, zonder numerieke discontinuïteit t.o.v. v2.0-bedoeling.

*Einde HANDOFF_v2.1.3.md*
