/**
 * v3.0.38: smoke voor NL-decimaalkomma in aftrek-stand.
 * v3.0.79: locatie verschoven — vpvAftrekPct-slider bestaat niet meer als
 *   geaggregeerde scalar; aftrek wordt opgebouwd uit cascade-componenten
 *   in de M1/2-pane. Tests checken nu NL-komma in:
 *     1. Cascade-rij "Wettelijke reserves" toont "2,0%" (niet "2.0%")
 *     2. Slider-mutatie wettelijk → 0.025 toont "2,5%"
 *     3. Cascade-tabel toont DG met 1 decimaal NL-locale ("136,1%")
 * v3.0.95: Test 4 (fonds-modal cascade-tabel) verwijderd — "Mijn pensioenfonds"-
 *   pane bestaat niet meer; fonds-parameters staan nu in audit-rapport sectie 4.
 *
 *   De algemene NL-decimaalkomma-discipline blijft daarmee getest, alleen
 *   de plek waar de stand staat is verhuisd.
 */
import { JSDOM } from 'jsdom'
import { readFileSync } from 'fs'

;(async () => {
const html = readFileSync('/mnt/user-data/outputs/calculator.html', 'utf8')
const dom = new JSDOM(html, { runScripts: 'dangerously', resources: 'usable' })
;(dom.window as unknown as { matchMedia: (q: string) => unknown }).matchMedia = (q: string) => ({
  matches: false, media: q, onchange: null,
  addListener: () => {}, removeListener: () => {},
  addEventListener: () => {}, removeEventListener: () => {}, dispatchEvent: () => false,
})
await new Promise<void>((res) => setTimeout(res, 200))

const doc = dom.window.document
const fail = (msg: string) => { console.log('  ✗ ' + msg); process.exit(1) }
const ok = (msg: string) => console.log('  ✓ ' + msg)

console.log('\n=== Test 1: cascade-rij "Wettelijke reserves" toont "2,0%" met komma ===')
const wettelijkSlider = doc.querySelector('input[data-co="wettelijkeReservesPct"]') as HTMLInputElement
if (!wettelijkSlider) fail('wettelijkeReservesPct-slider niet gevonden')
const wettelijkRow = wettelijkSlider!.closest('.cascade-row')
if (!wettelijkRow) fail('cascade-row voor wettelijk niet gevonden')
const wettelijkVal = wettelijkRow!.querySelector('.cascade-val')?.textContent ?? ''
if (wettelijkVal.includes('2.0%')) fail(`wettelijk-stand bevat punt: "${wettelijkVal}"`)
if (!wettelijkVal.includes('2,0%')) fail(`wettelijk-stand bevat geen "2,0%": "${wettelijkVal}"`)
ok(`initial: "${wettelijkVal.trim()}"`)

console.log('\n=== Test 2: slider-mutatie wettelijk → 0.025 → "2,5%" ===')
wettelijkSlider.value = '0.025'
wettelijkSlider.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
await new Promise<void>((res) => setTimeout(res, 100))
const wettelijkSliderNew = doc.querySelector('input[data-co="wettelijkeReservesPct"]') as HTMLInputElement
const updated = wettelijkSliderNew!.closest('.cascade-row')!.querySelector('.cascade-val')?.textContent ?? ''
if (!updated.includes('2,5%')) fail(`na mutatie geen "2,5%" in: "${updated}"`)
ok(`na 0.025: "${updated.trim()}"`)

console.log('\n=== Test 3: DG-stand "136,1%" met 1 decimaal NL-locale ===')
const wettelijkResetSlider = doc.querySelector('input[data-co="wettelijkeReservesPct"]') as HTMLInputElement
wettelijkResetSlider.value = '0.02'
wettelijkResetSlider.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
await new Promise<void>((res) => setTimeout(res, 100))

const dgRow = (doc.querySelector('input[data-co="dekkingsgraad"]') as HTMLInputElement).closest('.cascade-row')
if (!dgRow) fail('cascade-row voor dekkingsgraad niet gevonden')
const dgStrong = dgRow!.querySelector('.cascade-val strong')?.textContent ?? ''
// v3.0.94: SSPF-default DG is 1.361 (= F/vpvTotal = 26000/19100), getoond als "136,1%".
if (dgStrong !== '136,1%') fail(`DG-stand niet "136,1%", maar "${dgStrong}"`)
ok(`DG-stand: "${dgStrong}"`)

console.log('\n=== Alle tests geslaagd ✓ ===')
})()
