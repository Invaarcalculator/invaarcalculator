// Q-D opnieuw — fonds-niveau x* via demografie-loop
import * as fs from 'fs'
import * as path from 'path'
import { fileURLToPath } from 'url'
// v3.0.38: relatieve paden (was hardcoded /home/claude/keep9/...)
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const ag = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'ag2024.json'), 'utf-8'))
// @ts-expect-error
globalThis.window = { __AG2024__: ag }
import { survivalProb } from './src/engine.m1'

function survAG(x: number, h: number, g: 'M'|'V'='M'): number {
  return survivalProb(x, h, 2026, g, 1.0, ag)
}
function gompMu(y: number): number { return 1.5e-5 * Math.pow(1.105, y) }
function survGomp(x: number, h: number): number {
  let c = 0; for (let k = 0; k < h; k++) c += gompMu(x + k)
  return Math.exp(-c)
}

// SSPF-typische demografie: gesloten fonds, R9.30-template 'gesloten':
// [0, 0, 0, 0, 0, 50, 400, 1500, 2500, 2800, 2200, 1300, 700, 250, 50]
// 5-jaars cohorten, mid-ages 27, 32, ..., 97
const COHORT_MIDAGES = [27, 32, 37, 42, 47, 52, 57, 62, 67, 72, 77, 82, 87, 92, 97]
const SSPF_COUNTS = [0, 0, 0, 0, 0, 50, 400, 1500, 2500, 2800, 2200, 1300, 700, 250, 50]

// Cohort-aanspraak: R9.30-aanpak via kvProfile (actieven onder 65, gepensheerden boven)
// Voor bijlage-2: per cohort eenheids-aanspraak 1, dan opslag-decompositie zelfde voor allen
// Maar bestuurlijke punt: jongeren krijgen +75% bij N=∞, ouderen veel minder.
// Vereist: per cohort een aanspraak-niveau dat realistisch is.
// Voor SSPF-gepensheerden (zwaartepunt 65+): allen ongeveer dezelfde €30k aanspraak.
// Voor jongere cohorten (geprojecteerd op pensioenleeftijd 68): nodig om effect van
// 'tijd tot pensioen' (Pl=68 indicator) zichtbaar te maken.
// Vereenvoudiging: alle cohorten zelfde aanspraak U=30000 EUR/jaar als ze pensioneren.

function fondsLineairSpreiding(N: number, DG: number, W: number, r: number,
  surv: (x: number, h: number) => number, U: number = 30000, Pl: number = 68, C: number = 110) {

  const v = (h: number) => Math.pow(1 + r, -h)

  // Stap 1: CW_voor over heel fonds = Σ_c n_c · CW_voor(midage_c)
  // Stap 2: CW_star over heel fonds = Σ_c n_c · CW_star(midage_c, N)
  let CW_voor_fonds = 0
  let CW_star_fonds = 0
  const cohortData: { x: number; n: number; CW_voor_i: number; CW_star_i: number; KS_voor: number[] }[] = []

  for (let c = 0; c < COHORT_MIDAGES.length; c++) {
    const n = SSPF_COUNTS[c]
    if (n === 0) { cohortData.push({ x: COHORT_MIDAGES[c], n: 0, CW_voor_i: 0, CW_star_i: 0, KS_voor: [] }); continue }
    const x = COHORT_MIDAGES[c]
    const horizon = C - x
    let CW_voor_i = 0, CW_star_i = 0
    const KS_voor: number[] = []
    for (let h = 1; h <= horizon; h++) {
      const ind = (x + h) >= Pl ? 1 : 0
      const ks = U * surv(x, h) * ind
      const q_hN = Math.min(h / N, 1)
      KS_voor.push(ks)
      CW_voor_i += ks * v(h)
      CW_star_i += ks * q_hN * v(h)
    }
    cohortData.push({ x, n, CW_voor_i, CW_star_i, KS_voor })
    CW_voor_fonds += n * CW_voor_i
    CW_star_fonds += n * CW_star_i
  }

  // Stap 3: fonds-x*
  const M_fonds = DG * CW_voor_fonds * (1 - W)
  const x_star = CW_star_fonds > 0 ? (M_fonds - CW_voor_fonds) / CW_star_fonds : 0

  // Stap 4: per-cohort PV met fonds-niveau x*
  return cohortData.map((cd) => {
    if (cd.n === 0) return { x: cd.x, PV: 0, opslag: 0, n: 0 }
    let PV = 0
    for (let h = 1; h <= cd.KS_voor.length; h++) {
      const q_hN = Math.min(h / N, 1)
      PV += cd.KS_voor[h - 1] * (1 + q_hN * x_star) * v(h)
    }
    const opslag = (PV - cd.CW_voor_i) / cd.CW_voor_i
    return { x: cd.x, PV, opslag, n: cd.n, x_star }
  })
}

console.log('=== Fonds-niveau lineair-spreidings-test ===\n')
console.log('SSPF-demografie (gesloten preset), U=€30k voor allen, DG=1.35, W=0.10, r=0.025\n')

for (const N of [10, 1000]) {
  console.log(`--- N=${N === 1000 ? '∞' : N} (AG2024) ---`)
  const r1 = fondsLineairSpreiding(N, 1.35, 0.10, 0.025, (x, h) => survAG(x, h, 'M'))
  const xstar = (r1[5] as any).x_star
  console.log(`  fonds-x* = ${xstar?.toFixed(4) ?? 'n/a'}`)
  for (const c of r1) {
    if (c.n === 0) continue
    console.log(`    leeftijd ${c.x}: PV=${c.PV.toFixed(0).padStart(8)}, opslag=${(c.opslag * 100).toFixed(2).padStart(7)}%, n=${c.n}`)
  }
  console.log()
}

console.log('--- DG=1.15 (SSPF realistisch) ---')
for (const N of [10, 1000]) {
  console.log(`N=${N === 1000 ? '∞' : N}:`)
  const r = fondsLineairSpreiding(N, 1.15, 0.10, 0.025, (x, h) => survAG(x, h, 'M'))
  const xstar = (r[5] as any).x_star
  console.log(`  fonds-x* = ${xstar?.toFixed(4) ?? 'n/a'}`)
  for (const c of r) {
    if (c.n === 0) continue
    console.log(`    x=${c.x}: opslag=${(c.opslag * 100).toFixed(2).padStart(7)}%`)
  }
  console.log()
}
