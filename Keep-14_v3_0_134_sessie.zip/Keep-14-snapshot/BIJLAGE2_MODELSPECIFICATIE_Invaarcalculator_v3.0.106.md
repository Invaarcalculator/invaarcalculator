# Bijlage 2 — Modelspecificatie

## Formele uitwerking van het rekenmodel van de Invaarcalculator® v3.0.106

*Begeleidend technisch document bij de Invaarcalculator-binary*
*`calculator_v3.0.106.html` (peildatum-bron: 11 mei 2026)*

---

## 1. Doel en bereik

Deze bijlage geeft de formele specificatie van het rekenmodel dat is geïmplementeerd in de Invaarcalculator® v3.0.106. Het model berekent, op basis van een individuele aanspraak en fondsspecifieke invaarparameters, de kapitaalwaarde van de huidige pensioenaanspraak (M1, "KV") en het persoonlijk pensioenvermogen na invaren onder de standaardregel van bijlage 2a Regeling Pensioenwet (M2, "PPV"). Het document beschrijft de gebruikte variabelen, formules, parameterwaarden, demografische cohort-aannames en de fondsbalans-decompositie, zodat onafhankelijke verificatie en reproductie mogelijk zijn.

Het model implementeert de standaardregel uit bijlage 2a Regeling Pw als productie-pad (M2 v3.0), aangevuld met (i) AG2024-prognosesterftekansen per geslacht (KAG-publicatie 12 september 2024), (ii) een joint-life partnerpensioen-annuïteit met multiplicatieve broken-heart-correctie voor de overlevende partner, (iii) een twee-stappen-fondsbalans (Model C bundle-aftrek) waarin verschillende reserveringen voorafgaand aan de toedeling worden afgesplitst, en (iv) een cohort-proxy met SSPF-genderweging (95% M / 5% V) voor de wettelijk vereiste fondsschalingsfactor. Het is daarmee uitdrukkelijk een vollediger model dan de vereenvoudigde Bijlage 2 bij de brief aan SSPF van 2 mei 2026 (Gompertz, vlakke discontering, geen partner); de verschillen zijn benoemd in sectie 10.

Voor de SSPF-build van de binary worden alle parameters uit `fondsen/sspf/fonds.config.ts` ingelezen; voor een andere fondsconfiguratie wijzigen alleen die waarden, niet de formules.

---

## 2. Afkortingen en begrippen

- **Wtp** — Wet toekomst pensioenen, het wettelijk kader voor de hervorming van het Nederlandse pensioenstelsel (in werking 1 juli 2023).
- **Pw** — Pensioenwet.
- **DNB** — De Nederlandsche Bank, prudentieel toezichthouder op pensioenfondsen.
- **RTS** — Rentetermijnstructuur, de door DNB gepubliceerde curve van risicovrije rentes per looptijd waarmee pensioenverplichtingen contant worden gemaakt. Het model gebruikt een vlakke benadering hiervan (zie §8).
- **AG2024** — Prognosetafels van het Koninklijk Actuarieel Genootschap (publicatie 12 september 2024), die sterftekansen per leeftijd, gender en projectiejaar specificeren voor de Nederlandse pensioensector. Het model embed jaarkolommen 2022–2050.
- **Standaardregel** — de in bijlage 2a Regeling Pw vastgelegde rekenregel voor verdeling van fondsvermogen over individuele pensioenvermogens bij invaren naar de Wtp-solidaire premieregeling (in dit model: M2-engine v3.0, productie-pad).
- **Spreidingstermijn (N)** — parameter in de standaardregel die bepaalt over hoeveel jaar het beschikbare overschot wordt verdeeld onder deelnemers; wettelijke default 10 jaar, range in het model [0, 1000] (waarbij N=1000 als proxy voor levenslange spreiding fungeert).
- **Invaardekkingsgraad (DG)** — verhouding tussen het beschikbare fondsvermogen en de pensioenverplichtingen op het invaarmoment.
- **vpvTotal** — totale technische voorziening van het fonds in mln euro; in dit model een fonds-anker (parameter direct uit de fondsconfig) waaromheen F en DG in tandem worden gehouden via F = DG × vpvTotal.
- **M (beschikbaar vermogen)** — netto vermogen voor de standaardregel na bundle-aftrek; zie §5.3.
- **KV (kapitaalwaarde)** — de contante waarde van de pensioenaanspraak vóór invaren, inclusief kostenopslag ρ. Som van KV_OP en KV_NP.
- **PPV (persoonlijk pensioenvermogen)** — het individuele kapitaal dat aan een deelnemer wordt toegerekend bij invaren (in de code: `ppkTotal`). Som van ppkBase, ppkSurplus en ppkComp.
- **OP / NP** — ouderdomspensioen / nabestaandenpensioen (partnerpensioen).
- **CW_voor / CW_star** — contante waarde van toekomstige kasstromen vóór toepassing van de standaardregel-aanpassing, respectievelijk de spreidings-gewogen contante waarde (Σ_h q(h,N)·KS(h)·v(h)).
- **q(h, N)** — wettelijke trapsgewijze spreidings-multiplier: q(h, N) = min(⌊h⌋/N, 1).
- **ä(x, r)** — actuariële annuïteitsfactor: contante waarde van een eenheidskasstroom levenslang vanaf leeftijd x, arrears, maandbasis m = 12.
- **ä_{x|y}(r)** — joint-life annuïteit voor een NP-uitkering: betaling vanaf moment van overlijden van de deelnemer (x) zolang de partner (y) leeft.
- **f (ervaringssterftefactor)** — multiplicatieve schaal op de AG2024-q's voor populatie-specifieke afwijking (SSPF-default 0,90 op grond van top-inkomenskwintiel-overlevings­verschillen, CBS 2019/2022).
- **ρ (kostenopslag)** — multiplicatieve opslag op KV voor toekomstige uitvoeringskosten; afgeleid via een fallback-ladder (§4.6).
- **RDR** — Risicodelingsreserve onder de Wtp-solidaire premieregeling, bedoeld om rendementsschokken te dempen en kortingen op uitkeringen te beperken. In het model afgesplitst voorafgaand aan de standaardregel.
- **Compensatiedepot** — afgezonderd vermogen ter compensatie van actieven voor de afschaffing van de doorsneesystematiek (art. 150f Pw). Verdeeld via een Gaussische bell-curve over de cohorten (§5.7).
- **Bijstort** — eenmalige werkgevers-transitiebijdrage, toegevoegd aan het fondsvermogen voorafgaand aan de standaardregel-toepassing.
- **Cohort** — leeftijdsgroep van 5 jaar breed; het model hanteert 15 cohorten van [25–29] tot [95–99].
- **Bell-curve w(x)** — w(x) = exp(−½·((x−μ)/σ)²); Gaussische dichtheid (zonder normalisatie) gebruikt voor de compensatiedepot-verdeling.
- **Broken-heart-factor bh(τ, g)** — multiplicatieve schok op de sterftekans van de overlevende partner direct na overlijden van de deelnemer, lineair afnemend van bh₀(g) naar 1 over 5 jaar.
- **67%-randvoorwaarde** — art. 150n lid 4 Pw, dat de toedeling van overschotten zodanig beperkt dat geen enkele groep meer dan 67% boven het gemiddelde collectieve effect ontvangt. Niet gemodelleerd in de calculator (zie §11).

---

## 3. Variabelen en parameters

Onderstaande tabellen bevatten alle in het model gebruikte symbolen, hun betekenis, eenheid en de gehanteerde numerieke waarde voor de SSPF-build. Symbolen volgen waar mogelijk de notatie van de wettekst (bijlage 2a Regeling Pw) en de spec-documentatie `ENGINE_SPECIFICATIE_v1.md`.

### 3.1 Deelnemer-input (M1Deelnemer-schema)

| Symbool | Betekenis | Eenheid | Default UI |
|---|---|---|---|
| x₀ | huidige leeftijd deelnemer op peildatum (fractioneel toegestaan, afgeleid uit geboortedatum) | jaren | 70 |
| pen | jaarlijks bruto ouderdomspensioen ("huidige aanspraak") | EUR/jaar | 100.000 |
| g | geslacht deelnemer voor AG2024-tafelkeuze | {M, V} | M |
| heeftPartner | indicator voor aanwezigheid van een NP-aanspraak | bool | false |
| y₀ | jaarlijks bruto nabestaandenpensioen-aanspraak; bij null en heeftPartner=true: fallback 0,70 · pen | EUR/jaar | null |
| x_partner | leeftijd partner op peildatum (fractioneel) | jaren | n.v.t. |
| g_y | geslacht partner | {M, V} | V |
| hooglaagActief | indicator voor hoog-laag-regeling (art. 63 Pw) | bool | false |
| pen_laag | jaarlijks bruto OP ná de knip; alleen bij hooglaagActief | EUR/jaar | null |
| x_knip | leeftijd waarop de hoog-laag-knip plaatsvindt (x_knip > x₀ vereist) | jaren | null |

### 3.2 Engine-parameters (FondsParameterset, gedeeld M1+M2)

| Symbool | Betekenis | Eenheid | SSPF-waarde |
|---|---|---|---|
| r | vlakke reële disconteringsvoet | per jaar | 0,025 |
| sterftekansTabelId | identifier sterftetafel | string | "AG2024" |
| t₀ | projectiejaar voor AG2024-kolomselectie (periode-snapshot) | jaar | 2026 |
| f | ervaringssterftefactor; q_fonds = f · q_AG2024 | — | 0,90 |
| m | betalingsfrequentie | per jaar | 12 |
| annuïteitsconventie | timing kasstromen | enum | "arrears" |
| π | indexatie op aanspraak tijdens waardering (KV-anker = kale aanspraak) | per jaar | 0,000 |
| ω | eindleeftijd sterftetafel / horizon-cap voor annuïteiten | jaren | 120 |

### 3.3 M1-specifieke parameters (ρ-ladder)

| Symbool | Betekenis | Eenheid | SSPF-waarde |
|---|---|---|---|
| uitvoeringskostenJaarlijks | jaarlijkse uitvoeringskosten voor ρ-Variant-A | mln EUR/jaar | null |
| kostenOpslagPct | directe override-ρ (alleen als Variant-A niet beschikbaar) | fractie | null |
| ρ_default | ultieme default als beide vorige null zijn | fractie | 0,02 |

### 3.4 M2-specifieke parameters (fondsbalans + standaardregel)

| Symbool | Betekenis | Eenheid | SSPF-waarde |
|---|---|---|---|
| F | fondsvermogen | mln EUR | 26.000 |
| DG | invaardekkingsgraad | fractie | 1,361 |
| vpvTotal | totale technische voorziening (fonds-anker) | mln EUR | 19.100 |
| vpvAftrekPct | bundle-aftrek-fractie van vpvTotal (VEV + operationele reserve + solidariteitsreserve + inhaalindexatie) | fractie | 0,06 |
| compensatiedepot | compensatiedepot DRS (art. 150f Pw) | mln EUR | 0 |
| buffer | aanvullende M2→M3-buffer | mln EUR | 0 |
| bijstort | eenmalige werkgevers-transitiebijdrage | mln EUR | 500 |
| N_deelnemers | totaal aantal deelnemers voor cohort-normalisatie | aantal | 26.000 |
| N (spreidingN) | wettelijke spreidingstermijn standaardregel | jaren | 1000 *(proxy levenslang; SSPF-keuze, impl.plan §5.6)* |
| compensatieMu (μ) | leeftijds-middelpunt bell-curve compensatiedepot | jaren | 55 |
| compensatieSigma (σ) | standaardafwijking bell-curve | jaren | 8 |
| demografie | cohort-leeftijdsverdeling | preset / counts[15] | preset "gesloten" |

### 3.5 Engine-interne constanten (niet UI-blootgesteld)

| Symbool | Betekenis | Waarde |
|---|---|---|
| w_M^SSPF, w_V^SSPF | SSPF-genderweging deelnemer voor cohort-proxy (§5.5) | 0,95 / 0,05 |
| NP_AANDEEL_PROXY | NP-aandeel proxy-deelnemer bij cohort-sommatie | 0,70 |
| PARTNER_LFTD_VERSCHIL | leeftijdsverschil partner in cohort-proxy | 3 jaar |
| bh₀(M), bh₀(V) | broken-heart-piekfactoren overlevende man/vrouw | 1,50 / 1,25 |
| SHOCK_WINDOW | dempingsperiode broken-heart-schok | 5 jaar |
| COHORT_BOUNDS | grenzen 15 cohorten | [25, 30, …, 95, 100] |
| T_eff_cap | maximale annuïteitshorizon | min(ω−x, 55, t bij ℓ < 10⁻³) |

---

## 4. Formele uitwerking M1 — Kapitaalwaarde huidige aanspraak

M1 berekent de contante waarde van de toekomstige pensioen-kasstromen onder de aanspraak vóór invaren. Het pad volgt vier stappen: sterftekansen → overlevingskansen → annuïteitsfactor → kapitaalwaarde KV.

### 4.1 Sterftekansen — AG2024

Voor leeftijd y, projectiejaar t₀ en geslacht g levert de AG2024-tafel een eenjaars-sterftekans q^AG2024(y, t₀, g). Het model embed jaarkolommen 2022–2050 en leeftijden 0–120. Boven leeftijd 120 geldt q = 1 (overleving 0; horizon-cap voor numerieke stabiliteit). De **periode-snapshot**-conventie houdt in dat één t₀-kolom voor alle toekomstige leeftijden wordt gebruikt:

```
q(y, t₀, g) = q^AG2024(y, t₀, g)        (geen kolom-verschuiving over t)
```

Voor g = "gemengd" (engine-interne fallback voor cohort-niveau, niet UI-blootgesteld als eindgebruiker-keuze) geldt q_gemengd = w_M · q(y, t₀, M) + w_V · q(y, t₀, V) met SSPF-prior w_M = 0,95 en w_V = 0,05.

### 4.2 Overlevingskansen

De **ervaringssterftegecorrigeerde** eenjaars-sterftekans is q_fonds(y) = f · q(y, t₀, g). Hieruit volgt de t-jaars overlevingskans vanaf leeftijd x:

```
ℓ(x, t, t₀, g, f) = ∏_{s=0}^{t-1} (1 − f · q(x + s, t₀, g))
```

Voor sub-jaarlijkse tijdstippen k/m (met m = 12) wordt lineair geïnterpoleerd tussen ℓ(x, ⌊k/m⌋) en ℓ(x, ⌊k/m⌋ + 1) — dit is de **arrears-conventie** voor maandbetalingen.

### 4.3 Annuïteitsfactor

De annuïteitsfactor voor één leven, arrears, maandbasis m, met indexatie π en discontering r:

```
ä(x, r, t₀, g) = (1/m) · Σ_{k=1}^{m·T_eff} (1+π)^{k/m} · ℓ(x, k/m, t₀, g, f) · (1+r)^{−k/m}
```

met T_eff = min(ω − x, 55, t zodat ℓ(x, t) < 10⁻³). De horizon-cap van 55 jaar voorkomt overflow bij zeer jonge x bij overigens onbeduidende kasstroombijdragen ver in de toekomst.

Voor **fractionele leeftijden** (x niet-integer; afgeleid uit geboortedatum + peildatum via dagentelling 365,25) past het model lineaire interpolatie toe tussen ä(⌊x⌋) en ä(⌈x⌉). Voor integer-x is dit bit-identiek aan de directe evaluatie.

### 4.4 KV ouderdomspensioen (KV_OP)

Bij **enkelvoudige aanspraak** (geen hoog-laag-regeling):

```
KV_OP = (1 + ρ) · pen · ä(x₀, r)
```

Bij **hoog-laag-regeling** (art. 63 Pw, hooglaagActief = true, x_knip > x₀) wordt het kasstroomprofiel ontbonden via lineariteit. De kasstromen zijn pen vanaf x₀ tot x_knip, pen_laag vanaf x_knip levenslang. Dit is equivalent aan:

```
ä_temp(x₀, x_knip) = (1/m) · Σ_{k zodat x₀ + k/m ≤ x_knip} (1+π)^{k/m} · ℓ(x₀, k/m) · (1+r)^{−k/m}

KV_OP = (1 + ρ) · [ pen_laag · ä(x₀, r) + (pen − pen_laag) · ä_temp(x₀, x_knip) ]
```

waarbij ä_temp een **tijdelijke annuïteit** is die alleen kasstromen tot leeftijd x_knip telt. Voor x_knip ≤ x₀ levert ä_temp = 0 op (UI weigert deze invoer reeds als verleden-knip).

### 4.5 KV nabestaandenpensioen (KV_NP) via joint-life met broken-heart-correctie

Voor heeftPartner = false geldt KV_NP = 0. Voor heeftPartner = true en y₀ bekend (anders fallback y₀ = 0,70 · pen) gebruikt het model een **joint-life annuïteit met broken-heart-correctie** voor de overlevende partner.

De joint-life-annuïteit ä_{x|y}(r) is de contante waarde van een eenheidskasstroom die start bij het overlijden van de deelnemer (x) en doorloopt zolang de partner (y) leeft, gemeten in maand-incrementen:

```
ä_{x|y}(r) = (1/m) · Σ_{k=1}^{m·T_eff}  (1+π)^{k/m} · Π(x, y, k) · (1+r)^{−k/m}
```

waarin Π(x, y, k) de gezamenlijke kans is dat deelnemer x reeds overleden is op tijdstip k/m én partner y nog leeft, onder broken-heart-correctie. Numeriek wordt Π opgebouwd via incrementele decompositie over het deelnemer-overlijdens-tijdstip k_d:

```
Π(x, y, k) = Σ_{k_d=1}^{k}  Δℓ_x(k_d) · ℓ_y^{bh}(k_d, k)
```

met Δℓ_x(k_d) = ℓ(x, (k_d−1)/m) − ℓ(x, k_d/m) de incrementele sterftekans van de deelnemer in maand k_d, en ℓ_y^{bh}(k_d, k) de overlevingskans van de partner op tijdstip k/m, gegeven dat de deelnemer is overleden op tijdstip k_d/m, onder broken-heart-schok:

- Voor s ∈ [1, k_d]: gewone baseline-overleving partner (geen schok).
- Voor s ∈ [k_d+1, k_d + 5m]: geschokte q_eff = min(1, bh(τ, g_y) · q(y + ⌊(s−1)/m⌋, t₀, g_y)) met τ = (s − k_d − 0,5)/m.
- Voor s > k_d + 5m: schok uitgewerkt, terug naar baseline-ratio.

De broken-heart-factor bh(τ, g_y) is gespecificeerd in §6.1.

De NP-kapitaalwaarde is dan:

```
KV_NP = (1 + ρ) · y₀_eff · ä_{x|y}(r)
```

met y₀_eff = y₀ als opgegeven, anders 0,70 · pen.

Voor reeds ingegaan NP (deelnemer overleden, partner ontvangt al uitkering) reduceert dit tot KV_NP = (1 + ρ) · y₀_eff · ä(x_partner, r) (joint-life vervalt naar enkelvoudig).

### 4.6 Kostenopslag ρ — fallback-ladder

ρ wordt afgeleid via een fallback-ladder (§2.7 spec):

1. **Variant-A** (beide uitvoeringskostenJaarlijks én fondsvermogen aanwezig): c_jaar = uitvoeringskostenJaarlijks / fondsvermogen; ρ = c_jaar · ä(x₀, r).
2. **Directe override** (kostenOpslagPct ingevuld): ρ = kostenOpslagPct.
3. **Ultieme default**: ρ = 0,02.

Voor SSPF (M1-config in §3.3): beide bronvelden null → ρ_default = 0,02. Deze waarde wijkt bewust af van het "rijk-rekenen" alternatief ρ = 0; het publieke calculator-doel is het kostenverschil tussen verwachting en realisatie zichtbaar maken.

### 4.7 Totaal-KV

```
KV = KV_OP + KV_NP
```

---

## 5. Formele uitwerking M2 — Persoonlijk pensioenvermogen onder standaardregel

M2 implementeert de wettelijke standaardregel uit bijlage 2a Regeling Pw als productie-pad (engine-version v3.0). De berekening verloopt in zes stappen: q-gewogen kasstroomgewicht → individueel cw_star → fondsbalans M → cohort-proxy → fondsschalingsfactor x_fonds → ppk-componenten.

### 5.1 Wettelijke spreidings-multiplier q(h, N)

```
q(h, N) = min(⌊h⌋ / N, 1)
```

h is de looptijd in jaren vanaf het invaarmoment (kan sub-jaarlijks zijn bij m = 12). Voor h < 1 is ⌊h⌋ = 0 dus q = 0 — de eerste 11 maanden krijgen onder N = 10 geen overschot toegewezen, conform de "trapsgewijs jaarlijks stijgend" wettekst. Voor N → ∞ (proxy: N = 1000) convergeert q(h, N) naar nul voor alle praktisch relevante h.

### 5.2 Individuele spreidings-gewogen kapitaalwaarde cw_star

Per deelnemer levert M1 (in cascade-modus) twee q-gewogen contante waarden:

```
cw_star_OP = (1 + ρ) · pen · ä^q(x₀, r, N)        (enkelvoudig, of hoog-laag-decompositie)
cw_star_NP = (1 + ρ) · y₀_eff · ä^q_{x|y}(r, N)   (bij heeftPartner=true)
```

waarbij de **q-gewogen annuïteitsvarianten** ä^q en ä^q_{x|y} identiek zijn aan §4.3/§4.5 maar met een extra q(t, N)-multiplier in de buitenste sommatie:

```
ä^q(x, r, N) = (1/m) · Σ_{k=1}^{m·T_eff}  q(k/m, N) · (1+π)^{k/m} · ℓ(x, k/m) · (1+r)^{−k/m}

ä^q_{x|y}(r, N) = (1/m) · Σ_{k=1}^{m·T_eff}  q(k/m, N) · (1+π)^{k/m} · Π(x, y, k) · (1+r)^{−k/m}
```

Per individu i geldt dus, op kasstroomvector-niveau (zie wettekst):

```
KS_voor(i, h) = pen_i · ℓ(x₀_i, h)  + [NP-component]
CW_voor(i)    = Σ_h KS_voor(i, h) · v(h)         = KV(i)            (per definitie M1)
CW_star(i)    = Σ_h q(h, N) · KS_voor(i, h) · v(h)                  (cw_star_OP + cw_star_NP)
```

### 5.3 Fondsbalans — beschikbaar vermogen M (Model C bundle)

Voorafgaand aan de standaardregel-toedeling worden vier bestemmings-reserveringen afgesplitst (bundle-aftrek):

```
M = F − vpvAftrekPct · vpvTotal − compensatiedepot − buffer + bijstort
```

Alle bedragen in mln EUR. Voor SSPF (defaults): M = 26.000 − 0,06 · 19.100 − 0 − 0 + 500 = 26.000 − 1.146 + 500 = 25.354 mln EUR.

Het **verdeelbare overschot** boven vpvTotal:

```
verdeelbaar = M − vpvTotal
```

Voor SSPF defaults: verdeelbaar ≈ 25.354 − 19.100 = 6.254 mln EUR. Kan negatief zijn bij onderdekking; in dat geval levert x_fonds (§5.5) een negatieve waarde, wat zich vertaalt in een negatieve ppkSurplus — de standaardregel modelleert daarmee automatisch een korting op de aanspraak. ppkBase = KV blijft in beide gevallen ongewijzigd (zie §5.6).

### 5.4 Cohort-proxy: kvProfile en cwStarProfile

De wettelijke schalingsfactor x_fonds (§5.5) vereist een schatting van CW_star op fondsniveau. Het model schat deze via een **cohort-proxy** met SSPF-genderweging, per cohort-mid-leeftijd x̄_c ∈ {27, 32, …, 97}.

De **kvProfile**-functie levert een proxy-KV per cohort-mid:

```
kvProfile(a, pen, r, g) = pen · (a − 25)/40 · ä(65, r, g) · (1 + r)^{−(65 − a)}     voor 25 ≤ a < 65
                       = pen · ä(min(a, 99), r, g)                                  voor a ≥ 65
```

Voor actieven (a < 65) modelleert dit een aanspraak die lineair opbouwt over de loopbaan, ingaat op 65, en disconteert vanaf nu. Voor gepensioneerden (a ≥ 65) is het direct de levenslange annuïteit op leeftijd a, gecapt op 99 (om q's bij zeer hoge leeftijd niet door 1 te laten breken).

De **cwStarProfile**-functie is de q-gewogen analogon:

```
cwStarProfile(a, pen, r, g, N) = pen · (a − 25)/40 · ä^q_shift(65, r, g, N, shift=65−a) · (1+r)^{−(65−a)}     voor a < 65
                              = pen · ä^q(min(a, 99), r, g, N)                                              voor a ≥ 65
```

waarbij **ä^q_shift** een gewettelijke q-multiplier toepast die het invaartijdstip als referentie houdt (niet het pensioenmoment). Voor een 27-jarige (shift = 38) onder N = 10 vallen alle pensioenstromen vanaf 65 al onder q = 1, omdat de eerste pensioenstroom op h = 38 ligt en 38 > 10.

### 5.5 Fondsschalingsfactor x_fonds via cohort-sommatie

Het model sommeert kvProfile en cwStarProfile over de 15 cohorten met SSPF-genderweging op cohort-mix-niveau, en voegt een NP-component toe via joint-life met proxy-partner (3 jaar jonger, ander geslacht, y₀ = 0,70 · pen). De NP-component is noodzakelijk omdat vpvTotal als noemer al OP+NP-aanspraken bevat; zonder NP zou er een dimensieconflict ontstaan tussen teller (individu OP+NP) en noemer (fonds OP-only).

```
kv̄_c    = w_M · [kvProfile(x̄_c, M) + np_M] + w_V · [kvProfile(x̄_c, V) + np_V]
cwStar̄_c = w_M · [cwStarProfile(x̄_c, M, N) + npStar_M] + w_V · [cwStarProfile(x̄_c, V, N) + npStar_V]

n_c = fractie_c · N_deelnemers

CW_voor_proxy = Σ_c  n_c · kv̄_c
CW_star_proxy = Σ_c  n_c · cwStar̄_c

R = CW_star_proxy / CW_voor_proxy                          (fonds-karakteristiek)
CW_star_fonds_estimated = R · vpvTotal                     (anker-gecalibreerd)
```

waarin np_g en npStar_g de joint-life-annuïteit-bijdragen zijn voor een partner van het andere geslacht, 3 jaar jonger dan x̄_c, met aanspraak 0,70 · pen.

De wettelijke schalingsfactor is:

```
x_fonds = (M − vpvTotal) / CW_star_fonds_estimated
```

De ratio R is een **fonds-karakteristiek** per (preset, sterftetafel, N). Voor SSPF (preset "gesloten", AG2024, N = 1000) ligt R typisch in de orde 0,3–0,4. De anker-calibratie via vpvTotal × R ontkoppelt de absolute schaal van de proxy-aanname (proxy-pen × demografie kan vpvTotal niet exact reproduceren omdat de werkelijke SSPF-aanspraken niet uniform zijn).

### 5.6 PPV-componenten (lineariteit)

Per individu i bestaat het persoonlijk pensioenvermogen uit drie componenten:

```
ppkBase(i)       = KV(i)                                             (CW_voor, "het deel zonder fonds-overschot")
ppkSurplus_OP(i) = x_fonds · cw_star_OP(i)
ppkSurplus_NP(i) = x_fonds · cw_star_NP(i)
ppkSurplus(i)    = ppkSurplus_OP(i) + ppkSurplus_NP(i)
ppkComp(i)       = (compensatiedepot / N_deelnemers) · w_rel(x₀_i)   (zie §5.7; voor SSPF = 0)

ppkTotal(i) = ppkBase(i) + ppkSurplus(i) + ppkComp(i)
```

OP/NP-decompositie via dezelfde lineariteit:

```
ppk_OP(i) = KV_OP(i) + ppkSurplus_OP(i) + ppkComp(i)                 (alle compensatie naar OP, art. 150f Pw)
ppk_NP(i) = KV_NP(i) + ppkSurplus_NP(i)
```

Het model dwingt twee sluitingscontroles af op tolerantie 10⁻⁶:

- ppk_OP + ppk_NP = ppkTotal
- ppkBase + ppkSurplus + ppkComp = ppkTotal

### 5.7 Bell-curve verdeling compensatiedepot

Het compensatiedepot is wettelijk bestemd voor actieven met gemiste toekomstige opbouw onder de afschaffing van de doorsneesystematiek (art. 150f Pw + DNB Q&A juni 2025). Het model verdeelt dit via een Gaussische bell-curve gecentreerd op μ = 55 (mid-carrière) met σ = 8:

```
w(x) = exp(−½ · ((x − μ) / σ)²)

w̄ = demografisch gewogen gemiddelde van w over alle cohorten:
       w̄ = Σ_c  (fractie_c / 5) · Σ_{a ∈ cohort_c} w(a)
          / Σ_c  (fractie_c / 5) · 5
       = Σ_c fractie_c · ⟨w⟩_{cohort_c}

w_rel(x) = w(x) / w̄
```

Per deelnemer: ppkComp(i) = (compensatiedepot / N_deelnemers) · w_rel(x₀_i).

Voor SSPF is compensatiedepot = 0 (geen DRS-doelgroep — fonds is feitelijk gesloten voor nieuwe actieven), dus ppkComp = 0 voor alle deelnemers. De bell-curve blijft in de engine aanwezig voor multi-fonds-toepassing en voor het cohort-uitsplitsing-rapport.

---

## 6. Aanvullende modelfuncties

### 6.1 Broken-heart-correctie

Multiplicatieve schok op de overlevende-partner-sterftekans direct na overlijden van de deelnemer; lineair afnemend van bh₀(g) naar 1 over een dempingsperiode van 5 jaar:

```
bh(τ, g) = bh₀(g) − (bh₀(g) − 1) · (τ / 5)        voor τ ∈ [0, 5]
         = 1                                       voor τ > 5
```

met τ = jaren sinds overlijden van de deelnemer. Default-parametrisering (placeholder, bron-todo AG-2018-publicatie, openstaand item A3 in handoff §5):

- bh₀(M) = 1,50 (overlevende man na vrouwelijke partner)
- bh₀(V) = 1,25 (overlevende vrouw na mannelijke partner)
- gemengd: 1,375 (gemiddelde van M en V)

### 6.2 Levensverwachting

Het model rapporteert de **verwachte sterfleeftijd** (curtate + halfjaar-correctie):

```
lifeExp(x) = x + Σ_{t=1}^{T_eff}  ℓ(x, t, t₀, g, f) + 0,5
```

Dit is dus niet de resterende levensverwachting (E[T] − x) maar de absolute verwachte leeftijd bij overlijden. Voor SSPF-defaults (x₀ = 70, g = M, f = 0,90) geeft dit lifeExp(70) ≈ 86,02 jaar.

### 6.3 Joint-life-annuïteit numerieke optimalisatie

De naïve joint-life-implementatie heeft complexiteit O(K³) waar K = m · T_eff. Het model gebruikt een **O(K²) optimalisatie** via incrementele decompositie:

- Pre-compute van deelnemer-incrementele sterftekansen Δℓ_x(k_d) — O(K).
- Pre-compute van partner-baseline-overlevingskansen p_base[k] — O(K).
- Voor elke (k, k_d) wordt p_y^{bh} uit drie segmenten samengesteld:
  - Baseline-segment [1, k_d]: p_base[k_d].
  - Schok-segment [k_d+1, min(k, k_d + 5m)]: expliciete iteratie met bh-correctie (≤ 60 iteraties).
  - Post-schok-baseline-ratio: p_base[k] / p_base[shockEnd] (constante factor).

De memoisatie-caches per annuïteitsvariant beperken het geheugen tot 256 entries (FIFO-eviction), wat voldoende is voor de typische 5–20 unieke leeftijdsparen per UI-sessie.

### 6.4 Fractionele leeftijden

Sinds v3.0.51 is de UI-input een geboortedatum; de leeftijd is x = (peildatum − dob) / 365,25. Bij quasi-integer-waarden (fractie > 0,998 of < 0,002) wordt afgerond naar de gehele leeftijd ("snap-to-integer") om equivalentie te bewaren met test-ankers op gehele jaren. Voor niet-integer x past het model lineaire interpolatie toe op annuïteit-niveau:

```
ä(x, r) = (1 − frac) · ä(⌊x⌋, r) + frac · ä(⌊x⌋ + 1, r)        met frac = x − ⌊x⌋
```

Dit is equivalent aan de constant-force-aanname voor sub-jaarlijkse leeftijden — een actuariële standaard die DNB en het AG hanteren bij fractionele waarderingen. De theoretische fout t.o.v. exacte fractionele AG2024-evaluatie is rond x = 70 in de orde 0,1%, omdat ä bijna lineair is in x op enkelvoudige jaren.

Voor joint-life-annuïteiten geldt bilineaire interpolatie over het paar (x_d, x_p):

```
ä_{x_d | x_p} = (1−f_D)(1−f_P)·ä(⌊x_d⌋, ⌊x_p⌋)
              + f_D·(1−f_P)·ä(⌊x_d⌋+1, ⌊x_p⌋)
              + (1−f_D)·f_P·ä(⌊x_d⌋, ⌊x_p⌋+1)
              + f_D·f_P·ä(⌊x_d⌋+1, ⌊x_p⌋+1)
```

---

## 7. Cascade-presentatie (SSPF-specifiek)

De engine implementeert de bundle-aftrek (§5.3) als één geaggregeerde vpvAftrekPct + losse bijstort. Voor uitlegbaarheid wordt deze aftrek in de UI-rapportage echter ontleed in vier conceptuele componenten (impl.plan §5.5 + §5.9 + §5.10):

| Component | Conceptueel bedrag SSPF | Engine-mapping |
|---|---|---|
| Bijstort werkgever (compensatie sponsorgarantie) | + 500 mln EUR (DG ≥ 135%; bij 130–135%: 650 mln; bij 125–130%: 850 mln) | `bijstort = 500` |
| Wettelijke reserves (VEV + operationele reserve + inhaalindexatie) | ≈ 2% van vpvTotal ≈ 382 mln EUR | onderdeel van `vpvAftrekPct = 0,06` |
| Risicodelingsreserve (RDR) | 500 mln EUR | onderdeel van `vpvAftrekPct = 0,06` |
| Compensatiedepot DRS (afschaffing doorsnee) | 400 mln EUR | onderdeel van `vpvAftrekPct = 0,06` |

De totale bundle (vpvAftrekPct · vpvTotal = 0,06 · 19.100 = 1.146 mln EUR) komt overeen met de som van wettelijke reserves + RDR + compensatiedepot ≈ 1.282 mln EUR, met de afronding 6,0% als conservatieve middenwaarde (cascade-comment in `fonds.config.ts`). De UI-rapportage toont de cascade-componenten apart voor uitlegbaarheid; de engine rekent met de geaggregeerde 6,0%. Het feit dat het compensatiedepot conceptueel is afgesplitst maar in de engine als 0 staat (niet apart toegekend via bell-curve) reflecteert dat SSPF feitelijk geen actieve DRS-doelgroep heeft — de 400 mln EUR conceptuele bestemming zit in de aftrek maar wordt niet via de bell-curve naar individuen verdeeld; ze blijft in de fondsbalans als bestemmingsreserve buiten de standaardregel.

Voor een fonds met een actieve DRS-doelgroep (bv. een fonds met actieven) zou het compensatiedepot expliciet als M2-parameter `compensatiedepot > 0` worden ingevoerd, en dan via §5.7 over de actieven worden verdeeld.

---

## 8. Toegepast voorbeeld — SSPF default-scenario

Ter illustratie volgt de berekening voor het UI-default-scenario: 70-jarige man met huidige aanspraak EUR 100.000, geen partner, peildatum 2026. De stappen A–F tonen welke grootheden de engine berekent; de exacte numerieke uitkomsten (PPV-ankers) worden door de regressie-suite gepind, niet door handmatige aritmetiek gereproduceerd. De rapportage hieronder geeft de direct parameter-afgeleide grootheden (M, verdeelbaar) en het anker, maar laat de tussen-stappen (R, x_fonds, cw_star) in formule-vorm.

**Stap A — KV_OP (M1):** Met ρ = 0,02, ä(70, r = 0,025, t₀ = 2026, g = M, f = 0,90) volgens AG2024 + arrears m = 12:
- KV_OP = (1 + ρ) · pen · ä(x₀, r) = 1,02 · 100.000 · ä(70, 0,025) → engine-anker **EUR 1.298.341**
- KV_NP = 0 (geen partner)
- KV = EUR 1.298.341

**Stap B — Verwachte sterfleeftijd:** lifeExp(70) = 70 + Σ ℓ + 0,5 → engine-anker **86,02 jaar**.

**Stap C — Fondsbalans M (M2):** Met SSPF-parameters in §3.4:
- M = F − vpvAftrekPct · vpvTotal − compensatiedepot − buffer + bijstort
- M = 26.000 − 0,06 · 19.100 − 0 − 0 + 500 = **25.354 mln EUR**
- verdeelbaar = M − vpvTotal = 25.354 − 19.100 = **6.254 mln EUR**

Het verdeelbaar overschot van 6.254 mln EUR komt overeen met een DG-equivalent van M/vpvTotal − 1 = 25.354/19.100 − 1 = 32,7 procentpunt boven volledige dekking; deze 32,7 percentpunten worden via x_fonds × CW_star verdeeld over de individuen.

**Stap D — Fonds-ratio R en x_fonds:** Cohort-sommatie over preset "gesloten" met SSPF-genderweging w_M = 0,95, w_V = 0,05, en NP-proxy (partner 3j jonger, ander geslacht, y₀ = 0,70 · pen):
- CW_voor_proxy = Σ_c n_c · kv̄_c
- CW_star_proxy = Σ_c n_c · cwStar̄_c (met spreidingN = 1000)
- R = CW_star_proxy / CW_voor_proxy (fonds-karakteristiek voor het tripel ⟨preset, AG2024, N⟩)
- CW_star_fonds_estimated = R · vpvTotal
- x_fonds = (M − vpvTotal) / CW_star_fonds_estimated = 6.254 mln / (R · 19.100 mln)

Voor de preset "gesloten" onder N = 1000 levert R een waarde in de orde 0,10–0,20 (de R-waarde zelf is een diagnostische output in de audit-rapport-sectie van de UI; hij is fonds-karakteristiek en niet handmatig na te rekenen zonder de engine-loop over 15 cohorten te draaien).

**Stap E — Individueel cw_star (deelnemer):**
- cw_star_OP = (1 + ρ) · pen · ä^q(x₀, r, N) met N = 1000
- ä^q(x, r, N) = (1/m) · Σ_k q(k/m, N) · (1+π)^{k/m} · ℓ(x, k/m) · (1+r)^{−k/m}
- Voor N = 1000 en h ≤ ω − 70 = 50 geldt q(h, 1000) = ⌊h⌋/1000 ∈ [0, 0,050]; ä^q is daarmee ongeveer twee orden van grootte kleiner dan ä.
- cw_star_NP = 0 (geen partner)

**Stap F — Persoonlijk pensioenvermogen:**
- ppkBase = KV = EUR 1.298.341
- ppkSurplus = x_fonds · cw_star_OP
- ppkComp = 0 (SSPF heeft compensatiedepot = 0)
- ppkTotal = ppkBase + ppkSurplus + ppkComp

**Engine-anker (regressie-test `test_browser_calc.ts` Test 3 in v3.0.106):**
- **ppkTotal = PPV M2 = EUR 1.611.130**
- ppkSurplus = ppkTotal − ppkBase = EUR 312.789 (= +24,1% boven KV)

De +24,1% opslag voor een 70-jarige man zonder partner, bij SSPF-DG = 136,1% en N = 1000, is hoger dan de Haringa-Bijlage-1-modeluitkomst van +13,6% bij DG = 135% en N = ∞. Het verschil van ~10 percentpunten is grotendeels te herleiden tot:

1. **Andere bundle-aftrek**: Haringa hanteert α = 10% (vlakke aftrek op DG · CW_voor); calculator-SSPF hanteert vpvAftrekPct = 6% (op vpvTotal) + bijstort = +500 mln (op fondsvermogen). Het verschil leidt tot een hogere M/vpvTotal-ratio in de calculator (1,327) versus Haringa (1,215 bij DG = 135%).
2. **Andere DG**: SSPF actueel 1,361 versus Haringa-illustratie 1,35.
3. **f = 0,90 vs f = 1,0**: lagere ervaringssterfte verhoogt zowel de aanspraak-waarde als de cw_star bij gelijkblijvende cohort-mix.
4. **AG2024 vs Gompertz**: AG2024-prognosetafels voor mannen-pensioenfonds zijn iets gunstiger qua resterende levensduur dan vereenvoudigde Gompertz, hetgeen iets meer cw_star aan oudere cohorten geeft.

**Anker onder N = 10 (educatieve vergelijking, wettelijke default):** door spreidingN in de UI van 1000 naar 10 te zetten kan de gebruiker het verschil tussen tien-jaars default en levenslange spreiding voor het SSPF-fonds rechtstreeks aflezen. Dat verschil reproduceert kwalitatief de Haringa-Bijlage-1-tabel: voor een 70-jarige onder DG ≈ 135% een nadeel van ongeveer 5 procentpunten persoonlijk vermogen bij overgang van N = 10 naar N = ∞, oftewel een corresponderend nadeel in elke pensioenuitkering levenslang.

---

## 9. Aannames en hun rechtvaardiging

- **Vlakke disconteringsvoet r = 2,5%**: orde van grootte van de DNB UFR-curve eind 2025 (~2,5%). Werkelijke RTS varieert per looptijd; effect op directionele uitkomst (verschil N = 10 vs N = ∞) is verwaarloosbaar omdat zowel teller als noemer met dezelfde curve disconteren.

- **AG2024-prognosetafel (KAG 12-09-2024) per geslacht**: officiële Nederlandse actuariële standaard; embed jaarkolommen 2022–2050. Vervangt de eerdere R9.30-Q-tabel. Periode-snapshot t₀ = 2026 (één kolom voor alle toekomstige leeftijden) is in M1 een bewuste keuze; cohort-projectie is een v2-uitbreidingspad (M4-gedrag).

- **Ervaringssterfte f = 0,90**: conservatief midpoint voor de SSPF-populatie (hoog-opgeleide top-inkomensquintiel-witte-boorden-fondsen). Bron: CBS levensverwachting naar inkomen (vzinfo.nl, peildata 2019/2022): 65-jarige mannen hoogste inkomensquintiel 20,5 jaar resterende levensverwachting versus laagste 16,4 jaar (verschil 4,1 jaar); CBS-welvaartsstudie verschil hoogste vs laagste welvaartsgroep ruim 4 jaar op 65-jarige leeftijd. Industrie-benchmark voor hoog-opgeleide-witte-boorden-fondsen typisch 0,85–0,95. Beperking: vlak (geen leeftijds-/gender-differentiatie); v2-uitbreidingspad voor leeftijdsafhankelijke vorm. Een echt SSPF-fondsspecifiek getal vraagt niet-publieke ABTN-data en zou waarschijnlijk lager liggen.

- **Maandbasis m = 12 en arrears-conventie**: cross-module-lock (§7.3 ENGINE_SPECIFICATIE_v1). Conceptueel toestaan van m ∈ {1, 4, 12} is uitgesloten in v2.0-SCHEMA omdat hard-consistentie tussen M1, M2, (M3, M4) eist dat alle modules dezelfde kasstroom-timing-conventie hanteren. Heropening vergt SCHEMA minor-bump.

- **Indexatie π = 0 op aanspraak**: bewust anker — KV staat voor de kale papieren aanspraak vóór invaren. Indexatie-effect wordt elders in de calculator (post-invaren-projectie, niet in dit document) als pedagogische payload getoond.

- **Eindleeftijd ω = 120**: bovengrens AG2024-tafel; praktisch geen overlevingskans boven deze leeftijd. Kasstromen voorbij 120 zijn verwaarloosbaar.

- **N = 1000 als proxy voor levenslange spreiding**: voor alle relevante looptijden h ≤ ω − 25 = 95 geldt h/N ≪ 1, hetgeen kwalitatief gelijk is aan een levenslange spreiding. UI-range [0, 1000] dekt zowel de wettelijke default (10), tussenwaarden (onder art. 2 lid 3 onderbouwd), als de educatieve N = ∞-vergelijking.

- **Vermogensaftrek vpvAftrekPct = 0,06 (SSPF)**: cascade-middenwaarde — 2% wettelijke reserves + RDR 500 mln + compensatiedepot 400 mln ≈ 6,7% bij DG = 135%, afgerond op 6,0% als conservatieve middenwaarde omdat de samenstelling met de DG meebeweegt. ABN-referentiewaarde (publieke transitiecommunicatie) ligt op 0,10 maar bevat dáár het compensatiedepot wél in de bundle; SSPF (gesloten, geen DRS-doelgroep) heeft een andere bundle-samenstelling. Klakkeloos overnemen → compensatie zou dubbel tellen of verkeerd kalibreren.

- **SSPF-genderweging cohort-mix 95% M / 5% V**: SSPF-prior, v1-placeholder. De cohort-proxy gebruikt deze weging voor s̄ en kvProfile-aggregatie op fondsniveau. Effect op directionele uitkomst gering omdat ratio R primair afhangt van de leeftijdsverdeling (preset "gesloten") en de tijd-structuur, niet van de gender-verdeling.

- **Demografie-preset "gesloten" (SSPF)**: cohort-aantallen [0, 0, 0, 0, 0, 50, 400, 1500, 2500, 2800, 2200, 1300, 700, 250, 50] voor cohorten [25–29]..[95–99]. Indicatieve aantallen; ze leveren alleen de vorm (fracties). SSPF-specifieke counts zijn niet publiek beschikbaar; bron-todo (§11.19 spec) voor vervanging via customCounts zonder formule-bump. ~60% van het bestand 65+, consistent met SSPF-Jaarverslag 2024 (ruim 60% pensioengerechtigd, ~26k totaal).

- **Cohort-proxy NP-aandeel = 0,70 met partner 3j jonger, ander geslacht**: een typische UPO-ratio voor de NP-aanspraak. Beïnvloedt alleen de fonds-ratio R, niet het individuele cw_star — die laatste gebruikt de werkelijke deelnemer-input (y₀, x_partner, g_y). Performance-keuze: proxy gebruikt m = 1 (jaarlijks) ipv m = 12; verschil in fonds-ratio <0,1% maar reduceert de joint-life K² loop met factor 144.

- **Bell-curve μ = 55, σ = 8** (compensatiedepot-verdeling): mid-carrière-aanname die de wettelijke DRS-doelgroep (actieven met opbouwjaren in het oude doorsneesysteem) benadert. Niet kritisch voor SSPF (compensatiedepot = 0); relevant voor fondsen met actieve DRS-doelgroep.

- **Broken-heart-factoren bh₀(M) = 1,50, bh₀(V) = 1,25, 5-jaars lineaire demping**: placeholder, bron-todo AG-2018-publicatie (openstaand item A3 in handoff §5). De waardes komen overeen met de literatuur-orde voor mortality-multipliers in het eerste jaar na partnerverlies. Effect op KV_NP voor een typisch 70-jarig paar in de orde 5–15% versus naïef-onafhankelijke leven-modelering (waarvoor v1.3 een bovengrens KV_NP = y₀ · ä(x_partner, r) gebruikte; deze is binnen v2.2.11 vervangen door de joint-life-mechaniek).

- **Theoretische maximale leeftijd ω = 120**: praktisch geen overlevingskans boven deze leeftijd; horizon-cap voor numerieke stabiliteit (q = 1 bij y > 120 voorkomt crashes bij hoge x₀ in de joint-life-cascade).

---

## 10. Verschillen met het Haringa-vereenvoudigde-rekenmodel (brief 2 mei 2026, Bijlage 2)

Het hier beschreven calculator-model is een vollediger model dan het rekenmodel in Bijlage 2 bij Haringa's vragenbrief aan SSPF van 2 mei 2026. De voornaamste verschillen, ten gunste van calculator-precisie:

| Aspect | Haringa-Bijlage 2 | Invaarcalculator v3.0.106 |
|---|---|---|
| Sterftekansen | Gompertz-curve (B = 1,5·10⁻⁵, c = 1,105) | AG2024-prognosetafel KAG 12-09-2024, per geslacht, jaarkolom t₀ = 2026 |
| Disconteringsvoet | vlak r = 2,5% | vlak r = 2,5% (afspiegeling DNB UFR eind 2025) |
| Ervaringssterfte | impliciet f = 1,0 | f = 0,90 (CBS-onderbouwd voor hoog-inkomenskwintiel) |
| Annuïteits-conventie | vereenvoudigd jaarbasis | arrears m = 12 (maandbetalingen) |
| Partnerpensioen | niet gemodelleerd (alleen OP) | joint-life met broken-heart-correctie (bh₀, 5-jaars demping) |
| Hoog-laag-regeling (art. 63 Pw) | niet gemodelleerd | lineaire decompositie via tijdelijke annuïteit ä_temp |
| Kostenopslag ρ | niet gemodelleerd | fallback-ladder (Variant-A / directe override / default 0,02) |
| Vermogensaftrek | α = 0,10 als vlakke pre-aftrek op DG · CW_voor | bundle vpvAftrekPct · vpvTotal − compensatiedepot − buffer + bijstort (Model C, parameter-geïsoleerd per aftrekgrond) |
| Fondsschalingsfactor | scalair x* uit (M − CWvoor) / CW_star op één-individu-niveau | x_fonds uit cohort-sommatie met SSPF-genderweging + NP-via-joint-life-proxy, anker-gecalibreerd via vpvTotal × R |
| Bell-curve compensatiedepot | n.v.t. (geen compensatiedepot) | Gaussisch (μ = 55, σ = 8), demografisch genormaliseerd |
| Demografie | impliciet uniform per leeftijd | preset "gesloten" of customCounts[15] over 15 cohorten |
| Fractionele leeftijden | niet ondersteund | lineaire interpolatie ä(x) tussen integer-jaren; snap-to-integer bij quasi-integer-DOB |
| Cohort-uitsplitsing | tabel per gehele leeftijd 30..90 | 15 cohorten × 5 jaar, met surplusBijdrage_c en compBijdrage_c per cohort |
| 67%-randvoorwaarde (art. 150n lid 4 Pw) | erkend in voetnoot, niet gemodelleerd | erkend in spec §3.6, niet gemodelleerd (zie §11 hieronder) |
| Stochastische scenario's | deterministische verwachting | deterministisch ppk-berekening; goed-/mediaan-/slechtweer-projectie is M3-gedrag (niet gebouwd) |
| RDR-werking post-invaren | aangenomen neutraal tussen N = 10 en N = ∞ | RDR-buffer afgesplitst voorafgaand; demping-werking post-invaren in M3 (niet gebouwd) |

Voor de directionele uitkomst — het verschil tussen tien-jaars default en levenslange spreiding voor pensioengerechtigden — zijn beide modellen consistent. De Haringa-orde van grootte voor een 70-jarige bij DG = 135% (~5,3% nadeel van N = ∞ vs N = 10) reproduceert kwalitatief wat de calculator levert bij dezelfde DG en geslachts/leeftijd-input; het exacte percentage hangt af van de hier benoemde precisie-verschillen (vooral f = 0,90, AG2024, arrears m = 12, en de NP-component bij gehuwde deelnemers).

---

## 11. Elementen die het model niet modelleert

Voor transparantie volgt hieronder een uitputtende lijst van elementen die het calculator-model **niet** of slechts vereenvoudigd weergeeft, met indicatie van de mogelijke richting van het effect.

- **67%-randvoorwaarde (art. 150n lid 4 Pw)**: voorkomt dat persoonlijke vermogens tussen cohorten meer dan 67% boven het gemiddelde collectieve effect kunnen ontvangen. Niet gemodelleerd; relevant vooral voor jongere cohorten onder N = ∞ (modelmatige opslag kan oplopen tot zeer hoge waarden, in werkelijkheid getemperd). Voor SSPF (preset "gesloten" — geen actieven jonger dan 50) is het effect in de praktijk gering, maar voor multi-cohort-fondsen substantieel. Openstaand actuaris-item, mogelijk D-categorie.

- **DG-afhankelijke bijstort-staffel (Shell-bijdrage)**: het impl.plan §5.5 specificeert een dekkingsgraadafhankelijke transitiebijdrage (€ 850 mln bij DG 125–130%, € 650 mln bij 130–135%, € 500 mln bij DG ≥ 135%). Het model neemt **één bijstort-bedrag** als parameter (default 500 mln, SSPF-keuze bij DG ≥ 135%); een staffel-implementatie waarin de bijstort automatisch met DG meebeweegt is openstaand actuaris-item D5 (HOOG-prioriteit).

- **Stochastische scenario-analyse (goed/mediaan/slechtweer-projectie)**: het model levert deterministische verwachtingen. De wettelijke transitiemaatstaven (netto profijt, pensioenverwachting in 95-/50-/5-percentiel-scenario's, gemiddelde kortingskans over 15 jaar) zijn M3-gedrag dat in deze versie niet gebouwd is (openstaand strategisch-item M3 Monte Carlo).

- **DB-vs-WTP-projectie post-invaren**: vergelijking van uitkeringspaden onder voortzetting van de DB-aanspraak (geen invaren) versus invaren naar de WTP-solidaire premieregeling, met regime-specifieke indexatie/projectie-aannames. M4-gedrag dat in deze versie niet gebouwd is (openstaand strategisch-item M4).

- **5-jaars rendementsspreiding op uitkeringen onder Wtp**: Wtp voorziet in spreiding van rendementsschokken over 5 jaar; de calculator toont een deterministische initiële PPV maar geen tijdspad van uitkeringen na invaren met daarbij behorende dempingsdynamiek.

- **RDR-werking post-invaren (mitigerende dynamiek)**: de risicodelingsreserve mitigeert kortingen in slechte rendementsscenario's na invaren. Het model splitst de RDR voorafgaand af (als onderdeel van vpvAftrekPct) maar modelleert de post-invaren-dempingsdynamiek niet. Aangenomen wordt — in lijn met Haringa-Bijlage 2 — dat deze werking neutraal uitwerkt tussen N = 10 en N = ∞ voor het verschil-in-bufferaandeel. Of de RDR in zijn omvang feitelijk fungeert als compensatie voor het door levenslange spreiding lagere bufferaandeel (i.p.v. als zelfstandig risicobeperkend instrument) is een evenwichtigheidsvraag die buiten model-bereik valt.

- **Partnerpensioen-overlevingsuitkering los van OP**: het model modelleert NP als joint-life-annuïteit (uitkering aan overlevende partner zolang die leeft, conditioneel op overlijden deelnemer). Een aparte modellering van partner-overlijden vóór deelnemer met behoud van NP-rechten is niet expliciet uitgewerkt — openstaand item D4 (buiten scope per gebruikersbesluit, handoff §5).

- **PPV → maandelijks bedrag onder SPR**: de vertaling van persoonlijk pensioenvermogen naar maandbedrag (annuïteitsfactor voor de SPR-uitkering met regime-specifieke parameters) is M4-gedrag, niet in deze versie gebouwd.

- **Werkelijke fonds-demografie**: het model gebruikt een preset-template (cohort-counts voor "gesloten" fondstype, indicatief). SSPF-specifieke aantallen zijn niet publiek beschikbaar; bron-todo voor vervanging via customCounts (handoff §5, strategisch-item 5).

- **AG2024-cohorttafels**: het model gebruikt een periode-snapshot (één t₀-kolom voor alle toekomstige leeftijden). De cohorttafel-variant (kolom mee-evolueert met t) is een M4-uitbreidingspad; verschil typisch <1% op KV-niveau (§5.12.7 spec).

- **Leeftijds- en gender-afhankelijke ervaringssterftefactor f**: in deze versie is f een scalair (0,90 voor SSPF). v2-uitbreidingspad voor f(x, g) is gedocumenteerd (§11.13 spec) maar niet geïmplementeerd.

- **Compensatiedepot via uitvoeringspaden buiten bell-curve**: alle compensatie wordt via Gaussische bell-curve over alle cohorten verdeeld. Voor SSPF is dit irrelevant (compensatiedepot = 0); voor andere fondsen kan een meer doelgroep-getrouwe verdeling (alleen actieven, met opbouwjaren-weging) een verfijning zijn.

- **Hoog-laag-knip in het verleden**: het model weigert x_knip ≤ x₀ (verleden-knip) reeds in de UI; engine-zijde levert ä_temp = 0 als safeguard. Deelnemers met een reeds gepasseerde knip kunnen niet via de UI worden gemodelleerd; in dat geval geldt pen = pen_laag en is hooglaag dus uit.

---

*Einde Bijlage 2.*
