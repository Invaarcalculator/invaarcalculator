# ENGINE SPECIFICATIE v3.0.3 — WTP-pensioencalculator

Datum: 05-05-2026 19:55 (v3.0.3); 05-05-2026 19:35 (v3.0.2); 05-05-2026 18:55 (v3.0.1); 05-05-2026 (v3.0); 05-05-2026 11:44 (v2.2.13); 05-05-2026 00:01 (v2.2.12); 04-05-2026 23:37 (v2.2.11); 04-05-2026 21:04 (v2.2.10); 23-04-2026 21:54 (v2.2.9); 23-04-2026 21:49 (v2.2.8); 23-04-2026 19:53 (v2.2.7); 23-04-2026 19:46 (v2.2.6); 23-04-2026 19:42 (v2.2.5); 23-04-2026 19:30 (v2.2.4); 23-04-2026 19:24 (v2.2.3); 23-04-2026 19:20 (v2.2.2); 23-04-2026 19:09 (v2.2.1); 23-04-2026 19:03 (v2.2.0); 23-04-2026 17:05 (v2.1.9); 23-04-2026 16:55 (v2.1.8); 23-04-2026 16:34 (v2.1.7); 23-04-2026 16:14 (v2.1.6); 23-04-2026 15:47 (v2.1.5); 23-04-2026 15:22 (v2.1.4); 23-04-2026 14:44 (v2.1.3); 23-04-2026 14:28 (v2.1.2); 23-04-2026 14:12 (v2.1.1); 23-04-2026 13:40 (v2.1); 23-04-2026 13:35 (v2.0); 23-04-2026 13:21 (v1.9); 23-04-2026 12:21 (v1.8); 23-04-2026 11:58 (v1.7); 23-04-2026 11:32 (v1.6); 23-04-2026 10:24 (v1.5); 23-04-2026 10:05 (v1.4); 23-04-2026 09:59 (v1.3); 23-04-2026 09:53 (v1.2); 23-04-2026 09:24 (v1.1); oorspronkelijk 23-04-2026 00:15 (v1)
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Status: **normatief** — specificatie van de engine in vier modules; niet van de huidige code
Licentie: CC BY-NC 4.0

Dit document legt in gelijke diepgang de vier rekenmodules van de engine vast. Het operationaliseert `ARCHITECTUUR_v1.md` in concreet specificatieniveau: per module de te beantwoorden vraag, het input- en output-schema, de formules, de impliciete aannames, de fallbacks, de validaties, de scope-voorbehouden en de reviewpunten. Module 4 is overgenomen uit `calculator_specificatie.docx` met aangepaste nummering; modules 1-3 zijn getild van impliciete beschrijving in `DESIGN_engine_v0.md` naar spec-niveau.

**Patch v1.1 (23-04-2026 09:24).** Vier open vragen uit §11 beslist: §11.1 (φ expliciet of impliciet in module 2) → Optie 2 (afgeleid en getoond); §11.2 (regeling-selector) → Optie 1 bevestigd; §11.3 (rente-parameters) → Optie 2 bevestigd; §11.10 (sterftetafel-default) → Optie 1 bevestigd.

**Patch v1.2 (23-04-2026 09:53).** Besluit §11.4 (annuïteitsconventie) gewijzigd naar **uniform arrears, m=12** cross-module. Rationale: keten-coherentie scherm 1 → 2 → 3 → 4. Doorwerking: §2.3, §2.5, §2.6, §2.10, §3.5, §4.5, §7.3, §10.1, §10.4.

**Patch v1.3 (23-04-2026 09:59).** Besluit §11.5 (partneruitbreiding module 1) → **Optie 2: aparte KV-regel voor nabestaandenpensioen**. Wijziging t.o.v. voorlopige v1-keuze. Rationale: realistisch voor SSPF-publiek (NP is dominant deel van aanspraak); geen nieuwe wiskunde vereist (herbruikt M1-annuïteit met tweede aanroep op partner-leven); grondslag-congruent met M4 op partner-as. Doorwerking: §2.1 (vraag), §2.2 (input deelnemer), §2.4 (output), §2.5 (formules), §2.6 (aannames), §2.7 (fallbacks), §2.8 (validaties), §2.9 (scope), §2.10 (reviewpunten), §10.1 (cross-module communicatie). Impliciete sub-defaults in v1.3 die Hans nog expliciet moet bevestigen: partner-tafel = zelfde AG2022-leeftijdstafel-gemengd als deelnemer; correlatie tussen levens = 0 (onafhankelijke levens); NP-fallback bij onbekende hoogte = 70% van OP (wettelijke Nederlandse ratio).

**Patch v1.4 (23-04-2026 10:05).** Besluit §11.13 (ervaringssterftefactor `f`) → **Optie 2: vaste scalar, structuur actief in v1.4, waarde 1,0 als placeholder**. SCHEMA v2 krijgt veld `actuarieel.ervaringsSterfte` (scalar); FONDS_DATASET.SSPF heeft hem op 1,0 totdat een SSPF-specifieke bron beschikbaar is (Implementatieplan, jaarverslag, of AG2022-fondsklasse-factor). Rationale: structuur nu leggen is bronhoudbaar en future-proof; numerieke default reproduceert v1.3-gedrag. Doorwerking: §2.3 (M1 parameterset, status `f` → actief), §2.6 (aanname 3 herschreven), §6.3/§8 (gedeelde parameter). Geen numerieke impact op KV/potje/U₀ zolang `f = 1,0`.

**Patch v1.5 (23-04-2026 10:24).** Besluit §11.14 (kostenopslag `ρ`) → **Variant A + dataset-fallback, niet-nul ultieme default**. Wijziging t.o.v. voorlopige v1-keuze én **bewuste afwijking van spec-met-reserveringen-principe**: ρ=0 zou het R9.30-gedrag reproduceren maar is niet-conservatief ("rekent rijk"); publieke calculator moet het kostenverschil tussen verwachting en realisatie na-WTP zichtbaar maken. Formule: `ρ = c_jaar × ä(x, r)` met `c_jaar = uitvoeringskostenJaarlijks / fondsvermogen`. Fallback-ladder: (1) afgeleid uit dataset-velden, (2) direct `beleid.kostenOpslagPct`, (3) ultieme default **ρ = 0,02** (cumulatief op KV, dus KV ~2% hoger dan kale aanspraak). Doorwerking: §2.3 (M1 parameterset, ρ actief, default 0,02), §2.5 (afleidingsformule en fallback-logica), §2.6 (nieuwe aanname), §2.7 (fallback-volgorde), §2.8 (validatie), §2.10 (reviewpunt opgelost), §10.1 (cross-module getallenverschil verder verkleind). Numerieke impact: KV ~2% hoger dan v1.4 bij placeholder, groeit naar ~3–5% als SSPF-bron hogere waardes levert.

**Patch v1.6 (23-04-2026 11:32).** Twee samenhangende wijzigingen. **(a) Narratief kompas opgenomen in §1.1** als normatief sturend principe voor alle toekomstige keuzes. Drie momenten (nu, invaren, straks) × vier schermen, met scherm 4 als *regime-split van moment 1*. Sturend principe: "bij identieke aannames mag hetzelfde getal op meerdere schermen staan — dat is geen redundantie maar ankerfunctie". **(b) Besluit §11.15 (indexatie `π` op aanspraak tijdens waardering)** → Optie 2: structurele scalar, waarde 0 in M1 als bewust anker. Rationale: houdt scherm 1 als "kale papieren aanspraak", zodat scherm 4 een pedagogische payload (indexatie-effect onder DB vs WTP) kan tonen. Geen numerieke wijziging. Reproduceert R9.30-gedrag. Doorwerking: §1.1 (nieuw), §2.3 (π actief met waarde 0), §2.6 (nieuwe aanname), §7.3 (narratief-verankering), §11.15 (nieuw).

**Patch v1.7 (23-04-2026 11:58).** Besluit §11.16 (sterftetafel-migratie naar AG2024 met gender-activering). Educatieve leidraad: de tool moet verborgen dimensies zichtbaar maken voor de gebruiker, niet alleen een getal uitrekenen. Grootste wijziging sinds v1.3: de R9.30 Q-tafel wordt volledig gedeprecieerd en vervangen door de officiële AG2024-prognosetafel per geslacht, met periode-snapshot t₀=2026 als v1-gebruikswijze. Gender-velden `g` en `g_y` worden actief in v1.7: gebruikers kiezen M/V direct; "gemengd" is alleen fallback voor onbekend/anders, populatie-gewogen per leeftijd (~45% M / 55% V voor leeftijden 65+). Onderbouwing: analyse 23-04-2026 met geüploade AG2024-dataset toont dat R9.30 systematische afwijkingen heeft van −28% tot +70% per leeftijd; anomalie Q[62]→Q[63]=0,00748 is bevestigd als data-entry-fout (AG2024 is monotoon stijgend). Netto KV-impact bij overstap op "gemengd"-fallback: ~−3% voor 65-jarige; gender-verschil 9,7% op annuïteitsfactor — de belangrijkste educatieve onthulling van de tool. Drie impliciete sub-defaults uit v1.3 (§11.5) operationeel: partner-tafel = AG2024 per `g_y`; correlatie tussen levens = 0 (bevestigd); NP-fallback bij onbekende `y₀` = 70% OP (bevestigd). Doorwerking: §1.1 (educatieve doelstelling), §2.1 (M1 vraag), §2.2 (deelnemer-input, gender actief), §2.3 (parameterset, tabelId AG2024), §2.5 (formules), §2.6 (aannames 1-3 herschreven), §2.7 (fallbacks), §2.8 (validaties), §2.9 (scope), §2.10 (reviewpunten 1+2 opgelost), §3.5/§4.5 (M2/M3 krijgen gender door via KV/ä), §10.1 (cross-module verder geconvergeerd), §10.3 (opgelost), §11.10 (geoperationaliseerd), §11.16 (nieuw).

**Patch v1.8 (23-04-2026 12:21).** Sluitpatch scherm-1-doorloop. **(a)** Drie v1.3-sub-defaults formeel bevestigd door Hans op 23-04-2026 12:21: partner-sterftetafel = AG2024 per `g_y` (niet deelnemer-tafel); correlatie tussen levens = 0; NP-fallback = 70% van OP bij onbekend. Deze waren in v1.7 al geoperationaliseerd; patch v1.8 markeert ze formeel als gesloten. **(b)** Rekenrente-default vastgesteld op **r = 0,02 (2%)** voor M1, zowel als SSPF-dataset-default als generieke UI-slider-startwaarde. Doorwerking: §2.3 (`r` default expliciet), §11.3 (voorlopig eenduidig voor M1; cross-module consistentie later te toetsen). Geen numerieke wijziging t.o.v. v1.7 zolang bestaande dataset-default 2% was. Scherm 1 in engelere zin is hiermee compleet; cross-screen doorwerking naar M2/M3 wordt in volgende sessie geaudit.

**Patch v1.9 (23-04-2026 13:21).** Cross-screen punt 1 beslist: gender-doorwerking in M2 (DNB-spreidingsfactor en cohort-normalisatie). Hybride-aanpak conform §3.6.1 gebruikersconsistentie-principe: **individu krijgt gender-specifieke s(x₀, N, g)**, **cohort-normalisatie ν(N) gebruikt SSPF-gender-weging** (niet CBS-algemene). v1.7-fallback van CBS-populatie-weging wordt vervangen door SSPF-specifieke prior, gezien SSPF-gepensioneerden overwegend mannen zijn. v1-placeholder-waarden: `demografie.genderWegingSSPF.deelnemer = (95% M, 5% V)` en `demografie.genderWegingSSPF.partnerGegevenM = (5% M, 95% V)` en `demografie.genderWegingSSPF.partnerGegevenV = (50% M, 50% V)`. Upgrade-pad: SSPF-jaarverslag-data vervangt placeholders zonder spec-revisie. Doorwerking: §3.5 (M2 formules gender-expliciet), §3.6 (nieuwe aanname over cohort-gender), §3.7/§3.9 (fallbacks en scope), §11.16 (CBS-weging vervangen door SSPF), §11.17 nieuw. Numerieke impact individu: <0,5% op ppkTotal (tweede-orde via ν(N)).

**Major release v2.0 (23-04-2026 13:35).** Structurele modelwijziging: cross-screen punt 2 beslist op basis van SSPF-transitieplan en WTP-wetgeving onderzoek (23-04-2026). **Optie 4 "één potje met geoormerkte OP/NP-componenten"** — nabestaandenpensioen wordt mee-ingevaren in het persoonlijk pensioenvermogen conform het wettelijke standaard-invaarpad, maar met geoormerkte label voor NP-functiebehoud. Dit is een *major* versiebump (§12.6) omdat de output-structuur van M2 verandert: ppk_totaal wordt opgesplitst in ppk_OP en ppk_NP als aparte geoormerkte componenten. Onderbouwing: SSPF-transitieplan en werkenaanonspensioen.nl bevestigen dat "het standaardpad geldt voor alle bestaande pensioenregelingen, dus ook voor het nabestaandenpensioen". Andere fondsen (PostNL-transitieplan) documenteren expliciet: "opgebouwd partnerpensioen wordt gehandhaafd als persoonlijk pensioenvermogen en geoormerkt t.b.v. nabestaandenpensioen". Doorwerking: §1.1 (narratief uitgebreid met geoormerkte-kapitaal-concept), §3.4 (M2 output: ppk_OP, ppk_NP, ppk_totaal), §3.5 (decompositie per OP/NP), §3.6 (nieuwe aanname NP-integratie), §4.4/§4.5 (M3: één potje, interne NP-schakel bij overlijden — detailimplementatie in scherm-3-sessie), §5 (M4: overname docx; optionele OP/NP-breakdown in presentatie), §11.18 (nieuw besluit). Numerieke impact: ppk_totaal ongeveer gelijk aan v1.9, maar nu met OP/NP-splitsing zichtbaar. UPO-herkenning blijft op scherm 1 intact (KV_OP en KV_NP als twee aanspraken).

**Patch v2.1 (23-04-2026 13:40).** Cross-screen punt 4 beslist: rente-cross-module-implementatie. **Optie 3: één primaire rente-slider (discontering) met "geavanceerd"-toggle voor per-module ontkoppeling**. Verfijnt §11.3 (drie onafhankelijke parameters bevestigd v1.1) naar UI-gedrag: de drie velden `r` (M1), `proj` (M3), `i` (M4-fallback) blijven structureel aanwezig in SCHEMA v2 maar zijn in default-UI gekoppeld aan één slider. Ontkoppeling via toggle voor audit/debug/power-user. Default-waarde uit FONDS_DATASET (SSPF: 2%). `μ` (verwachtingswaarde rendement Monte Carlo, M3) blijft expliciet apart — dat is geen discontering maar rendementsparameter. Narratief-kompas-rationale: dezelfde vraag ("wat is de euro van morgen waard in geld van vandaag") krijgt één antwoord tenzij gebruiker expliciet anders kiest. Doorwerking: §2.3 (`r` toelichting), §4.3 (M3 `proj` toelichting), §5.4 (M4 `i` verwijzing), §11.3 (besluit verfijnd naar Optie 3-implementatie). Geen numerieke wijziging — alleen UI-structuur.

**Patch v2.1.1 (23-04-2026 14:12).** Scherm-2-punt 1 beslist: ppkSurplus-OP/NP-splitsingsformule. **Optie A1 — actuarieel bottom-up, één ν(N) met SSPF-deelnemer-weging**. `ppkSurplus` wordt *definitionally* de som `ppk_OP_surplus + ppk_NP_surplus`, waarbij elk deel de eigen levensspecifieke `sFactor` gebruikt (conform §11.18). De gewogen rapportagevorm `sFactor_gew = (KV_OP·sFactor(x₀,g) + KV_NP·sFactor(x_p,g_y)) / KV_totaal` is een afgeleide, geen primaire formule. De v2.0 "Notatie-noot"-ambiguïteit en de mysterieuze `ppkComp_dubbelgeteld_correctie`-term vervallen: ppkComp gaat volledig naar OP (§3.6 aanname 11; in v2.1.2 bronverankerd). Sluitingscontrole wordt exact: `ppk_OP + ppk_NP = ppkTotal` (`ppkComp` is volledig in `ppk_OP` opgenomen per §3.5-formule, dus geen aparte term; geen "kleine afwijking" meer). ν(N) blijft uniform voor OP- en NP-componenten met SSPF-deelnemer-weging (95/5); partner-ν als eventuele v2-uitbreiding bij beschikbaarheid SSPF-partner-demografie. Rationale in drie lagen: (a) bekrachtigt §11.18-besluit ("elk deel gebruikt de eigen sFactor, niet puur lineair") zonder major-bump; (b) spiegelt M4-docx bottom-up structuur (docx §5.5.5, per-leven stromen) en behoudt daarmee de ankerfunctie `ppkTotal ≈ V_x^Wtp_totaal` uit §1.1; (c) houdt gender-verschil op partner-leven zichtbaar in ppk_NP (educatieve leidraad, §1.1). Doorwerking: §3.5 (ppkSurplus expliciet bottom-up; Notatie-noot v2.1.1 vervangt v2.0-versie; sluitingscontrole exact), §3.6 (nieuwe aanname 12 over ν-uniformiteit), §11.18 (Follow-up bullet 1 gemarkeerd als opgelost). Geen numerieke wijziging t.o.v. v2.0-bedoeling — alleen definitie-aanscherping die de v2.0-ambiguïteit wegpoetst.

**Patch v2.1.2 (23-04-2026 14:28).** Scherm-2-punt 2 beslist: ppkComp dubbeling-check. **Optie A bevestigd — `ppkComp` volledig aan OP, wettelijk verankerd**. Bronnenonderzoek 23-04-2026 (DNB Q&A "onderbouwing compensatie per leeftijdscohort"; FRP 2024/622 Sdu; DNB "Compensatie en compensatiedepot" verwijzend naar art. 150f lid 1 Pw; ABP-transitieplan 2024) levert unanieme conclusie: compensatie onder de WTP ziet uitsluitend op gemiste toekomstige pensioenopbouw voor actieve deelnemers als gevolg van afschaffing doorsneesystematiek. Geen van de onderzochte bronnen noemt OP/NP-splitsing van compensatie binnen een persoonlijk pensioenvermogen. De v2.0-aanname 11 (§3.6) — die in v2.1.1 nog conditioneel was ("mocht punt 2 wijzigen…") — is hiermee structureel verankerd in plaats van conceptueel. Aanpalende vraag over bell-curve-toepasbaarheid voor gepensioneerden (SSPF-doelpubliek valt strikt genomen buiten DRS-compensatie-doelgroep) is bewust niet behandeld in scherm-2-sessie; genoteerd in §3.10 voor latere overweging. Doorwerking: §3.5 Notatie-noot laatste zin herformuleerd van conditioneel naar bevestigd; §3.6 aanname 11 aangescherpt met wettelijke bronvermelding; §3.10 reviewpunt "Compensatiedepot-verdeling" krijgt bron- en parkeer-notitie. Geen numerieke wijziging — uitsluitend bronverankering van een bestaande aanname.

**Patch v2.1.3 (23-04-2026 14:44).** Scherm-2-punt 3 beslist: `phiDerived`-granulariteit en §11.12 standalone-fallback. **(a) Optie A — alleen totaal-scalar, geen component-varianten in v1**. M2 levert uitsluitend `phiDerived = ppkTotal / V_x^Wtp_totaal`; geen `phiDerived_OP` en geen `phiDerived_NP` als eigenstandige output-velden. Rationale: (i) ankerzuiverheid — ppkTotal (M2-primair na patch v2.1.1) gespiegeld aan V_x^Wtp_totaal (M4-docx-primair); M4's OP/NP-breakdown is presentatie-laag, niet berekeningslaag (§5, "berekening blijft op totaal"), waardoor een component-anker M2-primair aan M4-secundair zou koppelen; (ii) §11.1-decoratief-niveau consistent houden — één decoratief veld past, drie zouden een tweede output-structuur worden; (iii) §12.5 spec-met-reserveringen — OP/NP-phiDerived is naadloos toe te voegen in v2 als M4's breakdown promoveert van presentatie naar berekening; (iv) de geoormerkte OP/NP-structuur heeft zijn eigen educatieve werk in de M2-output-velden `ppk_OP` en `ppk_NP` (§3.4), hoeft niet via phiDerived gedupliceerd te worden. **(b) §11.12 voorlopige keuze Optie 1 bevestigd**: bij standalone-M2-modus (M4-output niet beschikbaar) levert `phiDerived = null`. Optie 2 (KV-proxy) afgewezen — KV is op periode-snapshot M1-3-tafel, V_x^Wtp op cohort M4-tafel; een proxy zou precies de brug-ambiguïteit introduceren die Optie A juist vermijdt. Optie 3 (M4 altijd aanroepen) afgewezen — botst met modulaire architectuur §6.2. Doorwerking: §3.4 (`phiDerived`-rij toelichting aangescherpt, "geen component-varianten in v1"), §3.5 (Afgeleide-toedelingsfactor-blok toelichting uitgebreid), §11.12 (vierde optie toegevoegd voor component-varianten, voorlopige keuze geformaliseerd tot besluit met datum). Geen numerieke wijziging — alleen output-contract verscherpen.

**Patch v2.1.4 (23-04-2026 15:22).** Scherm-3-punt 1 beslist: NP-schakel mechaniek bij deelnemer-overlijden in M3-projectie (§11.18 follow-up bullet 2). **Optie A — impliciete annuïteit-splitsing (waarderingsbenadering)**. M3 berekent in v2.1.4 de startuitkering decompositief: `U₀_OP = ppk_OP / ä(x₀, proj, g)` en — indien `heeftPartner=true` — `U₀_NP = ppk_NP / ä(x_partner, proj, g_y)` als latent-NP-bovengrens conform §2.6.7. Het hoofd-uitkeringspad `U₀ = U₀_OP` reflecteert wat de deelnemer als levende ontvangt; `U₀_NP` is een deepdive-veld dat de latente NP-dekking zichtbaar maakt zonder de Monte Carlo te vertroebelen met expliciete overlijdens-events. Mortality pooling blijft impliciet via de actuariële annuïteiten, parallel aan §4.6.5 (huidige aanname behouden). Joint-life-verfijning blijft v2-reservering, conform §2.10. Rationale in drie lagen: (a) architecturale congruentie cross-module — M4 berekent ook op totaal met OP/NP alleen presentatie-laag (§11.18), Optie A houdt M2→M3 en M3↔M4 structureel-congruent; (b) M1-spiegel — `KV_NP = y₀ · ä(x_partner, r)` (§2.5) en `U₀_NP · ä(x_partner, proj, g_y) ≈ ppk_NP` (M3) zijn dezelfde aannames één module verder, narratief-anker §1.1 blijft intact; (c) educatieve leidraad zonder MC-vervuiling — gebruiker ziet op deepdive dat NP latent in kapitaal zit, p10/p50/p90-banden blijven conceptueel zuiver. Doorwerking: §4.4 (output uitbreiden met `U₀_OP` en `U₀_NP` als deepdive-velden), §4.5 (decompositie-blok toegevoegd vóór huidige `U₀ = potje / ä`-formule), §4.6 (nieuwe aanname 14 over impliciete latent-NP-pooling parallel aan aanname 5), §4.7 (fallback `heeftPartner=false` → `U₀_NP=0`, terugval naar v1.x-eenkanaalgedrag), §4.9 (joint-life als v2-reservering expliciet bevestigd), §11.18 (Follow-up bullet 2 gemarkeerd als opgelost). Geen numerieke wijziging op hoofdpad `U₀`/`U_t` t.o.v. v2.1.3-bedoeling — alleen output-decompositie en formele regulering van wat in §11.18 al impliciet was.

**Patch v2.1.5 (23-04-2026 15:47).** Scherm-3-punt 2 beslist: Cross-punt 3 — gender in `ä(x, proj)` voor U₀ (formele doorwerking v1.7-besluit naar M3). **Optie 1 — minimale formaliseringspatch**. Geen nieuwe inhoudelijke beslissing; v1.7 (§11.16) had M2/M3-doorwerking conceptueel toegezegd maar M3-spec-administratie was achtergebleven. Patch v2.1.4 had `ä(x₀, proj, g)` en `ä(x_partner, proj, g_y)` als bijproduct van de NP-schakel-decompositie reeds in §4.5 ingevoerd; deze patch sluit het audit-gat door §4.2 (deelnemer-input), §4.3 (fondsparameter-input), §4.6 (aannames) en §4.8 (validaties) spiegelgelijk te trekken aan §2-administratie van M1. Rationale: (a) audit-zuiverheid — een formule-argument (`g`) dat in input-tabellen niet opduikt en in aannames/validaties niet wordt geadresseerd is een coherentie-defect, precies het type fout dat de scherm-2-coherentie-check moest opvangen; (b) spiegelgelijkheid M1↔M3 — §2 heeft sinds v1.7 een complete gender-administratie (input, parameterset, formule, aanname, fallback, validatie), §4 verdient dezelfde behandeling om de §1.1 ankerfunctie ("dezelfde aannames → hetzelfde getal") in audit-context aantoonbaar te maken; (c) UI-rationale-uitbreiding (Optie 2 uit besluit-discussie) bewust uitgesteld naar UI-design-ronde uit §11.18 follow-up bullet 3 die thematisch over schermen 2/3/4 loopt en een eigen sessie verdient. Doorwerking: §4.2 (uitgebreid met `g`, `heeftPartner`, `x_partner`, `g_y`, `y₀` allen uit M1), §4.3 (nieuwe rijen `sterftekansTabelId`, `q_{x,t,g}`, `t₀` parallel aan §2.3), §4.6 (nieuwe aanname 15 over gender-tafel-doorwerking en AG2024 periode-snapshot in M3, analoog aan §2.6.1-2), §4.8 (nieuwe validatie-regels voor `g`/`g_y` ∈ {M, V, gemengd}, AG2024-tafel-bereik, `2022 ≤ t₀ ≤ 2200`), §11.16 (M3-doorwerkings-zin geactualiseerd met v2.1.4-decompositie en v2.1.5-administratie). Geen numerieke wijziging — uitsluitend formele inhaalslag op v1.7-doorwerking.

**Patch v2.1.6 (23-04-2026 16:14).** Scherm-3-punt 3 beslist: §11.6 BufferTrigger-conventie + drie aanpalende M3-buffer-vraagstukken. **Vier-delige uitkomst, gegrond in SSPF-design-input van Hans (RDR-buffer en 5-jaars rolling demping).** **(A) BufferTrigger-default: Optie 1 — `effR < inf` (R9.30-conform, koopkracht-anker)** geformaliseerd in §4.3 als `bufferTrigger = 'koopkracht'`. Enum uitgebreid van twee naar vier waardes: `'koopkracht'` (default), `'rendement'` (effR < 0), `'projectie'` (effR < proj), `'koopkracht-projectie'` (effR < proj + inf). Educatief-narratief-rationale: SSPF-gepensioneerden willen hun WTP-uitkering vergelijken met huidige indexatie-praktijk; de koopkracht-trigger spiegelt precies dat anker ("kreeg ik vroeger indexatie ja/nee" ↔ "wordt mijn buffer aangesproken om koopkracht te behouden ja/nee"). Optie 3 (zuiver wiskundig op FPR-update-formule) zou indexatie-vergelijking missen; Optie 4 zou indexatie dubbel ankeren. **(B) Demping-default: `dempJaren = 5`** (was placeholder "dataset"); SSPF-design specificeert 5-jaars rolling-gemiddelde van jaarlijkse rendementen, jaar-2-vaststelling-na-invaren elk jaar opnieuw — exact wat het bestaande `effR_t = mean(window_t)`-mechanisme implementeert (§4.5). Placeholder vervangen door bron. **(C) Terminologie-koppeling RDR-buffer.** `buffer-aandeel` (M2-output, M3-input) is in SSPF-design de eenmalige RDR-buffer (Reserve voor Dempings-Reserve) bij invaren; toelichting toegevoegd aan §4.3 en §4.5 voor cross-referentie naar SSPF-stukken. **(D) Nieuw reviewpunt: RDR-uitputtingsmechaniek.** R9.30-implementatie (volledig tekort tot bufferbodem, `trekking = min(tekort, buffer_t)`) is v1-default; SSPF-design hanteert mogelijk ander uitputtingsregime (plafond per jaar, gefaseerde aanwending, prioritering tussen cohorten) maar mechanisme onbekend bij Hans. Geparkeerd in §4.10 met expliciete bron-onderzoeks-notitie, parallel aan §3.10 compensatie-bell-curve-parkering uit v2.1.2. Doorwerking: §4.3 (`dempJaren` default 5; `bufferTrigger` status `actief`, enum vier waardes, default `'koopkracht'`; RDR-terminologie-noot bij `buffer-aandeel`), §4.5 (buffer-mechaniek-blok herschreven met trigger-formule per enum-waarde + RDR-terminologie-noot), §4.6 (nieuwe aanname 16 over default-trigger en bron-afhankelijkheid), §4.10 (Buffer-trigger-formule als opgelost gemarkeerd; nieuw RDR-uitputtingsmechaniek-reviewpunt met parkeer-status), §11.6 (besluit-paragraaf met datum, vier opties geformaliseerd, default vastgelegd). Numerieke impact: geen op hoofdpad (R9.30-trigger blijft default; demping `dempJaren=5` was reeds R9.30-conform); structurele opening voor latere bron-gebaseerde aanpassing zonder spec-revisie.

**Patch v2.1.7 (23-04-2026 16:34).** Scherm-3-punt 4 beslist: §11.7 Correlatie rendement-inflatie. **Optie 3 — parametrische structuur met expliciete koppeling, default 0**. Geen numerieke wijziging op default-pad; structurele aanscherping van afhankelijkheids-administratie. Achtergrond: het `correlatieRenteInflatie`-veld stond sinds v1 in §4.3 als gereserveerd zonder te documenteren dat het zonder stochastische `inf` betekenisloos is — `inf` is in v1 deterministisch (één scalar per simulatie) en correlatie kan pas operationeel worden als `inf` zelf stochastisch wordt. Patch v2.1.7 maakt deze afhankelijkheid expliciet door (a) het bestaande `correlatieRenteInflatie`-veld in §4.3 te koppelen aan een nieuw gereserveerd object `inflatieStochastiek` met sub-velden `μ_inf` en `σ_inf`, beide null in v1; (b) in §4.5 een korte noot na het rendementsgeneratie-blok dat `inf` in v1 deterministisch is en stochastiek+correlatie een gekoppeld v2-pad vormen; (c) een nieuwe aanname 17 in §4.6 over deterministische `inf` en gekoppelde activering; (d) §4.10 reviewpunt aanpassen — geen open vraag meer maar gekoppelde v2-uitbreiding, parallel aan SPR-reservering-structuur. Rationale (drie lagen): (a) **spec-met-reserveringen (§12.5) strikter gerespecteerd dan Optie 4** — verwijderen van het reservering-veld zou een gemiste structuurkans zijn die later met SCHEMA-revisie hersteld moet worden; (b) **eerlijke afhankelijkheids-administratie** — Optie 3 maakt expliciet dat *twee* dingen samen geactiveerd moeten worden, identieke "gekoppeld v2-pad"-structuur als bij `RTS`/`agHerzienPeriode`/`renteAfdekkingFactor` voor SPR-varianten in §4.9; (c) **geen numerieke wijziging, geen SSPF-bron-afhankelijkheid** — Optie 2 (vaste consensus-waarde ρ=0,3) zou speculatief zijn zonder SSPF-specifieke kalibratie, Optie 3 vermijdt dat. Bron-onderzoek (DNB-FTK-publicaties over scenario-correlatie, AG-stochastische-set-parameters) is een eigenstandige ronde voor latere parking, parallel aan RDR-uitputtingsmechaniek-parking uit v2.1.6. Doorwerking: §4.3 (`correlatieRenteInflatie`-rij toelichting uitgebreid met koppelings-noot; nieuw veld `inflatieStochastiek` als gereserveerd object), §4.5 (deterministische-inf-noot na rendementsgeneratie-blok), §4.6 (aanname 17), §4.10 ("Correlatie rente-inflatie"-reviewpunt herschreven van open vraag naar gekoppelde v2-uitbreiding), §11.7 (besluit-paragraaf met datum, vier opties, Optie 3 als keuze met drie-laags rationale). Geen numerieke wijziging — uitsluitend structurele aanscherping en administratieve helderheid.

**Patch v2.1.8 (23-04-2026 16:55).** Scherm-3-punt 5 beslist: §11.8 Lifecycle-rente + drie aanpalende verfijningen op M3-portfolio-administratie. **Optie 4 — vlakke rente als default met expliciete bundel-koppeling**, parallel aan v2.1.7-pattern voor inflatie-correlatie. Geen numerieke wijziging op M3-mechaniek; één concretisering van placeholder-defaults op basis van SSPF-portfolio-input. Achtergrond: SSPF hanteert collectieve toedeling met één vast portfolio (60% matching / 40% rendement-seeking, zonder leeftijdsafhankelijke afbouw of individuele profielkeuze door gepensioneerden); `proj`, `μ`, `σ` zijn daarmee structureel scalars en blijven dat. **(A) Lifecycle-bundel-koppeling.** De drie velden `proj` (scalar), `lifecycle-profiel` (μ/σ per leeftijd), en nieuw toegevoegde `rtsCurve` (proj per leeftijd) vormen een gekoppelde structuur; activering vereist hen alle drie tegelijk om semantische coherentie te waarborgen. Een latere implementator die alleen `rtsCurve` activeert zonder `lifecycle-profiel` zou een spec-incoherent fonds modelleren (rendementsverwachting onafhankelijk van leeftijd, maar discontering wel). Identieke "gekoppeld v2-pad"-structuur als bij `correlatieRenteInflatie`+`inflatieStochastiek` (v2.1.7) en bij `RTS`+`agHerzienPeriode`+`renteAfdekkingFactor` (SPR-varianten in §4.9). **(B) μ/σ-defaults concreet (Keuze A1).** SSPF-portfolio-input van Hans (60/40 matching/rendement-seeking) geconcretiseerd als indicatieve waardes: `μ = 0,045` (4,5%) en `σ = 0,08` (8%) als default in §4.3. Placeholder "dataset" vervangen, parallel aan `dempJaren=5` in v2.1.6. Indicatief karakter expliciet: SSPF-bestuursnotitie of officiële Wtp-richtlijn kan deze later vervangen zonder spec-revisie; status van indicatief naar bron-vastgesteld upgradeable. **(C) RTS-distinctie expliciet (Keuze "Ja").** §4.3 had één veld `RTS` (vector, voor SPR-hybride rentetermijnstructuur), terwijl §11.8 sprak van `rtsCurve` (FPR-lifecycle). Twee verschillende concepten met overlap in naamgeving, wat audit-verwarring veroorzaakte. v2.1.8 maakt onderscheid: `RTS` blijft SPR-rente-curve (zero-coupon rentes per looptijd, voor SPR-hybride rente-afdekking — §5.5 in M4 gebruikt deze ook), nieuw `rtsCurve` is FPR-lifecycle (proj per leeftijd, gekoppeld aan `lifecycle-profiel`). Beide gereserveerd in v1; conceptueel orthogonaal. Doorwerking: §4.3 (`proj`-rij toelichting bundel-koppeling; `μ`-default 0,045 met SSPF-60/40-noot; `σ`-default 0,08 met SSPF-60/40-noot; `RTS`-rij toelichting verfijnd naar SPR-context; `lifecycle-profiel`-rij toelichting koppelings-noot; nieuw `rtsCurve`-veld voor FPR-lifecycle), §4.5 (vlakke-rente-noot na rendementsgeneratie en update-formule), §4.6 (nieuwe aanname 18 over vlakke rente, gekoppelde activering, RTS-distinctie, en SSPF-collectieve-toedeling), §4.10 ("Lifecycle-profiel"-reviewpunt herschreven naar gekoppelde v2-uitbreiding), §11.8 (besluit-paragraaf met datum, vier opties, drie verfijningen). Numerieke impact: `μ` en `σ` defaults van placeholder naar concrete indicatieve waardes — geen impact als FONDS_DATASET deze al overschreef; bij datasets die placeholders gebruikten verschuift dit U-bandbreedte conform 60/40-mix.

**Patch v2.1.9 (23-04-2026 17:05).** Scherm-3-punt 6 beslist: §11.9 Plot-horizon (laatste open punt scherm 3). **Optie 4 — engine-berekening tot ω, UI-cap als presentatie-laag met configureerbare default**. Geen numerieke wijziging op berekening; structurele scheiding berekening/presentatie. Achtergrond: huidige formule `endAge = min(ω, ⌈lifeExp(x₀)⌉)` (§4.5) capt de berekening hard op verwachte sterfleeftijd, wat (a) per definitie de helft van het cohort tail-mist (lifeExp = mediaan), (b) §4.6 aanname 11 ("FPR-paden = uitkering *als* deelnemer nog leeft") visueel verbergt, en (c) zonder reden informatie weggooit die al berekend is. Optie 4 lost deze drie problemen op door berekening en presentatie te scheiden: engine berekent altijd tot `ω`, UI past `plotHorizonRule`-enum toe als presentatie-cap met v1-default `'lifeExpPlus10'` (R9.30-conform). Vier enum-waardes: `'lifeExpPlus10'` (default, dynamisch op individu), `'omega'` (geen cap, levenslang), `'coverage1pct'` (tot leeftijd met overlevingskans > 1%, statistisch eerlijke compromis), `'lifeExpExact'` (huidige R9.30-cap, voor backward-compat-vergelijking). Drie-laags rationale: (a) **pattern-consistentie met v2.1.6/v2.1.7/v2.1.8** — één default voor R9.30-conformiteit, alternatieven als enum-veld voor latere bron-keuze, en hier nog stricter passend omdat de keuze écht UI-presentatie is, niet engine-mechaniek; (b) **behoud van informatie in de berekening** — extra paden beschikbaar voor power-users (debug-mode, alternatieve UI-keuzes, onderzoeks-uitvoer) zonder gebruiker-default te veranderen; (c) **§4.6 aanname 11 wordt scherper toonbaar** — bij levenslang-tot-ω plot zien power-users dat p10/p50/p90-banden tot allerlaatste tijdstap doorlopen, wat impliciete-mortality-pooling-aanname (aanname 5) visualiseert. Doorwerking: §4.3 (nieuw veld `plotHorizonRule` als enum, status `actief`, default `'lifeExpPlus10'`), §4.4 (`years` blijft engine-output = `ω − x₀`; nieuwe optionele output `years_display` en `endAge_display` voor UI-cap), §4.5 (horizon-blok herschreven met scheiding berekening/presentatie), §4.6 (aanname 12 herschreven naar berekening/presentatie-onderscheid; nieuwe aanname 19 over UI-cap-default), §4.10 (Plot-horizon-reviewpunt opgelost gemarkeerd), §11.9 (besluit-paragraaf met datum, vier opties, drie-laags rationale). Numerieke impact: geen op berekening; UI-default `'lifeExpPlus10'` toont +10 jaar meer dan v2.1.8-default, wat de tail van langlevenden zichtbaar maakt zonder de plot oncomfortabel breed te maken. Met deze patch is scherm 3 volledig afgerond (zes besluiten, zes patches v2.1.4 t/m v2.1.9).

**Patch v2.2.0 (23-04-2026 19:03).** Openingspatch scherm-4-sessie. Cross-punt 5 beslist: cohort-correct M4 vs periode-snapshot M1-3. **Optie 1 — UI-disclosure, methodische asymmetrie behouden**. Geen numerieke wijziging; geen SCHEMA-impact. Achtergrond: v1.7 (§11.16) heeft M1-3 op AG2024-periode-snapshot t₀=2026 vastgelegd en M4 op AG2024-cohort (diagonaal q_{x+t, t₀+t, g}, §5.5.1 docx-spec); AG2024 veronderstelt toekomstgerichte sterfte-verbetering, dus cohort geeft systematisch iets hogere overlevingskansen. Effect op annuïteitsfactor: <1% voor een 67-jarige in 2026 (groter bij jongere x₀, kleiner bij oudere). Consequentie: KV (M1) en V_x^DB (M4-linkerkant, onder verder identieke grondslagen) zijn structureel congruent (§1.1) maar niet numeriek gelijk — terwijl ze dezelfde vraag beantwoorden ("aanspraak nu onder DB"). Drie-laags rationale voor Optie 1: (a) **narratief-kompas-consistentie** — §1.1 stelt expliciet dat informatieve verschillen *een boodschap dragen*; period vs cohort ís precies zo'n boodschap (scherm 1 = "zo staat uw aanspraak er vandaag bij" = momentopname; scherm 4 = "zo wordt uw aanspraak gewaardeerd met toekomstprognose" = volledig actuarieel). Pedagogisch waardevol. (b) **Proportionaliteit** — <1% numeriek effect rechtvaardigt geen SCHEMA-herstructurering van M1-3 naar 2D-generatietafel (Optie 2 was technisch zuiverder maar disproportioneel). (c) **Patch-karakter klopt** — klassieke snel-formalisering analoog aan v2.1.5: geen nieuwe velden, geen nieuwe formules, alleen UI-disclosure-eis + kruisverwijzingen. Doorwerking: nieuw §5.12.7 (periode-snapshot M1-3 vs cohort M4 als bewuste methodische asymmetrie; UI-disclosure-eis; <1%-ordegrootte; §1.1-verankering), §10.1 (bestaande cross-module-communicatie-paragraaf uitgebreid met tafel-gebruikswijze-asymmetrie als concreet voorbeeld van informatief verschil), §11.16 (afsluitende kruisverwijzing naar §5.12.7 en v2.2.0 toegevoegd, geen herformulering van het besluit zelf). Numerieke impact: geen. SCHEMA-impact: geen (geen nieuwe velden). UI-impact: scherm-4-ontwerp moet een disclosure-noot bevatten bij getoonde V_x^DB. Met deze patch is 1 van de 8 open scherm-4-punten gesloten; resterend zijn §5.12.1–§5.12.6 (zes inhoudelijke sub-paragrafen), §5.13-bevestiging, en §11.12-Optie-4-heroverweging (OP/NP-promotie M4).

**Patch v2.2.1 (23-04-2026 19:09).** Scherm-4-punt 2 beslist: §5.12.1 V_x^Wtp als waarde-equivalent. **Optie 1 — formalisering als besloten aanname met harde UI-disclosure-eis**. Geen numerieke wijziging; geen SCHEMA-impact; geen formule-wijziging. Achtergrond: §5.12.1 benoemt sinds de docx-overname dat de V_x^Wtp-formule uit §5.5.5 een DB-achtige structuur (vast bedrag × annuïteit met indexatie-opslag) hanteert terwijl de Wtp-uitkering wezenlijk anders is (rendements-/beleggingsgekoppeld, π^Wtp als verwachte jaarlijkse ontwikkeling in plaats van contractuele toeslag). Dit was geformuleerd als reviewpunt met aanbeveling ("in de UI dient dit onderscheid expliciet zichtbaar te zijn"), maar niet als besloten aanname met harde eis. Drie-laags rationale: (a) **symmetrie met v1.5/§11.15** — bij M1 is dezelfde keuze al gemaakt (π=0 als bewust anker met UI-uitleg); §5.12.1 is de M4-pendant waarvoor dezelfde disciplinaire helderheid vereist is, beide zijn aannames over het karakter van de projectie-component; (b) **narratief kompas §1.1** — V_x^Wtp vs V_x^DB onder hetzelfde π-scenario is precies het type informatief verschil dat het kompas vraagt, mits de gebruiker begrijpt dat π^Wtp een andere soort parameter is dan π^DB (verwachting vs voorwaardelijke toeslag); de UI-disclosure maakt dit leesbaar; (c) **proportionaliteit** — snel-formalisering, geen SCHEMA-impact, geen formule-wijziging, analoog aan v2.2.0 in schaal. Vier kern-elementen in besluit-notitie §5.12.1: (i) waarde-equivalent-status geformaliseerd als v1-aanname; (ii) UI-disclosure verplicht (niet-adviserend); (iii) terminologie-anker vastgelegd ("waarde-equivalent onder projectie-aanname" voor V_x^Wtp; "verwachte-waardeverschil" voor Δ); (iv) kruisverwijzing §11.15 als M1-spiegel. Doorwerking: §5.12.1 (besluit-notitie toegevoegd onderaan), §5.1.1 (bestaande bullet "Waarde-equivalent onder veronderstellingen" uitgebreid met inline-verwijzing naar §5.12.1 als volledige uitwerking, zodat vooraan en achteraan in het document dezelfde conceptuele status hebben), §11.15 (afsluitende zin toegevoegd die cross-module pendant §5.12.1 noemt, geen herformulering). Met deze patch is 2 van de 8 open scherm-4-punten gesloten; resterend §5.12.2–§5.12.6, §5.13-bevestiging, §11.12-Optie-4-heroverweging.

**Patch v2.2.2 (23-04-2026 19:20).** Scherm-4-punt 3 beslist: §5.12.2 afleiding π^Wtp buiten de rekenmodule. **Optie 1 — formalisering als scope-grens met drie engine-niet-verantwoordelijkheden**. Geen numerieke wijziging; geen SCHEMA-impact; geen formule-wijziging. Achtergrond: §5.12.2 legt sinds de docx-overname vast dat de rekenmodule π^Wtp als invoer behandelt, niet als afleiding; de reële compositie (beschermingsrendement, overrendement, operationele kosten, reserve-onttrekkingen) is complex en leeftijdsafhankelijk. De paragraaf bevatte al een normatieve aanbeveling ("afbakening dient in documentatie parameterset te worden vastgelegd") zonder formele besluit-status. Samen met §5.12.1 (v2.2.1) vormt deze paragraaf de tweede helft van één parameterset-discipline: §5.12.1 legt vast *wat* V_x^Wtp is (waarde-equivalent onder projectie-aanname), §5.12.2 legt vast *wie* de projectie-aanname bepaalt (samensteller parameterset, niet de engine). Drie-laags rationale: (a) **gekoppelde parameterset-discipline met §5.12.1** — "gekoppelde v2-pad"-patroon uit scherm 3 (v2.1.7/v2.1.8) toegepast op scope-verantwoordelijkheid in plaats van op gereserveerde velden; (b) **fondsagnostische architectuur §5.2 component 3 wordt operationeel** — §5.2 zegt al "de module maakt zelf geen keuzes over aannames", v2.2.2 maakt dat expliciet via drie concrete engine-niet-verantwoordelijkheden (geen automatische afleiding, geen bronvaliditeits-check, geen realisme-alarmbel); (c) **scope-creep-preventie bij implementatie** — zonder formalisering kan een toekomstige implementator redelijkerwijs denken dat de engine π^Wtp moet valideren op bereik of leeftijdsafhankelijkheid; de besluit-notitie sluit dat uit. Vier kern-elementen: (i) scope-grens geformaliseerd als v1-besluit; (ii) drie niet-verantwoordelijkheden expliciet (geen afleiding uit beleggingsbeleid, geen validatie van bronkwaliteit, geen alarmbel bij onrealistische waardes); (iii) documentatie-eis aan parameterset ("π^Wtp-afleidingsmethode moet bij parameterset zijn vastgelegd"); (iv) kruisverwijzing §5.12.1 als gekoppelde discipline en §5.10 (toepassingsmodi) omdat bronkwaliteit daar al onderscheid maakt tussen volledige/benaderings-/demonstratiemodus. Doorwerking: §5.12.2 (besluit-notitie toegevoegd onderaan), §5.2 (component 2 Fondsparameterset-alinea uitgebreid met zin over §5.12.2 als verantwoordelijkheidsgrens), §5.10.1 (Volledige modus-alinea uitgebreid met kruisverwijzing §5.12.2 voor bronverantwoordelijkheid). Met deze patch is 3 van de 8 open scherm-4-punten gesloten; resterend §5.12.3–§5.12.6, §5.13-bevestiging, §11.12-Optie-4-heroverweging.

**Patch v2.2.3 (23-04-2026 19:24).** Scherm-4-punt 4 beslist: §5.12.3 onafhankelijkheid x⊥y (broken-heart-effect). **Optie 1 — onafhankelijkheid als v1-aanname formaliseren; joint-life als gekoppelde v2-reservering parallel §2.10/§4.9**. Geen numerieke wijziging; geen SCHEMA-impact; geen formule-wijziging. Achtergrond: §5.5.4 berekent joint-life overlevingskans `_{k/m}p_{x₀ y₀} = _{k/m}p_{x₀} · _{k/m}p_{y₀}` onder onafhankelijkheid; §5.12.3 noemt sinds de docx-overname het broken-heart-effect (weduwen/weduwnaars hebben hogere sterftekansen dan algemene populatie), wat V_x^PP licht overschat — typisch enkele procenten op V_x totaal. Dit punt heeft een directe spiegel in M1 (§11.5 v1.3 + v1.8 formeel bevestigd; §2.10 joint-life als v2-reservering) en M3 (§4.9 joint-life als v2-reservering, v2.1.4), maar was in M4 niet als besluit gemarkeerd. Drie-laags rationale: (a) **cross-module spiegelgelijkheid** — M1 (§2.10), M3 (§4.9) en nu M4 (§5.12.3) hebben alle drie dezelfde v1-aanname (onafhankelijkheid) met dezelfde v2-reservering (joint-life met broken-heart-factor); de ankerfunctie §1.1 vereist deze congruentie; (b) **"gekoppeld v2-pad"-patroon toepasbaar** — een joint-life-uitbreiding raakt M1/M3/M4 tegelijk en moet samen worden geactiveerd om spec-incoherentie te voorkomen (bijv. M4 joint-life maar M1 onafhankelijk zou broken-heart-effect alleen op V_x^PP toepassen terwijl KV_NP het negeert); hetzelfde bundelings-principe als v2.1.7/v2.1.8; (c) **proportionaliteit** — overschatting enkele procenten, geen SSPF-specifieke broken-heart-data beschikbaar; Optie 2 (placeholder-scalar default 1,0) zou structurele ballast zijn zonder bronhoudbaarheidsperspectief. Vier kern-elementen in besluit-notitie §5.12.3: (i) onafhankelijkheid `_{k/m}p_{x₀ y₀} = _{k/m}p_{x₀} · _{k/m}p_{y₀}` als v1-aanname; (ii) joint-life met broken-heart-factor als gekoppelde v2-reservering parallel §2.10/§4.9; (iii) overschattings-orde enkele procenten op V_x totaal; (iv) cross-module discipline M1/M3/M4 expliciet. Doorwerking: §5.12.3 (besluit-notitie toegevoegd onderaan), §2.10 (bestaande "NP als bovengrens" bullet uitgebreid met M4-spiegel-kruisverwijzing naar §5.12.3), §4.9 (bestaande "NP als bovengrens, niet joint-life" bullet uitgebreid met M4-spiegel-kruisverwijzing naar §5.12.3). Met deze patch is 4 van de 8 open scherm-4-punten gesloten; resterend §5.12.4–§5.12.6, §5.13-bevestiging, §11.12-Optie-4-heroverweging.

**Patch v2.2.4 (23-04-2026 19:30).** Scherm-4-punt 5 beslist: §5.12.4 geen SPR/FPR-differentiatie in kern-module, via §5.13-parametersets. **Optie 1 — formalisering als v1-aanpak-bevestiging met cross-module spiegel §11.2**. Geen numerieke wijziging; geen SCHEMA-impact; geen formule-wijziging. Achtergrond: §5.12.4 stelt sinds de docx-overname dat de rekenmodule één π^Wtp en één φ(x) kent en dat SPR/FPR-differentiatie via aparte parametersets wordt geaccommodeerd (§5.13 als uitwerking met vier sub-paragrafen: §5.13.1 wat differentieert, §5.13.2 parameter-uitbreidingen, §5.13.3 wat niet kan in v1, §5.13.4 aanbevolen invulling). §11.2 (v1.1 bevestigd) heeft al de top-level regeling-selector-architectuur vastgelegd (top-level SPR/FPR + M3-sub-selector); §5.12.4 + §5.13 zijn de M4-specifieke uitwerking van diezelfde architectuur. Maar §5.12.4 zelf was nog niet als besluit gemarkeerd, en §5.13 miste een formele "v1-aanpak bevestigd"-stempel. Drie-laags rationale: (a) **sluit §5.12-serie netjes af** — §5.12.1 (karakter V_x^Wtp), §5.12.2 (parameterset-verantwoordelijkheid), §5.12.3 (onafhankelijkheid levens), §5.12.4 (regime-accommodatie); alle vier zijn dimensies van "wat doet de engine wel/niet", alle vier verdienen besluit-status voor audit-volledigheid; (b) **cross-module spiegel §11.2 → §5.12.4 → §5.13 maakt regeling-architectuur expliciet** — §11.2 zegt *hoe* de gebruiker regeling kiest, §5.12.4 zegt *hoe de engine dat verwerkt* (via parameterset, niet intern), §5.13 zegt *welke parameters* verschillen (π^Wtp, φ, reservering); keten was inhoudelijk af, alleen formele verankering ontbrak; (c) **proportionaliteit** — snel-formalisering consistent met v2.2.0 t/m v2.2.3, markeert §5.13 als "v1-aanpak bevestigd" wat implementatie-scope verheldert. Vier kern-elementen in besluit-notitie §5.12.4: (i) accommodatie via parametersets als v1-aanpak bevestigd; (ii) §5.13 formeel als v1-uitwerking gestempeld (vier sub-paragrafen structureel geaccepteerd); (iii) spiegel §11.2 regeling-selector en §5.12.2 parameterset-verantwoordelijkheid expliciet; (iv) drie "wat niet kan in v1"-punten uit §5.13.3 als bevestigde scope-grens herhaald (waardering risicodeling, pad-afhankelijkheid buffers, keuze-effecten FPR). Doorwerking: §5.12.4 (besluit-notitie toegevoegd onderaan), §5.13 (inleidende zin toegevoegd die v2.2.4 deze paragraaf formeel als v1-aanpak bevestigt), §11.2 (afsluitende zin toegevoegd die M4-pendant §5.12.4 + §5.13 noemt, geen herformulering). Met deze patch is 5 van de 8 open scherm-4-punten gesloten; resterend §5.12.5 (toedeelbaar vs totaal vermogen, mogelijke M2-doorwerking), §5.12.6 (π^DB als vereenvoudiging toeslagmechaniek), §11.12-Optie-4-heroverweging (OP/NP-promotie M4).

**Patch v2.2.5 (23-04-2026 19:42).** Scherm-4-punt 6 beslist: §5.12.5 toedeelbaar vermogen vs totaal (φ_effectief vs φ-as-supplied). **Optie 1 — v1-aanname φ=φ_effectief aangeleverd bevestigen met UI-disclosure-eis en parameterset-documentatie-eis; geen SCHEMA-wijziging, geen M2-doorwerking**. Geen numerieke wijziging; geen SCHEMA-impact; geen formule-wijziging. Achtergrond: §5.12.5 benoemt sinds de docx-overname de conceptuele spanning dat M4's `K_x = φ(x) · V_x^Wtp` impliciet φ toepast op volledig fondsvermogen A, terwijl bij transitie een deel wordt afgezonderd voor bestemmingsreserves (solidariteitsreserve 3–15% onder SPR, compensatiedepots, operationele buffers). Correcte toedeling vereist `φ_effectief = (A − A_gereserveerd) / TV`. Expliciete observatie bij review: M2 §3.5 doet deze correctie al *expliciet* via `verdeelbaar = fondsvermogen − compensatiedepot − buffer − overigeReserves − operRes + bijstort` en `baseRatio = verdeelbaar / vpvTotal` (effectief M2's impliciete φ). Dit levert een architecturale asymmetrie: M2 rekent expliciet op netto-vermogen met eigen reserveringsvelden; M4 verwacht dat de samensteller dat al heeft gedaan voordat φ wordt aangeleverd. Bij bron-inconsistentie tussen M2-reserveringen-input en M4-φ-input kan de ankerfunctie `ppkTotal ≈ V_x^Wtp_totaal` (§1.1, v2.1.1) numeriek ontsporen. Drie-laags rationale voor Optie 1: (a) **consistentie met §5.12.2 (parameterset-verantwoordelijkheid)** — dezelfde scope-grens-discipline als voor π^Wtp-afleiding, nu voor φ-effectiviteit; de engine valideert geen parameterset-brondiscipline, wel verplicht documentatie-eis; (b) **proportionaliteit** — Optie 2 (φ-metadata-veld met gekoppeld v2-pad) en Optie 3 (M4-formule herschrijven op expliciete netto-basis, spiegelgelijk aan M2) zijn structureel zuiverder maar introduceren SCHEMA-/formule-wijziging; Hans koos voor pragmatiek bij dit punt consistent met scherm-4-snel-formaliseringspatroon; (c) **M1/M2-build-stabiliteit** — Optie 1 blokkeert of vertraagt scherm-1-build niet; cross-module audit-risico wordt procedureel ondervangen via documentatie-eis in plaats van via engine-code. Vier kern-elementen in besluit-notitie §5.12.5: (i) v1-aanname φ=φ_effectief aangeleverd; (ii) engine-niet-verantwoordelijkheid parallel §5.12.2 (geen bronvaliditeits-check op φ-effectiviteit); (iii) parameterset-documentatie-eis expliciet ("samensteller moet vastleggen of φ voor reserveringen gecorrigeerd is en zo ja welke"); (iv) UI-disclosure-eis bij V_x^Wtp + ankerfunctie-risico-notitie cross-module M2↔M4. **Eerlijke boekhouding opgenomen in besluit-notitie:** het audit-risico dat M2 expliciet en M4 impliciet dezelfde reserveringen moeten aftrekken voor ankerfunctie-integriteit wordt *niet weggepoetst* maar als v1-limitatie erkend; Optie 2 blijft v2-heropenpunt indien parameterset-bron-discipline onvoldoende blijkt in praktijk. Doorwerking: §5.12.5 (besluit-notitie toegevoegd onderaan met vier kern-elementen en expliciete v2-heropenpunt-markering), §5.12.2 (kruisverwijzing uitgebreid met §5.12.5 als tweede toepassing van dezelfde parameterset-discipline, nu voor φ naast π^Wtp), §5.1.1 (bullet 3 "Fondsparameters bepalen realisme" uitgebreid met inline-verwijzing naar §5.12.5 voor φ-effectiviteit-documentatie-eis). Met deze patch is 6 van de 8 open scherm-4-punten gesloten; resterend §5.12.6 (π^DB als vereenvoudiging toeslagmechaniek) en §11.12-Optie-4-heroverweging (OP/NP-promotie M4). Scherm-1-build-implicatie: geen; M1 blijft onberoerd, M2 blijft onberoerd, SCHEMA v2 voor M1/M2 onveranderd; scherm 1 is bouw-klaar.

**Patch v2.2.6 (23-04-2026 19:46).** Scherm-4-punt 7 beslist: §5.12.6 π^DB als vereenvoudiging van toeslagmechaniek. **Optie 1 — v1-vereenvoudiging formaliseren; scenario-aanpak §5.6 als operationele compensatie verankeren; DG-afhankelijke toeslagprojectie als v2-reservering**. Geen numerieke wijziging; geen SCHEMA-impact; geen formule-wijziging. Achtergrond: §5.12.6 stelt sinds de docx-overname dat het gebruik van één constante π^DB of één vector π^DB_t een sterke vereenvoudiging is van DB-toeslagmechaniek, die in werkelijkheid voorwaardelijk is (dekkingsgraad, toeslagbeleid met staffel/plafond/inhaalindexatie, rentestand). §5.6 bevat al een aanbevolen standaardset van vijf π^DB × π^Wtp scenarioparen (van "Geen indexatie" 0%/0% tot "Ambitiescenario beide zijden" 2%/3%) die in de praktijk het operationele antwoord vormt op deze vereenvoudiging, maar deze connectie was nog niet formeel gelegd. Structurele spiegel met §5.12.1 en §5.12.2: beide projectie-componenten (π^Wtp en π^DB) hanteren symmetrische parameterset-discipline, maar π^DB heeft een extra laag (scenario-vergelijking §5.6) die voor π^Wtp niet bestaat — conceptueel consistent omdat π^DB-onzekerheid uit beleidsvariatie komt (staffel-keuze, DG-pad) terwijl π^Wtp-onzekerheid uit rendementsvariatie komt (in M3 stochastisch, in M4 deterministisch via parameterset). Drie-laags rationale: (a) **sluit §5.12-blok volledig af** — §5.12.1 t/m §5.12.5 zijn gesloten in v2.2.1–v2.2.5; §5.12.6 is het laatste reviewpunt dat geformaliseerd moet worden, naast §5.12.7 die als aanvullend punt bij v2.2.0 is opgesteld; (b) **scenario-compensatie-verankering maakt §5.6-functie expliciet** — de scenario-set is niet decoratie maar de v1-oplossing voor DB-toeslag-beleidsvariatie; zonder formele verankering blijft §5.6 zonder duidelijke conceptuele status; (c) **proportionaliteit** — snel-formalisering consistent met v2.2.0-v2.2.5 schaal, geen SCHEMA-impact, geen formule-wijziging. Vier kern-elementen in besluit-notitie §5.12.6: (i) v1-vereenvoudiging π^DB als scalar/vector formeel; (ii) scenario-aanpak §5.6 als operationele compensatie voor beleidsvariatie; (iii) parameterset-documentatie-eis (samensteller motiveert gekozen π^DB-waardes en scenario-selectie); (iv) DG-afhankelijke toeslagprojectie (staffel, plafond, inhaalindexatie) als v2-reservering parallel aan §5.11 uitbreidings-pad. Doorwerking: §5.12.6 (besluit-notitie toegevoegd onderaan), §5.6 (inleidende zin toegevoegd die v2.2.6 deze scenario-set als operationele compensatie bevestigt), §5.11 (nieuwe bullet toegevoegd over DG-afhankelijke toeslagprojectie als v2-uitbreiding). Met deze patch is 7 van de 8 open scherm-4-punten gesloten; resterend alleen §11.12-Optie-4-heroverweging (OP/NP-promotie M4). §5.12-blok is na deze patch volledig gesloten (alle zes oorspronkelijke sub-paragrafen geformaliseerd + §5.12.7 als aanvullend punt uit v2.2.0).

**Patch v2.2.7 (23-04-2026 19:53).** Scherm-4-punt 8 beslist: §11.12 OP/NP-breakdown M4 promoveren van presentatie- naar berekeningslaag. **Optie A — conservatieve bevestiging; OP/NP blijft presentatie-laag in v1; Optie 4-heropening verankerd als expliciete v2-reservering met voorwaarden-lijst**. Geen numerieke wijziging; geen SCHEMA-impact; geen formule-wijziging. Achtergrond: §11.12 had in v2.1.3 (scherm-2-sessie) Optie 1 + Optie A bevestigd (alleen `phiDerived`-totaal-scalar, geen component-varianten) met Optie 4 (component-varianten via M4-promotie) expliciet afgewezen voor v1 onder de motivering "in v2 heropenbaar indien M4-breakdown promoveert tot berekeningslaag". Bij scherm-3-afronding (HANDOFF_v2.1.9) is dit heropen-punt als scherm-4-agendapunt toegevoegd onder de noemer "potentieel major v2.2/v3.0". In scherm-4-sessie is de conservatieve weg gekozen: M4's V_x^Wtp blijft als één-totaal-output berekend (OP en NP als twee termen in de sommatie §5.5.5, niet als aparte output-velden); een UI-laag kan desgewenst OP/NP-bijdragen tonen als presentatie, maar niet als berekeningslaag. Drie-laags rationale: (a) **scherm-4-sessie als formaliseringssessie** — alle andere scherm-4-besluiten (v2.2.0 t/m v2.2.6) zijn snel-formaliseringen zonder structurele wijziging; Optie B (promotie tot berekeningslaag met major-bump v3.0) zou uit de toon vallen; (b) **docx-spec-coherentie behouden** — §5.5 formule-structuur blijft intact, wat audit-continuïteit met de oorspronkelijke docx-spec waarborgt; M4 is als enige module nog niet geïmplementeerd en een structurele herziening van de output-structuur voordat implementatie begint is onnodig risico; (c) **heldere v2-voorwaarden** — door expliciet te maken *welke omstandigheden* Optie 4-heropening rechtvaardigen (gebruikerstest, actuariële reviewer-feedback, SSPF-communicatiebehoefte), krijgt een toekomstige implementator een concreet trigger-criterium in plaats van open heroverweging. Drie kern-elementen in sluit-notitie §11.12: (i) v2.1.3-besluit bevestigd; (ii) Optie 4 blijft v2-pad met expliciete heroverwegings-voorwaarden (niet "wellicht ooit"); (iii) SCHEMA v2 anker: M4-output is één-niveau (totaal), M2-output houdt geoormerkte OP/NP-structuur (v2.0), phiDerived blijft scalar. Doorwerking: §11.12 (sluit-notitie toegevoegd onderaan met scherm-4-bevestiging en v2-heropenings-voorwaarden), §5.2 (korte aanvulling aan Component 3 Rekenmodule dat OP/NP-breakdown in v1 presentatie-laag is en geen primaire output). Met deze patch is 8 van de 8 open scherm-4-punten gesloten. **Scherm 4 is volledig afgerond — zeven patches v2.2.0 t/m v2.2.7, acht besluiten, geen numerieke wijziging in de engine.** Spec-stand: 22e gesloten besluit over vier sessies (12 scherm-1 + 3 scherm-2 + 6 scherm-3 + 8 scherm-4 = 29 totaal, inclusief §11.12-heroverweging als opnieuw-gesloten); ~1970 regels. Volgende stappen na deze patch: SCHEMA v2 schrijven (afgeleide van spec), TEST_FIXTURES v1 voor M1/M2/M3, AG2024-integratie, M1-implementatie.

**Patch v2.2.8 (23-04-2026 21:49).** Cosmetische tabel-kop-aanscherping §2.3 tijdens SCHEMA-v2-schrijven ontdekt. Geen inhoudelijk besluit, geen numerieke wijziging, geen SCHEMA-impact in eigenlijke zin; uitsluitend in-spec-consistentie-correctie. Achtergrond: bij het schrijven van SCHEMA v2 M1-block viel op dat §2.3-tabel voor velden `f(x,g)` en `π` nog de oorspronkelijke brede type-formulering voert ("scalar of map → decimal" resp. "decimal of vector"), terwijl de sturende besluiten §11.13 v1.4 (`f` → "Optie 2: vaste scalar, structuur actief in v1.4") en §11.15 v1.6 (`π` → "Optie 2: structurele scalar, waarde 0 als bewust anker") beide expliciet voor scalar hebben gekozen. De tabel-kop was residu van een eerdere bredere formulering; de besluiten zelf vernauwden naar scalar. Patch v2.2.8 trekt de tabel-kop gelijk met de besluiten: `f(x,g)` type-kolom wordt "scalar → decimal" (met toelichting dat map-vorm v2-uitbreidingspad is), en `π` type-kolom wordt "decimal" (met toelichting dat vector-vorm v2-uitbreidingspad is). Drie-laags rationale: (a) **in-spec-consistentie** — tabel-kop en sturend besluit moeten identieke type-claims maken, anders krijgt een SCHEMA-schrijver of implementator twee verschillende signalen uit hetzelfde document; (b) **SCHEMA v2 ankering expliciet** — SCHEMA v2 modelleert beide velden als scalar conform §11.13/§11.15; de tabel-kop moet dat weerspiegelen zodat de afleiding spec → SCHEMA traceerbaar blijft; (c) **upgrade-pad naar v2 blijft helder** — map/vector-extensie blijft mogelijk als minor SCHEMA-bump v2.1 wanneer een use-case het vereist, dat pad wordt in de toelichting vermeld zodat het niet uit het oog verdwijnt. Doorwerking: §2.3 (twee tabel-rijen herschreven met scalar-type + upgrade-pad-noot). Geen doorwerking naar §11.13/§11.15 zelf (besluiten waren al scalar; dit patcht alleen de tabel-kop die niet synchroon liep). Geen numerieke impact.

**Patch v2.2.9 (23-04-2026 21:54).** M1 `t₀` verplaatst van deelnemer-invoer (§2.2) naar fondsparameterset (§2.3) — semantische plaatsingscorrectie tijdens SCHEMA-v2-M1-schrijven ontdekt. Geen inhoudelijk besluit over gedrag, geen numerieke wijziging; uitsluitend veld-hergroepering met cross-module-symmetrie-rationale. Achtergrond: bij het schrijven van SCHEMA v2 M1-block kwam aan het licht dat `t₀` in §2.2 een semantische misplaatsing is — het veld is géén UPO-invoer die de deelnemer uit eigen situatie kent, maar een periode-snapshot-kolomselector voor AG2024 die logisch bij de fondsparameterset hoort. Bevestiging van deze plaatsingscorrectie komt uit twee richtingen: (a) **M3 doet het al zo** — §4.3 regel 620 heeft `t₀` als parameterset-veld met status `actief (v2.1.5)`, met identieke semantiek ("Projectiejaar voor AG2024-kolomselectie; M3 gebruikt periode-snapshot conform §2.6.2 (zelfde aanname als M1)"). M1's plaatsing in §2.2 was dus een asymmetrie t.o.v. M3 die §7.2-consistentie schond; (b) **casual/audit-scheiding (Model D)** — `t₀` verschijnt in geen enkel realistisch scenario op een casual scherm (deelnemer weet niet wat hij daar moet invullen), maar wel in audit-scherm als parameter-audit-veld. Plaatsing bij parameterset is daarmee ook UI-conformer. Drie-laags rationale: (a) **cross-module spiegelgelijkheid** — M1 en M3 gebruiken beide periode-snapshot voor dezelfde reden (zie §2.6.2), dus `t₀` hoort op identieke plek te staan; v2.1.5 had M3 al goed, v2.2.9 haalt M1 in; (b) **semantische helderheid** — fondsparameterset is "fonds- en regelinggebonden grootheden" (conform §5.2 component 2), en een peildatum-keuze voor de sterftetafel valt conceptueel in die categorie, niet onder "deelnemer-UPO-invoer"; (c) **SCHEMA v2 afleiding helder** — SCHEMA v2 M1-block plaatst `t₀` in `M1.parameterset` conform deze patch; zonder patch zou SCHEMA v2 ofwel een onverdedigbare asymmetrie met M3 invoeren, ofwel de spec-claim moeten negeren. **M4-context bewust niet gepatcht:** §5.3 regel 872 heeft `t₀` in deelnemer-invoer met andere semantiek ("Kalenderjaar van transitiedatum (voor generatietafel)") — M4 gebruikt `t₀` niet als periode-snapshot-kolom maar als start-kalenderjaar voor cohort-diagonaal (§5.5.1). In die interpretatie is `t₀` een deelnemer-specifiek transitiemoment; plaatsing bij §5.3 blijft verdedigbaar. Eventuele M4-heroverweging ligt bij de M4-implementatie-track, niet in scope van deze patch. Doorwerking: §2.2 (t₀-rij verwijderd), §2.3 (t₀-rij toegevoegd na `sterftekansTabelId`), §2.2-kop-tekst aangepast (wordt weer minimaal-UPO-invoer). Geen doorwerking naar §2.5 (formules), §2.6 (aannames), §2.7 (fallbacks), §2.8 (validaties) of §11.16 — `t₀` blijft semantisch identiek, alleen adresloos verschoven. Geen numerieke impact. SCHEMA-impact: M1Deelnemer verliest `t0`-veld; M1Parameterset wint `t0`-veld met default 2026.

**Patch v2.2.10 (04-05-2026 21:04).** SCHEMA-/implementatie-track-doorwerking en CRM-2026-34-bron-integratie tijdens M2-combi-sessie. **(A) Bundle-aftrek-mechaniek toegevoegd (Model C hybride)** voor §3.5: nieuw veld `vpvAftrekPct` (default 0,10 als ABN-conservatieve placeholder; SSPF-bron-todo in §11.19) representeert "alle bestemmingsreserveringen behalve compensatiedepot" als fractie van `vpvTotal` — ABN AMRO Pensioenfonds-publicatie (transitieplan 17-10-2024 + implementatieplan 22-09-2025) en de in CRM-2026-34 aangehaalde ABN-toelichting bij DG-115%/125%/135% (5%/15%/25% verdeelbaar overschot) verifiëren `0,10·vpvTotal` als bundle-grondslag voor VEV + operationele reserve + solidariteitsreserve + inhaalindexatie. Verdeelbaar-formule herschreven: `verdeelbaar = fondsvermogen − vpvAftrekPct·vpvTotal − compensatiedepot − buffer + bijstort`. Velden `overigeReserves` en `operationeleReserveringPct` worden **v2-deprecated** gemarkeerd: nog in §3.3 zichtbaar voor backward-compat met v2.1.x-datasets, maar door v2.2.10-engine niet langer gelezen (gepasseerd door `vpvAftrekPct`-bundle). Een dataset met legacy-velden gevuld én `vpvAftrekPct` ingevuld krijgt waarschuwing in M2-superRefine. **(B) Grondslagverschuiving fondsvermogen → vpv** voor de bundle. §3.6 aanname 5 ("operationele reserve als percentage van fondsvermogen, niet van voorziening — tool-keuze") wordt geherformuleerd: bundle-grondslag is in v2.2.10 vpv conform ABN-praktijk; legacy-velden behouden fondsvermogen-grondslag voor backward-compat. Wiskundige verificatie: ABN's bundle-toelichting matcht exact bij `aftrek = 0,10·vpvTotal` (DG=1,15: 0,05·vpv = 5%; DG=1,25: 0,15·vpv = 15%; DG=1,35: 0,25·vpv = 25%). **(C) UI-disclosure-eis op `spreidingN`** voor SCHEMA-laag-toevoeging: CRM-2026-34 (04-03-2026, ABN AMRO N.V. + Stichting Pensioenfonds van de ABN AMRO Bank N.V.) bevestigt dat de wettelijke spreidingstermijn van 10 jaar uit art. 2 lid 1 Bijlage 2a Regeling indirect leeftijdsonderscheid oplevert maar objectief gerechtvaardigd is (terughoudende toets sociale-partner-onderhandeling, doel evenwichtige verdeling, middel passend en noodzakelijk). De rekenmethode raakt ouderen in het bijzonder — typisch ontvangen oudste gepensioneerden op transitiedatum minder dan de helft van wat actieve deelnemers ontvangen. Een transparante calculator hoort die juridische context op het audit-scherm te tonen, niet pas na klacht. SCHEMA implementeert dit als `uiDisclosure`-string op `M2.parameterset.spreidingN` met expliciete verwijzing naar CRM-2026-34, de redenering indirect-onderscheid → objectieve rechtvaardiging, en de wettelijke uitwijkmogelijkheid art. 2 lid 3 Bijlage 2a (dus geen advies om af te wijken). **(D) UI-disclosure-eis op `vpvAftrekPct`**: ABN-publicatie als voornaamste bron, met expliciete waarschuwing dat ABN's 10% leeftijdsmix actieven+gepensioneerden bevat; SSPF (gesloten, alleen gepensioneerden) heeft een andere bundle-samenstelling — geen DRS-compensatie-aandeel in dezelfde range, mogelijk wel inhaalindexatie en RDR-buffer-vorming. Een SSPF-samensteller die ABN's 10% klakkeloos overneemt zou compensatie-positie verkeerd kalibreren. **(E) Nieuw §11.19 reviewpunt: SSPF-`vpvAftrekPct`-kalibratie.** Hans (Innovation Nestor SSPF) heeft "wel eens 6%" gehoord als SSPF-aftrek-niveau; geen publieke bron geverifieerd. Default 0,10 (ABN-conservatief) is bewuste placeholder boven SSPF-vermoeden om "rekent rijk"-asymmetrie te vermijden parallel aan §11.14 v1.5-rationale (ρ=0,02 ultieme default). Bron-onderzoek nodig in SSPF-jaarverslag/transitieplan/implementatieplan voor exacte percentage; vervanging zonder spec-revisie via dataset. **(F) §3.10 reviewpunt-uitbreiding: dubbele administratie-risico.** Model C (gekozen architectuur) houdt `compensatiedepot` apart van `vpvAftrekPct` zodat bell-curve-input behouden blijft. ABN's gepubliceerde 10% **bevat compensatie wél**; een SSPF-samensteller die ABN als referentie gebruikt moet daarom decomposeren in `vpvAftrekPct(ABN-zonder-compensatie)` + `compensatiedepot(apart in mln euro)`, niet 1-op-1 overnemen. Documentatie-eis bij dataset-load. Drie-laags rationale voor v2.2.10-patch: (a) **bron-traceerbaarheid** parallel aan §11.16 (AG2024) en §11.17 (SSPF-genderweging) — fondsbestuur-besluit-parameters horen verifieerbaar te zijn tegen publieke transitieplannen, niet impliciet hardcoded; (b) **publieke-rapportage-conformiteit** — Nederlandse pensioenfondsen rapporteren bestemmingsreserveringen typisch als bundle-percentage in transitieplannen; SCHEMA moet daar op aansluiten in plaats van decompositie eisen die alleen interne actuariële stukken kennen; (c) **juridische zorgvuldigheid** — een publieke calculator die spreidings-effect impliciet doorvoert zonder de juridische context (CRM-2026-34, art. 21 lid 2 uitwijkmogelijkheid) is informatie-arm voor de doelgroep. Doorwerking: §3.3 (`vpvAftrekPct` toegevoegd na `compensatiedepot`-rij, default 0,10, status `actief`; `overigeReserves` en `operationeleReserveringPct` toelichtings-kolom uitgebreid met deprecation-noot), §3.5 (verdeelbaar-formule herschreven met bundle-aftrek-term; legacy-formule behouden in commentaar-blok als v2.1.x-backward-compat), §3.6 (aanname 5 herschreven van "tool-keuze" naar "v2.2.10-grondslagverschuiving"; nieuwe aanname 13 over CRM-2026-34-bevestiging spreidings-mechaniek), §3.10 (Compensatiedepot-reviewpunt uitgebreid met dubbele-administratie-noot; nieuw reviewpunt CRM-2026-34-context op `spreidingN`), §11 (nieuw §11.19 SSPF-`vpvAftrekPct`-kalibratie). SCHEMA-impact: M2-parameterset krijgt `vpvAftrekPct` als veld met `uiDisclosure`; M2-parameterset krijgt `uiDisclosure`-string op `spreidingN`; legacy-velden krijgen `.describe()`-noot over deprecation. Numerieke impact bij placeholder-default (`vpvAftrekPct=0,10`): voor SSPF-typisch DG=1,15 daalt verdeelbaar van `fondsvermogen − operRes − overigeReserves − …` (typisch ~3-5% van fondsvermogen) naar `fondsvermogen − 0,10·vpvTotal − compensatiedepot − buffer + bijstort` (~8-9% van fondsvermogen bij DG=1,15). Bij SSPF-bron-kalibratie 6% zou het effect omkeren naar verlagings van aftrek t.o.v. R9.30. Effect op individuele `ppkTotal` is mengsel van `ppkBase` (proportioneel aan `verdeelbaar/vpvTotal`) en `ppkSurplus` (afgeleide); puntschatting voor SSPF-default-67-jarige bij DG=1,15: −2 tot −4% ppkTotal t.o.v. v2.1.9-baseline.

**Patch v2.2.11 (04-05-2026 23:37).** **M1 joint-life-uitbreiding met broken-heart-correctie geactiveerd; M3/M4-pendanten als gekoppelde v2-pad expliciet niet-gewijzigd.** Combi-sessie M2-vervolg, na publieksvraag van Hans over SSPF-deelnemer-uitleg waarbij KV_NP-overschattings-effect zichtbaar werd op concreet voorbeeld (Henk 68M + Anna 66V + €14k NP: KV_NP-bovengrens €237k vs strict-correcte joint-life-waarde ~€90k, ofwel ~62% overschatting). v2.2.3 had `_{k/m}p_{x₀ y₀} = _{k/m}p_{x₀} · _{k/m}p_{y₀}`-onafhankelijkheid als gekoppelde v2-reservering parallel §2.10/§4.9/§5.12.3 vastgelegd; v2.2.11 activeert die reservering voor M1 alléén (β-keuze: M1-eerst-met-reservering, geen major-bump). **(A) Joint-life-formule §2.5.** KV_NP-formule wijzigt van `KV_NP = (1+ρ)·y₀·ä(x_partner, r)` (bovengrens, partner-altijd-betalend) naar `KV_NP = (1+ρ)·y₀·ä_{x|y}(r)` met `ä_{x|y}(r) = (1/m)·Σ_{k=1}^{m·T_eff} (1+π)^{k/m} · _{k/m}q_x · _{k/m}p_y · (1+r)^{−k/m}`. Wiskundige interpretatie per maandelijkse periode: NP-uitkering t = `kans dat deelnemer in [0, k/m] is overleden` × `kans dat partner k/m levend is` × kasstroom × disconto. Onafhankelijkheid `_{k/m}p_{x y} = _{k/m}p_x · _{k/m}p_y` blijft v1-aanname conform §2.10-bullet (broken-heart als sterftekans-schock-correctie wel toegepast — zie (B) — maar latere afhankelijkheid in covarianten levensomstandigheden niet). T_eff blijft volgens §2.5 horizon-cap `min(ω−x_partner, 55, t zodat ℓ < 0,001)`. Ingegaan-NP-onderscheid: voor partner waarvan NP al ingaat (deelnemer reeds overleden voor peildatum) wordt `_{k/m}q_x = 1` voor alle k → formule reduceert naar oorspronkelijke `ä(x_partner, r)`; SCHEMA krijgt geen aparte input-vlag, engine detecteert via deelnemer-flag. **(B) Broken-heart-correctie via sterftekans-multiplier (S-JL-1 + S-JL-2 keuze).** Na overlijden van eerste partner stijgt sterftekans van overlevende; gemodelleerd als tijds-afhankelijke factor `bh(τ, g_y)` op q_partner waarbij τ = jaren sinds overlijden eerste partner. v2.2.11-default-parametrisering (placeholder, AG-2018-rapport-Spreiding-overlijdenstijden als beoogde bron, exacte waardes te verifiëren in §11.20 bron-onderzoek): `bh(0, M) = 1,50`, `bh(0, V) = 1,25`, lineair afnemend naar `bh(5, ·) = 1,00` voor beide geslachten; gender-asymmetrie reflecteert dat mannen na verlies vrouwelijke partner sterker afgewogen sterftestijging vertonen dan andersom (Nederlandse data uit AG-2018-onderzoek). Implementatie in formule (A): `_{k/m}p_y` wordt `_{k/m}p_y^{bh}` waarbij sub-periodes na deelnemer-overlijdens-tijdstip τ_eersteoverlijden bh-factor toepassen op `q_y(t)`; conditioneel op `_{k/m}q_x` (overlijden eerste partner) wordt overlevende-q geschokt over τ ∈ [0, 5]. Wiskundig vereist dit een twee-dimensionale integratie of meercommentaarse uitwerking — implementatie-detail engine, niet spec-laag — engine berekent benadering via convex-combinatie ψ-gewogen sterftepad-paren (zie §2.5-implementatie-noot). **(C) §2.6 aanname 7 herschreven** van "Partnerpensioen als aparte KV-regel (v1.3, bovengrens-aanname)" naar "Partnerpensioen als joint-life met broken-heart-correctie (v2.2.11). KV_NP gebruikt `ä_{x|y}` met conditionele kans `kans deelnemer dood × kans partner levend` (onafhankelijkheid behouden) plus broken-heart-multiplier op overlevende-partner-q over 5 jaar lineair dempend (AG-2018-bron-placeholder). Voor ingegaan NP (deelnemer reeds overleden) reduceert formule naar `y₀·ä(x_partner, r)`. Numerieke impact tussen 30-60% verlaging KV_NP afhankelijk van leeftijdsverschil x−x_partner — voor Henk-Anna-typisch scenario (x=68, x_partner=66) ~62% verlaging, dus KV_NP daalt van bovengrens-niveau naar materieel kleinere waarde". **(D) §2.10 reviewpunt herschreven.** Bullet "NP als bovengrens" wordt opgelost-status. Bestaande sub-koppeling met M3 (§4.9) en M4 (§5.12.3) blijft staan als **expliciet niet-gewijzigd in v2.2.11**: M3/M4-formule blijft de onafhankelijkheids-aanname zonder broken-heart-correctie hanteren (bovengrens-formule). Dit creëert een **bewuste tijdelijke spec-incoherentie** tussen modules tot M3/M4 hun pendant-implementaties krijgen — gerechtvaardigd door v2.2.3-werkafspraak ("gekoppeld v2-pad") als gekoppelde-toepassing, en door pragmatische β-keuze van Hans in combi-sessie M2 om M1-effect zichtbaar te maken op concreet publieksvoorbeeld vóór M3/M4 bouw. M3-`U₀_NP = ppk_NP/ä(x_partner, proj, g_y)` (§4.5) wordt door M1's KV_NP-verlaging mechanisch geraakt (lagere `KV_NP` → lagere `ppk_NP` via M2-keten → lagere `U₀_NP`); dit doorwerkings-effect is correct bedoeld. M4-`V_x^PP` (§5.12.3) blijft op de docx-formule met onafhankelijkheid-zonder-broken-heart en moet bij M4-bouw expliciet gepatcht worden. **(E) Nieuw §11.20 reviewpunt: broken-heart-bron-onderzoek.** AG-2018-Spreiding-overlijdenstijden-rapport als beoogde bron voor `bh(τ, g)`-factoren is uit geheugen geciteerd door spec-auteur (Claude); placeholder-cijfers `bh(0,M)=1,50`, `bh(0,V)=1,25`, 5-jaars-demping lineair zijn pragmatische default tot bron-verificatie. Hans-actie: AG-2018-rapport opvragen of alternatieve Nederlandse-bron (CBS-langlevenstudies, Algemene Pensioenfonds-rapporten) lokaliseren; bij vondst gewenste vorm: tabel `bh(τ, g)` met τ ∈ [0..5] of formule met decay-rate λ. Bij afwezigheid bevestigde bron is conservatieve fallback: gender-symmetrische `bh(0)=1,20` met 3-jaars demping (Bowers-1997-stijl maar afgevlakt). **(F) Cross-track-impact.** SCHEMA-track: geen wijziging; M1-deelnemer-velden ongewijzigd, parameter-velden ongewijzigd, output ongewijzigd (alleen `KV_NP` waarde-verandering, geen schema-vorm-verandering). Engine-track: `engine.m1.ts` krijgt nieuwe functie `jointLifeAnnuity(x_deelnemer, x_partner, ...)` parallel aan bestaande `annuity()`; `KV_NP`-berekening switcht. M1-anker € 808.815 wordt vervangen door nieuwe waarde (placeholder-schatting: KV_NP daalt van €367.532 naar ~€140.000-€180.000, KV-totaal van €808.815 naar ~€580.000-€620.000; exacte waarde uit engine-rerun). M2-anker € 852.481 wijzigt evenredig via M2-keten. Browser-test-anker bijwerken in `test_browser_calc.ts`. Drie-laags rationale: (a) **publieksvoorbeeld als spec-driver** — werkafspraak 2 (educatieve leidraad) eist dat publieke calculator-uitkomsten plausibel zijn; €237k voor Anna's NP is op concrete-vraag-niveau onverdedigbaar als niet-erkende bovengrens; (b) **Werkafspraak 12 (eerlijke boekhouding) + bronhoudbaarheid** — placeholder-cijfers met §11.20-vlag conform §11.14 (ρ=0,02) en §11.19 (vpvAftrekPct=0,10) precedent; (c) **proportionaliteit M3/M4-vertraging** — M3 niet bestaat, M4 niet bestaat; M1-only-eerst-keuze pragmatisch boven strikt-parallel-α-keuze, mits §2.10 expliciet markeert. Doorwerking: §2.5 (NP-blok herschreven met joint-life-formule en broken-heart-multiplier; ingegaan-NP-reductie expliciet), §2.6 (aanname 7 herschreven), §2.10 (reviewpunt "NP als bovengrens" opgelost-gemarkeerd; gekoppelde sub-koppeling M3/M4 blijft staan met "v2.2.11-asymmetrie" noot), §4.9 (M3-pendant onaangetast, kruisverwijzing-tekst uitgebreid met "v2.2.11-status: M1 geactiveerd, M3 nog open"), §5.12.3 (M4-pendant onaangetast, kruisverwijzing-tekst idem), §11 (nieuw §11.20 broken-heart-bron-onderzoek). Numerieke impact: KV_NP −30% tot −60% per geval; KV-totaal −10% tot −25% afhankelijk van NP-aandeel; ppkTotal-keten via M2 evenredig.

**Patch v2.2.12 (05-05-2026 00:01).** **Numerieke claim-correctie v2.2.11.** Eerlijke boekhouding (werkafspraak 12) — engine-implementatie van v2.2.11 geleverd nieuwe ankerwaardes die *buiten* de in v2.2.11 geclaimde bandbreedte vallen. Geen wijziging van besluit, formule, SCHEMA, of code; uitsluitend correctie van geclaimde getalreeksen in de v2.2.11-patch-tekst en in §2.5-numerieke-impact-tabel. Wat er gebeurde: v2.2.11 schatte KV_NP-verlaging op "30-60%" en KV-totaal op "−10% tot −25%". Werkelijke meting na engine-implementatie en numerieke validatie tegen het Henk-Anna-scenario (68M+66V+€14k NP, SSPF-defaults, r=2%) levert: **KV_NP daalt met 72%** (van €237.214 v1.3-bovengrens naar €67.558 v2.2.11-joint-life), **KV-totaal daalt met 33%** (van €520.260 naar €350.603). Voor het oorspronkelijke SSPF-anker-scenario (67M+65V+€21k+SSPF-defaults): **KV_NP daalt met 72%** (€367.532 → €101.812), **KV-totaal daalt met 33%** (€808.815 → €543.096). De −72% KV_NP-verlaging is groter dan de v2.2.11-claim van "30-60%". **Verklaring effect-grootte:** twee mechanismen werken samen: (a) joint-life-conditionering — partner krijgt alleen NP zodra deelnemer overleden is, niet alvast; (b) broken-heart-multiplier — overlevende-partner-q wordt geschokt met 1,25 (V) of 1,50 (M) over 5 jaar dempend. Het gecombineerde effect bij gepensioneerden-leeftijden (60-70) waar deelnemer-overlijdens-kans tweede-orde maar niet-verwaarloosbaar is, is groter dan oorspronkelijke schatting verwachtte. **M2-keten-doorwerking:** M2-anker € 852.481 → € 572.166 (−33%), evenredig met M1 KV-daling. Wijzigingen in spec-tekst: (a) v2.2.11-changelog-paragraaf "Numerieke impact" aan einde wordt verfijnd: "KV_NP −60% tot −75% per geval afhankelijk van leeftijdsverschil; KV-totaal −25% tot −40% afhankelijk van NP-aandeel"; (b) §2.5 "v2.2.11 numerieke impact (Henk-Anna-typisch)"-blok krijgt feitelijke meting "v2.2.11 joint-life met bh: KV_NP €67.558 (72% verlaging t.o.v. bovengrens)"; (c) §11.20 "Numerieke gevoeligheid"-blok krijgt feitelijke meting in plaats van "ongeveer 90k-100k"; (d) v2.2.11-changelog-paragraaf vermeldt expliciet de v2.2.12-correctie met datum + reden voor latere lezers (geen retroactieve herschrijving van de v2.2.11-claim, alleen v2.2.12-noot toegevoegd). **Werkafspraak-12 uitvoering:** dit patch ontstond niet uit nieuwe inhoudelijke afweging maar uit *eerlijke meting tegen schatting*. Het is de tweede mini-patch ooit met dat patroon (eerste was v2.2.8 type-cosmetiek SCHEMA M1, geen numerieke impact). De grotere v2.2.11-bandbreedte was Claude's pragmatische "30-60%"-claim op basis van vergelijkbare-leeftijd-vuistregel; de werkelijke −72% komt door bh-multiplicatie-effect over de 5-jaars-schok-venster. Bij M3- en M4-implementatie hoort dezelfde meet-ronde te volgen vóór numerieke claims worden gepubliceerd. Doorwerking: §2.5 (numerieke-impact-tabel uitgebreid met v2.2.12-meting), §11.20 (numerieke-gevoeligheid-blok uitgebreid). Geen wijziging in §2.6 aanname 7 of §2.10 reviewpunt-bullet (claim "30-60%" daar staat nog; verwijzing naar v2.2.12-correctie via doorwerking-noot). Numerieke impact: nul; uitsluitend tekstuele correctie.

**Major release v3.0 (05-05-2026).** **Wet-canonieke standaardregel — implementatie van bijlage 2a Regeling Pensioenwet artikel 2.** Deze release sluit het §11.21-bron-onderzoek uit v2.2.13 af met "bron-bevestigd, implementatie-aanpassing voltooid" en vervangt de R9.30-pragmatiek (`sFactor·ν(N)`-formule) door de wettelijke standaardregel `KS_na(i,h) = KS_voor(i,h) · (1 + q(h) · x_fonds)` met `q(h) = min(floor(h)/N, 1)` en fonds-niveau-schalingsfactor `x_fonds = (M − CW_voor_fonds) / CW_star_fonds` (art. 3 bijlage 2a). **Aanleiding:** §11.21 bron-onderzoek-trap (1) levert eenduidig antwoord — Bijlage 2a Regeling Pw beschrijft een per-kasstroom-aanpassings-formule met staircase q(h), fundamenteel anders gestructureerd dan de R9.30-DNB-pragmatiek (kapitaal-niveau-aanpassing met sFactor·ν(N)). De wet-conformiteit-claim "§3.5 R9.30-conform" was niet bron-houdbaar; "R9.30" verwijst aantoonbaar naar onze interne 21-04-2026-baseline (`21-04-2026_2216.html`), niet naar een externe DNB-bron. **Wiskundige kern v3.0 via lineariteit:** `ppk(i) = KV(i) + x_fonds · CW_star(i)` met `CW_star(i) = Σ_h q(h,N) · KS_voor(i,h) · v(h)`. Dit ontkoppelt KV (= CW_voor; geleverd door M1) van CW_star (= q-gewogen CW; nieuwe scalar geleverd door M1 onder M2-cascade). De OP/NP-decompositie volgt automatisch uit lineariteit zonder aparte sFactor-aannames: `ppk_OP = KV_OP + x_fonds · cw_star_op` en `ppk_NP = KV_NP + x_fonds · cw_star_np`; sluiting `ppk_OP + ppk_NP = ppkTotal` is per constructie exact (machine-precisie). **N-keuze educatief uitgebreid:** SCHEMA accepteert `spreidingN` in [0, 1000] (was [0, 30]); UI biedt radio-keuze tussen N=10 (wettelijke standaard art. 2 lid 1) en N=1000 (proxy voor oneindige spreiding, educatieve N=∞-vergelijking). Verschil tussen N-waardes laat zien hoeveel van de leeftijdsongelijke verdeling specifiek aan de stylering van indexatie-blootstelling-historie toe te schrijven is — bij N=∞ wordt de verdeling bijna proportioneel aan KV. **Engine-architectuur v3.0:** `engine.m1.ts` uitgebreid met `q_wet(h, N)`, `annuityWithQ()`, `jointLifeAnnuityWithQ()` (analoog aan `annuity`/`jointLifeAnnuity` met q-staircase-multiplier in de som; aparte memoization-caches met N in cache-key); `computeM1` accepteert optioneel `m2Context: { spreidingN }`-argument waarbij `cw_star_op` en `cw_star_np` als nieuwe optionele M1Output-velden worden gevuld. Scherm-1-standalone-modus (zonder m2Context) gedraagt zich identiek aan v2.2.x — geen breaking change voor M1-only-gebruik. `engine.m2.ts` herstructureert `computeM2` op basis van `computeFondsXStar`-helper (cohort-sommatie via `kvProfile` + nieuwe `cwStarProfile` met SSPF-genderweging 95/5; ratio R = CW_star_proxy / CW_voor_proxy als fonds-karakteristiek per (preset, sterftetafel, N)). Oude formule behouden als `computeM2_R930_LEGACY` voor regressie-vergelijking tegen v2.2.11+12-ankers (Knelpunt G uit Stap-2-plan). **Output-contract M2 ongewijzigd:** velden `ppkBase, ppkSurplus, ppkComp, ppkTotal, ppk_OP, ppk_NP, bufferAandeel, cohortOutcomes, vpvTotal, verdeelbaar, phiDerived` blijven; backward-compat-mapping: `ppkBase = KV` (was `KV·baseRatio`), `ppkSurplus = x_fonds·(cw_star_op + cw_star_np)` (was `(KV/vpvTotal)·surplus·sFactor·ν`). De v2.x baseRatio-conventie en de R9.30-DNB-formule zijn daarmee conceptueel vervangen, niet velden-niveau breaking. `vpvAftrekPct·vpvTotal + compensatiedepot + buffer − bijstort` mapping behouden (Model C bundle, v2.2.10 ongewijzigd) als M-aftrek; CRM-2026-34-context (§11.13) behouden, juridische argumentatie versterkt door wet-canonieke implementatie. **Nieuwe ankers (SSPF 67M+65V+€30k OP+€21k NP, DG=1.15, vpvAftrekPct=0.10, demografie-preset 'gesloten', N=10):** M1 KV € 543.096 (onveranderd; KV-formule M1-only ongewijzigd), M2 ppkTotal **€ 574.369** (was € 572.166 onder R9.30-legacy; +€ 2.203 = +0,4%). N=1000-vergelijking levert M2 € 580.519 (+1,1% t.o.v. N=10). Verschil v3.0 vs R9.30-legacy is voor SSPF-67M-anker klein (~0,4%) maar voor jongere cohorten en hogere DG substantieel (Q-D-test: tot 25 procentpunten verschil voor 52M+DG=1.35); v3.0 geeft consequent de wet-canonieke uitkomst, R9.30-legacy reproduceert v2.2.11-baseline voor regressie-doeleinden. **SCHEMA-impact:** `M2KetenInputSchema` uitgebreid met verplichte `cw_star_op` en `cw_star_np` (geen optional — M2 vereist v3.0-cascade); `M1OutputSchema` uitgebreid met optionele `cw_star_op` en `cw_star_np` (alleen aanwezig bij m2Context-aanroep, scherm-1-standalone-modus ongewijzigd); `spreidingN.max(30)` → `.max(1000)` met uitgebreide uiDisclosure (CRM-2026-34 + §11.21 v3.0 + N=∞-educatieve onthulling). **UI-impact:** `renderM2Sliders` uitgebreid met radio-control "10 jaar (wettelijk standaard) / 1000 jaar (proxy ∞)" + spreidingN-disclosure direct zichtbaar; `applyM2SliderInput` accepteert `spreidingN`-veld; `recompute` in ui.app.ts roept M1 aan met `m2Context` zodat cw_star meekomt. **Test-suite v3.0:** alle 17 SCHEMA-smoke-tests groen, 10 M2-engine-tests groen (sluitingscontroles 0 op machine-precisie), 7 UI-tests groen (radio-toggle + SCHEMA-acceptatie 0/10/15/1000), 4 cw_star-smoke-tests groen (v.b. cw_star ≤ KV, lineariteit, ratio-rangschikking N=10 > N=1000). Browser-test (8 tests) wordt na build hertest met nieuw anker € 574.369. **Werkafspraak-12 uitvoering:** v3.0 is een major bump (eerste sinds v2.0 NP-geoormerkt-structuur op 23-04-2026), niet een mini-patch — zowel formule-vorm als spec-claim ("R9.30-conform" → "wet-canoniek") zijn structureel veranderd. R9.30-legacy-functie blijft beschikbaar voor regressie via `computeM2_R930_LEGACY`-export; de twee formules kunnen tegelijk worden uitgevoerd op identieke input voor audit-vergelijking. **Loskoppeling v3.0 van SSPF-bestuurlijke-traject:** §11.21-status-update is bewust ontkoppeld van het 02-05-2026 SSPF-vragen-document (Hans, relatienummer xyz620620). Onze calculator is parallel onderzoeksinstrument; v3.0 implementatie volgt eigen bron-houdbaarheid-tempo, niet externe deadline. **Open na v3.0:** §11.20 broken-heart-bron-onderzoek (AG-2018-rapport, ongewijzigd); §11.19 SSPF-vpvAftrekPct-kalibratie (ongewijzigd); §5.12.3 cross-module-asymmetrie M3+M4 onder joint-life (v2.2.11 introduceerde, v3.0 raakt niet — M3 en M4 ongewijzigd); R9.30-regressie verschuift van "klein verschil verifiëren" naar "v3.0-overstap kwantificeren tegen R9.30-baseline". Doorwerking: §3.5 (volledig herschreven, R9.30-pragmatiek-blok behouden in commentaar voor backward-readability), §3.6 (aannames 7+8+10+12 herzien voor wet-canoniek; nieuwe aanname 14 over N=∞-educatieve-keuze), §11.21 (status-update naar "bron-bevestigd, implementatie-aanpassing voltooid"; bron-ladder-resultaten gedocumenteerd; numerieke impact bevestigd via test-suite), §11.18 (status-update: OP/NP-decompositie nu via wiskundige lineariteit i.p.v. aanname-niveau; sluitingscontrole automatisch). M3/M4 ongewijzigd (geen joint-life-asymmetrie-resolutie in deze release; v2.2.11-asymmetrie-status §4.9/§5.12.3 blijft open).

**Patch v3.0.3 (05-05-2026 19:55).** **Publiek-release-prep voor invaarcalculator.nl.** Eerste stap richting publiek deelbaar product: audit-pane wordt verborgen achter access-code, footer/disclaimer toegevoegd voor zelfstandig gebruik door SSPF-deelnemers. Geen wijziging in engine, formule, of cijferproductie; uitsluitend UI/HTML-laag-aanpassingen. **Aanleiding:** Hans wil de calculator beschikbaar stellen via eigen domein `invaarcalculator.nl` rond UPO-uitgifte-moment, opdat deelnemers zelfstandig hun "nu → invaren"-overgang kunnen verkennen. Audit-scherm met wiskundige decompositie en specRef-verwijzingen is voor professionals/onderzoekers, niet voor deelnemers; verbergen-met-code-toegang is gewenst zodat Hans en collega-onderzoekers wel zonder code-share toegang hebben via URL-parameter. **Wijzigingen:** (a) `state.auditUnlocked: boolean` toegevoegd aan AppState (default false); (b) URL-parameter `?audit=innovation-nestor2026` checkt bij init en unlockt automatisch (handig voor deelbare-link-toegang); (c) inputveld onderaan casual-pane in `<details>`-element ("Toegangscode auditscherm (alleen voor professionals)") met code-validatie + feedback "Onjuiste code"; (d) view-toggle (casual/audit-knoppen) alleen zichtbaar wanneer auditUnlocked=true; (e) `effectiveView`-mechanisme dwingt casual-pane wanneer niet unlocked, ongeacht state.view; (f) `renderFooter()`-functie met release-versie ("Release 3.0.3 · 05-05-2026"), contact-link "hans@invaarcalculator.nl", privacy-statement "Deze tool werkt volledig lokaal in uw browser. Er worden geen gegevens verstuurd, opgeslagen of gedeeld.", copyright "© 2026 Hans Haringa — Innovation Nestor", CC BY-NC 4.0-link; (g) `legal-disclaimer`-blok bovenaan casual-pane: "Educatief instrument... aan deze berekening kunnen geen rechten worden ontleend... default-waarden afgestemd op SSPF". **HTML-template-aanpassingen (`build.calc.ts`):** title "Invaarcalculator — pensioenaanspraak nu en na invaren" (was "WTP-pensioencalculator scherm 1+2 v3.0.2"); h1 "Invaarcalculator — uw pensioenaanspraak en het persoonlijk pensioenvermogen na invaren"; oude subtitle-regel met spec-versie verwijderd (versie staat nu in footer); CSS toegevoegd voor `.site-footer`, `.audit-unlock`, `.legal-disclaimer`. **Test-suite:** test_browser_calc.ts Test 6 aangepast — eerst audit-code invoeren via input + submit, dan audit-pane testen. Nieuwe test_v303_publiek.ts (niet gecommit; ad-hoc verifie) bevestigt 17 publiek-release-checks: audit verborgen by default, audit-unlock-blok zichtbaar, footer met correcte content, URL-parameter-flow werkt, code-input-flow werkt (verkeerde code → "Onjuiste code"-feedback, juiste code → audit-pane verschijnt). **Numerieke impact op v3.0/v3.0.1/v3.0.2-ankers:** nul. M1 €543.096, M2 €574.369 ongewijzigd. Bundle 113.9 KB → 116.1 KB (+2.2 KB door extra UI-elementen, CSS, code-flow-handlers). **Werkafspraak-12 uitvoering:** v3.0.3 is de zesde mini-patch — pure UI/HTML-laag-uitbreiding voor publiek release-prep zonder enginewijziging. **Volgende stappen voor invaarcalculator.nl:** (i) UPO-veldnamen overnemen wanneer Hans voorbeeld-UPO deelt; (ii) defaults SSPF nog te verifiëren door Hans (DG, vpvAftrekPct kalibratie via §11.19); (iii) mobile-responsive-check; (iv) print/deelbaarheid-knop; (v) hosting-deployment naar invaarcalculator.nl. SCHEMA-impact: nul. Engine-impact: nul. Doorwerking: §3.10 reviewpunt "UI-design voor schermen 2-3-4" krijgt v3.0.3-status-noot dat publiek-release-prep voor M1+M2-traject is gestart; volledige UI-design-ronde voor schermen 3-4 nog open na M3+M4-implementatie.

 **DRY-cleanup UI-renderers.** Geen wijziging in engine, formule, of cijferproductie; uitsluitend code-architectuur-refactor. **Aanleiding:** v3.0.1 'gemengd'-fix moest in twee bestanden gemaakt worden (`src/ui.m1.ts` én `src/ui.app.ts`) omdat beide modules een eigen kopie van `renderInputField` hadden — eerste fix-poging in alleen ui.m1.ts werkte niet voor `calculator.html` omdat de gebundelde versie ui.app's eigen kopie gebruikte. Hans observeerde direct: "een mini-patch v3.0.2 zou deze twee functies moeten consolideren". Daarbij bleek dat `escapeHtml` drievoudig gedupliceerd was (ui.m1, ui.m2, ui.app) en `FieldInfo`-type ook (drie identieke definities). **Wijzigingen:** nieuw bestand `src/ui.shared.ts` (~75 regels) met drie pure functies: `escapeHtml(s)`, `renderInputField(f, deelnemer, labels)`, en exporteerbaar `FieldInfo`-type. Alle drie de UI-modules importeren nu uit `ui.shared`; lokale duplicaten verwijderd. Beide `renderInputField`-callers (`ui.m1.ts` en `ui.app.ts`) hebben een dunne `renderField(f)`-wrapper die hun eigen `state.deelnemer` en `DEELNEMER_LABELS` doorgeeft aan de gedeelde renderer. `FieldInfo`-type is nu één bron-van-waarheid in `ui.shared.ts`. **Bestand-deltas:** `ui.shared.ts` 0 → ~75 regels (nieuw); `ui.m1.ts` 619 → 581 regels (−38 door verwijdering FieldInfo + escapeHtml + renderInputField + +6 voor wrapper); `ui.app.ts` 723 → 679 regels (−44, idem); `ui.m2.ts` 497 → 487 regels (−10, alleen escapeHtml + FieldInfo verwijderd). Netto: 4 bestanden licht verkleind, één nieuwe shared module, totale code-grootte ongeveer gelijk maar geen meer duplicatie. **Numerieke impact op v3.0/v3.0.1-ankers:** nul. Alle 8 browser-tests groen, M1-anker € 543.096, M2-anker € 574.369, dropdown-cleanup uit v3.0.1 blijft werken (gemengd-filter zit nu één keer in `ui.shared.renderInputField`). **Werkafspraak-12 uitvoering:** v3.0.2 is een mini-patch (vijfde ooit) — code-hygiene zonder gedrags-wijziging. Voorkomt dat toekomstige UI-features twee keer geschreven moeten worden; eliminate latente bron van bugs zoals v3.0.1-deel-fix. Doorwerking: §11.16 v3.0.1-blok krijgt korte v3.0.2-noot dat de gedeelde renderer is geïmplementeerd in `ui.shared.ts`. SCHEMA-impact: nul. Engine-impact: nul. UI-gedrag: identiek. Test-impact: alle bestaande tests groen zonder aanpassing (zelfde DOM-output, zelfde event-handlers).

 **UI-cleanup: 'gemengd' verbergen uit deelnemer-dropdowns (geen UI-keuze voor eindgebruiker).** Geen wijziging in engine, formule, of cijferproductie; uitsluitend (a) UI-laag toont alleen `M`/`V` als opties in scherm-1 deelnemer- en partner-gender-dropdowns, en (b) SCHEMA-defaults voor `M1.deelnemer.g` en `M1.deelnemer.g_y` verschuiven van `'gemengd'` naar `'M'` zodat ongekozen velden niet stilletjes als 'gemengd' blijven staan. **Aanleiding:** Hans observeerde tijdens v3.0-test (70M+70M scenario) dat `'gemengd'` als dropdown-keuze beschikbaar was naast `M`/`V`, en stelde de scherpe vraag: "voor een gebruiker betekent gemengd helemaal niks?" Antwoord: klopt — `'gemengd'` is een engine-interne fallback met SSPF-prior 95% M / 5% V (§11.17 v1.9), bedoeld voor anonieme/onbekende-geslacht-batch-validatie en als cohort-mid-proxy in M2 `computeFondsXStar`. Een eindgebruiker kent zichzelf en zijn partner; de 95/5-weging is fonds-niveau, niet persoons-niveau. SCHEMA-uiDisclosure waarschuwde reeds voor `'gemengd'`-keuze bij bekend-geslacht maar UI implementeerde de waarschuwing niet — UI-defect dat in v3.0 nog stond. **Wijzigingen:** `src/ui.m1.ts` `renderInputField` filtert `'gemengd'` uit `f.typeLabel.split(' | ')`-opties (universeel — `'gemengd'` is altijd engine-fallback, nooit gebruikersinvoer); SCHEMA `g.default('gemengd')` → `g.default('M')` en idem voor `g_y` in `M1Deelnemerschema`; `.describe()` en `uiDisclosure` aangepast om v3.0.1-context te benoemen. **Engine-laag onveranderd:** `GenderSchema` accepteert nog steeds `['M', 'V', 'gemengd']`; `q(x, t0, g, ...)` blijft `'gemengd'` accepteren met SSPF-prior; M2 `cwStarProfile` en `kvProfile` blijven cohort-mid-proxy via `'gemengd'` aanroep gebruiken. SCHEMA-niveau-input via batch (developers, onderzoekers) kan nog steeds `'gemengd'` zetten voor anonieme records. **Numerieke impact op v3.0-ankers:** nul — alle bestaande tests gebruiken expliciet `g: 'M'` en `g_y: 'V'` voor SSPF-anker (67M+65V), nooit defaults. M2-anker € 574.369 ongewijzigd; M1-anker € 543.096 ongewijzigd. **Werkafspraak-12 uitvoering:** v3.0.1 is een mini-patch (vierde ooit, na v2.2.8 / v2.2.12 / v2.2.13) — UI-bug-fix zonder engine-impact, ontstaan uit eerlijke gebruikerstest. Doorwerking: §11.16 (nieuw v3.0.1-blok dat UI-laag-restrictie documenteert; engine-laag ongewijzigd). SCHEMA-impact: defaults `g`/`g_y` van `'gemengd'` → `'M'` (potentieel breaking voor SCHEMA-clients die op default vertrouwden, maar geen bekende clients buiten onze eigen tests). Engine-impact: nul.

 **Reviewpunt-vlag voor §3.5-spreidings-formule + cosmetische correctie §3.10.** Geen wijziging van besluit, formule, SCHEMA of code; uitsluitend (a) toevoeging van nieuw §11.21-reviewpunt over wettelijke-canoniciteit van §3.5-spreidings-mechaniek, parallel aan §11.19 (vpvAftrekPct-bron-todo) en §11.20 (broken-heart-bron-todo), en (b) tikfout-correctie "gepensheerden" → "gepensioneerden" in §3.10 reviewpunt-tekst (open knelpunt 11 uit HANDOFF_combi_M2). **Aanleiding §11.21:** Hans verstrekte op 05-05-2026 een externe modelspecificatie (drs. ing. H. Haringa, "Bijlage 2 — Modelspecificatie", 02-05-2026, "SSPF vragen spreidingstermijn compleet model.pdf") die een eigen formele uitwerking van bijlage 2a Regeling Pw geeft. Het model gebruikt een lineaire spreidings-formule `q(h, N) = h/N` (per individu, per loopduur h, met spreidingstermijn N) en levert per-cohort-PV via een fonds-niveau-schalingsfactor `x* = (M − CW_voor) / CW*`. Onze huidige §3.5-implementatie gebruikt een R9.30-DNB-conforme cohort-gewogen formule met `dnbShareFactor(x, N) = 1 − ν(N)` en kvProfile-aanpak. **De twee formules zijn niet equivalent.** Numerieke verkenning uitgevoerd op 05-05-2026 (Q-D-test, gedocumenteerd in `/tmp/qd_v2.ts` ~210 regels) toont systematische verschillen op identieke demografie en sterftetafel (AG2024). Voor SSPF-anker-67M-OP-only-DG-1,15: R9.30-DNB-formule levert `+5,32%` opslag op KV; bijlage-2-lineair-formule levert `+3,59%` op CW_voor. Materieel verschil ~7% op individuele ppkTotal in dit scenario. Voor jongere cohorten en hogere DG (52M-DG-1,35) is de spec-gevoeligheid groter: R9.30-formule levert ~+30% opslag terwijl bijlage-2-lineair onder N=∞ tot +56,5% oplevert; verschil tussen N=10 en N=∞ binnen één formule is bestuurlijk relevant (Δ +25 procentpunten voor 52-jarige) maar voor SSPF-doelgroep 67+ marginaal (Δ <0,2 procentpunten). **Spec-claim "§3.5 R9.30-conform" is daarmee mogelijk overstated.** R9.30 vermeldt "DNB-spreidings-methode" maar of die identiek is aan bijlage 2a Regeling Pw §I-art-2 of een afleiding daarvan, is op 05-05-2026 niet bron-bevestigd. **Wat §11.21 beoogt:** brede formele uitwerking opzoeken, met bron-ladder primaire wet (`wetten.overheid.nl` bijlage 2a Regeling Pw) → DNB-Q&A's invaren/Wtp → Pensioenfederatie-implementatieleidraad → AG-rapporten → empirische sectorpraktijk (transitieplannen ABN/ABP/PMT/PFZW). Stop-criteria: zodra primaire wet of DNB-Q&A eenduidig antwoord geeft, lager-rangschikte bronnen worden niet meer geraadpleegd. **Wat §11.21 niet doet:** geen implementatie-keuze, geen alternatieve-formule-toevoeging, geen casual-UI-toggle, geen 67%-cap-implementatie (allemaal gereserveerd voor v2.2.14+ na bron-resultaat). Onze R9.30-DNB-formule blijft ongewijzigd actief in v2.2.13-engine; bestuurlijke disclaimer in audit-scherm wordt overwogen voor latere patch. **Loskoppeling van bestuurlijke deadline:** §11.21 wordt **bewust** losgekoppeld van het SSPF-bestuurlijke-vragen-traject (Hans 02-05-2026 SSPF-relatienummer xyz620620). Dat traject werkt met de bijlage-2-modelspecificatie als illustratief instrument; onze calculator is parallel onderzoeksinstrument, geen onderdeel van het SSPF-vragen-document. Dit voorkomt dat de spec onder externe deadline wordt geforceerd; v2.2.14+ kan op eigen tempo volgen. **Cosmetische correctie §3.10:** "gepensheerden" wordt "gepensioneerden" (ontbrekende "io"). Geen inhoudelijke verandering. **Werkafspraak-12 uitvoering:** v2.2.13 is de derde mini-patch ooit (na v2.2.8 type-cosmetiek en v2.2.12 numerieke-claim-correctie) zonder code-impact. Q-D-test-script blijft beschikbaar in werkmap voor latere reproductie en is verifieerbaar door derden. Doorwerking: §3.5 (geen wijziging formule; commentaar-blok aangevuld met v2.2.13-reservering-noot), §3.10 (tikfout gecorrigeerd; reviewpunt-bullet uitgebreid met §11.21-kruisverwijzing), §11 (nieuw §11.21 spreidings-formule-canoniciteit-onderzoek). SCHEMA-impact: nul. Engine-impact: nul. Numerieke impact: nul.

De spec is geschreven met *spec-met-reserveringen*-principe: ook verrijkingen die in R9.30 niet gebouwd zijn (geslacht, generatietafel, ervaringssterftefactor, kostenopslagen, partnerpensioen, betalingsfrequentie, SPR-varianten) krijgen een veld in het input-schema met een expliciete default die het huidige gedrag reproduceert. Hierdoor is `SCHEMA_v2.md` (sessie 2) een directe afgeleide van dit document en vraagt het geen tweede architectuur-ronde.

---

## §1. Vier-modules-model

De engine beantwoordt vier complementaire vragen. Drie daarvan vormen een keten, de vierde staat parallel:

```
  ┌──────────────────────────────────┐
  │ Module 1 — Huidige waarde        │  "Wat is uw pensioen nu waard?"
  │ → KV, levensverwachting          │
  └──────────────┬───────────────────┘
                 │
                 ▼
  ┌──────────────────────────────────┐
  │ Module 2 — Potje                 │  "Wat krijgt u mee uit de pot?"
  │ → potje, buffer-aandeel          │
  └──────────────┬───────────────────┘
                 │
                 ▼
  ┌──────────────────────────────────┐      ┌──────────────────────────────────┐
  │ Module 3 — Uitkeringsbenadering  │      │ Module 4 — Waardevergelijking    │
  │ → U_t banden, buffer-statistiek  │      │ → V_DB, V_Wtp, K_x, Δ            │
  └──────────────────────────────────┘      └──────────────────────────────────┘
                                             "Hoe verhoudt uw aanspraak zich
                                              pre- versus post-transitie?"
```

Modules 1, 2 en 3 vormen een **keten**: module 2 gebruikt de KV van module 1, module 3 gebruikt het potje en buffer-aandeel van module 2 plus de levensverwachting uit module 1. Module 4 staat **parallel**: zij leest rechtstreeks uit deelnemersinvoer en fondsparameterset, en gebruikt geen output van de eerste drie modules. Dit is een bewuste architecturale keuze — de waarderingsgrondslagen van module 4 (generatietafel, RTS, indexatiescenario's) zijn typisch anders dan de vereenvoudigde grondslagen van modules 1-3 (leeftijdstafel, vlakke rente, slider-inflatie). Zie §7 voor de consistentie-eisen die hieruit volgen.

De vier modules delen slechts twee bronnen: de deelnemersinvoer (leeftijd, pensioenbedragen, optioneel geslacht en partnerdata) en de `FONDS_DATASET` als parameter-bron. Maar ze gebruiken **verschillende deelverzamelingen** van de dataset. Module 1 gebruikt de sterftetafel. Module 2 gebruikt fondsbalans + compensatie + demografie + DNB-N. Module 3 gebruikt defaults-rate (projectie/rendement/volatiliteit/inflatie) + buffer. Module 4 gebruikt RTS + generatietafel + f + π_DB/π_Wtp + ρ + φ. Zie §8 voor de parameterset-overlap en de implicaties voor `SCHEMA_v2`.

Elke module wordt in dit document volgens een vaste substructuur beschreven: *vraag* / *input-deelnemer* / *input-fondsparameterset* / *output* / *formules* / *impliciete aannames* / *fallbacks* / *validaties* / *scope-voorbehouden* / *reviewpunten*. Module 4 wijkt af in zoverre dat de docx-paragraafindeling (§§5.1 t/m 5.13) is behouden; de inhoud van die paragrafen bestrijkt materieel dezelfde gebieden als de substructuur van modules 1-3.

### §1.1 Narratief kompas (v1.6)

Onder het technische ontwerp ligt een didactisch narratief dat sturend is voor alle ontwerpkeuzes in deze spec. Het narratief beantwoordt de kernvraag van de gebruiker: **wat gebeurt er met WTP-invaren op kapitaalniveau, hoe verhoudt zich dit tot wat er nu is en wat het gaat worden?**

**Drie narratieve momenten:**

1. **Nu** — de waarde van de aanspraak op peildatum, in de huidige regeling.
2. **Invaren** — wat er in het persoonlijke potje belandt op het transitiemoment.
3. **Straks** — het uitkeringspad na invaren, over de resterende jaren.

**Vier schermen, waarvan scherm 4 een regime-split van moment 1 is:**

- **Scherm 1 (module 1)** → anker voor *nu*. KV onder de eenvoudigste, juridisch zuivere aannames: de kale papieren aanspraak.
- **Scherm 2 (module 2)** → *invaren*. Het potje dat ontstaat bij transitie, als decompositie van dekking + overschot + compensatie.
- **Scherm 3 (module 3)** → *straks*. Het uitkeringspad met onzekerheidsbanden, de enige module die tijdsprojectie doet.
- **Scherm 4 (module 4)** → regime-split van moment 1. Geen nieuw moment, maar een *keuze-framing*: dezelfde aanspraak onder DB-voortzetting (V_DB) versus WTP-transitie (V_Wtp), beide vanuit peildatum.

**Sturend principe — "dezelfde aannames → hetzelfde getal" als ankerfunctie.**

Bij coherente aannames mag een getal op meerdere schermen hetzelfde zijn. Dit is geen redundantie die vermeden moet worden, maar een **anker** dat de gebruiker helpt te begrijpen dat schermen dezelfde werkelijkheid beschrijven. Bijvoorbeeld: KV (scherm 1) en V_DB (scherm 4 linkerkant) beschrijven beide "de aanspraak nu onder DB-voortzetting". Als de aannames identiek worden gemaakt (annuïteitsconventie, dekking, kosten, sterftetafel), zijn het dezelfde euro's. Verschillen die overblijven zijn dan *informatief* — ze dragen een boodschap, ze zijn geen rekenartefact.

**Twee soorten congruentie tussen modules:**

- **Structureel congruent.** Zelfde rekenformule en zelfde grondslagen. Verschillen komen dan louter uit verschillende parameterwaardes en zijn interpretabel.
- **Numeriek gelijk.** Structureel congruent én identieke parameterwaardes. Levert letterlijk hetzelfde bedrag.

Beide zijn legitieme ontwerpdoelen. Structureel congruent is de minimumeis voor uitlegbaarheid. Numeriek gelijk is wenselijk waar dezelfde vraag op meerdere plaatsen wordt gesteld (zoals KV vs V_DB onder gelijkgestelde aannames).

**Toetsing van besluiten aan dit kompas.** Elke open-vraag-resolutie in §11 moet aantoonbaar bijdragen aan de heldere navigatie van *nu → invaren → straks*, of de regime-split op scherm 4 scherper maken. Besluiten die dat niet doen worden heroverwogen. De reeds genomen besluiten (§11.1, §11.4, §11.5, §11.10, §11.13, §11.14, §11.15, §11.16, §11.17, §11.18) zijn met dit kompas achteraf consistent: zij brengen M1 en M4 structureel congruent op de dimensies die ertoe doen (annuïteitsconventie, dekking, partner, kosten, sterftetafel-aanpak, NP-integratie), waardoor het overblijvende cross-module verschil op scherm 4 juist de pedagogische payload (DB-indexatie versus WTP-rendement) kan dragen.

**NP-integratie binnen het narratief (v2.0).** Het invaren-moment wordt pedagogisch verfijnd door besluit §11.18: OP en NP zijn twee aanspraken op scherm 1 (UPO-herkenbaar), komen op scherm 2 samen in één persoonlijk pensioenvermogen met geoormerkte label, en worden op scherm 3 als één collectief kapitaal belegd waaruit zowel OP-uitkering als latent-NP-dekking worden gefinancierd. Dit matcht wat SSPF feitelijk gaat doen onder het WTP-standaardinvaarpad en maakt tegelijkertijd het educatieve moment mogelijk: *"uw twee aanspraken worden één kapitaal, maar blijven apart herkenbaar."*

---

## §2. Module 1 — Huidige waarde

### §2.1 Vraag

*Wat is mijn huidige pensioenaanspraak waard, gegeven mijn leeftijd en een gekozen rekenrente?* In v1.3 omvat "aanspraak" zowel het eigen ouderdomspensioen (OP) als het nabestaandenpensioen (NP) op het leven van de partner, indien aanwezig.

Module 1 levert de **kapitaalwaarde van de aanspraak** (uitgesplitst in KV_OP en KV_NP, met totaal KV) en een **verwachte sterfleeftijd** onder een standaard sterftetafel. De uitkomst is regime-agnostisch — zij hangt niet af van de keuze tussen DB-voortzetting of Wtp-transitie, en niet van de Wtp-regelingsvariant. Het is het meest basale antwoord dat de engine levert en het meest volwassen onderdeel van de huidige code; de NP-uitbreiding (v1.3, §11.5 besluit) is een structurele aanvulling die R9.30 nog niet kent.

### §2.2 Invoerschema — deelnemer

De deelnemersinvoer is minimaal en alleen gebaseerd op informatie die direct uit het UPO of de persoonlijke situatie beschikbaar is. Velden die in R9.30 nog niet actief zijn krijgen een expliciete default die het huidige gedrag reproduceert; zij zijn gereserveerd voor uitbreiding. In v1.3 (besluit §11.5) zijn de partner-gerelateerde velden geactiveerd voor de NP-component.

| Veld | Type | Verplicht | Default | Status v1 | Toelichting |
|---|---|---|---|---|---|
| `x₀` | decimal | ja | — | actief | Leeftijd deelnemer op peildatum, in jaren (fractioneel toegestaan) |
| `pen` | decimal ≥ 0 | ja | — | actief | Jaarlijks bruto ingegaan ouderdomspensioen in euro (OP) |
| `g` | enum {M, V, gemengd} | nee | `gemengd` | **actief (v1.7)** | Geslacht deelnemer; keuze M of V activeert AG2024-tafel per geslacht, `gemengd` is fallback met populatie-weging (zie §2.5). UI toont waarschuwing bij `gemengd` voor bekend-geslacht gebruik |
| `heeftPartner` | boolean | nee | `false` | actief (v1.3) | Of er een nabestaandenpensioen-aanspraak is; bij `false` worden onderstaande partner-velden genegeerd |
| `y₀` | decimal ≥ 0 | voorwaardelijk | `0,70 × pen` (fallback) | actief (v1.3) | Jaarlijks bruto NP-aanspraak in euro; verplicht als `heeftPartner=true` en bekend; anders fallback 70% van OP |
| `x_partner` | decimal | voorwaardelijk | — | actief (v1.3) | Leeftijd partner op peildatum; verplicht als `heeftPartner=true` |
| `g_y` | enum {M, V, gemengd} | nee | `gemengd` | **actief (v1.7)** | Geslacht partner; identiek behandeld als `g` — UI-waarschuwing bij `gemengd` voor bekend geslacht |

### §2.3 Invoerschema — fondsparameterset

| Veld | Type | Verplicht | Default | Status v1 | Toelichting |
|---|---|---|---|---|---|
| `r` | decimal | ja | 0,02 (2%, v1.8) | actief | Rekenrente voor discontering. v2.1: UI-primaire rente-slider; default gekoppeld aan M3-`proj` en M4-`i` (zie §11.3). Ontkoppeling via "geavanceerd"-toggle voor audit/debug |
| `sterftekansTabelId` | string | ja | `'AG2024'` | actief (v1.7) | Identificatie van de tafel; v1.7 gebruikt de officiële AG2024-prognosetafel (publicatie KAG 12-09-2024). Vervangt R9.30-mengtafel die als `'AG2022'` was gelabeld. |
| `q_{x,t,g}` | 2D-map per geslacht → decimal | ja | uit tabel-ID | actief (v1.7) | AG2024 prognosetafel: sterftekansen voor leeftijden 0–120, projectiejaren 2022–2200, per geslacht (M/V). In M1-3 (periode-snapshot v1.7) wordt alleen kolom `t₀` gebruikt; M4 gebruikt diagonaal voor cohort |
| `q_x` (gemengd) | map int → decimal | nee | berekend uit q_M en q_V | afgeleid (v1.7) | Gemengde tafel voor fallback-scenario; populatie-gewogen samenstelling, zie §2.5 |
| `t₀` | integer | nee | 2026 | **actief (v1.7; verplaatst v2.2.9)** | Projectiejaar voor AG2024-kolomselectie; v1.7 gebruikt periode-snapshot (zelfde kolom voor alle toekomstige leeftijden). Zie §2.5 en §11.16. Parallel aan M3 §4.3 t₀-rij voor cross-module symmetrie |
| `f(x,g)` | scalar → decimal | nee | 1,0 | actief (v1.4) | Ervaringssterftefactor, multiplicatief op q. v1.4/v2.2.8: scalar conform §11.13-besluit; SSPF-waarde 1,0 als placeholder tot bron beschikbaar. Leeftijds-/geslachts-afhankelijke map-vorm is v2-uitbreidingspad (minor SCHEMA-bump bij activering) |
| `m` | int ∈ {1,4,12} | nee | 12 | actief (v1.2) | Betalingsfrequentie; v1.2: maandbasis conform fondsuitbetalingspraktijk |
| `π` | decimal | nee | 0 | actief (v1.6) | Indexatie op aanspraak tijdens waardering; v1.6/v2.2.8: scalar conform §11.15-besluit, waarde 0 als bewust anker (kale papieren aanspraak). Zie §1.1, §11.15. Tijdsafhankelijke vector-vorm is v2-uitbreidingspad (minor SCHEMA-bump bij activering) |
| `ρ` | decimal | nee | 0,02 (afgeleid of fallback) | actief (v1.5) | Cumulatieve kostenopslag op KV; afgeleid uit `c_jaar × ä(x, r)` of direct dataset-veld, met ultieme default 0,02. Zie §2.5, §2.7 |
| `ω` | integer | nee | 100 | actief | Eindleeftijd sterftetafel |
| `annuïteitsconventie` | enum {due, arrears} | nee | `arrears` | actief (v1.2) | v1.2: arrears (eerste betaling op tijd 1/m), uniform cross-module |

### §2.4 Output

| Veld | Type | Toelichting |
|---|---|---|
| `KV_OP` | decimal ≥ 0 | Kapitaalwaarde eigen OP-aanspraak in euro |
| `KV_NP` | decimal ≥ 0 | Kapitaalwaarde NP-aanspraak in euro; 0 als `heeftPartner=false` |
| `KV` | decimal ≥ 0 | Totaal: KV_OP + KV_NP |
| `ä(x₀, r)` | decimal ≥ 0 | Annuïteitsfactor deelnemer; deelresultaat |
| `ä(x_partner, r)` | decimal ≥ 0 of `null` | Annuïteitsfactor partner; `null` als geen partner |
| `lifeExp(x₀)` | decimal | Verwachte sterfleeftijd deelnemer onder de gebruikte tafel; niet de resterende levensverwachting |
| `lifeExp(x_partner)` | decimal of `null` | Verwachte sterfleeftijd partner; `null` als geen partner |

### §2.5 Formules

**Overlevingskans** (v1.7 — AG2024 periode-snapshot per geslacht):

```
ℓ^g_{x+t} = ∏_{s=0}^{t-1} (1 − q^fonds_{x+s, g})

met q^fonds_{x+s, g} = f · q^AG2024_{x+s, t₀, g}
```

Toelichting: AG2024 publiceert q_{x,t,g} voor x ∈ [0,120], t ∈ [2022,2200], g ∈ {M,V}. De v1.7-gebruikswijze in M1-3 is **periode-snapshot**: voor een gegeven projectiejaar `t₀` (default 2026) wordt één kolom uit de AG2024-tabel genomen en voor alle toekomstige leeftijden van de deelnemer gebruikt — alsof de sterftekansen van `t₀` voor altijd zouden gelden. Dit wijkt af van de cohort-interpretatie die in M4 wordt gebruikt (zie §5.5.2), waarin q^{fonds}_{x+s, t₀+s, g} — diagonaal door de tabel — de juiste referentie is. Voor SSPF-gepensioneerden is het verschil in levensverwachting <1% over de relevante horizon; de didactische eenvoud van periode-snapshot weegt voor M1-3 zwaarder dan de marginale actuariële verfijning van cohort.

**Gemengde tafel** (alleen fallback, als `g = gemengd`):

```
q^mix_{x, t₀} = w_M(x) · q^AG2024_{x, t₀, M}  +  w_V(x) · q^AG2024_{x, t₀, V}

met w_M(x), w_V(x) = populatie-gewicht per leeftijd uit CBS-bevolkingsstatistiek
     (w_M + w_V = 1; voor leeftijd 65+ typisch w_M ≈ 0,45, w_V ≈ 0,55)
```

De populatie-weging per leeftijd wordt eenmalig samengesteld uit CBS-demografie en opgenomen in FONDS_DATASET onder `demografie.genderWegingNL` als map. Dit maakt de fallback-tafel bronhoudbaar en reproduceerbaar. De gemengde tafel wordt alleen opgeroepen bij expliciete `gemengd`-keuze van deelnemer/partner; UI toont dan een waarschuwing dat gender-specifieke keuze accurater is.

**Annuïteitsfactor — v1.2 default (arrears, m=12)**:

De primaire berekening in v1.2 hanteert maandbasis achteraf (arrears), conform fondsuitbetalingspraktijk en cross-module consistentie met module 4. De algemene formule luidt:

```
ä^(m)(x, r; π, f, ω) = (1/m) · Σ_{k=1}^{m·(ω−x)} (1+π)^{k/m} · _{k/m}p_{x} · (1+r)^{-k/m}

(arrears: sommatie start bij k=1)
```

In v1.2 met `π=0`, `f=1`, `m=12`, `ρ=0` reduceert dit tot:

```
ä(x₀, r) = (1/12) · Σ_{k=1}^{12·(ω−x₀)} _{k/12}p_{x₀} · (1+r)^{-k/12}

met _{k/12}p_{x₀} = lineaire interpolatie tussen jaarlijkse overlevingskansen ℓ_{x₀+⌊k/12⌋} en ℓ_{x₀+⌊k/12⌋+1}
```

**Horizon-cap onder m=12.** `T_eff` blijft in jaren uitgedrukt: `T_eff = min(ω−x, 55, t zodat ℓ_{x+t} < 0,001)`. De sommatie loopt tot `k = m · T_eff`.

**Kapitaalwaarde**:

```
KV_OP    = (1 + ρ) · pen · ä(x₀, r)
KV_NP    = (1 + ρ) · y₀ · ä(x_partner, r)     indien heeftPartner, anders 0
KV       = KV_OP + KV_NP
```

In v1.3 met `ρ=0` vereenvoudigt dit tot `KV_OP = pen · ä(x₀, r)` en `KV_NP = y₀ · ä(x_partner, r)`. In v1.5 is `ρ` niet meer 0; zie hieronder voor afleiding.

**Kostenopslag ρ — v1.5 afleiding (Variant A)**:

De kostenopslag wordt afgeleid uit de jaarlijkse uitvoeringskostenquote vermenigvuldigd met de annuïteitsfactor (cumulatief over resterende uitkeringsjaren):

```
c_jaar = uitvoeringskostenJaarlijks / fondsvermogen       # jaarlijkse kostenquote
ρ       = c_jaar · ä(x, r)                                 # cumulatief op KV
```

**Fallback-ladder** (hoog naar laag prioriteit):

1. Beide velden beschikbaar → `ρ` afgeleid via bovenstaande formule (primair).
2. Alleen `beleid.kostenOpslagPct` beschikbaar → `ρ = beleid.kostenOpslagPct` direct.
3. Geen van beide beschikbaar → **ρ = 0,02** (ultieme default).

De ultieme default (0,02) is **niet** nul, wat afwijkt van het spec-met-reserveringen-principe (§12.5). Rationale: ρ=0 rekent de KV systematisch te hoog ("rekent rijk") en creëert een uitlegbaarheidsprobleem bij de WTP-transitie wanneer potje en uitkering lager uitvallen dan scherm 1 deed vermoeden. 2% cumulatief op KV is aan de lage kant van realistische uitvoeringskostendepots voor grote Nederlandse fondsen (typisch 2–5%); een conservatieve placeholder totdat SSPF-specifieke bron beschikbaar is.

**Voorbeeld.** Bij SSPF met fondsvermogen €20 mld en hypothetische uitvoeringskosten €50 mln/jaar: `c_jaar = 0,25%`; voor 70-jarige met `ä(70, 0,02) ≈ 14,5` geldt `ρ ≈ 3,6%`. Voor 80-jarige met kortere annuïteit geldt `ρ ≈ 2,5%`.

**Leeftijdsafhankelijkheid van ρ.** Omdat ρ via ä(x, r) wordt berekend, is ρ impliciet leeftijdsafhankelijk: jongere gepensioneerden dragen langer de kostenlast en krijgen een hogere cumulatieve opslag dan ouderen. Dit is zowel wiskundig als conceptueel correct.

**NP-waardering — v2.2.11 joint-life met broken-heart-correctie (vervangt v1.3-bovengrens):**

KV_NP wordt vanaf v2.2.11 berekend als joint-life-annuïteit met conditionele kans op uitkering en sterftekans-schock op overlevende partner:

```
KV_NP = (1+ρ) · y₀ · ä_{x|y}(r)

ä_{x|y}(r) = (1/m) · Σ_{k=1}^{m·T_eff} (1+π)^{k/m} · _{k/m}q_x · _{k/m}p_y^{bh} · (1+r)^{−k/m}
```

waar:
- `_{k/m}q_x = 1 − _{k/m}p_x` = kans dat deelnemer in [0, k/m] is overleden
- `_{k/m}p_y^{bh}` = broken-heart-gecorrigeerde overlevingskans van partner (zie hieronder)
- T_eff = `min(ω−x_partner, 55, t zodat ℓ_{partner}(t) < 0,001)` (consistent met §2.5 hoofdformule)
- Onafhankelijkheidsaanname `_{k/m}p_{x y} = _{k/m}p_x · _{k/m}p_y` blijft v1; gedeelde-levensomstandigheden-correlatie niet gemodelleerd (zie §2.6 aanname 7)

**Broken-heart-multiplier (§11.20 placeholder, AG-2018-bron beoogd):**

Na deelnemer-overlijden op tijdstip τ ∈ [0, k/m] krijgt overlevende-partner-q een tijds-afhankelijke schock:

```
bh(τ_dood, g_partner) = bh₀(g) − (bh₀(g) − 1) · (τ_dood / 5)    voor τ_dood ∈ [0, 5]
                      = 1                                          voor τ_dood > 5

bh₀(M) = 1,50    (overlevende man na vrouwelijke partner)
bh₀(V) = 1,25    (overlevende vrouw na mannelijke partner)
```

Effective `q_y(t | deelnemer dood τ_dood jaar geleden) = bh(τ_dood, g_y) · q_y(t)`.

Engine-implementatie van `_{k/m}p_y^{bh}`: per sub-periode k/m wordt over alle mogelijke deelnemer-overlijdens-tijdstippen geïntegreerd, met bijbehorende geschokte partner-overlevingskansen. Wiskundig:

```
_{k/m}p_y^{bh} = ∫₀^{k/m} f_x(τ) · _{k/m}p_y^{bh,τ} dτ + (1 − _{k/m}q_x) · _{k/m}p_y
```

waar `f_x(τ)` de overlijdens-dichtheid van deelnemer is en `_{k/m}p_y^{bh,τ}` de partner-overlevingskans onder schok bh(t−τ, g_y) voor t ∈ [τ, k/m]. Implementatie via convex-combinatie sterftepad-paren in engine-laag.

**Ingegaan-NP-reductie:** Voor partner waarvan NP al ingaat (deelnemer reeds overleden voor peildatum) wordt `_{k/m}q_x = 1` voor alle k → formule reduceert naar oorspronkelijke `(1+ρ)·y₀·ä(x_partner, r)` met optioneel bh-schok zolang τ_dood < 5 jaar. Engine-detectie via deelnemer-flag.

**v2.2.11 numerieke impact** (Henk-Anna-typisch, x=68M, x_partner=66V, y₀=€14.000, r=0,02):
- v1.3 bovengrens: KV_NP ≈ y₀·ä(66V) ≈ €14k·16,6 ≈ €232k
- v2.2.11 joint-life met bh: KV_NP ≈ €90k–€110k afhankelijk van bh-kalibratie (60-65% verlaging t.o.v. bovengrens)
- Effect op KV_totaal: −15% tot −25% afhankelijk van NP-aandeel

**v1.3 → v2.2.11 migratie-noot:** Voor v1.3-conform regime (R9.30-baseline-vergelijking) blijft de oude formule `KV_NP = y₀·ä(x_partner, r)` opvraagbaar als debug-flag, niet via dataset; identiek patroon als `due/jaarbasis` bij §2.5 v1.2.

**M3/M4-koppeling (v2.2.11 bewust asymmetrisch):** §4.5 `U₀_NP = ppk_NP/ä(x_partner, proj, g_y)` blijft onafhankelijkheids-aanname zonder broken-heart; M3 wordt mechanisch geraakt via verlaagde `ppk_NP`-input uit M2-keten (M1 KV_NP-verlaging → M2 ppk_NP-verlaging → M3 U₀_NP-verlaging) maar M3-formule zelf ongewijzigd. §5.12.3 (M4-V_x^PP) idem ongewijzigd. Spec-incoherentie tussen modules is bewust en tijdelijk; volledige resolutie volgt bij M3/M4-implementatie. Zie §2.10 reviewpunt + §4.9 + §5.12.3 voor cross-module-status.

**R9.30-baseline (due, jaarbasis) — historisch, niet-normatief in v1.2**:

Voor vergelijking met huidige code-output:

```
ä_R9.30(x, r) = Σ_{t=0}^{T_eff} ℓ_{x+t} / (1+r)^t
```

Het verschil `ä_R9.30 − ä_v1.2` is typisch 0,5–1% voor gepensioneerden (x ≥ 65). Deze formule is geen fallback maar een debug-referentie tijdens migratie van R9.30 naar v1.2.

**Levensverwachting** (curtate + halfjaar-correctie):

```
lifeExp(x) = x + Σ_{t=1}^{T_eff} ℓ_{x+t} + 0,5
```

De +0,5 corrigeert voor het feit dat overlijden gemiddeld halverwege een jaar plaatsvindt; deze formulering sluit aan bij hoe CBS en AG2022 levensverwachting rapporteren.

### §2.6 Impliciete aannames

1. **Gender-specifieke tafel als primair (v1.7, §11.16 besluit).** Gebruikers kiezen direct M of V; AG2024 publiceert aparte sterftekansen per geslacht en het verschil is educatief significant (~9,7% op annuïteit). `gemengd` is alleen fallback-optie voor onbekend/anders, met populatie-gewogen samenstelling uit CBS-demografie. Dit is een wijziging t.o.v. v1-v1.6 waarin `gemengd` default was.
2. **AG2024 periode-snapshot in M1-3, cohort in M4 (v1.7).** AG2024 is een prognosetafel met kalenderjaar-dimensie. Voor M1-3 wordt in v1.7 de periode-snapshot-gebruikswijze gekozen (één kolom `t₀=2026` voor alle toekomstige leeftijden), als didactisch eenvoudige benadering. M4 gebruikt cohort-interpretatie (diagonaal q_{x+t, t₀+t, g}); zie §5.5.2. Periode-snapshot onderschat levensverwachting marginaal (<1% op KV voor gepensioneerden) t.o.v. cohort; de eenvoud weegt zwaarder in M1-3-context.
3. **Ervaringssterftefactor als structurele parameter (v1.4, §11.13 besluit).** Fondsspecifieke afwijkingen van populatiesterfte worden via scalar `f` (multiplicatief op q) meegenomen. In v1.4 heeft SSPF `f = 1,0` als placeholder-waarde; een SSPF-specifieke bron (Implementatieplan, jaarverslag, of AG2022-fondsklasse-factor) kan dit later invullen zonder spec-wijziging. Voor academisch/hogere-inkomens populaties is `f` typisch 0,85–0,95 (5–15% lagere sterfte); dit zou KV met 2–4% verhogen.
4. **Arrears, maandbasis (m=12).** Eerste betaling op tijd 1/12 (eind van eerste maand). Dit representeert de SSPF-uitbetalingspraktijk (maandelijks achteraf) direct en is cross-module consistent met module 4. De R9.30-code (due jaarbasis) wordt in v1.2 gedeprecieerd; zie §2.5 voor de relatie.
5. **Kostenopslag ρ expliciet, niet-nul default (v1.5, §11.14 besluit).** KV wordt met factor `(1+ρ)` opgehoogd voor uitvoeringskostendepot. ρ wordt bij voorkeur afgeleid uit `c_jaar × ä(x, r)` waar `c_jaar = uitvoeringskostenJaarlijks / fondsvermogen`; ultieme fallback ρ=0,02. Dit is een bewuste afwijking van het reproduceerbaarheid-principe: ρ=0 rekent rijk en bemoeilijkt de uitleg van lagere uitkering na WTP. Zie §2.5 voor afleiding en §12.5 voor principeafwijking.
6. **π = 0 als bewust anker (v1.6, §11.15 besluit).** KV in M1 wordt zuiver nominaal gewaardeerd: de contantwaarde van de huidige jaarrente zonder indexatie-correctie. Dit is niet een vereenvoudiging bij gebrek aan beter, maar een *ontwerpkeuze* die scherm 1 positioneert als "de kale papieren aanspraak" — het anker waartegen scherm 4 het indexatie-effect onder DB (π^DB > 0) en het rendements-effect onder WTP toont. Scherm 3 brengt indexatie binnen via projectierendement op potje-basis; scherm 4 brengt het binnen via V_DB en V_Wtp. Drievoudige modellering van hetzelfde fenomeen wordt hiermee voorkomen. Zie §1.1 narratief kompas.
7. **Partnerpensioen als joint-life met broken-heart-correctie (v2.2.11, §2.10 + §11.20).** KV_NP wordt sinds v2.2.11 berekend als `(1+ρ)·y₀·ä_{x|y}(r)` met conditionele kans `_{k/m}q_x · _{k/m}p_y^{bh}` per maandelijkse periode (kans deelnemer dood × kans partner levend, met broken-heart-schok op overlevende-q). Onafhankelijkheid `_{k/m}p_{x y} = _{k/m}p_x · _{k/m}p_y` blijft v1-aanname (gedeelde levensomstandigheden niet gemodelleerd); broken-heart-multiplier wel via `bh(τ, g_y)`-factor lineair dempend over 5 jaar (default `bh(0,M)=1,50`, `bh(0,V)=1,25` als AG-2018-bron-placeholder, zie §11.20). Voor ingegaan NP (deelnemer reeds overleden) reduceert formule naar oorspronkelijke `y₀·ä(x_partner, r)`. Vervangt v1.3-bovengrens-aanname (Optie 2 in §11.5 besluit). Numerieke impact: KV_NP −30% tot −60% per geval afhankelijk van leeftijdsverschil; voor Henk-Anna-typisch ~62% verlaging t.o.v. v1.3-bovengrens. Zie §2.5 voor formule + engine-implementatie-noot.
8. **Leeftijd gecapt op ω−1 bij annuïteit-evaluatie.** De huidige code gebruikt `min(age, 99)` om een vloer van één jaar verwachte duur te garanderen voor honderdjarigen.
9. **Triple horizon-cap.** `T_eff = min(ω−x, 55, t zodat ℓ < 0,001)`. De 55-jaars cap is hard en bindt voor jongeren (25-jarigen stoppen op 80); voor gepensioneerden is de overlevingsdrempel typisch eerder bindend.

### §2.7 Fallbacks

| Ontbrekend veld | Fallback | Impact |
|---|---|---|
| `r` | Dataset-default uit `beleid` of `defaults` | Geen; dataset-default is een bewust ijkpunt |
| `g` | `gemengd` met populatie-weging | Waarschuwing in UI; accuracy ~3% lager dan expliciete M/V-keuze |
| `t₀` | 2026 (SSPF-peildatum) | v1.7 gebruikt periode-snapshot; default reflecteert huidig jaar |
| `f` | 1,0 | Mogelijk enkele procenten afwijking voor fondsen met afwijkend populatieprofiel |
| `ρ` — primaire bron | `c_jaar × ä(x, r)` met `c_jaar = uitvoeringskostenJaarlijks / fondsvermogen` | Meest nauwkeurig; leeftijdsafhankelijk |
| `ρ` — secundaire bron | `beleid.kostenOpslagPct` direct | Constant over leeftijden |
| `ρ` — ultieme default | 0,02 | v1.5-placeholder; KV ~2% hoger dan kale aanspraak |
| `ω` | 100 | Consistent met huidige `MAX_AGE`-constante |
| `heeftPartner` | `false` | KV_NP = 0; KV = KV_OP alleen |
| `y₀` bij `heeftPartner=true` | `0,70 × pen` | Wettelijke NP-ratio; typisch binnen 5-10% van werkelijke waarde |
| `x_partner` bij `heeftPartner=true` | — (hard vereist) | Hard reject; partner-leeftijd kan niet worden afgeleid |
| `g_y` | `gemengd` | Zelfde impact als `g` |

### §2.8 Validaties

| Categorie | Regel | Actie bij schending |
|---|---|---|
| Invoerbereik | 0 ≤ x₀ ≤ ω | Hard reject: ongeldige leeftijd |
| Invoerbereik | `pen` ≥ 0 | Hard reject |
| Parameterbereik | −0,02 ≤ r ≤ 0,10 | Waarschuwing; resultaat wel berekend |
| Data-integriteit | q_x gedefinieerd voor alle benodigde x ∈ [x₀, ω] | Hard reject: tafel incompleet |
| Consistentie | sterftekansTabelId ∈ bekende engine-tabellen | Hard reject bij onbekende ID |
| Data-integriteit (v1.7) | q_{x,t,g} gedefinieerd voor alle benodigde (x, t₀, g) uit AG2024 | Hard reject |
| Parameterbereik (v1.7) | 2022 ≤ t₀ ≤ 2200 | Hard reject buiten AG2024-range |
| Gender (v1.7) | `g` ∈ {M, V, gemengd} | Waarschuwing bij `gemengd`-keuze als UI-signaal dat specifieke keuze accurater is |
| Partner (v1.3) | `heeftPartner=true` ⇒ `x_partner` gegeven en `0 ≤ x_partner ≤ ω` | Hard reject |
| Partner (v1.3) | `y₀` ≥ 0 | Hard reject |
| Partner (v1.3) | `y₀` ≤ 2 × `pen` | Waarschuwing (onwaarschijnlijke NP-ratio); resultaat wel berekend |
| Kosten (v1.5) | 0 ≤ ρ ≤ 0,20 | Waarschuwing bij ρ > 0,10 (hoge opslag); hard reject bij ρ < 0 of ρ > 0,20 |

### §2.9 Scope-voorbehouden

- **Geen regelingsverschil.** KV is regime-agnostisch. De Wtp-regelingskeuze (FPR, SPR-clean, SPR-hybride) beïnvloedt module 1 niet.
- **Partnerpensioen als bovengrens (v1.3).** NP wordt als aparte KV-regel meegenomen onder aanname van onafhankelijke levens. Voor ingegaan NP exact; voor latent NP bovengrens (zie §2.5, §2.10). Joint-life verfijning is v2-reservering.
- **Geen indexatieprojectie.** Het verschil tussen nominale en reële waarde op toekomstige tijdpunten is het domein van module 3 (pad) of module 4 (puntwaardering onder scenario's), niet van module 1.

### §2.10 Reviewpunten

- **~~Annuity-due versus arrears.~~** ~~Module 1 hanteert annuity-due (eerste betaling op tijd 0); module 4 hanteert arrears (eerste betaling op tijd 1/m). Het numerieke verschil is voor gepensioneerden klein (~0,5–1%) maar systematisch. Voor interpretatie-consistentie zou v1 één conventie kunnen afdwingen; voor code-stabiliteit houdt v1 beide conventies naast elkaar. Zie §10 voor de cross-module behandeling.~~ **Opgelost in v1.2 (besluit §11.4, 23-04-2026 09:53):** uniform arrears m=12 cross-module.
- **~~Onregelmatigheid in Q rond leeftijd 62-69.~~** ~~De huidige tafel kent kleine niet-monotoniciteiten (Q[66] < Q[65], Q[68] < Q[67]) die niet in codecommentaar zijn verklaard.~~ **Opgelost in v1.7 (besluit §11.16, 23-04-2026 11:58):** R9.30 Q-tafel gedeprecieerd; vervangen door AG2024-prognose per geslacht. De anomalie Q[62]=0,00945 → Q[63]=0,00748 is bevestigd als data-entry-fout — AG2024 geeft monotoon 0,00671 → 0,00749 → 0,00811.
- **~~Leeftijdstafel versus AG2022-generatietafel.~~** ~~De opschaling van `q_x` naar `q_{x,t}` is technisch licht maar semantisch substantieel.~~ **Opgelost in v1.7 (besluit §11.16):** AG2024 is een prognose-(generatie-)tafel die in M1-3 als periode-snapshot wordt gebruikt (één kolom t₀) en in M4 als cohort (diagonaal). De tafel is in beide gebruikswijzen dezelfde bron, wat §11.10 besluit invult.
- **~~Kostenopslag ρ.~~** ~~Ontbreekt in v1; toevoeging kan een enkele procent op KV opleveren. Beleidsmatig interessant als de calculator ook als deelnemer-equivalent van de VPV wil dienen.~~ **Opgelost in v1.5 (besluit §11.14, 23-04-2026 10:24):** ρ structureel actief met afleidingsformule `ρ = c_jaar × ä(x, r)`, fallback-ladder en ultieme default 0,02. Zie §2.5, §2.7.
- **~~NP als bovengrens in plaats van joint-life (v1.3).~~** ~~De v1.3-aanname `KV_NP = y₀ · ä(x_partner, r)` overschat de werkelijke NP-waarde bij latent NP (uitkering begint pas bij overlijden deelnemer). Exacte formulering vereist joint-life annuïteit `ä_{x|y}(r) = Σ (1 − ℓ_x(t)) · ℓ_y(t) · v^t`. Voor gepensioneerden met vergelijkbare leeftijd is het verschil typisch 10-20% op KV_NP (dus enkele procenten op KV totaal). Aanbevolen voor v2.~~ **Opgelost in v2.2.11 (04-05-2026 23:37):** joint-life met broken-heart-correctie geactiveerd voor M1; formule `KV_NP = (1+ρ)·y₀·ä_{x|y}(r)` met `ä_{x|y}(r) = (1/m)·Σ(1+π)^{k/m}·_{k/m}q_x·_{k/m}p_y^{bh}·(1+r)^{−k/m}`. Onafhankelijkheidsaanname behouden; broken-heart-schok via `bh(τ, g_y)`-multiplier (AG-2018-bron-placeholder, §11.20). Numerieke impact: −30% tot −60% op KV_NP, −10% tot −25% op KV-totaal. **M4-spiegel (v2.2.3) — v2.2.11 bewust asymmetrisch:** §5.12.3 (M4-V_x^PP) en §4.9 (M3-U₀_NP) blijven in v2.2.11 op de oude onafhankelijkheids-aanname zonder broken-heart-correctie. M3 wordt mechanisch geraakt via verlaagde `ppk_NP`-input uit M2-keten; M3-formule zelf ongewijzigd. M4 vereist eigen patch bij M4-implementatie. v2.2.3-werkafspraak ("gekoppeld v2-pad") expliciet doorbroken voor pragmatische β-keuze: M1-effect zichtbaar maken op concreet publieksvoorbeeld vóór M3/M4 bouw. Volledige resolutie cross-module bij M3/M4-implementatie.
- **Partner-geslacht in v1.3 op gemengd.** Als `g` en `g_y` verschillen (typisch: man M, vrouw V) zou differentiatie per geslacht KV_NP enkele procenten verschuiven; vrouwen leven gemiddeld langer dus KV_NP bij `g_y=V` is hoger. Zie §11.10 besluit (twee tafels naast elkaar); activering van `g`/`g_y` is een v2-actie.

---

## §3. Module 2 — Potje

### §3.1 Vraag

*Wat krijg ik uit het fondsvermogen meegeleverd bij invaren, gegeven mijn eigen KV en de fondsbalans?*

Module 2 is de **toedelingsengine** van de calculator. Zij verdeelt het verdeelbare fondsvermogen op basis van persoonlijke KV, fondsdekkingsgraad, DNB-spreidingsmethode en een Gaussische compensatie-curve. De berekening is **empirisch-boekhoudkundig**: zij modelleert hoe een fondsbestuur bij invaren verdeelt, niet hoe een actuaris waardeert. De docx-specificatie module 4 gebruikt daarentegen een formele toedelingsfactor `φ`; module 2 heeft die factor impliciet in `(kv/vpvTotal) × surplus × sFactor × nFactor`. Zie §3.10 en §10 voor de relatie.

### §3.2 Invoerschema — deelnemer

Module 2 ontvangt deelnemersgegevens primair via de keten van module 1:

| Veld | Type | Verplicht | Herkomst | Toelichting |
|---|---|---|---|---|
| `x₀` | decimal | ja | deelnemersinvoer | Leeftijd; gebruikt voor DNB-spreiding en compensatie-curve |
| `pen` | decimal ≥ 0 | ja | deelnemersinvoer | Jaarbedrag; nodig voor KV-berekening |
| `KV` | decimal ≥ 0 | ja | **module 1** | Persoonlijke kapitaalwaarde |

### §3.3 Invoerschema — fondsparameterset

| Veld | Type | Verplicht | Default | Status v1 | Toelichting |
|---|---|---|---|---|---|
| `fondsvermogen` | decimal > 0 | ja | — | actief | In mln euro |
| `dekkingsgraad` | decimal | ja | — | actief | Fractie, typisch 1,0–1,5 |
| `compensatiedepot` | decimal ≥ 0 | ja | 0 | actief | In mln euro; reservering voor afschaffing doorsneesystematiek. **v2.2.10**: blijft expliciet apart van `vpvAftrekPct`-bundle om bell-curve-input behouden te houden (Model C). LET OP bij ABN-bron: ABN's gepubliceerde `vpvAftrekPct=0,10` bevat compensatiedepot wél; bij overname als referentie eerst decomposeren. Zie §3.10 dubbele-administratie-reviewpunt |
| `vpvAftrekPct` | decimal ∈ [0, 0,30] | ja | 0,10 | **actief (v2.2.10)** | Fractie van `vpvTotal`; bundle-aftrek voor VEV + operationele reserve + solidariteitsreserve + inhaalindexatie (alles behalve `compensatiedepot`). Default 0,10 ABN-conservatief (transitieplan ABN AMRO Pensioenfonds 17-10-2024 + implementatieplan 22-09-2025; geverifieerd via DG-115%/125%/135% bundle-toelichting in CRM-2026-34 dossier 2025-0107: 5%/15%/25% verdeelbaar overschot na aftrek). SSPF-bron-todo §11.19. Zie ook UI-disclosure-eis in §3.10 (ABN-mix-waarschuwing) |
| `overigeReserves` | decimal ≥ 0 | ja | 0 | **deprecated v2.2.10** | In mln euro; RDR, overige onttrekkingen. Behouden voor backward-compat met v2.1.x-datasets; door v2.2.10-engine niet meer gelezen (vervangen door `vpvAftrekPct`-bundle). Bij gelijktijdig gevuld én `vpvAftrekPct` gevuld: superRefine-waarschuwing |
| `operationeleReserveringPct` | decimal ≥ 0 | ja | 0,02 | **deprecated v2.2.10** | Fractie van fondsvermogen. Behouden voor backward-compat met v2.1.x-datasets; door v2.2.10-engine niet meer gelezen (vervangen door `vpvAftrekPct`-bundle, grondslag-shift naar vpv conform ABN-praktijk). Bij gelijktijdig gevuld én `vpvAftrekPct` gevuld: superRefine-waarschuwing |
| `bijstort` | decimal ≥ 0 | ja | 0 | actief | In mln euro; werkgeversbijdrage bij transitie |
| `N_deelnemers` | integer > 0 | ja | — | actief | Totaal aantal deelnemers voor normalisatie |
| `spreidingN` | integer ∈ [0,30] | ja | 10 | actief | DNB-spreidingstermijn in jaren. Wettelijke standaard art. 2 lid 1 Bijlage 2a Regeling Pensioenwet; afwijken alleen onder voorwaarden art. 2 lid 3. **v2.2.10**: SCHEMA-`uiDisclosure` op dit veld verwijst naar CRM-2026-34 (04-03-2026) dat het indirect-onderscheid-karakter en de objectieve rechtvaardiging van de 10-jaars termijn vastlegt; transparantie-eis voor publieke calculator |
| `compensatieMu` | decimal | ja | 55 | actief | Leeftijd-middelpunt Gaussische compensatie-curve |
| `compensatieSigma` | decimal > 0 | ja | 8 | actief | Standaardafwijking compensatie-curve |
| `buffer` | decimal ≥ 0 | ja | 0 | actief | In mln euro; afgezonderd voor module 3 (scherm-3-demping) |
| `demografie.preset` of `.customCounts` | enum of vector[15] | ja (exact één) | — | actief | Populatieverdeling over 15 cohorten (25..99, per 5 jaar) |
| `φ(x)` | scalar of map int→decimal | nee | impliciet berekend | gereserveerd | Expliciete toedelingsfactor; alternatief rekenpad |

### §3.4 Output

| Veld | Type | Toelichting |
|---|---|---|
| `ppkBase` | decimal ≥ 0 | Dekking-deel: KV_totaal × min(1, verdeelbaar/vpvTotal) |
| `ppkSurplus` | decimal ≥ 0 | Overschot-deel via DNB-spreidings-normalisatie |
| `ppkComp` | decimal ≥ 0 | Compensatie-deel via bell-curve |
| `ppkTotal` | decimal ≥ 0 | Som van de drie componenten (over KV_totaal) |
| `ppk_OP` | decimal ≥ 0 | **Geoormerkt v2.0, besluit §11.18:** OP-deel van ppkTotal, proportioneel aan KV_OP/KV_totaal en met gender-specifieke s(x₀, N, g) |
| `ppk_NP` | decimal ≥ 0 | **Geoormerkt v2.0, besluit §11.18:** NP-deel van ppkTotal, proportioneel aan KV_NP/KV_totaal en met gender-specifieke s(x_partner, N, g_y). Alleen als `heeftPartner=true`, anders 0 |
| `buffer-aandeel` | decimal ≥ 0 | Naar module 3: buffer × (KV_totaal / vpvTotal) |
| `cohortOutcomes` | array | Per cohort (25-29, 30-34, ..., 95-99) aggregaten voor deepdive-weergave |
| `vpvTotal` | decimal > 0 | Totale technische voorziening = fondsvermogen / dekkingsgraad |
| `verdeelbaar` | decimal | Fondsvermogen minus reserveringen plus bijstort |
| `phiDerived` | decimal ≥ 0 of `null` | **v1.1 (besluit §11.1, Optie 2); v2.1.3 granulariteit bevestigd op totaal-scalar.** Afgeleide toedelingsfactor = `ppkTotal / V_x^Wtp_totaal`; `null` als V_x^Wtp niet beschikbaar is (§11.12, Optie 1 bevestigd v2.1.3). Decoratief: geen invloed op ppkTotal. **Geen `phiDerived_OP` of `phiDerived_NP` component-varianten in v1** — M4-docx-berekening blijft op totaal, componenten zijn daar presentatie-laag; upgrade-pad naar component-varianten in v2 als M4's OP/NP-breakdown promoveert tot berekeningslaag. |

### §3.5 Formules

**v3.0 wet-canonieke standaardregel** — bijlage 2a Regeling Pensioenwet artikel 2 + 3.

**Fondsbalans-decompositie** (Model C bundle, v2.2.10 ongewijzigd onder v3.0):

```
vpvTotal     = fondsvermogen / dekkingsgraad
M            = fondsvermogen − vpvAftrekPct · vpvTotal − compensatiedepot − buffer + bijstort
verdeelbaar  = M − vpvTotal                                         (= surplus_euros bij DG > 1; negatief onder tekort)
```

`M` is "het beschikbare vermogen waar de standaardregel op toegepast wordt" (art. 3 bijlage 2a). Onder v2.x werd `verdeelbaar` als hoofdvariabele gepresenteerd; onder v3.0 is `M` de wettelijk juiste schaal-grootheid en `verdeelbaar` de v2.x-backward-compat-naam (= surplus-deel boven vpvTotal). Voor DG=1.15 met vpvAftrekPct=0.10 levert `M = 1.15·(1−0.10)·vpvTotal = 1.035·vpvTotal`, dus `verdeelbaar = 0.035·vpvTotal`. CRM-2026-34-context op `spreidingN` blijft van toepassing (zie §3.6 aanname 13 + §11.13).

**Wettelijke spreidingsfunctie** q(h, N) (art. 2 lid 1 bijlage 2a):

```
q(h, N) = min(floor(h) / N, 1)                  trapsgewijze staircase, jaarlijks 1/N stijgend tot 1
```

Voor sub-jaarlijkse h (m=12) is q(h)=0 in maanden 1-11, q(h)=1/N in maanden 12-23, etc. Eerste jaar geen overschot toegekend (compatibel met "trapsgewijs jaarlijks stijgend" uit wettekst). N=10 is wettelijke standaard; N=1000 als proxy voor oneindige spreiding (educatieve N=∞-vergelijking, §3.6 aanname 14 + §11.21).

**Kasstroom-aanpassings-formule** (art. 2 lid 1 + art. 4 lid 1 bijlage 2a):

```
KS_voor(i, h) = verwachte uitgaande kasstroom van individu i op looptijd h
KS_na(i, h)   = KS_voor(i, h) · (1 + q(h, N) · x_fonds)            wettelijke standaardregel

CW_voor(i)    = Σ_h KS_voor(i, h) · v(h)        = KV(i)              uit M1
CW_star(i)    = Σ_h q(h, N) · KS_voor(i, h) · v(h)                   uit M1 (cw_star_op + cw_star_np)
```

Per individu wordt `KV` uit M1 geïnterpreteerd als CW_voor (per definitie identiek), en `CW_star` als nieuwe scalar geleverd door M1 onder M2-cascade. Beide volgen via `annuity()` resp. `annuityWithQ()` voor OP, en `jointLifeAnnuity()` resp. `jointLifeAnnuityWithQ()` voor NP. M1 berekent deze pas wanneer aangeroepen met `m2Context: { spreidingN }`-argument (geen overhead voor scherm-1-standalone-modus).

**Fonds-niveau-schalingsfactor** x_fonds (art. 3 bijlage 2a):

```
CW_voor_fonds = vpvTotal                                            per definitie via DG
CW_star_fonds = ratio · vpvTotal                                    geschat via cohort-proxy
ratio R       = CW_star_proxy / CW_voor_proxy                       fonds-karakteristiek per (preset, sterftetafel, N)
              = (Σ_c n_c · cwsBar(c)) / (Σ_c n_c · kvBar(c))

x_fonds       = (M − CW_voor_fonds) / CW_star_fonds
              = (M − vpvTotal) / (ratio · vpvTotal)
              = verdeelbaar / (ratio · vpvTotal)
```

Cohort-sommatie via proxy-deelnemer per midage (M2-E1=A keuze, R9.30-pragmatiek behouden) met SSPF-genderweging 95% M / 5% V (§11.17). De ratio R is fonds-karakteristiek: voor SSPF-preset 'gesloten' onder AG2024 levert R(N=10) ≈ 0.65–0.70 (gepensheerden, kasstromen direct), R(N=1000) ≈ 0.01–0.02 (alle q's klein). De ratio kan vooraf worden gecached per (preset, sterftetafel, N); UI-slider-respons (DG, vpvAftrekPct) raakt alleen het M-deel van x_fonds, niet de ratio.

**Persoonlijke kapitaalwaarde** (per definitie via lineariteit):

```
ppk(i)        = KV(i) + x_fonds · CW_star(i)                        wet-canoniek
ppk_OP(i)     = KV_OP(i) + x_fonds · cw_star_op(i)
ppk_NP(i)     = KV_NP(i) + x_fonds · cw_star_np(i)                  [= 0 als heeftPartner=false → KV_NP=0 én cw_star_np=0]

ppkComp       = (compensatiedepot / N_deelnemers) · w_rel(x₀)       (alleen deelnemer; volledig aan OP — §3.6 aanname 11)

sluitingscontrole:  ppk_OP + ppk_NP + ppkComp = ppkTotal             (per constructie exact, machine-precisie)
                    ppkBase + ppkSurplus + ppkComp = ppkTotal        (zie backward-compat-mapping hieronder)
```

Bij DG > 1 is x_fonds positief (overschot-toedeling); bij DG < 1 is x_fonds negatief (gespreide korting via dezelfde mechaniek). De v2.x `baseRatio = min(1, verdeelbaar/vpvTotal)`-cap vervalt: onder v3.0 wordt onderdekking via x_fonds < 0 gemodelleerd, niet via een cap op KV. Dit is wettelijk-conform — de standaardregel kent geen "geen-korting"-conditionaliteit, kortingen worden net zo gespreid als overschotten.

**Backward-compat-mapping** voor v2.x-output-velden (`ppkBase`, `ppkSurplus`):

```
ppkBase       = KV                                                  was: KV · baseRatio
ppkSurplus    = x_fonds · (cw_star_op + cw_star_np)                 was: (KV/vpvTotal) · surplus · sFactor · ν(N)
ppkSurplus_OP = x_fonds · cw_star_op
ppkSurplus_NP = x_fonds · cw_star_np
ppkTotal      = ppkBase + ppkSurplus + ppkComp                      = KV + x_fonds · CW_star + ppkComp
```

Beide vormen zijn identiek per constructie (lineariteit `KV(i) + x_fonds · CW_star(i)`). De v2.x-namen blijven beschikbaar voor UI/SCHEMA-continuïteit, met conceptuele verandering: ppkBase is nu de hele KV (geen surplus-cap), ppkSurplus is het individuele aandeel in fondssurplus via fonds-niveau-x. De OP/NP-decompositie is automatisch lineair — geen aparte sFactor-aannames nodig (§3.6 aanname 12 herzien).

**Geoormerkte OP/NP-splitsing** (v2.0 §11.18 status: nu via wiskundige lineariteit):

```
fractie_OP    = KV_OP / KV                                           definitiegemak
fractie_NP    = KV_NP / KV

ppk_OP        = KV_OP + x_fonds · cw_star_op + ppkComp               (compensatie volledig aan OP-deelnemer)
ppk_NP        = KV_NP + x_fonds · cw_star_np                         (geen NP-compensatie, §3.6 aanname 11)

sluitingscontrole:  ppk_OP + ppk_NP = KV + x_fonds·(cw_star_op + cw_star_np) + ppkComp
                  = ppkBase + ppkSurplus + ppkComp = ppkTotal        (exact, automatisch)
```

De v2.1.1 "ppkSurplus is bottom-up som"-keuze blijft staan in geest, nu via lineariteit afgedwongen i.p.v. via aanname 12. De ppkComp blijft volledig OP-toegewezen (§3.6 aanname 11; v2.1.2 bronverankerd via DNB Q&A + art. 150f Pw).

**v2.x R9.30-pragmatiek-blok** (gedeprecieerd, behouden voor regressie via `computeM2_R930_LEGACY`):

```
v2.x: ppk_OP_surplus     = (KV_OP / vpvTotal) · surplus · sFactor(x₀, g)    · ν(N)
v2.x: ppk_NP_surplus     = (KV_NP / vpvTotal) · surplus · sFactor(x_p, g_y) · ν(N)
v2.x: ppkSurplus         = ppk_OP_surplus + ppk_NP_surplus               (bottom-up som)
v2.x: sFactor(x, g)      = (1/N) · Σ_{t=0}^{N−1} ℓ^g_{x+t}               kapitaal-niveau-aanpassing
v2.x: ν(N)               = (Σ_c n_c · kv̄_c) / (Σ_c n_c · kv̄_c · s̄(x̄_c, N))    cohort-normalisatie
```

Onder v3.0 vervangen door wet-canonieke `KV + x_fonds · CW_star`-mechaniek; sFactor en ν(N) niet meer aangeroepen. Helper-functies `dnbShareFactor` en `dnbNormFactor` blijven exporteerbaar uit `engine.m2.ts` voor regressie-doeleinden via `computeM2_R930_LEGACY`. SSPF-genderweging 95/5 (§11.17) blijft van toepassing op proxy-cohort-sommatie in `computeFondsXStar`. Numerieke vergelijking v3.0 vs R9.30-legacy: voor SSPF-67M-anker (DG=1.15, N=10) +0,4% (€572.166 → €574.369); voor jongere cohorten en hogere DG groter (Q-D-test +1,73 procentpunten in opslag).

**Persoonlijke kapitaalwaarde** (M1, identiek v1.2 conventie):

```
KV = pen · ä(min(x₀, ω−1), r)
   = (1+ρ) · pen · ä(x₀, r)                    voor gepensioneerde

met ä(x, r) = (1/12) · Σ_{k=1}^{12·T_eff} _{k/12}p_{x} · (1+r)^{-k/12}
```

Zie §2.5 voor volledige afleiding. v3.0 voegt `annuityWithQ(x, r, t0, g, N, opts)` toe als q-gewogen analogon: `(1/12) · Σ_k q(k/12, N) · _{k/12}p_x · (1+r)^{-k/12}`. Voor de NP-component idem voor `jointLifeAnnuityWithQ` met broken-heart-correctie ongewijzigd (v2.2.11 logica).

**Gaussische compensatie-curve** (ongewijzigd onder v3.0):

```
w(x)  = exp(−0,5 · ((x − μ) / σ)²)
w̄    = Σ_x (n_x · w(x)) / Σ_x n_x       waar n_x uniform over cohorten is verdeeld
```

**Afgeleide toedelingsfactor φ_afgeleid** (v1.1, besluit §11.1; v2.1.3 granulariteit; v3.0 ongewijzigd):

```
phiDerived = ppkTotal / V_x^Wtp_totaal    indien V_x^Wtp_totaal beschikbaar uit module 4
           = null                          anders (§11.12, Optie 1 bevestigd v2.1.3)
```

V_x^Wtp_totaal verwijst naar de Wtp-waarde uit module 4 (§5.5, stap 2). Onder v3.0 is `ppkTotal` numeriek anders (~+0,4% voor SSPF-anker), dus `phiDerived` schuift evenredig; geen formule-wijziging.

### §3.6 Impliciete aannames

1. **Gebruikersconsistentie boven fondsconsistentie.** De engine simuleert één deelnemer met bekende KV en kent de pensioenverdeling binnen zijn cohort niet. Een normalisatie die `Σ PPK_i = verdeelbaar` afdwingt op fondsniveau zou een aanname vereisen ("iedereen in cohort c heeft dezelfde pen als de gebruiker") die vrijwel nooit klopt. De engine kiest bewust voor zuiverheid op individueel niveau ten koste van fondsbrede optel-consistentie.
2. **Basis-deel volledig proportioneel aan KV bij dekking ≤ 100%.** Bij onderdekking krijgt iedereen pro-rata; bij volledige dekking gaat het hele vpv-aandeel mee en blijft de surplus-stap over voor het overschot.
3. **Overschot via DNB-spreidingsmethode.** Ouderen (korte resterende levensduur binnen N-jaar venster) krijgen minder van het overschot; dit wordt herverdeeld via ν(N). Bij N=0 reduceert het tot pure KV-proportionele toedeling.
4. **Compensatie-deel uitgesmeerd over hele populatie 25–99.** De bell-curve dempt de bijdrage voor jongeren en ouderen; de wettelijke DRS-compensatie geldt strikt genomen alleen voor actieven die onder het oude systeem inkoop verloren. v1 rekent met de bell-curve als benadering.
5. **Bundle-aftrek-grondslag is vpv (v2.2.10).** Bestemmingsreserveringen (VEV, operationele reserve, solidariteitsreserve, inhaalindexatie) worden in v2.2.10 als bundle gemodelleerd via `vpvAftrekPct · vpvTotal` — een fractie van de technische voorziening, niet van het fondsvermogen. Deze grondslag-shift volgt ABN AMRO Pensioenfonds-publicatie (transitieplan 17-10-2024 + implementatieplan 22-09-2025) en is wiskundig geverifieerd via DG-115%/125%/135% bundle-toelichting in CRM-2026-34: `aftrek = 0,10·vpvTotal` levert exact 5%/15%/25% verdeelbaar overschot op. Pre-v2.2.10 hanteerde §3.5 een gemengde grondslag: `operRes = operationeleReserveringPct · fondsvermogen` met `overigeReserves` apart in mln euro; deze tool-keuze is in v2.2.10 vervangen omdat publieke transitieplannen typisch alleen het bundle-percentage rapporteren, niet de losse componenten. Legacy-velden blijven beschikbaar voor backward-compat.
6. **Bijstort toegevoegd aan verdeelbaar.** Transitiebijdragen van de werkgever gaan direct in de verdeelbare pot; geen apart kanaal.
7. **Buffer apart afgezonderd.** Buffer is geen boekhoudkundige fondsbuffer maar een reservering voor module 3's dempingsmechaniek. Dit koppelt scherm 2 en scherm 3 tot één gekoppeld systeem.
8. **Cohort-midage in ν(N).** Elk cohort wordt in de normalisatie vertegenwoordigd door één leeftijd (midden van het bereik). Bij brede cohorten ontstaat een kleine vertekening; consistent binnen de cohort-framework.
9. **φ impliciet.** Er is geen expliciet veld voor een toedelingsfactor. De docx-spec (module 4 §5.5.6) gebruikt `K_x = φ(x₀) · V_x^Wtp`; in module 2 zit de equivalente factor impliciet in de som van drie componenten op basis van KV. Beide benaderingen zijn verdedigbaar; zie §3.10.
10. **Cohort-gender-weging via SSPF-prior (v1.9, §11.17 besluit).** De DNB-normalisatiefactor ν(N) gebruikt een gemengde sterftetafel s̄ over cohorten, waar de gender-mix van elk cohort niet bekend is bij de engine. v1.9 hanteert hiervoor een SSPF-specifieke prior (95% M / 5% V voor alle leeftijdscohorten) in plaats van een CBS-populatie-weging. Rationale: SSPF-gepensioneerden zijn overwegend voormalige Shell-werknemers uit een overwegend mannelijke arbeidspopulatie; een neutrale Nederlandse weging zou niet representatief zijn voor dit fonds. De deelnemer krijgt zelf altijd een gender-specifieke s(x₀, N, g) op basis van eigen invoer; de SSPF-weging beïnvloedt alleen de tweede-orde normalisatie (<0,5% op ppkTotal). SSPF-jaarverslag-data kan de placeholder 95/5 later vervangen zonder spec-revisie.
11. **NP als geoormerkt deel van één persoonlijk pensioenvermogen (v2.0, §11.18 besluit; ppkComp-toekenning bronverankerd v2.1.2).** Conform WTP-standaardinvaarpad en SSPF-transitieplan wordt opgebouwd NP mee-ingevaren in het persoonlijk pensioenvermogen, maar geoormerkt t.b.v. NP-functie bij overlijden deelnemer. De engine produceert daarom één geaggregeerd ppkTotal met twee geoormerkte subcomponenten ppk_OP en ppk_NP. Dit is géén dubbele administratie maar een label binnen hetzelfde kapitaal. De decompositie (base, surplus, comp) werkt op het geaggregeerde totaal; de OP/NP-splitsing is een lineaire (ppkBase) c.q. actuariële (ppkSurplus, met levensspecifieke spreidingsfactor) herverdeling. Compensatiedepot (ppkComp) gaat volledig aan OP, niet aan NP. **Wettelijke verankering v2.1.2**: art. 150f lid 1 Pw koppelt compensatie aan werknemers in het leeftijdscohort waarvoor compensatie is overeengekomen; DNB Q&A "onderbouwing compensatie per leeftijdscohort" (juni 2025) specificeert dat compensatie uitsluitend ziet op gemiste toekomstige pensioenopbouw; FRP 2024/622 (Sdu, 2024) bevestigt dat het compensatiedepot bestemd is voor actieve deelnemers; ABP-transitieplan 2024 sluit zelfs gewezen deelnemers uit van compensatie afschaffing doorsneesystematiek. Geen van de onderzochte bronnen (DNB, wetgeving, transitieplannen ABP/PFZW/PPF) noemt een OP/NP-splitsing van compensatie binnen een persoonlijk pensioenvermogen. NP-opbouw loopt bij actieve deelnemers doorgaans op risicobasis en is daarmee conceptueel niet vatbaar voor "gemiste inkoop". Zie §11.18 voor volledige onderbouwing van de geoormerkte-NP-architectuur.
12. **ν(N) uniform over OP- en NP-componenten met SSPF-deelnemer-weging (v2.1.1).** De cohort-normalisatiefactor ν(N) gebruikt de SSPF-gender-weging `demografie.genderWegingSSPF.deelnemer` (placeholder 95/5) voor zowel de OP- als de NP-component in de geoormerkte splitsing. Rationale: (a) de cohort-demografie (n_c, kv̄_c) zelf is één populatie — de engine kent geen aparte partner-cohort-telling, dus een tweede ν zou een extra aanname forceren (partner-cohort ≡ deelnemer-cohort qua leeftijdsverdeling) zonder meetbaar betere onderbouwing; (b) ν(N) is een tweede-orde correctie (<0,5% op ppkTotal, §11.17), waardoor stapelen van placeholder-onzekerheid via partner-specifieke ν niet proportioneel is. De *individuele* gender-specificiteit blijft volledig behouden in `sFactor(x₀, g)` voor OP en `sFactor(x_p, g_y)` voor NP; ν werkt alleen op de gedeelde cohort-normalisatie. Upgrade-pad: bij beschikbaarheid van SSPF-partner-demografie kan een aparte `ν_partner(N)` in v2 worden ingevoerd zonder spec-revisie dieper dan deze aanname.
13. **Spreidingstermijn 10 jaar als wettelijke standaard, juridisch beproefd (v2.2.10).** De DNB-spreidingstermijn `spreidingN = 10` is de wettelijke standaard uit art. 2 lid 1 Bijlage 2a Regeling Pensioenwet en wordt zonder afwijking toegepast door de v2.2.10-engine. CRM-2026-34 (College voor de Rechten van de Mens, 04-03-2026, Nederlandse Bond voor Pensioenbelangen tegen ABN AMRO N.V. en Stichting Pensioenfonds van de ABN AMRO Bank N.V.) heeft beoordeeld of het hanteren van een 10-jaars termijn verboden onderscheid op grond van leeftijd oplevert. Oordeel in vier lagen: (a) **geen direct onderscheid** — de leeftijd-percentages in transitieplannen zijn een eindproduct van uitkeringskasstromen, niet van leeftijd zelf; (b) **wel indirect onderscheid** — de rekenmethode raakt ouderen in het bijzonder, oudste gepensioneerden ontvangen op transitiedatum typisch minder dan de helft van wat actieve deelnemers ontvangen; (c) **objectief gerechtvaardigd** — legitiem doel (evenwichtige verdeling), passend middel (wettelijke standaard), noodzakelijk (subsidiariteit + proportionaliteit, geen excessieve afbreuk); (d) **terughoudende toets** door sociale-partner-onderhandeling. Implicatie voor calculator: geen aanpassing in `spreidingN`-default of formule-mechaniek, wel SCHEMA-`uiDisclosure`-eis op `spreidingN` voor audit-scherm-transparantie (CRM-context, art. 2 lid 3 uitwijkmogelijkheid wordt benoemd zonder advies om af te wijken). Aannames 11 en 12 (NP-geoormerkte structuur, uniforme ν) worden door deze uitspraak niet weerlegd maar conceptueel versterkt: de juridische argumentatie steunt op uitkeringskasstromen-rekenmethode, hetgeen exact de bottom-up `sFactor(x,g)`-decompositie van §3.5 is.

14. **N=1000 als proxy voor oneindige spreiding (v3.0, §11.21 educatieve-keuze).** SCHEMA accepteert `spreidingN ∈ [0, 1000]` (was [0, 30] tot v2.2.13); UI biedt radio-keuze tussen N=10 (wettelijke standaard art. 2 lid 1) en N=1000 (proxy voor oneindige spreiding). N=1000 is geen wettelijke keuze en niet onderbouwbaar in een implementatieplan onder art. 2 lid 3 — het is een educatieve N=∞-vergelijking die zichtbaar maakt hoeveel van de leeftijdsongelijke verdeling specifiek aan de stylering van indexatie-blootstelling toegeschreven kan worden. Onder N=∞ wordt de q(h)-staircase platgedrukt naar bijna nul over alle realistische looptijden, wat via de fonds-x*-compensatie (`x_fonds = (M − vpvTotal) / (R · vpvTotal)`) leidt tot een verdeling die bijna proportioneel is aan KV — dus ouderen en jongeren krijgen in vrijwel gelijke verhouding van het fondsoverschot. Tussenwaarden in [11, 999] zijn ook geldig in SCHEMA: kortere termijnen (1-9) altijd toegestaan onder art. 2 lid 3 (kortere onderbouwing simpel onder vergrijzing), langere onderbouwbaar bij DG > 100%. UI biedt alleen 10 en 1000 als preset-knoppen; custom waarden verschijnen in audit-scherm met "(custom)"-marker. Numerieke gevoeligheid (zie §11.21): voor SSPF-67M-anker N=10 → +5,76%, N=1000 → +6,89% (Δ ~1pp); voor 52-jarige cohort onder DG=1.35 N=10 → +31%, N=1000 → +57% (Δ 25pp).

**v3.0-doorwerking aannames (05-05-2026).** De wettelijke standaardregel (bijlage 2a Regeling Pw art. 2+3) vervangt de R9.30-pragmatiek; aannames-status onder v3.0:
- **Aanname 2** ("Basis-deel volledig proportioneel aan KV bij dekking ≤ 100%") **vervalt** in conceptuele zin: onder v3.0 is `ppkBase = KV` (altijd, geen surplus-cap), en onderdekking wordt gemodelleerd via `x_fonds < 0` (gespreide korting) i.p.v. via een baseRatio-cap. Numerieke uitkomst voor onderdekking-scenario (DG=0.85): onder R9.30 was ppkBase = KV·0.85 = €461.632 + ppkSurplus = 0; onder v3.0 is ppkBase = KV = €543.096 en ppkSurplus = x_fonds·CW_star ≈ −€117.691. ppkTotal-uitkomst is materieel vergelijkbaar (~€323.592 onder v3.0 vs vergelijkbaar onder R9.30) maar boekhoudkundig anders gedecomposeerd.
- **Aanname 3** ("Overschot via DNB-spreidingsmethode … via ν(N)") **vervalt**: geen `ν(N)` meer in v3.0. De wet-canonieke formule gebruikt fonds-niveau-`x_fonds` met per-individu `CW_star`-weging; geen aparte cohort-normalisatiefactor. R9.30-specifieke `dnbShareFactor` en `dnbNormFactor` blijven exporteerbaar voor `computeM2_R930_LEGACY`-regressie.
- **Aanname 8** ("Cohort-midage in ν(N)") **blijft van toepassing** in geherformuleerde vorm: `kvProfile` en `cwStarProfile` gebruiken nog steeds midages voor cohort-sommatie in `computeFondsXStar`. Vertekenings-orde nu marginaler omdat ratio R afgevlakt wordt over cohorten.
- **Aanname 10** ("Cohort-gender-weging via SSPF-prior") **blijft van toepassing**: SSPF-95/5-weging actief in `cwStarProfile` voor proxy-cohort-sommatie. Effect verschuift van tweede-orde-correctie op ν(N) naar tweede-orde-correctie op ratio R; ordegrootte vergelijkbaar (<0,5% op ppkTotal).
- **Aanname 11** ("NP geoormerkt") **blijft van toepassing en wordt sterker** onder v3.0: OP/NP-decompositie volgt automatisch uit lineariteit `KV(i) + x_fonds·CW_star(i)` zonder aparte aanname over sFactor-decompositie. Sluitingscontrole `ppk_OP + ppk_NP = ppkTotal` is nu wiskundig per constructie exact (machine-precisie), niet meer aanname-niveau zoals onder v2.1.1. ppkComp blijft volledig OP-toegewezen (v2.1.2 bronverankering ongewijzigd).
- **Aanname 12** ("ν(N) uniform over OP/NP") **vervalt structureel**: er is geen ν(N) meer onder v3.0. De equivalente eigenschap (gedeelde fonds-niveau-mechaniek voor OP en NP) blijft door `x_fonds` één getal te zijn dat zowel `cw_star_op` als `cw_star_np` schaalt — gedeelde schaal, automatische OP/NP-consistentie.
- **Aanname 13** ("Spreidingstermijn 10 jaar wettelijke standaard, CRM-2026-34") **blijft van toepassing en wordt versterkt**: v3.0 implementeert nu de wettelijke standaard rechtstreeks (was R9.30-pragmatiek met onbevestigde wet-conformiteit-claim). De juridische argumentatie van CRM-2026-34 was al gegrond op uitkeringskasstromen-rekenmethode — exact wat v3.0 nu rechtstreeks implementeert. Geen wijziging in default `spreidingN=10`; alternatieve N=1000 als educatieve keuze (zie aanname 14) raakt deze juridische context niet.

14. **N=∞-educatieve-keuze als proxy voor proportionele KV-toedeling (v3.0).** SCHEMA accepteert onder v3.0 `spreidingN` in [0, 1000]; UI biedt radio-keuze tussen N=10 (wettelijke standaard art. 2 lid 1) en N=1000 (proxy voor oneindige spreiding). Rationale: bij N=∞ blijft `q(h, N)` voor alle realistische h ver onder 1, waardoor `CW_star → 0` voor alle individuen en `ppk(i) → KV(i) + ε`. Dit is de proportionele-KV-toedeling waar overschot/tekort vrijwel volledig naar rato van KV wordt verdeeld zonder leeftijdsonderscheid. **Educatieve onthulling:** verschil tussen N=10 en N=1000 toont expliciet hoeveel van de leeftijdsongelijke verdeling specifiek aan de stylering van toekomstige-indexatie-blootstelling toe te schrijven is (CRM-2026-34 indirect onderscheid → "indexatie-verwachting onder huidig stelsel, juridisch geaccepteerd als evenwichtige verdeling"). N=1000 is **niet** een wettelijk-toelaatbare uitwijkmogelijkheid (art. 2 lid 3 vereist concrete voorwaarden voor langere spreiding); de calculator presenteert N=1000 expliciet als educatief instrument, niet als bestuurlijk advies.

**Status-overlay v3.0 (05-05-2026) — herziening aannames 3, 8, 10, 12 onder wet-canonieke implementatie:**

- **Aanname 3 (overschot via DNB-spreidingsmethode).** Onder v3.0 vervangen door wet-canonieke `(1 + q(h, N) · x_fonds)`-aanpassing per kasstroom (art. 2 lid 1 bijlage 2a). De ν(N)-cohort-normalisatie vervalt structureel; in plaats daarvan komt fonds-niveau-x_fonds via cohort-sommatie van CW_star_proxy. De inhoudelijke uitkomst (ouderen relatief minder van overschot) blijft, maar wordt nu via per-kasstroom-staircase q(h) bereikt i.p.v. via kapitaal-niveau-`sFactor·ν(N)`. Bij N=0 reduceert het tot pure KV-proportionele toedeling (q ≡ 1 zou implicaeren maar N=0 is undefined; engine returnt q=0 voor N≤0 wat geen surplus-toedeling genereert).

- **Aanname 8 (cohort-midage in ν(N)).** Inhoudelijk geldig onder v3.0 maar de toepassings-context schuift: cohort-midage wordt nu gebruikt in `cwStarProfile`-proxy voor de cohort-CW_star-sommatie (Σ_c n_c · cwsBar_c → CW_star_fonds). De vertekening-bron (één leeftijd per cohort als proxy) is identiek; alleen de aggregatie-doelfunctie verschuift van ν(N) naar fonds-x_fonds.

- **Aanname 10 (cohort-gender-weging via SSPF-prior 95/5).** Onder v3.0 onveranderd actief: SSPF-genderweging blijft de cohort-mix-aanname voor `cwStarProfile` en `kvProfile`-proxy in `computeFondsXStar`. Individuele deelnemer krijgt nog steeds gender-specifieke `annuityWithQ(x, ...g)` voor diens eigen `cw_star`. SSPF-weging beïnvloedt nu de fonds-niveau-ratio R i.p.v. ν(N); numerieke impact-orde vergelijkbaar (~0,5% op ppkTotal volgens §11.17 + Q-D-test).

- **Aanname 12 (ν(N) uniform over OP/NP).** **Vervalt structureel onder v3.0.** Geen ν(N) meer in productie-pad; OP/NP-decompositie volgt automatisch uit lineariteit `ppk = KV + x_fonds·CW_star` zonder aparte uniformiteit-aanname. De v2.1.1 bottom-up som-conventie is wiskundig overgenomen door de wet-canonieke formule (zie §11.18 v3.0 status-update). Aanname 12 blijft gedocumenteerd voor v2.x-backward-compat (legacy `computeM2_R930_LEGACY` gebruikt het nog).

Aannames 1, 2, 4, 5, 6, 7, 9, 11, 13 zijn onveranderd onder v3.0.

### §3.7 Fallbacks

| Ontbrekend veld | Fallback | Impact |
|---|---|---|
| `compensatiedepot` | 0 | Geen compensatiecomponent; ppkComp = 0 |
| `overigeReserves` | 0 | Verdeelbaar stijgt met dit bedrag |
| `bijstort` | 0 | Verdeelbaar daalt met dit bedrag |
| `buffer` | 0 | Geen module-3-dempingsreserve |
| `spreidingN` | 10 | DNB-standaardwaarde |
| `compensatieMu` / `compensatieSigma` | 55 / 8 | Bell-curve pieken op mid-carrière |
| `φ(x)` | impliciet berekend | Huidige v1-gedrag; geen alternatief rekenpad |
| `demografie.preset` of `customCounts` | **geen fallback** | Hard reject: demografie is verplicht voor ν(N) en w̄ |

### §3.8 Validaties

| Categorie | Regel | Actie bij schending |
|---|---|---|
| Invoerbereik | `fondsvermogen` > 0 | Hard reject |
| Invoerbereik | 0,5 ≤ `dekkingsgraad` ≤ 2,0 | Hard reject buiten bereik |
| Consistentie | `verdeelbaar` ≥ 0 | Waarschuwing: reserveringen overschrijden fondsvermogen |
| Parameterbereik | 0 ≤ `spreidingN` ≤ 1000 | Hard reject (v3.0: range vergroot van 30 naar 1000 t.b.v. educatieve N=∞-keuze, zie §3.6 aanname 14) |
| Parameterbereik | `compensatieSigma` > 0 | Hard reject bij σ ≤ 0 |
| Demografie | Exact één van `preset` of `customCounts` | Hard reject bij beide of geen |
| Demografie | Als `customCounts`: lengte 15, alle waarden ≥ 0 | Hard reject |
| Consistentie | `N_deelnemers` > 0 | Hard reject (delen door 0 in ppkComp) |

### §3.9 Scope-voorbehouden

- **Geen regelingsverschil in de berekening zelf.** De DNB-spreidingsmethode is fonds-toedelings-mechaniek, niet Wtp-regeling-specifiek. Indirect hangen sommige parameters (compensatiedepot, bijstort) wel samen met het gekozen transitieplan, maar de wiskundige structuur is identiek voor FPR, SPR-clean en SPR-hybride.
- **Empirisch, niet actuarieel.** Module 2 waardeert niet; zij verdeelt. Voor een zuivere actuariële vergelijking pre versus post is module 4 het juiste instrument.
- **Geen stochastiek.** De toedeling is deterministisch gegeven de parameters. Onzekerheid over toekomstige rendementen gaat in module 3; onzekerheid over fondsaannames komt terug als gevoeligheidsanalyse door de parameterset te variëren.

### §3.10 Reviewpunten

- **Relatie tot φ.** De docx-spec definieert `K_x = φ(x₀) · V_x^Wtp` als toegedeeld vermogen. Module 2 levert ppkTotal, dat materieel dezelfde grootheid is maar via een heel ander rekenpad tot stand komt. Voor cross-module consistentie is een expliciete φ een denkbare uitbreiding: de engine kan dan *optioneel* schakelen tussen het empirische pad (huidige v1) en het formele φ-pad (module-4-achtig). Zie open vraag in §11 over deze schakelaar.
- **Surplus-trigger.** `surplus = max(0, verdeelbaar − vpvTotal)` schakelt abrupt. Bij dekkingsgraad net onder 100% is surplus nul; net erboven springt het. Voor realistische dempings-communicatie kan een glijdende trigger zinvol zijn, maar dat verandert de boekhoudkundige interpretatie. **Status-update v3.0 (05-05-2026):** dit reviewpunt **vervalt** onder de wet-canonieke standaardregel. De `max(0, ...)`-cap zat in de R9.30-pragmatiek waar surplus alleen positief kon zijn (anders viel het terug op een baseRatio-cap < 1). Onder v3.0 (bijlage 2a Regeling Pw art. 3) wordt `x_fonds = (M − vpvTotal) / CW_star_fonds` zonder cap toegepast: bij dekking < 100% wordt `x_fonds` gewoon negatief (gespreide korting via dezelfde mechaniek), bij dekking > 100% positief (gespreide opslag). Geen sprong, geen tweedeling — één continue formule die het tekort en het overschot identiek behandelt. De abrupte schakeling die dit reviewpunt benoemde, was een artefact van de R9.30-pragmatiek; de wettelijke formule heeft die schakeling per ontwerp niet.
- **Cohort-midage in ν(N).** De benadering is practisch; een alternatief is ν op leeftijd-niveau berekenen met individuele sterftekansen. Numeriek klein effect, maar interpretatief zuiverder. **Status-update v3.0 (05-05-2026):** ν(N) bestaat niet meer onder de wet-canonieke standaardregel (zie §11.18 v3.0-update + §3.6 a.12-vervalt). Het structureel-analoge reviewpunt onder v3.0 betreft `cwStarProfile(midage, ...)` in `computeFondsXStar`: ook deze gebruikt cohort-midage-proxy via `kvProfile`/`cwStarProfile`-koppeling met SSPF-genderweging 95/5 (§11.17), niet leeftijd-niveau-individuele sterftekansen. De pragmatische schending van §3.6 aanname 1 is onder v3.0 dezelfde als onder R9.30 — de proxy-deelnemer-aanpak is niet veranderd, alleen de q-staircase-multiplier is toegevoegd. Numeriek klein effect, interpretatief zuiverder zou nog steeds een leeftijd-niveau-uitwerking zijn; dit blijft v2-reservering.
- **Compensatiedepot-verdeling over hele populatie.** De wet zegt: compensatie is voor actieven met verloren inkoopkansen. v1 verdeelt via bell-curve over 25–99. Voor gepensioneerden is de bijdrage typisch klein (bell-tail), maar conceptueel incorrect. Alternatief: doelgroep-parameter toevoegen (bv. alleen 35-60). **Notitie v2.1.2 (23-04-2026 14:28)**: bronnenonderzoek in het kader van scherm-2-punt 2 heeft dit reviewpunt sterker onderbouwd — art. 150f lid 1 Pw en DNB Q&A (juni 2025) stellen expliciet dat compensatie uitsluitend voor actieve deelnemers met gemiste toekomstige opbouw bedoeld is; SSPF-doelpubliek (gepensioneerden) valt strikt genomen geheel buiten deze doelgroep. Ondanks dit scherpere beeld is in scherm-2-sessie bewust besloten dit punt **niet** nu op te pakken — v1 reproduceert R9.30-gedrag conform §12.5 spec-met-reserveringen-principe, §3.6 aanname 4 documenteert de benadering al, en de bell-tail-bijdrage voor een 70-jarige SSPF-gepensioneerde is numeriek klein. Herbeoordelen bij latere publieke-release-ronde of bij reviewpunt-consolidatie. **Notitie v2.2.10 (04-05-2026 21:04)**: dubbele-administratie-risico bij Model C-architectuur. ABN AMRO Pensioenfonds publiceert `vpvAftrekPct ≈ 0,10` als bundle waarin compensatiedepot is meegenomen; in onze SCHEMA blijft `compensatiedepot` apart van `vpvAftrekPct` om bell-curve-input te behouden. Een SSPF-samensteller die ABN's 10% klakkeloos overneemt zou compensatie dubbel tellen (één keer in `vpvAftrekPct=0,10`, één keer in `compensatiedepot`-veld). Documentatie-eis bij dataset-load: ABN-bron als referentie eerst decomposeren in `vpvAftrekPct(zonder-compensatie)` + `compensatiedepot(in mln euro apart)`. SCHEMA-`uiDisclosure` op `vpvAftrekPct` benoemt dit risico expliciet. Bij SSPF (geen DRS-compensatie-doelgroep) is `compensatiedepot=0` natuurlijke default, wat het risico in praktijk wegneemt.
- **Spreidingstermijn `spreidingN` en juridische context (v2.2.10).** Bij wettelijke standaard 10 jaar conform art. 2 lid 1 Bijlage 2a Regeling Pensioenwet ontvangen oudere gepensioneerden op transitiedatum aanwijsbaar minder dan jongere actieve deelnemers; in CRM-2026-34 (04-03-2026) is geoordeeld dat dit indirect leeftijdsonderscheid oplevert maar objectief gerechtvaardigd is (terughoudende toets sociale-partner-onderhandeling, evenwichtige verdeling als legitiem doel, middel passend en noodzakelijk). De engine hanteert default `spreidingN=10` zonder afwijkingsadvies. Reviewpunt: kalibratie van de SCHEMA-`uiDisclosure`-tekst — hoe wordt de juridische context het beste gepresenteerd op het audit-scherm? Aanvankelijke v2.2.10-implementatie verwijst naar CRM-2026-34 met de redenering indirect-onderscheid → objectieve rechtvaardiging en benoemt art. 2 lid 3 uitwijkmogelijkheid neutraal (geen advies). Open vraag: in een latere copy-/design-ronde mogelijk een educatieve toelichting voor de gebruiker met cijfer-illustratie ("op transitiedatum krijgt 70-jarige typisch X%, 35-jarige typisch 2X%; reden: indexatie-verwachting onder huidig stelsel, juridisch geaccepteerd als evenwichtige verdeling"). Bron-onderhoud bij latere CRM-uitspraken nodig — mogelijke vervolg-zaken bij andere fondsen kunnen de juridische bouwstenen aanvullen. **Spreidings-formule-onzekerheid v2.2.13:** parallel aan deze juridische context bestaat een formele canoniciteit-vraag over §3.5-spreidings-mechaniek; zie §11.21. **Status-update v3.0 (05-05-2026):** §11.21-onderzoek opgelost en geïmplementeerd; v3.0 implementeert nu rechtstreeks de wet-canonieke standaardregel (bijlage 2a Regeling Pw art. 2). Dit versterkt de juridische context structureel: de CRM-2026-34-argumentatie (legitieme indirecte ongelijkheid) was al gegrond op de wettelijke uitkeringskasstromen-rekenmethode — exact wat v3.0 nu rechtstreeks implementeert i.p.v. via R9.30-pragmatiek-proxy. UI-disclosure-tekst is uitgebreid met §11.21+v3.0-context en N=∞-educatieve-onthulling (zie §3.6 a.14). Educatieve cijfer-illustratie wordt onder v3.0 een natuurlijke uitkomst van N=10 vs N=1000-vergelijking — de gebruiker kan zelf zien hoeveel van de leeftijdsongelijke verdeling specifiek aan de spreidings-stylering toegeschreven kan worden. Dit punt blijft een copy-/design-ronde-reviewpunt voor de finale UI-tekst, maar de inhoudelijke onderbouwing is onder v3.0 sterker.
- **Buffer-koppeling tussen scherm 2 en scherm 3.** Het buffer-veld hoort conceptueel bij module 3 maar wordt in module 2 van het verdeelbare vermogen afgezonderd. Dit koppelt de twee modules vast aan elkaar — een UI-keuze op scherm 2 beïnvloedt de uitkomst op scherm 3. Voor modulaire zuiverheid zou buffer als apart veld tussen module 2 en module 3 kunnen blijven, met duidelijke annotatie dat het verdeelbaar-vermogen daarmee verlaagt.

---

## §4. Module 3 — Uitkeringsbenadering

### §4.1 Vraag

*Hoe ontwikkelt mijn uitkering zich na transitie onder de gekozen Wtp-regeling, met welke onzekerheidsmarge?*

Module 3 is de **projectiemotor**: gegeven een potje uit module 2, berekent zij de startuitkering en het uitkeringspad over de tijd onder stochastische rendementen. De output is geen puntwaardering maar een verdeling van uitkeringsbanen, waarvan percentielen (p10/p50/p90) als onzekerheidsmarge worden weergegeven. Module 3 is de meest complexe van de vier modules in rekenomvang (Monte Carlo met typisch 2000 paden) en beantwoordt een fundamenteel andere vraag dan module 4: waar module 4 *waardeert*, simuleert module 3 *paden*.

De regelingsdimensie is hier concreet zichtbaar: de inner-loop-wiskunde verschilt per regeling. v1 specificeert alleen de FPR-inner-loop volledig; SPR-clean en SPR-hybride zijn beschreven in termen van parametercontract maar hun inner-loop-specificatie is expliciet **reservering** voor Fase B. Zie §9 voor de regeling-dimensie en §11 voor open vragen.

### §4.2 Invoerschema — deelnemer

| Veld | Type | Verplicht | Herkomst | Toelichting |
|---|---|---|---|---|
| `x₀` | decimal | ja | deelnemersinvoer | Leeftijd op transitiedatum |
| `lifeExp(x₀)` | decimal | ja | **module 1** | Verwachte sterfleeftijd; gebruikt voor plot-horizon |
| `pen` | decimal ≥ 0 | ja | deelnemersinvoer | Pre-transitie uitkering; gebruikt voor benchmark-lijn |
| `g` | enum {M, V, gemengd} | ja | **module 1** (deelnemersinvoer) | Geslacht deelnemer; activeert AG2024-tafel per geslacht in `ä(x₀, proj, g)`. v1.7-doorwerking, formeel in §4 vastgelegd v2.1.5 |
| `heeftPartner` | boolean | ja | **module 1** (deelnemersinvoer) | Of er een NP-aanspraak is; bij `false` worden onderstaande partner-velden genegeerd (`U₀_NP=0`, §4.7) |
| `x_partner` | decimal | voorwaardelijk | **module 1** (deelnemersinvoer) | Leeftijd partner; verplicht als `heeftPartner=true`. Gebruikt in `ä(x_partner, proj, g_y)` voor `U₀_NP` (§4.5) |
| `g_y` | enum {M, V, gemengd} | voorwaardelijk | **module 1** (deelnemersinvoer) | Geslacht partner; verplicht als `heeftPartner=true`. Identiek behandeld als `g` |
| `y₀` | decimal ≥ 0 | voorwaardelijk | **module 1** (deelnemersinvoer of fallback 0,70 × pen) | NP-aanspraak op peildatum; geen directe rol in M3-formules (NP komt M3 binnen via `ppk_NP` uit M2), maar bewaard voor presentatie/audit-doeleinden |

### §4.3 Invoerschema — fondsparameterset

| Veld | Type | Verplicht | Default | Status v1 | Toelichting |
|---|---|---|---|---|---|
| `potje` | decimal > 0 | ja | — (uit **module 2**) | actief | Startkapitaal in euro = `ppkTotal` uit M2 (§3.4). v2.1.4: M3 leest tevens de geoormerkte componenten `ppk_OP` en `ppk_NP` uit M2 voor de startuitkering-decompositie (§4.5) |
| `buffer-aandeel` | decimal ≥ 0 | ja | — (uit **module 2**) | actief | Startbuffer in euro voor dempingsmechaniek; in SSPF-design genaamd RDR-buffer (Reserve voor Dempings-Reserve), eenmalig vastgesteld bij invaren |
| `regeling` | enum {FPR, SPR-clean, SPR-hybride} | ja | FPR | actief voor FPR | SPR-varianten gereserveerd voor Fase B |
| `proj` | decimal | ja | 0,02 (2%, gekoppeld aan M1-`r` in UI) | actief | DNB-projectierendement voor potje→U₀-conversie. v2.1: default gekoppeld aan M1-`r`-slider; ontkoppeling via "geavanceerd"-toggle. v2.1.8: scalar in v1; lifecycle-pad activeert tegelijk `lifecycle-profiel` en `rtsCurve` (gekoppeld v2-pad voor fondsen met leeftijdsafhankelijke profielen, niet voor SSPF) |
| `μ` | decimal | ja | 0,045 (4,5%, SSPF 60/40 indicatief v2.1.8) | actief | Verwacht jaarlijks fondsrendement (arithmetisch). v2.1.8-default afgeleid van SSPF-portfolio-mix (60% matching / 40% rendement-seeking, geen lifecycle); indicatief, vervangbaar door SSPF-bestuursnotitie-waarde of officiële Wtp-richtlijn zonder spec-revisie |
| `σ` | decimal ≥ 0 | ja | 0,08 (8%, SSPF 60/40 indicatief v2.1.8) | actief | Volatiliteit jaarlijks fondsrendement. v2.1.8-default afgeleid van SSPF-portfolio-mix (60/40); indicatief, zelfde upgrade-pad als `μ` |
| `inf` | decimal | ja | dataset | actief | Verwachte jaarlijkse inflatie |
| `dempJaren` | integer ∈ [0,10] | ja | 5 (SSPF-default v2.1.6) | actief | Rollend-gemiddelde-venster voor dempingsmechaniek; SSPF-design hanteert 5-jaars rolling, jaarlijks doorschuivend (`effR_t = mean(window_t)`, §4.5) |
| `bufferTrigger` | enum {koopkracht, rendement, projectie, koopkracht-projectie} | nee | `koopkracht` | actief (v2.1.6) | Trigger-formule voor buffer-onttrekking, vier waardes: `'koopkracht'` (effR < inf, default — spiegelt huidige indexatie-praktijk), `'rendement'` (effR < 0), `'projectie'` (effR < proj), `'koopkracht-projectie'` (effR < proj + inf). Zie §4.5 voor formules per waarde |
| `N_paths` | integer > 0 | nee | 2000 | engine-constant | Aantal Monte Carlo paden |
| `seed` | integer | nee | 20260418 | engine-constant | Master-seed voor reproduceerbaarheid |
| `percentielen` | vector[decimal] | nee | [0.10, 0.50, 0.90] | engine-constant | Welke percentielen in de output |
| `RTS` | vector[decimal] | nee | null (v1: vlak via proj) | gereserveerd | **SPR-rente-curve**: zero-coupon rentes per looptijd in jaren 1..T_max, nodig voor SPR-hybride rente-afdekking. Conceptueel orthogonaal aan FPR-`rtsCurve` (v2.1.8). Identiek aan §5.5 M4 |
| `rtsCurve` | vector[{leeftijd: int, proj: decimal}] | nee | null (v1: vlak via `proj`-scalar) | gereserveerd (v2.1.8) | **FPR-lifecycle-projectierente**: leeftijdsafhankelijke discontering voor lifecycle-fondsen. Conceptueel onderscheiden van SPR-`RTS`. Activering vereist tegelijk `lifecycle-profiel` actief — semantische coherentie (rendementsverwachting en discontering moeten beide leeftijdsafhankelijk zijn of geen van beide). Niet relevant voor SSPF (collectieve toedeling, geen individuele lifecycles) |
| `agHerzienPeriode` | integer | nee | null | gereserveerd | Frequentie AG-tafel-updates, nodig voor SPR |
| `renteAfdekkingFactor` | decimal ∈ [0,1] | nee | null | gereserveerd | Rente-afdekkingsgraad, nodig voor SPR-hybride |
| `lifecycle-profiel` | object | nee | vlak (één μ/σ all ages) | gereserveerd | Leeftijdsafhankelijke μ(x), σ(x); nodig voor FPR met individuele lifecycles. v2.1.8: activering vereist tegelijk `rtsCurve` actief (gekoppeld v2-pad voor semantische coherentie). Niet relevant voor SSPF |
| `plotHorizonRule` | enum {lifeExpPlus10, omega, coverage1pct, lifeExpExact} | nee | `lifeExpPlus10` | actief (v2.1.9) | UI-presentatie-cap voor uitkeringspad. Engine berekent altijd tot `ω` (geen informatie-verlies in `paths`); deze regel bepaalt alleen welk venster `years_display` en `endAge_display` (§4.4) krijgen voor weergave. `'lifeExpPlus10'` (default, dynamisch op individu, R9.30-conform met +10-tail), `'omega'` (geen cap, levenslang), `'coverage1pct'` (tot leeftijd met overlevingskans > 1%), `'lifeExpExact'` (huidige R9.30-cap zonder tail-extensie). Zie §4.5, §4.6 aanname 19, §11.9 |
| `correlatieRenteInflatie` | decimal ∈ [−1,1] | nee | 0 | gereserveerd | Correlatie tussen rendement en inflatie. v2.1.7: blijft gereserveerd; activering vereist tegelijk `inflatieStochastiek` actief, want zonder stochastische `inf` is correlatie betekenisloos. Gekoppeld v2-pad |
| `inflatieStochastiek` | object {μ_inf: decimal, σ_inf: decimal ≥ 0} of null | nee | null | gereserveerd (v2.1.7) | Stochastische inflatie als log-normaal proces met eigen verwachtingswaarde en volatiliteit. Null in v1: `inf` blijft deterministische scalar uit §4.3. Activering opent gekoppeld pad naar `correlatieRenteInflatie` via bivariate trekking met Cholesky |
| `sterftekansTabelId` | string | ja | `'AG2024'` | actief (v2.1.5) | Identificatie van de tafel; identiek aan §2.3, M3 gebruikt dezelfde bron als M1 voor cross-module consistentie. Vervangt R9.30-mengtafel die in §4.5-formules tot v2.1.4 impliciet werd aangenomen |
| `q_{x,t,g}` | 2D-map per geslacht → decimal | ja | uit tabel-ID | actief (v2.1.5) | AG2024 prognosetafel per geslacht (M/V); M3 gebruikt periode-snapshot kolom `t₀` voor `ä(x₀, proj, g)` en `ä(x_partner, proj, g_y)`. Identiek aan §2.3 |
| `t₀` | integer | nee | 2026 | actief (v2.1.5) | Projectiejaar voor AG2024-kolomselectie; M3 gebruikt periode-snapshot conform §2.6.2 (zelfde aanname als M1) |

### §4.4 Output

| Veld | Type | Toelichting |
|---|---|---|
| `U₀` | decimal ≥ 0 | Startuitkering in euro per jaar; hoofdpad (= `U₀_OP`, wat deelnemer als levende ontvangt) |
| `U₀_OP` | decimal ≥ 0 | Decompositie-veld (deepdive): startuitkering uit OP-financiering; identiek aan `U₀` (v2.1.4) |
| `U₀_NP` | decimal ≥ 0 of 0 | Decompositie-veld (deepdive): latente NP-startuitkering uit `ppk_NP / ä(x_partner, proj, g_y)`; bovengrens conform §2.6.7. 0 als `heeftPartner=false` |
| `U_t[p10], U_t[p50], U_t[p90]` | arrays | Percentielbanden over t = 0..years; gegenereerd uit hoofdpad `U₀` |
| `benchmarkNom`, `benchmarkReel` | arrays | Rode referentielijn voor "oude situatie" |
| `bufEnd` | decimal ≥ 0 | Gemiddelde eindbuffer over alle paden |
| `shortfall` | decimal ∈ [0,1] | Fractie jaren met tekort-trigger |
| `fullyCov`, `partCov`, `notCov` | decimals | Fracties jaren met volledige/gedeeltelijke/geen dekking |
| `years` | integer | Engine-projectiehorizon in jaren = `ω − x₀`; volledige berekenings-bereik (v2.1.9) |
| `years_display` | integer | Optioneel UI-presentatie-bereik op basis van `plotHorizonRule` (§4.3, v2.1.9). `≤ years`. Default `'lifeExpPlus10'` → `min(ω, ⌈lifeExp(x₀)⌉ + 10) − x₀` |
| `endAge_display` | integer | Optioneel UI-eindleeftijd voor presentatie = `x₀ + years_display` (v2.1.9) |

### §4.5 Formules — FPR-variant (v1 enige volledig gespecificeerde regeling)

**Startuitkering — decompositie OP/NP (v2.1.4)**:

Conform de geoormerkte structuur uit §11.18 (v2.0) wordt de startuitkering decompositief afgeleid uit `ppk_OP` en — indien aanwezig — `ppk_NP`:

```
U₀_OP = ppk_OP / ä(x₀, proj, g)

U₀_NP = ppk_NP / ä(x_partner, proj, g_y)     indien heeftPartner; anders 0

U₀     = U₀_OP                               (hoofdpad: wat deelnemer als levende ontvangt)
```

Het hoofdpad `U₀` representeert de uitkering die de deelnemer ontvangt zolang deze leeft; dit is de waarde die in `U_t[p10/p50/p90]` wordt geprojecteerd. `U₀_NP` is een decompositie- en deepdive-veld dat de latente NP-dekking zichtbaar maakt: het zou de partner-uitkering zijn als die zou starten op peildatum (bovengrens conform §2.6.7), en is bedoeld om in de UI te tonen dat NP latent in het kapitaal zit zonder de Monte Carlo te vertroebelen met expliciete overlijdens-events. De gender-argumenten `g` en `g_y` activeren de AG2024-tafel per geslacht conform v1.7 (§2.5).

Voor `heeftPartner=false` reduceert de decompositie tot het v1.x-eenkanaalgedrag: `ppk_NP=0 → U₀_NP=0`, en `ppk_OP = ppkTotal → U₀ = ppkTotal / ä(x₀, proj, g)`.

**Mortality pooling impliciet via beide annuïteiten.** De latent-NP-pooling wordt analoog aan §4.6.5 impliciet meegenomen door `ä(x_partner, proj, g_y)`. Een expliciete event-modellering van deelnemer-overlijden in de Monte Carlo (Optie B uit besluit-discussie v2.1.4) is bewust niet gekozen, omdat dat (i) §4.6.11 — "FPR-paden representeren de uitkering *als* de deelnemer nog leeft" — zou breken, (ii) p10/p50/p90-banden conceptueel zou vertroebelen door menging deelnemer-paden en partner-paden, en (iii) het cross-module narratief-anker met M1 (§2.5) en M4 (§5, "berekening blijft op totaal") zou aantasten.

**Hoofdformule — startuitkering hoofdpad** (één actuariële annuïteit op projectierendement, v1.2 conventie: arrears m=12):

```
U₀ = ppk_OP / ä(x₀, proj, g)

met ä(x₀, proj, g) = (1/12) · Σ_{k=1}^{12·T_eff} _{k/12}p_{x₀, g} · (1+proj)^{-k/12}
```

De annuïteitsfactor weegt elke toekomstige betaling met de overlevingskans (mortality pooling impliciet). Dit wijkt af van een deterministische n-jarige annuïteit `(1 − (1+r)^{−n}) / r` waar n een vaste horizon is; de actuariële ä is wiskundig zuiver voor FPR omdat het fonds alleen hoeft te betalen wanneer de deelnemer nog leeft. Voor 70-jarigen is het verschil ~0,2%; voor 80+ is het −5% tot −7% op U₀.

**Conventie-consistentie.** U₀ is een jaarrente; de interne annuïteitssom loopt over 12·T_eff maandelijkse termijnen. De projectie-stap hierna (rendement, demping, update) blijft op jaarbasis — alleen de potje→U₀ omzetting gebruikt de fijnere annuïteit. Zie §2.5 voor volledige afleiding en §7.3 voor cross-module consistentie.

**Rendementsgeneratie** (log-normaal, GBM):

```
σ_log²  = ln(1 + σ² / (1+μ)²)
μ_log   = ln(1+μ) − σ_log² / 2

r_t = exp(μ_log + σ_log · Z_t) − 1,   Z_t ~ N(0,1) i.i.d.
```

Deze arithmetisch-naar-log conversie behoudt de verwachtingswaarde `E[r_t] = μ` en de variantie `Var(r_t) ≈ σ²` exact. De seed per pad is `mulberry32(MASTER_SEED + p)` zodat pad `p` deterministisch reproduceerbaar is onafhankelijk van `N_paths`.

**Inflatie deterministisch in v1 (v2.1.7-noot).** Het `inf`-veld uit §4.3 is in v1 één scalar per simulatie (geen tijd-as, geen onzekerheid). Stochastische inflatie en correlatie met rendement vormen een gekoppeld v2-pad: activering vereist tegelijk het gereserveerde object `inflatieStochastiek` (sub-velden `μ_inf`, `σ_inf`) en het bestaande `correlatieRenteInflatie`-veld. In dat scenario zou `inf_t` als tweede log-normaal proces worden getrokken met bivariate Cholesky-koppeling aan `r_t`. Zie §4.6 aanname 17 en §11.7 besluit-paragraaf voor rationale.

**Vlakke rente in v1 (v2.1.8-noot).** De parameters `proj`, `μ` en `σ` zijn in v1 alle drie scalars zonder leeftijds- of tijdsafhankelijkheid. Voor SSPF is dit conform werkelijk regime (collectieve toedeling, vast 60/40-portfolio, geen individuele lifecycles). Voor andere Wtp-fondsen met leeftijdsafhankelijke afbouw vormen `lifecycle-profiel` (μ(x), σ(x)) en `rtsCurve` (proj per leeftijd) een gekoppeld v2-pad — beide moeten samen actief zijn voor semantische coherentie. In dat scenario zou §4.5-rendementsgeneratie μ(x_t), σ(x_t) gebruiken en de update-formule `(1+effR_final)/(1+proj(x_t))`. Conceptueel onderscheiden van het `RTS`-veld dat SPR-hybride rente-afdekking ondersteunt (zie §4.3, §11.8). Zie §4.6 aanname 18 en §11.8 besluit-paragraaf voor rationale.

**Demping** (rollend gemiddelde van recente rendementen):

```
als dempJaren == 0:  effR_t = r_t
anders:              window_t = laatste min(dempJaren, t+1) rendementen
                     effR_t   = mean(window_t)
```

**Buffer-mechaniek (RDR-buffer)** — bij tekort wordt uit de buffer getrokken tot het tekort of tot de buffer op is. De buffer (`buffer_t`, geïnitialiseerd op `buffer-aandeel` uit M2) wordt in SSPF-design RDR-buffer (Reserve voor Dempings-Reserve) genoemd; het mechanisme hieronder is de R9.30-implementatie (volledige onttrekking tot bufferbodem). Of SSPF een ander uitputtingsregime hanteert (plafond per jaar, gefaseerde aanwending) is open en geparkeerd in §4.10.

```
threshold = bufferTrigger_drempel(proj, inf, bufferTrigger):
    'koopkracht'             → inf            # default v2.1.6: spiegelt indexatie-anker
    'rendement'              → 0              # alleen bij absolute verliezen
    'projectie'              → proj           # zuiver wiskundig op FPR-update
    'koopkracht-projectie'   → proj + inf     # streng dubbel-anker

bij effR_t < threshold:
    tekort     = U_{t-1} × (threshold − effR_t)
    trekking   = min(tekort, buffer_t)
    buffer_t  -= trekking
    effR_final = effR_t + trekking / U_{t-1}
    → fullyCov, partCov, of notCov bijhouden
```

In v1 is `bufferTrigger = 'koopkracht'` de default (v2.1.6, §11.6 besluit). Rationale: SSPF-gepensioneerden willen hun WTP-uitkering vergelijken met de huidige indexatie-praktijk, en de koopkracht-trigger spiegelt precies dat anker. De drie alternatieven zijn structureel beschikbaar voor latere SSPF-bron-gebaseerde aanpassing zonder spec-revisie.

**Uitkeringsupdate — kern van de FPR-wiskunde**:

```
U_{t+1} = U_t × (1 + effR_final) / (1 + proj)
```

Deze update-formule volgt wiskundig uit de startuitkeringsbepaling: U₀ wordt bepaald door het potje te delen door ä(n, proj), wat impliceert dat het potje zelf met `proj` groeit om n jaar lang U₀ te kunnen betalen. De uitkering moet daarom alleen meebewegen met het *over-rendement* t.o.v. projectie: als `r_t = proj`, blijft U vlak. Zonder deling door (1+proj) zou U automatisch met `proj` per jaar groeien — een systematische overschatting.

**Horizon en percentielen (v2.1.9: scheiding berekening en presentatie)**:

```
# Berekening — altijd tot ω, geen informatie-verlies
years   = ω − x₀
voor elke t ∈ [0, years]:
    sorteer paths[:, t]
    U_t[p_q] = paths[⌊q · N_paths⌋, t]   voor q ∈ {0.10, 0.50, 0.90}

# Presentatie — UI-cap op basis van plotHorizonRule (§4.3)
endAge_display = match plotHorizonRule:
    'lifeExpPlus10'  → min(ω, ⌈lifeExp(x₀)⌉ + 10)         # default, R9.30-conform met tail
    'omega'          → ω                                    # levenslang, geen cap
    'coverage1pct'   → max{x : ℓ_x(x − x₀) > 0,01}        # statistisch eerlijke compromis
    'lifeExpExact'   → min(ω, ⌈lifeExp(x₀)⌉)              # huidige R9.30-cap, voor backward-compat

years_display = endAge_display − x₀
```

De berekening loopt altijd tot `ω` zodat `paths[:, t]` voor alle t beschikbaar is voor power-users (debug, alternatieve UI-keuzes, onderzoeks-uitvoer). De UI-cap is een presentatie-laag die `years_display` en `endAge_display` (§4.4) zet voor weergave; de onderliggende `U_t[p10/p50/p90]`-arrays blijven volledig (lengte = `years + 1`).

**Benchmark** (rode "oude situatie" lijn, volledige indexatie):

```
benchmarkNom_t  = pen · (1+inf)^t
benchmarkReel_t = pen                     # constant in koopkracht
```

### §4.6 Impliciete aannames

1. **Log-normaal rendement, jaarbasis.** GBM-aanname garandeert `(1+r) > 0` altijd. Arithmetisch-naar-log conversie is standaard Itô-correctie.
2. **Onafhankelijke jaarlijkse rendementen.** Geen autocorrelatie, geen mean-reversion, geen regime-shifts. Eerste-orde Markov met stationaire verdeling.
3. **Geen correlatie rente-inflatie.** Inflatie is een deterministische slider-waarde; rendement en inflatie zijn onafhankelijk. In realiteit positief gecorreleerd via rente-route.
4. **Geen leeftijdsafhankelijkheid in μ en σ.** Eén μ en σ voor alle leeftijden. Consistent met FPR met collectieve toedelingskring; voor FPR met individuele lifecycles een simplificatie.
5. **Mortality pooling impliciet via ä-startuitkering.** De actuariële annuïteit zorgt dat overlevingskanswinsten in U₀ zijn verdisconteerd; een expliciete herverdeling van sterftewinsten per jaar (zoals bij een collectieve toedelingskring in werkelijkheid gebeurt) is niet gemodelleerd. De simulatie toont het verwachte pad voor iemand die in leven blijft.
6. **Geen kostenaftrek.** Geen ρ_Wtp of equivalent; alle rendement gaat één-op-één in U. Voor realisme 0,1–0,5% afhankelijk van regime.
7. **Seed-per-pad, niet één globale stream.** `mulberry32(MASTER_SEED + p)` voor pad p. Voordeel: pad 17 is altijd hetzelfde, onafhankelijk van N_paths. Nadeel: correlatie tussen paden bij nauw gerelateerde seeds (in praktijk verwaarloosbaar).
8. **Tekort volledig uit buffer, geen jaarlijkse staffel.** Eerste slechte jaren kunnen de buffer leegtrekken; geen plafond per jaar.
9. **Buffer gemeten per pad, gemiddeld in output.** `bufEnd` is de gemiddelde eindbuffer over paden, geen mediaan of percentiel.
10. **Benchmark = "oude situatie met volledige inflatie-indexatie".** Dit is een ideaal-benchmark, niet de werkelijke pre-Wtp uitkering die voorwaardelijke indexatie kent. Historische SSPF heeft deze indexatie niet altijd volledig gegeven.
11. **Benchmark constant in reële termen, FPR-paden niet sterftegewogen.** De vergelijking toont zuiver het FPR-effect in koopkracht. De FPR-paden representeren de uitkering *als* de deelnemer nog leeft, niet de verwachte uitkering over alle toestanden.
12. **Plot-horizon: berekening tot ω, presentatie via UI-cap (v2.1.9, §11.9 besluit).** De engine berekent altijd tot `years = ω − x₀` zodat `U_t[p10/p50/p90]`-arrays volledige lengte hebben — geen informatie-verlies in de berekening. UI past `plotHorizonRule` (§4.3) toe als presentatie-cap met v1-default `'lifeExpPlus10'`: dynamisch op individu, R9.30-conform met +10-tail-extensie. Drie alternatieven beschikbaar: `'omega'` (levenslang, voor power-users en onderzoeks-uitvoer), `'coverage1pct'` (tot leeftijd met overlevingskans > 1%, statistisch eerlijke compromis), `'lifeExpExact'` (huidige R9.30-cap zonder tail, voor backward-compat). Output-velden `years_display` en `endAge_display` (§4.4) tonen het UI-bereik; onderliggende arrays blijven volledig.
13. **Percentielen per tijdstap onafhankelijk gesorteerd.** De "p10-lijn" is geen coherent pad; zij toont voor elke t het 10%-kwantiel van de uitkering op die t. Dit is gangbare praktijk bij distributie-communicatie maar relevant om te vermelden: p10 is geen plausibele realisatie.
14. **Latent-NP-dekking via tweede annuïteit, geen expliciete event-MC (v2.1.4, §11.18 follow-up bullet 2).** Bij `heeftPartner=true` wordt `ppk_NP` decompositief omgezet naar een latent-NP-startuitkering `U₀_NP = ppk_NP / ä(x_partner, proj, g_y)`. Mortality pooling van de latente NP-stroom wordt impliciet meegenomen via deze actuariële annuïteit, parallel aan aanname 5 voor de OP-hoofdstroom. Geen expliciete deelnemer-overlijdens-event in de Monte Carlo: de p10/p50/p90-banden blijven het hoofdpad (= deelnemer leeft) representeren conform aanname 11. `U₀_NP` is een bovengrens — exacte joint-life behandeling vereist `ä_{x|y}(proj) = Σ (1−ℓ_x(t)) · ℓ_y(t) · v^t` en is reservering voor v2 (zie §4.9 en §2.10 spiegel-reviewpunt in M1).
15. **Gender-tafel-doorwerking M1→M3 en AG2024 periode-snapshot (v2.1.5, §11.16-doorwerking).** De annuïteiten `ä(x₀, proj, g)` (OP-hoofdpad) en `ä(x_partner, proj, g_y)` (latent-NP) gebruiken AG2024 per geslacht via dezelfde periode-snapshot-conventie als M1: één kolom `t₀` (default 2026) voor alle toekomstige leeftijden, conform §2.6.2. Dit borgt de §1.1 ankerfunctie tussen M1 (`KV_OP = pen · ä(x₀, r, g)`) en M3 (`U₀_OP = ppk_OP / ä(x₀, proj, g)`): identieke sterftetafel, identieke gebruikswijze, alleen de rente verschilt (`r` vs `proj`), wat in v2.1 UI-koppeling default gelijk is. Cohort-interpretatie blijft voorbehouden aan M4 (§5.5.2), conform §11.16 besluit. `gemengd`-fallback voor `g`/`g_y` gebruikt SSPF-weging (95/5 deelnemer, 5/95 partner-gegeven-M) per §11.17. Geen numerieke wijziging — formaliseert wat patch v2.1.4 reeds in §4.5-formules schreef.
16. **BufferTrigger op koopkracht-anker als default; uitputtingsmechaniek R9.30-conform (v2.1.6, §11.6 besluit).** De buffer (RDR in SSPF-terminologie) wordt aangesproken bij `effR < inf` — koopkrachttekort. Educatief-narratief-rationale: spiegelt de huidige indexatie-praktijk van SSPF en ondersteunt daarmee de gebruikers-vergelijking "wat kreeg ik vroeger aan indexatie ↔ wat doet de buffer nu". De drie alternatieve trigger-formules zijn als enum-waardes beschikbaar (`'rendement'`, `'projectie'`, `'koopkracht-projectie'`) voor latere bron-gebaseerde keuze. Het uitputtingsmechaniek (`trekking = min(tekort, buffer_t)`, geen jaarlijks plafond) is R9.30-conform en in v1 default; SSPF-design-specifieke uitputtingsregels (gefaseerde aanwending, prioritering) zijn onbekend en geparkeerd in §4.10 voor latere bron-onderzoeks-ronde, parallel aan §3.10 compensatie-bell-curve-parkering uit v2.1.2.
17. **Inflatie deterministisch, correlatie rendement-inflatie ongemodelleerd in v1 (v2.1.7, §11.7 besluit).** Het `inf`-veld is in v1 één scalar per simulatie (geen stochastiek, geen tijd-as). Daardoor is `correlatieRenteInflatie = 0` in §4.3 niet alleen default maar effectief de enige zinvolle waarde — een non-nul correlatie-coëfficiënt heeft pas operationele werking als `inf` ook stochastisch wordt getrokken. Beide structureel beschikbaar als gekoppeld v2-pad via reservering `inflatieStochastiek` (sub-velden `μ_inf`, `σ_inf`) plus bestaand `correlatieRenteInflatie`-veld; activering vereist beide tegelijk en triggert bivariate trekking via Cholesky in een uitgebreide §4.5 rendementsgeneratie-blok. Identieke "gekoppeld v2-pad"-structuur als bij `RTS`/`agHerzienPeriode`/`renteAfdekkingFactor` voor SPR-varianten in §4.9. Bron-onderzoek voor SSPF-specifieke kalibratie (DNB-FTK-publicaties, AG-stochastische-set-parameters) is een eigenstandige ronde, geparkeerd parallel aan RDR-uitputtingsmechaniek-parking uit v2.1.6.
18. **Vlakke rente in v1, lifecycle-bundel als gekoppeld v2-pad, RTS-distinctie expliciet (v2.1.8, §11.8 besluit).** De parameters `proj`, `μ` en `σ` zijn in v1 alle drie scalars zonder leeftijds- of tijdsafhankelijkheid. Voor SSPF is dit conform werkelijk regime: collectieve toedelingskring, vast 60/40-portfolio (60% matching / 40% rendement-seeking), geen individuele lifecycles, geen profielkeuze door gepensioneerden. v2.1.8 concretiseert `μ=0,045` en `σ=0,08` als indicatieve defaults voor dit portfolio. Voor andere Wtp-fondsen met leeftijdsafhankelijke afbouw vormen `lifecycle-profiel` (μ(x), σ(x)) en nieuw toegevoegde `rtsCurve` (proj per leeftijd) een **gekoppeld v2-pad** — beide moeten samen actief zijn voor semantische coherentie (rendementsverwachting en discontering moeten beide leeftijdsafhankelijk zijn of geen van beide). Identieke koppelings-structuur als bij `correlatieRenteInflatie`+`inflatieStochastiek` (aanname 17). **RTS-distinctie**: `RTS` (vector zero-coupon rentes per looptijd, voor SPR-hybride rente-afdekking) is conceptueel orthogonaal aan `rtsCurve` (proj per leeftijd, voor FPR-lifecycle); beide gereserveerd in v1, beide met eigen activerings-pad.
19. **UI-cap default `lifeExpPlus10`, niet `lifeExpExact` (v2.1.9, §11.9 besluit).** Verschil met R9.30-baseline: R9.30 capt op `lifeExp` (mediaan-sterfleeftijd), wat per definitie de helft van het cohort tail-mist. v2.1.9-default `lifeExpPlus10` toont +10 jaar extra zonder de plot oncomfortabel breed te maken; voor 67-jarige man met `lifeExp ≈ 85` wordt de plot getoond tot leeftijd 95 (was 85). Power-users kunnen via `'omega'` levenslang zien om aanname 11 ("FPR-paden = uitkering *als* deelnemer nog leeft") visueel te toetsen. R9.30-backward-compat-modus blijft beschikbaar via `'lifeExpExact'`.

### §4.7 Fallbacks

| Ontbrekend veld | Fallback | Impact |
|---|---|---|
| `potje`, `buffer-aandeel` | **Module 2 moet lopen**; zonder potje geen projectie | Hard reject |
| `dempJaren` | 0 (geen demping) | r_t direct gebruikt; hogere volatiliteit in U-paden |
| `proj` | Dataset-default of DNB-standaard 2% | Beleidsmatig ijkpunt; afwijking schuift U₀ lineair |
| `inf` | Dataset-default of 2% | Benchmark en buffer-trigger schuiven mee |
| `correlatieRenteInflatie` | 0 | Huidig v1-gedrag |
| `lifecycle-profiel` | vlak | Huidig v1-gedrag |
| `RTS`, `agHerzienPeriode`, `renteAfdekkingFactor` | null | Alleen relevant voor SPR-varianten; niet gelezen in FPR-pad |
| `heeftPartner=false` (uit M1) | `ppk_NP=0 → U₀_NP=0`; `U₀ = ppkTotal / ä(x₀, proj, g)` | v2.1.4: terugval naar v1.x-eenkanaalgedrag, geen NP-decompositie in output |
| `g`, `g_y` (uit M1) | `gemengd` met SSPF-weging (95/5 deelnemer, 5/95 partner-gegeven-M; §11.17) | Doorwerking v1.7-keuze; UI-waarschuwing bij `gemengd` voor bekend geslacht |

### §4.8 Validaties

| Categorie | Regel | Actie bij schending |
|---|---|---|
| Invoerbereik | `potje` > 0 | Hard reject |
| Parameterbereik | 0 ≤ `proj` ≤ 0,04 (0-4%) | Hard reject buiten bereik |
| Parameterbereik | −0,05 ≤ `μ` ≤ 0,15 | Waarschuwing bij extreme waarden |
| Parameterbereik | 0 ≤ `σ` ≤ 0,30 | Hard reject bij σ < 0; waarschuwing bij σ > 0,25 |
| Parameterbereik | −0,02 ≤ `inf` ≤ 0,10 | Waarschuwing bij extreme waarden |
| Parameterbereik | 0 ≤ `dempJaren` ≤ 10 | Hard reject |
| Consistentie | regeling = 'FPR' in v1 (SPR vereist Fase B) | Waarschuwing met verwijzing naar reservering |
| Consistentie | Als regeling ∈ {SPR-clean, SPR-hybride}: `RTS` verplicht | Hard reject in Fase B; in v1: regeling niet toegestaan |
| Consistentie | Als regeling = 'SPR-hybride': `renteAfdekkingFactor` verplicht | Hard reject in Fase B |
| Gender (v2.1.5) | `g` ∈ {M, V, gemengd} | Waarschuwing bij `gemengd`-keuze als UI-signaal dat specifieke keuze accurater is; identiek aan §2.8 |
| Gender (v2.1.5) | Als `heeftPartner=true`: `g_y` ∈ {M, V, gemengd} | Waarschuwing bij `gemengd`; hard reject als veld ontbreekt terwijl `heeftPartner=true` |
| Partner (v2.1.5) | Als `heeftPartner=true`: `x_partner` gegeven en `0 ≤ x_partner ≤ ω` | Hard reject (M2/M3-koppeling vereist consistentie met §2.8) |
| Data-integriteit (v2.1.5) | `q_{x,t,g}` gedefinieerd voor `(x₀, t₀, g)` en — indien `heeftPartner=true` — `(x_partner, t₀, g_y)` over horizon `T_eff` | Hard reject |
| Parameterbereik (v2.1.5) | 2022 ≤ `t₀` ≤ 2200 | Hard reject buiten AG2024-range; identiek aan §2.8 |
| Consistentie (v2.1.5) | `sterftekansTabelId` identiek aan M1-`sterftekansTabelId` | Waarschuwing bij mismatch; cross-module ankerfunctie §1.1 vereist identieke tafel |

### §4.9 Scope-voorbehouden

- **Alleen FPR volledig gespecificeerd in v1.** SPR-clean en SPR-hybride hebben een parametercontract (welke velden ze vereisen) en zijn conceptueel beschreven, maar hun inner-loop-wiskunde is expliciet **reservering voor Fase B**. Dit is consistent met de R9.30-code waarin `verwSimulate` één FPR-route implementeert en het Implementatieplan SSPF bevestigt dat SSPF voor FPR heeft gekozen.
- **Geen waardering.** Module 3 levert uitkeringsbanen, geen contante waardes. Voor Δ = V_Wtp − V_DB is module 4 het juiste instrument.
- **Geen Δ-vergelijking met een pre-transitie-scenario.** De benchmark-lijn is een ideaal-referentie, geen zuivere pre-transitie waardering.
- **Geen keuze-effecten.** Hoog/laag-constructies, uitruil OP-PP, profielwijziging binnen FPR, overstap SPR↔FPR na transitie — niets daarvan is gemodelleerd.
- **Geen regime-shifts of crisis-scenario's.** De log-normale GBM kent geen fat-tails of structurele breuken; zware marktcrises zitten in de tail-kans maar zijn niet als aparte scenario apart.
- **NP als bovengrens, niet joint-life (v2.1.4).** `U₀_NP = ppk_NP / ä(x_partner, proj, g_y)` overschat de werkelijke latente NP-waarde — het rekent alsof partner-uitkering meteen op peildatum start, terwijl in werkelijkheid pas bij overlijden deelnemer. Exacte joint-life vereist `ä_{x|y}(proj) = Σ (1−ℓ_x(t)) · ℓ_y(t) · v^t`. Reservering voor v2, parallel aan spiegel-reviewpunt §2.10 in M1 en §5.12.3 in M4 (v2.2.3). Voor gepensioneerden met vergelijkbare leeftijd is het verschil typisch 10–20% op `U₀_NP` (deepdive-veld); op het hoofdpad `U₀` is er geen impact want dat blijft het OP-pad. **Gekoppeld v2-pad:** activering joint-life raakt M1/M3/M4 tegelijk; zie §5.12.3 voor de expliciete coherentie-eis. **v2.2.11-asymmetrie-status (04-05-2026 23:37):** M1 (§2.10) heeft joint-life met broken-heart-correctie ge-activeerd; M3 blijft op bovengrens-formule, **M3 wordt mechanisch geraakt** door verlaagde `ppk_NP` uit M2-keten (lagere KV_NP → lagere ppk_NP → lagere `U₀_NP`) maar M3-formule zelf ongewijzigd. v2.2.3-werkafspraak ("gekoppeld v2-pad") procedureel doorbroken voor M1-only-keuze; M3-pendant openstaand tot M3-implementatie. Bij M3-bouw wordt `U₀_NP` herzien naar joint-life-conforme formule met dezelfde `bh()`-functie (zie §11.20). **v3.0-status (05-05-2026):** M3-formule blijft ongewijzigd onder v3.0, maar wordt opnieuw mechanisch geraakt door v3.0-formule-overstap in M2: `ppk_NP` schuift onder v3.0 lichtelijk t.o.v. R9.30-legacy (per individu afhankelijk van cw_star_np-verhouding); voor SSPF-anker is de richting identiek aan ppkTotal (~+0,4% voor 67M+65V). Asymmetrie-resolutie M3 (joint-life-conforme `U₀_NP`-formule) blijft openstaand onafhankelijk van v3.0; bij M3-bouw worden beide tegelijk opgepakt (joint-life + v3.0-cascade-input).

### §4.10 Reviewpunten

- **~~Buffer-trigger-formule.~~** ~~De huidige trigger `effR < inf` meet tekort in koopkrachttermen, maar bij FPR met opt-in buffer is `effR < proj + inf` zuiverder: tekort t.o.v. projectie-plus-inflatie. Het codecommentaar in R9.30 vlagt dit expliciet als heroverwegingspunt. De keuze raakt zowel de frequentie als de omvang van buffer-trekkingen. In het parametercontract is `bufferTrigger` daarom opgenomen als gereserveerd enum-veld; de v1-default is `koopkracht` voor gedragsbehoud.~~ **Opgelost in v2.1.6 (besluit §11.6, 23-04-2026 16:14):** `bufferTrigger` actief met vier enum-waardes (`'koopkracht'` default, `'rendement'`, `'projectie'`, `'koopkracht-projectie'`); zie §4.3, §4.5, §4.6 aanname 16. Educatief-narratief-rationale (indexatie-spiegeling) doorslaggevend; alternatieven structureel beschikbaar voor latere SSPF-bron-keuze.
- **RDR-uitputtingsmechaniek (v2.1.6, geparkeerd).** Het v1-mechanisme (`trekking = min(tekort, buffer_t)`) trekt bij elke trigger het volledige tekort uit de buffer tot de bufferbodem, R9.30-conform. SSPF-design hanteert mogelijk een ander uitputtingsregime: jaarlijks plafond (bv. max X% van buffer per jaar onttrekbaar), gefaseerde aanwending (bv. eerst halve trekking, dan pas volledig), of prioritering tussen cohorten. Het exacte mechanisme is niet bekend bij Hans (Innovation Nestor SSPF) en niet in publieke bronnen aangetroffen tijdens scherm-3-sessie. **Geparkeerd voor latere bron-onderzoeks-ronde**, parallel aan §3.10 compensatie-bell-curve-parkering uit v2.1.2. Bij vondst SSPF-RDR-reglement of bestuursnotitie kan een eigenstandige patch het mechanisme aanpassen zonder spec-revisie elders. Numerieke impact: kan `bufEnd`, `shortfall`, `fullyCov`/`partCov`/`notCov` substantieel verschuiven, vooral in sterke-tegenwind-paden.
- **SPR-clean en SPR-hybride inner loops.** De parameters zijn voorbereid (`RTS`, `agHerzienPeriode`, `renteAfdekkingFactor`), de update-formules niet. SPR-clean: U_{t+1} = f(AG-herziening, beschermings- en overrendement, RTS-update). SPR-hybride voegt rente-afdekking toe in de noemer. Uitwerken in Fase B.
- **Correlatie rente-inflatie als gekoppelde v2-uitbreiding (v2.1.7, §11.7 besluit).** Onafhankelijkheid is in v1 een nul-aanname die pragmatisch is: `inf` is deterministisch, dus correlatie-coëfficiënt heeft geen operationele werking. In de praktijk is correlatie tussen nominale rendementen en inflatie doorgaans positief (hogere inflatie → hogere nominale rente), en correlatie tussen *real* rendement en inflatie vaak licht negatief — wat voor SSPF-koopkrachtfocus de relevantere maatvoering is. Activering is een gekoppeld v2-pad: `inflatieStochastiek` (sub-velden `μ_inf`, `σ_inf`) + bestaand `correlatieRenteInflatie`, beide null in v1. Bivariate Cholesky-trekking voor `(r_t, inf_t)` in §4.5 rendementsgeneratie-blok. SSPF-bron-onderzoek (DNB-FTK, AG-stochastische-set) voor kalibratie geparkeerd, parallel aan RDR-uitputtingsmechaniek-parking uit v2.1.6.
- **Lifecycle-bundel als gekoppelde v2-uitbreiding (v2.1.8, §11.8 besluit).** Vlakke rente in v1 is voor SSPF correct (collectieve toedeling, vast 60/40, geen individuele lifecycles). Voor andere Wtp-fondsen met individuele FPR (lifecycle-belegging waarbij beleggingsrisico met leeftijd wordt afgebouwd) zou μ(x) en σ(x) per cohort realistischer zijn. Activering is een gekoppeld v2-pad: `lifecycle-profiel` (μ/σ per leeftijd) + nieuw `rtsCurve` (proj per leeftijd), beide null in v1. Activeren-zonder-koppeling zou semantisch incoherent zijn (rendementsverwachting leeftijdsafhankelijk, maar discontering niet, of omgekeerd). Conceptueel orthogonaal aan SPR-`RTS`-veld dat rente-afdekking ondersteunt; v2.1.8 maakt deze RTS-distinctie expliciet in §4.3.
- **Percentiel-selectie.** Hardcoded op p10/p50/p90; sommige communicatie-contexten vragen p5/p50/p95 of een bredere band (p2,5/p97,5). Parametercontract laat dit toe; UI-keuze is buiten scope.
- **~~Plot-horizon versus levenslang.~~** ~~De cap op verwachte sterfleeftijd comprimeert de grafiek maar verbergt de tail. Voor statistische eerlijkheid zou een levenslang-tot-ω variant naast de huidige kunnen staan, met lagere overlevingskans.~~ **Opgelost in v2.1.9 (besluit §11.9, 23-04-2026 17:05):** scheiding berekening (altijd tot ω) en presentatie (`plotHorizonRule`-enum met vier waardes); v1-default `'lifeExpPlus10'` toont tail van langlevenden. Zie §4.3, §4.4, §4.5, §4.6 aanname 12 + 19.
- **Scherm-2–scherm-3 koppeling via buffer.** Conceptueel doorkruist het buffer-aandeel de module-grens. Zie reviewpunt §3.10 voor de parallelle opmerking uit module 2.

---

## §5. Module 4 — Waardevergelijking

Module 4 beantwoordt een eigen vraag naast de keten 1→2→3: *wat is de contante waarde van mijn aanspraak onder voortgezet DB-regime vergeleken met onder Wtp-regime, onder dezelfde grondslagen?* De inhoud van deze sectie is overgenomen uit `calculator_specificatie.docx` (de oorspronkelijke engine-specificatie, die één module besloeg), met alleen nummering en cross-references aangepast om in te voegen in het vier-modules-model. De structuur binnen module 4 volgt daarmee de docx-paragraafindeling §§1-13, niet de vaste substructuur van modules 1-3; inhoudelijk dekt zij materieel dezelfde gebieden.

Module 4 is als enige module in v1 **niet gerealiseerd** in de R9.30-code. Alle actuariële infrastructuur (generatietafel als 2D-object, ervaringssterftefactor, joint-life annuïteiten, twee-pass V-berekening, indexatiescenario-combinaties) moet nieuw gebouwd worden. De implementatie is sessie 3 of later; deze sectie specificeert wat er gebouwd moet worden.

### §5.1 Doel en scope

Deze module specificeert de rekenmodule voor een calculator die op individueel niveau de pensioenaanspraak vóór Wtp-transitie vergelijkt met de aanspraak na transitie. De module neemt de positie van de deelnemer als uitgangspunt: de deelnemer vult in wat hij of zij weet uit het UPO, en de fondsspecifieke parameters worden afzonderlijk ingelezen uit een aparte parameterset.

De specificatie is ontworpen rondom drie principes:

- **Individueel perspectief:** de gebruiker is de deelnemer, niet het fonds; alle invoer is direct herkenbaar van het UPO of de persoonlijke situatie.
- **Fondsagnostische rekenmodule:** de module is niet gebonden aan één fonds of één regeling; de fondsspecifieke parameters vormen een inwisselbare blob die aan de module wordt aangeboden.
- **Expliciete vergelijking pre versus post:** de module waardeert de aanspraak onder voortgezet DB-regime en onder Wtp-regime met dezelfde actuariële grondslagen, zodat het verschil interpreteerbaar is.

#### §5.1.1 Scope-afbakening v1

Deze specificatie beschrijft een deterministische puntwaardering op transitiedatum. Dat heeft expliciete implicaties die in de calculator-UI duidelijk zichtbaar moeten zijn:

- **Waarde-equivalent onder veronderstellingen:** V_x^Wtp is geen actuariële contante waarde in strikte zin, maar een waarde-equivalent onder de aanname dat π^Wtp de verwachte jaarlijkse ontwikkeling van de uitkering representeert. Het verschil Δ is daarmee een verwachte-waardeverschil, geen gerealiseerd waardeverschil. Zie §5.12.1 voor de volledige uitwerking inclusief UI-disclosure-eis (besluit v2.2.1).
- **Geen risicodeling gewaardeerd:** onder een solidaire regeling (SPR) wordt risico tussen cohorten gedeeld via een collectieve reserve. De waarde van die risicodeling zelf wordt in een deterministisch model niet geprijsd; alleen de verwachtingswaarde komt tot uiting.
- **Fondsparameters bepalen realisme:** de module voert geen eigen afleiding uit van bijvoorbeeld π^Wtp uit beleggingsbeleid of toeslagstaffel uit dekkingsgraad. Die afleidingen worden verondersteld te zijn gedaan bij het samenstellen van de fondsparameterset. Zie §5.12.2 (v2.2.2) voor de scope-grens voor π^Wtp-afleiding en §5.12.5 (v2.2.5) voor de parallelle scope-grens voor φ-effectiviteit (φ wordt verondersteld reeds gecorrigeerd voor bestemmingsreserves); beide vormen samen de parameterset-discipline voor de kritieke projectie- en toedelings-grootheden.

De volledige reviewpunten en uitbreidingsmogelijkheden staan in §5.12 en §5.13.

### §5.2 Architectuur binnen module 4

Module 4 bestaat uit drie componenten die los van elkaar gespecificeerd en onderhouden kunnen worden:

**Component 1 — Deelnemersinvoer.** Een klein, door de eindgebruiker in te vullen formulier met gegevens die op het UPO staan: leeftijd, geslacht, jaarlijks bruto OP, eventueel PP-bedrag en partnerleeftijd.

**Component 2 — Fondsparameterset.** Een extern gedefinieerd object met alle fonds- en regelinggebonden grootheden: toedelingsfactor, rentestructuur, sterftetafel, ervaringssterfte, indexatie-aannames pre en post, kostenopslagen, betalingsfrequentie. Deze set wordt apart ingeladen en is uitwisselbaar tussen fondsen en scenario's. De verantwoordelijkheid voor afleiding en bronkwaliteit van de parameters (in het bijzonder π^Wtp) ligt bij de samensteller, niet bij de rekenmodule; zie §5.12.2 voor de formele scope-grens (v2.2.2).

**Component 3 — Rekenmodule.** Een deterministische functie die de deelnemersinvoer en de fondsparameterset combineert tot twee waarden: de actuariële contante waarde vóór transitie (V_x^DB) en na transitie (V_x^Wtp), en het toegedeelde individueel pensioenvermogen K_x. De module maakt zelf geen keuzes over aannames; alle keuzes zitten in component 2. **v2.2.7-status:** de module berekent V_x^DB, V_x^Wtp, K_x en Δ als totaal-output; OP en NP zijn twee termen binnen de sommatie §5.5.5, niet aparte output-velden. OP/NP-breakdown is in v1 presentatie-laag, geen berekeningslaag; zie §11.12 voor v2-heropenings-voorwaarden van component-primaire output (`V_x^Wtp_OP`, `V_x^Wtp_NP`).

De rekenmodule werkt in één pass per scenario. Voor gevoeligheidsanalyse wordt zij meerdere keren aangeroepen met verschillende fondsparametersets.

### §5.3 Invoerschema — deelnemer

De deelnemersinvoer is bewust minimaal en alleen gebaseerd op informatie die direct uit het UPO of de persoonlijke situatie beschikbaar is.

| Veld | Type | Verplicht | Toelichting |
|---|---|---|---|
| `x₀` | decimal | ja | Leeftijd van de deelnemer op transitiedatum, in jaren (fractioneel toegestaan) |
| `g_x` | enum {M, V} | ja | Geslacht van de deelnemer (voor selectie binnen de sterftetafel) |
| `t₀` | integer | ja | Kalenderjaar van transitiedatum (voor generatietafel) |
| `B_OP` | decimal ≥ 0 | ja | Jaarlijks bruto ingegaan ouderdomspensioen in EUR, zoals op UPO |
| `B_PP` | decimal ≥ 0 | optioneel | Jaarlijks bruto latent partnerpensioen in EUR (0 als er geen partnerpensioen is of geen partner bekend) |
| `y₀` | decimal | indien B_PP>0 | Leeftijd van de partner op transitiedatum |
| `g_y` | enum {M, V} | indien B_PP>0 | Geslacht van de partner |

### §5.4 Invoerschema — fondsparameterset

De fondsparameterset wordt separaat ingeladen. Velden kunnen ontbreken; ontbrekende velden activeren fallback-gedrag, zie §5.7. De rekenmodule hoeft zelf niets te weten over de herkomst of semantiek van de parameterset.

| Veld | Type | Default | Toelichting |
|---|---|---|---|
| `φ` | scalar of map[int→decimal] | scalar, geen default | Toedelingsfactor. Scalar wordt uniform toegepast; map geeft leeftijdsafhankelijke φ(x) |
| `i` | decimal | fallback | Vlakke rekenrente. Wordt alleen gebruikt als RTS ontbreekt |
| `RTS` | vector[decimal] | leeg → fallback | Rentetermijnstructuur: zero-coupon rentes per looptijd in jaren 1..T_max (bijv. 60) |
| `q_{x,t}` | 2D-array | verplicht | Generatietafel: sterftekansen per leeftijd en kalenderjaar, per geslacht |
| `f` | map[(x,g)→decimal] | 1,0 | Ervaringssterftefactor, multiplicatief op q_{x,t} |
| `π^DB` | decimal of vector | 0% | Projectie-indexatie onder voortgezet DB-regime, per jaar |
| `π^Wtp` | decimal of vector | 0% | Projectie van jaarlijkse ontwikkeling uitkering onder Wtp-regime |
| `ρ^DB` | decimal | 0% | Kostenopslag pre-transitie, multiplicatief op V_x^DB |
| `ρ^Wtp` | decimal | 0% | Kostenopslag post-transitie, multiplicatief op V_x^Wtp |
| `m` | int ∈ {1,4,12} | 12 | Betalingsfrequentie: 1=jaar, 4=kwartaal, 12=maand |
| `ω` | integer | 120 | Eindleeftijd sterftetafel |

### §5.5 Rekenmodule

De rekenmodule doorloopt zes deterministische stappen. De stappen zijn identiek voor de pre-transitiewaardering (V_x^DB) en de post-transitiewaardering (V_x^Wtp); verschillen zitten uitsluitend in de gebruikte indexatie- en kostenopslag.

#### §5.5.1 Stap 1 — Sterftekansen construeren

Voor elke leeftijd en elk kalenderjaar wordt de fondsspecifieke sterftekans berekend als het product van de generatietafel-sterftekans en de ervaringssterftefactor:

```
q^{fonds}_{x+j}(t₀+j) = f(x+j, g) · q^{AG}_{x+j}(t₀+j)
```

waarbij q^{AG} uit de generatietafel komt en f uit de ervaringssterftefactor. Bij ontbreken van f wordt f = 1 toegepast.

#### §5.5.2 Stap 2 — Overlevingskansen

De k/m-jaars overlevingskans vanaf leeftijd x₀ wordt berekend als het product van de complementen van de sterftekansen over de tussenliggende sub-periodes. Voor jaarlijkse stappen:

```
_t p_{x₀} = ∏_{j=0..t−1} (1 − q^{fonds}_{x₀+j}(t₀+j))
```

Voor sub-jaarlijkse stappen (m>1) wordt de éénjaars overlevingskans uniform over het jaar verdeeld: (1−q)^{1/m} per sub-periode. Dit is de standaard benadering bij niet-seizoensgebonden sterfte.

#### §5.5.3 Stap 3 — Disconteringsfactoren

De disconteringsfactor P(0,t) wordt bepaald volgens een van twee paden:

**RTS-pad (voorkeur):** gegeven de rentetermijnstructuur met zero-coupon rentes i_t per looptijd t:

```
P(0, t) = (1 + i_t)^{−t}
```

**Fallback-pad:** bij ontbreken van de RTS wordt de vlakke rekenrente i toegepast:

```
P(0, t) = (1 + i)^{−t}
```

Voor sub-jaarlijkse tijdpunten (t = k/m) wordt dezelfde formule toegepast met fractioneel t. Bij gebruik van de RTS wordt de rente voor niet-integere looptijden lineair geïnterpoleerd tussen de omliggende looptijden.

#### §5.5.4 Stap 4 — Koopsomfactoren

**Koopsomfactor OP** (direct ingaande levenslange annuïteit op x₀) bij betalingsfrequentie m (uitkering achteraf):

```
a_{x₀}^{(m)} = (1/m) · Σ_{k=1..m(ω−x₀)} _{k/m} p_{x₀} · P(0, k/m)
```

**Koopsomfactor PP** (reversionary annuity na overlijden van x₀). Het partnerpensioen keert uit aan de partner vanaf het moment van overlijden van de deelnemer, mits de partner op dat moment in leven is. De koopsomfactor volgt uit het verschil tussen de annuïteit op de partner alleen en de joint-life annuïteit op beiden:

```
a_{x₀ y₀}^{PP,(m)} = a_{y₀}^{(m)} − a_{x₀ y₀}^{(m)}
```

waarbij de joint-life annuïteit gebruikmaakt van de joint-overlevingskans (onafhankelijkheid verondersteld):

```
_{k/m} p_{x₀ y₀} = _{k/m} p_{x₀} · _{k/m} p_{y₀}
```

**Indexatie-verwerking.** De indexatie wordt verwerkt als een multiplicatieve opslag op de kasstromen. Voor een constante jaarlijkse indexatie π wordt de koopsomfactor:

```
a_{x₀}^{(m, π)} = (1/m) · Σ_{k=1..m(ω−x₀)} (1 + π)^{k/m} · _{k/m} p_{x₀} · P(0, k/m)
```

Bij een tijdsafhankelijke indexatievector π_t wordt (1+π)^{k/m} vervangen door het cumulatieve product ∏(1+π_s) over de voorliggende perioden.

#### §5.5.5 Stap 5 — Actuariële contante waarde (twee varianten)

De actuariële contante waarde wordt twee keer berekend: één keer met de DB-indexatie en DB-kostenopslag, en één keer met de Wtp-indexatie en Wtp-kostenopslag. Alle andere grondslagen (discontering, sterfte, leeftijd, frequentie) zijn identiek.

**Pre-transitie waardering:**

```
V_{x₀}^{DB} = (1 + ρ^DB) · [ B_OP · a_{x₀}^{(m, π^DB)} + B_PP · a_{x₀ y₀}^{PP,(m, π^DB)} ]
```

**Post-transitie waardering:**

```
V_{x₀}^{Wtp} = (1 + ρ^Wtp) · [ B_OP · a_{x₀}^{(m, π^Wtp)} + B_PP · a_{x₀ y₀}^{PP,(m, π^Wtp)} ]
```

#### §5.5.6 Stap 6 — Toegedeeld individueel pensioenvermogen

De toedelingsfactor wordt toegepast op de Wtp-waardering om het toegedeelde persoonlijke vermogen op transitiedatum te bepalen:

```
K_{x₀} = φ(x₀) · V_{x₀}^{Wtp}
```

Bij een scalar φ wordt φ(x₀) = φ voor alle x₀. Bij een leeftijdsafhankelijke toedelingsfactor wordt de waarde uit de φ-map voor de dichtstbijzijnde cohort gebruikt, of lineair geïnterpoleerd tussen aangrenzende cohorten (implementatiekeuze, vast te leggen bij parametercontract).

De vergelijking die de calculator aan de eindgebruiker toont is:

```
Δ = V_{x₀}^{Wtp} − V_{x₀}^{DB}
```

Een positieve Δ betekent dat de aanspraak onder Wtp-regime hoger wordt gewaardeerd dan onder voortgezet DB; een negatieve Δ het omgekeerde. De interpretatie hangt samen met de gekozen indexatiescenario's (§5.6).

### §5.6 Indexatiescenario's

*v2.2.6-status:* met patch v2.2.6 (23-04-2026 19:46) is deze scenario-set formeel bevestigd als de v1-operationele compensatie voor de π^DB-vereenvoudiging uit §5.12.6. De scenario-vergelijking is daarmee niet decoratie maar de v1-oplossing voor DB-toeslag-beleidsvariatie; parameterset-samensteller kiest welke subset of fondsspecifieke alternatieven worden getoond.

De vergelijking Δ is niet één getal maar een functie van de indexatieaannames. De calculator rapporteert de uitkomst voor meerdere scenarioparen. De aanbevolen standaardset:

| Scenario | π^DB | π^Wtp | Beschrijving |
|---|---|---|---|
| Geen indexatie | 0% | 0% | Nominale vergelijking, negeert toekomstige verhogingen |
| DB stil, Wtp laag | 0% | 1% | Historisch DB-gedrag, voorzichtig Wtp-rendement |
| DB stil, Wtp midden | 0% | 2% | Historisch DB-gedrag, realistisch Wtp-rendement |
| DB prijsinflatie, Wtp midden | 2% | 2% | Volledige DB-toeslag, realistisch Wtp-rendement |
| DB prijsinflatie, Wtp hoog | 2% | 3% | Ambitiescenario beide zijden |

De standaardset is niet uitputtend. De fondsparameterset kan scenario's toevoegen of vervangen, bijvoorbeeld om fondsspecifieke verwachte rendementen of historisch toeslaggedrag weer te geven.

### §5.7 Fallbacks bij ontbrekende gegevens

De rekenmodule is bestand tegen onvolledige fondsparametersets. Per veld geldt het onderstaande gedrag. Het is expliciet aan de calculator-UI om zichtbaar te maken welke fallbacks actief zijn voor de gebruiker, zodat het vertrouwen in de uitkomst onderbouwd is.

| Ontbrekend veld | Fallback-gedrag | Impact |
|---|---|---|
| RTS | v^t = (1+i)^{−t} | Systematische afwijking t.o.v. fondswaardering |
| `f(x,g)` | f = 1,0 (AG-baseline) | Mogelijk 10–20% afwijking voor fondsen met afwijkend populatieprofiel |
| `B_PP` | B_PP = 0 | PP-component wordt uit V_x gelaten |
| π^DB, π^Wtp | 0% | Nominale vergelijking; vergelijking zonder indexatieaannames |
| ρ^DB, ρ^Wtp | 0% | Kostenverschil niet zichtbaar in vergelijking |
| φ(x) | scalar φ voor alle leeftijden | Geen cohortdifferentiatie; voor gepensioneerden meestal kleine afwijking |

### §5.8 Consistentievoorwaarde

Voor een zuivere vergelijking tussen V_x^DB en V_x^Wtp moeten beide waarden onder identieke technische grondslagen berekend zijn. Dat wil zeggen: dezelfde rentestructuur, sterftetafel, ervaringssterfte, betalingsfrequentie en ω. Verschillen tussen pre en post zitten uitsluitend in de indexatie- en kostenopslagen.

Deze voorwaarde is geen beleidskeuze maar een wiskundige hygiëne-eis. Zonder deze voorwaarde reflecteert Δ niet alleen het effect van de transitie, maar ook methodische verschillen in waardering, waardoor de vergelijking zijn betekenis verliest.

De rekenmodule assumeert en valideert deze voorwaarde intern: beide waarderingspassages ontvangen dezelfde grondslagen-subset uit de fondsparameterset. Alleen de indexatie- en kostenopslag-parameters worden per passage anders toegepast.

Aanvullend geldt op fondsniveau de implicatie: als voor de totale populatie de som Σ V_i^DB gelijk is aan de door het fonds gerapporteerde technische voorziening TV, dan is de toedelingsfactor φ = A/TV een correcte proportionele toedeling. Afwijking duidt op grondslagverschil tussen calculator en fondsadministratie en moet worden afgestemd.

### §5.9 Validaties en sanity checks

De rekenmodule voert voor én tijdens de berekening de volgende controles uit. Waarschuwingen worden aan de UI doorgegeven; hard rejects doen de berekening niet starten.

| Categorie | Regel | Actie bij schending |
|---|---|---|
| Invoerbereik | 0 ≤ x₀ ≤ ω; 0 ≤ y₀ ≤ ω | Hard reject: ongeldige leeftijd |
| Invoerbereik | B_OP ≥ 0; B_PP ≥ 0 | Hard reject: negatieve pensioenbedragen |
| Consistentie | B_PP > 0 ⇒ y₀ en g_y verplicht | Hard reject met verduidelijking |
| Parameterbereik | 0,5 ≤ φ ≤ 1,5 | Waarschuwing; resultaat wel berekend |
| Parameterbereik | −0,02 ≤ i ≤ 0,10 | Waarschuwing; resultaat wel berekend |
| Parameterbereik | 0 ≤ π ≤ 0,10 | Waarschuwing bij hoge waarden |
| Data-integriteit | q_{x,t} gedefinieerd voor alle benodigde (x,t) | Hard reject: tafel incompleet |
| Consistentie rekenmodule | V_x^DB en V_x^Wtp onder dezelfde grondslagen | Interne assertion; mag niet divergeren |

### §5.10 Toepassingsmodi

De calculator ondersteunt drie toepassingsmodi, verschillend in de volledigheid van de fondsparameterset. De rekenmodule zelf is in alle modi identiek; alleen de invoer verschilt.

#### §5.10.1 Volledige modus

De fondsparameterset is afkomstig van de fondsadministrateur of is afgeleid uit het officiële transitieplan. Alle velden zijn gevuld: RTS, generatietafel met ervaringssterfte, cohortspecifieke φ, en de relevante indexatie- en kostenopslagen. De calculator levert in deze modus een uitkomst die in orde van grootte overeenstemt met de fondseigen berekening. De bronverantwoordelijkheid voor deze parameters — in het bijzonder de afleiding van π^Wtp uit beleggingsbeleid en reserve-onttrekkingen — ligt bij de samensteller van de parameterset conform §5.12.2 (v2.2.2).

#### §5.10.2 Benaderingsmodus

De gebruiker beschikt over gepubliceerde hoofdcijfers van het fonds (dekkingsgraad, gemiddelde rekenrente, AG-tafel zonder ervaringssterfte) maar niet over de volledige set. Vlakke rente wordt toegepast in plaats van RTS, en φ als scalar. De calculator geeft een indicatief resultaat met expliciete onzekerheidsmarge.

#### §5.10.3 Demonstratiemodus

Alle fondsparameters zijn defaults of illustratief gekozen. De calculator is alleen geschikt voor didactisch gebruik om het transitiemechaniek te verkennen. Uitkomsten mogen niet als reële prognose worden geïnterpreteerd.

### §5.11 Vooruitblik en uitbreidingen

De huidige specificatie is een eerste versie, bewust afgebakend. De volgende uitbreidingen passen op dezelfde rekenmodule-architectuur:

- Stochastische indexatiescenario's: verwachtingswaarde met bandbreedte in plaats van één percentage, uit te drukken als percentielen van het toegedeelde vermogen.
- DG-afhankelijke toeslagprojectie (v2.2.6-reservering): volledige toeslag-mechaniek als separate module met `π^DB(t, DG_t)` als functie van geprojecteerde dekkingsgraad onder een rente-pad, met staffel-parameters (vol-/half-/geen-indexatie), plafond (bijv. CPI) en eventueel inhaalindexatie-boekhouding. Vervangt de v1-scalar/vector-vereenvoudiging (§5.12.6) en de v1-scenario-compensatie (§5.6) door een expliciete toeslagmechaniek-laag.
- Leeftijds- én componentafhankelijke φ(x, component), voor fondsen die OP en PP in de toedeling verschillend behandelen.
- Ondersteuning voor nog niet gepensioneerde deelnemers (actieven, slapers), waarbij de ingangsdatum en projectie tot ingangsdatum worden meegenomen.
- Scenario's voor keuzes ná transitie binnen het Wtp-kader: solidair versus flexibel regime, hoog-laag-constructies, uitruil OP-PP.
- Expliciete modellering van de solidariteitsreserve, compensatiedepots en cohortoverdrachten waar deze in het transitieplan van het fonds zijn opgenomen.

### §5.12 Reviewpunten en scope-aanscherping v1

Deze paragraaf legt de methodische voorbehouden van v1 expliciet vast. Ze zijn geformuleerd als reactie op de vragen die een actuariële reviewer naar verwachting stelt. Het doel is niet om alle voorbehouden weg te nemen maar om ze transparant te maken en de grens van v1 scherp te markeren.

#### §5.12.1 V_x^Wtp is een waarde-equivalent, geen actuariële contante waarde

De formulering in §5.5.5 hanteert een DB-achtige waarderingsstructuur (vast bedrag × annuïteit met indexatie-opslag) ook voor de Wtp-kant. In werkelijkheid is de uitkering onder Wtp geen vast bedrag plus indexatie, maar een direct van fondsrendement afgeleide variabele uitkering.

De waardering V_x^Wtp moet daarom worden geïnterpreteerd als waarde-equivalent onder de aanname dat π^Wtp de verwachte jaarlijkse ontwikkeling correct weergeeft. Het verschil Δ = V_x^Wtp − V_x^DB is daarmee een verwachte-waardeverschil, geen gegarandeerd waardeverschil. In de UI dient dit onderscheid expliciet zichtbaar te zijn.

**Besluit Hans 23-04-2026 19:09 (patch v2.2.1): Optie 1 — formalisering als besloten aanname met harde UI-disclosure-eis.** Vier kern-elementen:

1. **Waarde-equivalent-status geformaliseerd als v1-aanname.** V_x^Wtp is in v1 een waarde-equivalent onder de projectie-aanname dat π^Wtp de verwachte jaarlijkse ontwikkeling van de uitkering correct representeert — niet een actuariële contante waarde in strikte zin. Δ = V_x^Wtp − V_x^DB is een verwachte-waardeverschil, geen gerealiseerd of gegarandeerd waardeverschil.
2. **UI-disclosure verplicht, niet-adviserend.** Het scherm-4-ontwerp *moet* bij de getoonde V_x^Wtp en Δ expliciet benoemen dat deze waardes afhankelijk zijn van de projectie-aanname π^Wtp. Voorstel-tekst: *"V_x^Wtp is een waarde-equivalent: de waarde van de aanspraak als de verwachte jaarlijkse ontwikkeling van de uitkering onder Wtp gelijk is aan π^Wtp. Een werkelijk hoger of lager rendement leidt tot een andere uitkomst. Δ toont daarmee een verwachte-waardeverschil, geen gegarandeerd verschil."*
3. **Terminologie-anker vastgelegd.** In deze specificatie, in SCHEMA v2-documentatie en in UI-teksten wordt voor V_x^Wtp de term *waarde-equivalent (onder projectie-aanname)* gebruikt, en voor Δ de term *verwachte-waardeverschil*. Deze termen vervangen ambiguë alternatieven als "contante waarde" of "Wtp-waarde" waar het onderscheid met V_x^DB (wél een strikte actuariële contante waarde onder π^DB-voorwaardelijk-toeslag-interpretatie) relevant is.
4. **Kruisverwijzing §11.15 als M1-spiegel.** In M1 (§11.15, v1.6) is de analoge keuze gemaakt voor π op aanspraak tijdens waardering: π=0 als bewust anker. §5.12.1 is de M4-pendant voor π^Wtp als *verwachte ontwikkeling*. Samen vormen ze één cross-module discipline: projectie-aannames zijn altijd expliciet, nooit impliciet; hun karakter (anker, voorwaardelijke toeslag, verwachte ontwikkeling) staat in UI-disclosure uitgelegd.

**Doorwerking.** §5.1.1 "Waarde-equivalent onder veronderstellingen"-bullet verwijst naar §5.12.1 voor volledige uitwerking. §11.15 afsluitende zin noemt §5.12.1 als M4-pendant. Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe velden. Numerieke impact: geen.

#### §5.12.2 Afleiding van π^Wtp is buiten de rekenmodule

De rekenmodule behandelt π^Wtp als een invoer. De reële samenstelling van π^Wtp is echter complex en bestaat minimaal uit: beschermingsrendement (rente-afhankelijk, leeftijdsafhankelijk), overrendement (leeftijdsafhankelijk, typisch afnemend met leeftijd), operationele kosten en eventuele onttrekkingen uit de solidariteits- of risicodelingsreserve.

De kwaliteit van de calculator-uitkomst hangt af van de kwaliteit waarmee π^Wtp door de samensteller van de fondsparameterset is afgeleid. De rekenmodule maakt dit niet controleerbaar en stelt geen eigen π^Wtp voor. Deze afbakening dient in de documentatie van de parameterset te worden vastgelegd.

**Besluit Hans 23-04-2026 19:20 (patch v2.2.2): Optie 1 — scope-grens geformaliseerd met drie engine-niet-verantwoordelijkheden.** Vier kern-elementen:

1. **Scope-grens geformaliseerd als v1-besluit.** De afleiding van π^Wtp valt buiten de rekenmodule. π^Wtp is een invoer die door de samensteller van de fondsparameterset wordt aangeleverd; de engine rekent zuiver maar beoordeelt de bron niet.
2. **Drie engine-niet-verantwoordelijkheden expliciet.** (a) *Geen automatische afleiding.* De engine leidt π^Wtp niet af uit beleggingsbeleid, lifecycle-profiel, RTS of andere fondsgegevens; er is geen formule `π^Wtp = f(beleggingsmix, rente, leeftijd)` in de module. (b) *Geen validatie van bronkwaliteit.* De engine controleert niet of π^Wtp is afgeleid volgens DNB-richtlijnen, AG-consensus of fondsspecifieke methodiek; bronkwaliteit is een documentatie-aspect van de parameterset, niet een runtime-check. (c) *Geen realisme-alarmbel.* De engine geeft geen waarschuwingen bij ongebruikelijke π^Wtp-waardes (anders dan de generieke invoerbereik-validaties uit §5.9, zoals 0 ≤ π ≤ 0,10); interpretatie van realisme is aan de samensteller.
3. **Documentatie-eis aan parameterset.** Elke fondsparameterset die de calculator voedt moet in begeleidende documentatie vastleggen hoe π^Wtp is afgeleid — minimaal welke componenten (beschermingsrendement, overrendement, kosten, reserve-onttrekkingen) zijn meegenomen, en welke bron (fondsbestuur, transitieplan, DNB, AG) autoriteit verleent aan de waardes. Zonder deze documentatie kan het resultaat niet reproduceerbaar worden verdedigd.
4. **Gekoppelde parameterset-discipline met §5.12.1.** §5.12.1 (v2.2.1) legt vast *wat* V_x^Wtp is (waarde-equivalent onder projectie-aanname). §5.12.2 legt vast *wie* de projectie-aanname bepaalt (samensteller parameterset). Samen vormen ze één scope-grens: engine rekent zuiver, samensteller bepaalt realisme. Dit is hetzelfde "gekoppelde v2-pad"-patroon dat in scherm 3 (v2.1.7/v2.1.8) is gestandaardiseerd voor gereserveerde velden, nu toegepast op verantwoordelijkheids-architectuur. **Uitbreiding v2.2.5:** §5.12.5 past dezelfde parameterset-discipline toe op φ-effectiviteit — de engine valideert niet of φ voor bestemmingsreserves is gecorrigeerd; dat is documentatie-verantwoordelijkheid van de samensteller. §5.12.2 en §5.12.5 vormen samen de parameterset-discipline voor zowel π^Wtp als φ.

**Doorwerking.** §5.2 component 2 (Fondsparameterset) verwijst expliciet naar §5.12.2 als verantwoordelijkheidsgrens. §5.10.1 (Volledige modus) verwijst naar §5.12.2 voor bronverantwoordelijkheid, vullend het onderscheid volledige/benaderings-/demonstratiemodus dat daar al bestaat. Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe velden. Numerieke impact: geen.

#### §5.12.3 Onafhankelijkheidsaanname tussen x en y (partnerpensioen)

In §5.5.4 wordt de joint-life overlevingskans berekend onder onafhankelijkheid: _{k/m}p_{x₀ y₀} = _{k/m}p_{x₀} · _{k/m}p_{y₀}. In de praktijk bestaat een partnerafhankelijkheidseffect (broken-heart-effect), waardoor sterftekansen van weduwen/weduwnaars hoger liggen dan van de algemene populatie.

Deze vereenvoudiging leidt tot een lichte overschatting van V_x^PP (en daarmee van V_x totaal). De afwijking is voor de meeste leeftijdscombinaties enkele procenten en valt onder de algemene onzekerheidsmarge van een deterministische waardering. Een volledige implementatie zou dit corrigeren via een partnerafhankelijkheidsfactor op de joint-overlevingskans.

**Besluit Hans 23-04-2026 19:24 (patch v2.2.3): Optie 1 — onafhankelijkheid als v1-aanname formaliseren; joint-life als gekoppelde v2-reservering parallel §2.10/§4.9.** Vier kern-elementen:

1. **Onafhankelijkheid als v1-aanname.** De joint-overlevingskans wordt in M4 berekend als `_{k/m}p_{x₀ y₀} = _{k/m}p_{x₀} · _{k/m}p_{y₀}` (§5.5.4). Partnerafhankelijkheidseffecten (broken-heart-effect) worden in v1 niet gemodelleerd. Deze keuze reproduceert niet zozeer R9.30-gedrag (M4 is in R9.30 niet geïmplementeerd) als wel de docx-spec, en spiegelt de M1-keuze uit §11.5 (v1.3) en de M3-keuze uit v2.1.4.
2. **Joint-life als gekoppelde v2-reservering parallel §2.10/§4.9.** Een volledige implementatie corrigeert via een broken-heart-factor `h(k)` op de joint-overlevingskans: `_{k/m}p_{x₀ y₀}^{afhankelijk} = h(k) · _{k/m}p_{x₀} · _{k/m}p_{y₀}` met `h(k) ≤ 1` (typisch 0,92–0,98 voor gepensioneerden-leeftijden). Activering is een gekoppeld v2-pad dat tegelijk in M1 (§11.5, §2.10), M3 (§4.9) en M4 (§5.12.3) geactiveerd moet worden; activeren-zonder-koppeling levert spec-incoherentie op (bijv. M4 joint-life maar M1 onafhankelijk zou broken-heart-effect selectief toepassen op V_x^PP terwijl KV_NP het blijft negeren). Hetzelfde bundelings-principe als `correlatieRenteInflatie`+`inflatieStochastiek` (v2.1.7) en `lifecycle-profiel`+`rtsCurve` (v2.1.8).
3. **Overschattings-orde van grootte.** Enkele procenten op V_x^PP (typisch 2–6% afhankelijk van leeftijdsverschil en leeftijdsniveau); op V_x totaal (OP + PP) levert dit een overschatting in de orde van 1–3% bij typische SSPF-gepensioneerde-partner-combinaties. Dit valt binnen de algemene onzekerheidsmarge van een deterministische waardering en overlapt conceptueel met de onzekerheid uit π^Wtp-projectie-aanname (§5.12.1).
4. **Cross-module discipline M1/M3/M4.** Alle drie de modules die partner-levens waarderen doen dat onder onafhankelijkheid in v1. Deze uniformiteit is zelf een eigenschap: de ankerfunctie §1.1 ("dezelfde aannames → hetzelfde getal") vereist dat KV_NP (§2.5), U₀_NP (§4.5, v2.1.4) en V_x^PP (§5.5.4) alle drie dezelfde partner-sterftebehandeling krijgen. Bij joint-life-activering in v2 geldt deze coherentie-eis ook, wat de "gekoppeld v2-pad"-status verantwoordt.

**Doorwerking.** §2.10 "NP als bovengrens in plaats van joint-life"-bullet uitgebreid met kruisverwijzing naar §5.12.3 als M4-spiegel. §4.9 "NP als bovengrens, niet joint-life"-bullet uitgebreid met kruisverwijzing naar §5.12.3 als M4-spiegel. Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe velden. Numerieke impact: geen.

**v2.2.11-asymmetrie-status (04-05-2026 23:37).** De v2.2.3-werkafspraak ("gekoppeld v2-pad") is in patch v2.2.11 procedureel doorbroken: M1 heeft joint-life met broken-heart-correctie ge-activeerd via `KV_NP = (1+ρ)·y₀·ä_{x|y}(r)` met `bh(τ, g_y)`-multiplier (§2.5, §11.20-bron-onderzoek). M3 (§4.9) en M4 (§5.12.3 hierboven) blijven op de oude onafhankelijkheids-aanname zonder broken-heart-correctie hanteren, oftewel `_{k/m}p_{x₀ y₀} = _{k/m}p_{x₀} · _{k/m}p_{y₀}`-formule blijft de v1-aanpak voor M4-V_x^PP. M3 wordt mechanisch geraakt door verlaagde `ppk_NP`-input uit M2-keten (lagere `KV_NP` → lagere `ppk_NP` → lagere `U₀_NP`) maar M3-formule zelf ongewijzigd. **M4 wordt door v2.2.11 niet geraakt** — V_x^PP-berekening blijft op docx-formule met onafhankelijkheid. Volledige cross-module-resolutie volgt bij M3- en M4-implementaties; bij M4-implementatie wordt §5.12.3 expliciet gepatcht met `bh()`-functie (gedeelde engine-laag). Rationale voor doorbreken-koppeling: pragmatische β-keuze van Hans in combi-sessie M2 om M1-effect zichtbaar te maken op concreet publieksvoorbeeld vóór M3/M4-bouw; M3 en M4 bestaan nog niet als code, dus parallel-update zou vacuum-werk zijn.

#### §5.12.4 Geen SPR/FPR-differentiatie in de kern-module

De module kent één π^Wtp en één φ(x). Onder de Wet toekomst pensioenen gelden echter twee regelingsvarianten — solidaire premieregeling (SPR) en flexibele premieregeling (FPR) — die tot verschillende uitkeringsprojecties leiden voor dezelfde deelnemer, vooral voor gepensioneerden.

Binnen de huidige architectuur kan SPR/FPR-differentiatie grotendeels via de fondsparameterset worden opgevangen door per regime een afzonderlijke set parameters aan te bieden. §5.13 specificeert welke parameters dan verschillen en welke effecten in v1 niet kunnen worden gevangen.

**Besluit Hans 23-04-2026 19:30 (patch v2.2.4): Optie 1 — accommodatie via parametersets als v1-aanpak; §5.13 formeel als v1-uitwerking bevestigd.** Vier kern-elementen:

1. **Accommodatie via parametersets als v1-aanpak.** De rekenmodule modelleert SPR en FPR niet intern. Regime-verschillen worden volledig extern in de fondsparameterset gerealiseerd: per regime wordt een complete set aangeleverd met verschillend geparametriseerde π^Wtp, φ, en reservering. De engine behandelt beide identiek en reproduceert regime-verschillen via herhaalde aanroep met verschillende parametersets (zie §5.13.4 voor aanbevolen invulling).
2. **§5.13 formeel als v1-uitwerking gestempeld.** De vier sub-paragrafen van §5.13 worden met v2.2.4 structureel geaccepteerd als de v1-oplossing voor regime-differentiatie: §5.13.1 specificeert wat differentieert (π^Wtp-opbouw, φ(x), gereserveerd vermogen), §5.13.2 de parameter-uitbreidingen met optioneel veld `regime ∈ {SPR, FPR, n.v.t.}`, §5.13.3 de drie "wat niet kan in v1"-beperkingen, §5.13.4 de aanbevolen twee-parametersets-invulling. Geen structurele herziening van §5.13 vereist; formele acceptatie sluit §5.13 als v1-contract.
3. **Cross-module spiegel §11.2 + §5.12.2.** §11.2 (v1.1 bevestigd) heeft de top-level regeling-selector-architectuur vastgelegd (top-level SPR/FPR met M3-sub-selector {clean, hybride} bij SPR). §5.12.4 + §5.13 zijn de M4-specifieke uitwerking: de regeling-selector bepaalt *welke parameterset* aan de module wordt aangeboden, niet *welke interne logica* de module uitvoert. Samen met §5.12.2 (parameterset-verantwoordelijkheid bij samensteller) vormt dit de volledige regeling-architectuur: §11.2 koppelt gebruikerskeuze aan parameterset-selectie; §5.12.2 legt bronverantwoordelijkheid bij samensteller; §5.12.4 legt regime-verschillen in parameterset-inhoud; §5.13 specificeert welke parameters daarbij verschillen.
4. **Drie "wat niet kan in v1"-punten als bevestigde scope-grens (§5.13.3).** Een deterministisch puntwaarderings-model kan drie effecten van regime-keuze niet vangen, en deze beperking is met v2.2.4 als expliciete scope-grens bevestigd: (a) *waardering van risicodeling zelf* — de waarde van SPR-solidariteitsreserve-demping vraagt stochastisch framework; (b) *pad-afhankelijkheid van buffers* — solidariteitsreserve-dynamiek over gerealiseerde rendementspaden; (c) *keuze-effecten onder FPR* — beleggingsprofiel-aanpassing, hoog-laag-constructies, nabestaandendekking-uitruil vragen optiewaarderingstechnieken. UI moet deze beperkingen expliciet tonen conform §5.13.3-slotalinea.

**Doorwerking.** §5.13 krijgt inleidende zin die v2.2.4 deze paragraaf formeel bevestigt als v1-aanpak. §11.2 besluit-paragraaf krijgt afsluitende zin die M4-pendant §5.12.4 + §5.13 noemt. Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe velden. Numerieke impact: geen.

#### §5.12.5 Toedeelbaar vermogen versus totaal vermogen

De toedelingsfactor φ wordt impliciet gebaseerd op het volledige fondsvermogen A. In werkelijkheid wordt bij transitie een deel van het vermogen vooraf afgezonderd voor bestemmingsreserves: de solidariteitsreserve (verplicht onder SPR, typisch 3–15%), compensatiedepots voor afschaffing van de doorsneesystematiek, en operationele buffers.

Voor een correcte toedeling geldt: φ_effectief = (A − A_gereserveerd) / TV. De fondsparameterset dient φ aan te leveren als reeds voor deze reserveringen gecorrigeerde waarde, of anders het gereserveerde deel separaat te benoemen zodat de calculator de correctie zelf kan toepassen. In v1 wordt deze logica niet geëxpliciteerd in de module; de aanname is dat φ reeds effectief is.

**Besluit Hans 23-04-2026 19:42 (patch v2.2.5): Optie 1 — v1-aanname φ=φ_effectief aangeleverd bevestigen met UI-disclosure-eis en parameterset-documentatie-eis.** Vier kern-elementen:

1. **V1-aanname φ=φ_effectief aangeleverd.** M4 neemt φ over zoals aangeleverd in de fondsparameterset en past deze toe in `K_x = φ(x) · V_x^Wtp` zonder interne correctie voor bestemmingsreserves. De aanname is dat de samensteller φ heeft aangeleverd als reeds voor solidariteitsreserve, compensatiedepot, operationele buffer en eventuele overige reserves gecorrigeerde waarde — dat wil zeggen `φ = (A − A_gereserveerd) / TV`, niet `A / TV`.
2. **Engine-niet-verantwoordelijkheid parallel §5.12.2.** De engine voert geen bronvaliditeits-check op φ-effectiviteit uit: geen vergelijking tussen aangeleverde φ en alternatieve φ_ruw-berekening, geen alarmbel bij `φ > 1` of `φ < typisch-bereik`, geen automatische afleiding van φ_effectief uit gereserveerd-velden. Deze scope-grens spiegelt §5.12.2 voor π^Wtp: de engine rekent zuiver, de samensteller bepaalt realisme. §5.12.5 is daarmee de tweede toepassing van dezelfde parameterset-discipline, nu voor φ naast π^Wtp.
3. **Parameterset-documentatie-eis expliciet.** Elke fondsparameterset moet in begeleidende documentatie vastleggen *of φ voor reserveringen gecorrigeerd is en zo ja welke* — minimaal: solidariteitsreserve (ja/nee, percentage), compensatiedepot (ja/nee, omvang), operationele buffer (ja/nee), overige reserves (specificeren). Zonder deze documentatie kan de V_x^Wtp-uitkomst niet reproduceerbaar worden verdedigd en is cross-module consistentie met M2-reserveringen-input (§3.5 `verdeelbaar`-formule) niet verifieerbaar.
4. **UI-disclosure-eis bij V_x^Wtp + ankerfunctie-risico-notitie.** Het scherm-4-ontwerp moet bij de getoonde V_x^Wtp en K_x expliciet benoemen dat φ wordt aangeleverd door de samensteller en dat controle op effectieve-status buiten scope van de engine valt. Voorstel-tekst: *"De toedelingsfactor φ wordt aangeleverd door de fondsparameterset-samensteller en wordt verondersteld reeds gecorrigeerd te zijn voor afgezonderde reserves (solidariteitsreserve, compensatiedepot, operationele buffer). De engine controleert dit niet; zie documentatie parameterset."*

**Eerlijke boekhouding — cross-module ankerfunctie-risico.** Een observatie die dit besluit expliciet erkent zonder het op te lossen: M2 §3.5 doet de reserveringen-correctie al *expliciet* via `verdeelbaar = fondsvermogen − compensatiedepot − buffer − overigeReserves − operRes + bijstort` met afleiding `baseRatio = verdeelbaar / vpvTotal` (effectief M2's impliciete φ). M4 verwacht dat dezelfde correctie *impliciet* in de aangeleverde φ zit verwerkt. Bij bron-inconsistentie tussen M2-reserveringen-input en M4-φ-input kan de ankerfunctie `ppkTotal ≈ V_x^Wtp_totaal` (§1.1, v2.1.1) numeriek ontsporen zonder dat de engine dat signaleert. In v1 is dit risico *procedureel* ondervangen via de parameterset-documentatie-eis (kern-element 3); een *structurele* oplossing (φ-metadata-veld met gekoppeld v2-pad voor expliciete breakdown, of M4-formule-herschrijving op netto-basis spiegelgelijk aan M2) is bewust naar v2 doorgeschoven bij besluit v2.2.5.

**V2-heropenpunt.** Als in de praktijk blijkt dat parameterset-samenstellers onvoldoende brondiscipline hanteren — bijvoorbeeld doordat eerste SSPF-parametersets φ_ruw in plaats van φ_effectief aanleveren — kan Optie 2 (φ-metadata-veld `φ_is_effectief: bool` + breakdown-velden, gekoppeld v2-pad-patroon zoals v2.1.7/v2.1.8) of Optie 3 (M4-formule herschrijven op netto-basis spiegelgelijk aan M2) worden heropend. De velden die bij activering nodig zijn, harmoniëren met M2's `verdeelbaar`-lijst zodat cross-module audit mogelijk wordt.

**Doorwerking.** §5.12.2 kruisverwijzing uitgebreid met §5.12.5 als tweede toepassing van dezelfde parameterset-discipline. §5.1.1 bullet 3 "Fondsparameters bepalen realisme" aangevuld met inline-verwijzing naar §5.12.5. Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe velden. Numerieke impact: geen.

#### §5.12.6 π^DB als vereenvoudiging van toeslagmechaniek

Onder het DB-regime is indexatie voorwaardelijk: afhankelijk van dekkingsgraad, toeslagbeleid (staffel, plafond, inhaalindexatie) en rentestand. Het gebruik van één constante π^DB of één vector π^DB_t is een sterke vereenvoudiging.

In v1 is deze vereenvoudiging acceptabel mits π^DB per scenario wordt gekozen op basis van een realistische projectie van het toeslagbeleid — bijvoorbeeld historisch gemiddelde, verwachte dekkingsgraadontwikkeling, of een scenario met volledige prijsindexatie. Een volledige projectie van toeslagmechaniek (DG-afhankelijke staffel, cumulatieve inhaalindexatie) vergt een separate module die in v2 kan worden toegevoegd.

**Besluit Hans 23-04-2026 19:46 (patch v2.2.6): Optie 1 — v1-vereenvoudiging formaliseren; scenario-aanpak §5.6 als operationele compensatie verankeren; DG-afhankelijke toeslagprojectie als v2-reservering.** Vier kern-elementen:

1. **V1-vereenvoudiging π^DB als scalar/vector formeel.** M4 hanteert in v1 π^DB als scalar (constant percentage) of eventueel als vector π^DB_t (tijdsafhankelijk maar vooraf vastgelegd). Geen DG-afhankelijke afleiding, geen staffel-functie, geen inhaalindexatie-mechaniek. Dit is een bewuste vereenvoudiging die de deterministische puntwaarderings-karakter van M4 (§5.1.1) respecteert: het toeslagbeleid is in werkelijkheid pad-afhankelijk (rentepad → DG-pad → toeslag-uitkomst), maar M4 als deterministisch model vat dit samen in één representatieve scalar per scenario.
2. **Scenario-aanpak §5.6 als operationele compensatie voor beleidsvariatie.** De aanbevolen standaardset van vijf π^DB × π^Wtp scenarioparen in §5.6 is niet decoratie maar de *v1-oplossing* voor DB-toeslag-beleidsvariatie: door de vergelijking Δ onder meerdere π^DB-aannames te tonen (van 0% "DB stil" tot 2% "DB prijsinflatie") krijgt de gebruiker inzicht in hoe gevoelig de Wtp-vs-DB-vergelijking is voor toeslag-aannames, zonder dat de engine zelf een toeslagprojectie-module hoeft te bevatten. Dit is structureel gelijk aan hoe M4 omgaat met π^Wtp-onzekerheid (via parameterset-aanlevering per regime, §5.12.2), maar met een extra laag: π^DB-onzekerheid komt uit *beleidsvariatie* (staffel-keuze, DG-pad), terwijl π^Wtp-onzekerheid uit *rendementsvariatie* komt.
3. **Parameterset-documentatie-eis.** De samensteller van de fondsparameterset moet in begeleidende documentatie motiveren *welke π^DB-waarde(s) zijn gekozen en waarom* — bijvoorbeeld: historisch gemiddelde van feitelijke toeslag over laatste 10 jaar, verwachte dekkingsgraadontwikkeling volgens bestuursnotitie, of ambitie-niveau conform toeslagstaffel. Ook de scenario-selectie (welke subset van de §5.6-standaardset wordt getoond, of welke fondsspecifieke alternatieven) hoort in documentatie. Dit is parallel aan §5.12.2 (π^Wtp-afleiding) en §5.12.5 (φ-effectiviteit): bronverantwoordelijkheid ligt bij de samensteller; de engine valideert niet.
4. **DG-afhankelijke toeslagprojectie als v2-reservering.** Een volledige toeslag-mechaniek-module zou `π^DB(t, DG_t)` berekenen als functie van een geprojecteerde dekkingsgraad onder een rente-pad, met staffel-parameters (vol-/half-/geen-indexatie-niveaus), plafond (bijv. CPI) en eventueel inhaalindexatie-boekhouding over voorgaande jaren. Zie §5.11 voor deze v2-uitbreiding. Activering breekt de deterministische puntwaarderings-karakter van M4 niet per se (DG-projectie kan deterministisch blijven onder één rente-pad), maar vraagt een separate projectie-laag die buiten v1-scope valt.

**Doorwerking.** §5.6 inleidende zin toegevoegd die v2.2.6 de scenario-set als operationele compensatie bevestigt. §5.11 nieuwe bullet over DG-afhankelijke toeslagprojectie als v2-uitbreiding. Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe velden. Numerieke impact: geen.

#### §5.12.7 Periode-snapshot M1-3 versus cohort M4 — bewuste methodische asymmetrie (v2.2.0)

De engine gebruikt dezelfde bron-sterftetafel (AG2024) in alle vier modules, maar in twee verschillende gebruikswijzen:

- **M1-3**: periode-snapshot, één kolom `q_{x, t₀, g}` waarbij t₀ = 2026. De sterftekansen die vandaag gelden worden op alle toekomstige leeftijden toegepast alsof sterftekansen niet verder verbeteren.
- **M4 (§5.5.1)**: cohort, diagonaal `q^{fonds}_{x+j}(t₀+j) = f(x+j, g) · q^{AG}_{x+j}(t₀+j)`. De verwachte toekomstige sterfte-verbetering wordt per kalenderjaar meegenomen — wat AG2024 als prognosetafel juist bedoelt te modelleren.

Deze asymmetrie is bewust. Zij weerspiegelt de verschillende didactische rollen van de schermen:

- **Scherm 1 (M1, KV)** staat voor de kale papieren aanspraak als momentopname — "zo staat uw aanspraak er vandaag bij onder eenvoudige, juridisch herkenbare grondslagen".
- **Scherm 4 (M4, V_x^DB en V_x^Wtp)** staat voor de volledige actuariële waardering — "zo wordt uw aanspraak door een actuaris gewaardeerd, met alle toekomstverwachtingen correct verwerkt".

**Numerieke impact.** Onder overigens identieke grondslagen (dezelfde x₀, g, r/i, m, π, ρ, φ) levert dit een verschil tussen KV (M1) en V_x^DB (M4-linkerkant) in de orde van grootte van **<1%** voor een typische SSPF-gepensioneerde (67–75 jaar in 2026). Het verschil is groter voor jongere deelnemers (langere horizon waarover sterfte-verbetering accumuleert) en kleiner voor oudere deelnemers (kortere horizon).

**UI-disclosure-eis.** Omdat KV en V_x^DB dezelfde conceptuele vraag beantwoorden onder het narratief kompas (§1.1, "aanspraak nu onder DB"), moet de UI het overblijvende verschil expliciet benoemen in plaats van het te verbergen. Voorstel-tekst voor scherm 4 bij getoonde V_x^DB:

> *Scherm 1 toont een momentopname op huidige sterftedata; scherm 4 gebruikt de toekomstgerichte cohortprognose. Onder verder identieke aannames verklaart dit een klein verschil (typisch <1%) tussen KV en V_x^DB.*

**Verankering §1.1.** Dit is precies het type informatief verschil dat het narratief kompas vraagt: "verschillen die overblijven [bij identieke aannames] zijn dan *informatief* — ze dragen een boodschap, ze zijn geen rekenartefact". De boodschap hier: momentopname versus prognose is een inhoudelijke dimensie die de gebruiker mag kennen, geen ruis die weggepoetst moet worden.

**Waarom niet opheffen.** M1-3 optillen naar 2D-generatietafel (Optie 2 in besluit v2.2.0) zou numeriek gelijktrekken maar is disproportioneel: SCHEMA-uitbreiding voor <1% effect. M4 terug naar periode-snapshot (Optie 3) zou met §5.5.1 docx-spec breken en M4's handtekening als rigoureuze actuariële waardering wegnemen. De asymmetrie houden en uitleggen is de zuinigste én didactisch rijkste keuze.

**Doorwerking.** Kruisverwijzing toegevoegd in §10.1 (cross-module-communicatie) en §11.16 (AG2024-migratie). Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe parameters.

### §5.13 SPR/FPR-differentiatie binnen v1

*v2.2.4-status:* met patch v2.2.4 (23-04-2026 19:30) is deze paragraaf formeel bevestigd als de v1-uitwerking van §5.12.4. De vier sub-paragrafen §5.13.1 t/m §5.13.4 vormen samen het v1-contract voor regime-differentiatie via parametersets; geen structurele herziening van §5.13 vereist.

De Wtp-regelingsvarianten verschillen substantieel in hoe uitkeringen zich ontwikkelen, ook voor gepensioneerden. Deze paragraaf specificeert hoe de differentiatie binnen v1 wordt geaccommodeerd zonder de architectuur van module 4 te wijzigen. De aanpak: SPR en FPR worden niet in de module gemodelleerd, maar vastgelegd als twee aparte fondsparametersets met verschillend geparametriseerde π^Wtp, φ en reservering.

#### §5.13.1 Wat differentieert tussen SPR en FPR

Voor de waardering op transitiedatum van een reeds gepensioneerde deelnemer zijn drie elementen regime-afhankelijk:

**π^Wtp-opbouw.** Onder SPR: combinatie van volledig beschermingsrendement voor ouderen (volgt rente) en leeftijdsafhankelijke overrendementstoedeling, typisch dempend naar oudere leeftijden. Onder FPR: rechtstreeks afgeleid van het gekozen beleggingsprofiel, typisch defensiever naarmate de deelnemer ouder wordt (lifecycle).

**φ(x).** Onder SPR kent de standaardmethode vaak expliciete cohortspecifieke toedeling ter bescherming van bestaande aanspraken. Onder FPR is de toedeling binnen de gepensioneerdengroep typisch uniformer.

**Gereserveerd vermogen.** Onder SPR wordt verplicht 3–15% afgezonderd in een solidariteitsreserve. Onder FPR is er geen solidariteitsreserve; wel kunnen risicodelingsreserves en operationele reserves van toepassing zijn, maar typisch kleiner.

#### §5.13.2 Parameter-uitbreidingen voor SPR/FPR

De fondsparameterset kent in v1 een optioneel veld `regime ∈ {SPR, FPR, n.v.t.}` dat de interpretatie van de overige parameters verduidelijkt. De volgende parameterverschillen worden verwacht per regime:

| Parameter | SPR (solidaire regeling) | FPR (flexibele regeling) |
|---|---|---|
| π^Wtp(x) | Leeftijdsafhankelijk; combinatie van volledig beschermingsrendement (ouderen) en dempende overrendementstoedeling. Voor 75-jarige typisch 0,5–1,5% | Volgt lifecycle beleggingsprofiel; voor defensief profiel oudere deelnemer typisch 1–2%, offensief 3–5% |
| φ(x) | Cohortspecifiek via standaardmethode; vaak hogere factoren voor ouderen ter aanspraakbescherming | Uniformer binnen gepensioneerdengroep; scalar φ vaak voldoende |
| A_gereserveerd | Solidariteitsreserve verplicht, 3–15% van A; φ dient hiervoor gecorrigeerd te zijn | Geen solidariteitsreserve; eventueel kleine operationele reserve |
| ρ^Wtp | Collectieve uitvoering; kosten typisch 0,1–0,3% van voorziening | Individueel vermogensbeheer; kosten typisch 0,2–0,5% afhankelijk van profiel |
| Scenario-gedrag | Uitkering relatief stabiel door collectieve risicodeling; waarde van demping niet gevangen in deterministisch model | Uitkering volgt rendement direct; volatiliteit afhankelijk van gekozen profiel |

De rekenmodule behandelt beide regimes identiek; de differentiatie wordt volledig extern in de parameterset gerealiseerd. De calculator-UI kan beide parametersets naast elkaar aanbieden, bijvoorbeeld als keuzeoptie voor de deelnemer ("Wat zou gelden onder SPR?" versus "Wat zou gelden onder FPR?") of als gevoeligheidsanalyse.

#### §5.13.3 Wat niet kan binnen v1

Een aantal effecten van de regimekeuze is deterministisch niet te vangen:

- **Waardering van risicodeling zelf.** Onder SPR dempt de solidariteitsreserve collectieve schokken. Deze demping heeft waarde die alleen in een stochastisch framework kan worden geprijsd; in een puntwaardering verschijnt alleen de verwachtingswaarde van onttrekkingen en toevoegingen aan de reserve.
- **Pad-afhankelijkheid van buffers.** De solidariteitsreserve wordt gevoed door overrendement en aangesproken bij tekorten. De verdeling over cohorten hangt af van de gerealiseerde rendementspaden, wat een deterministisch model niet vat.
- **Keuze-effecten onder FPR.** Deelnemers kunnen onder FPR hun beleggingsprofiel aanpassen, hoog-laag-constructies kiezen, of nabestaandendekking uitruilen. De waarde van deze keuzeopties vraagt optiewaarderingstechnieken.

Deze beperkingen dienen in de UI expliciet zichtbaar te zijn: de calculator toont een vergelijking onder één projectiepad per regime, niet een volledige waardering van de regelingskarakteristieken.

#### §5.13.4 Aanbevolen invulling voor de parameterset

Voor fondsen die beide regimes aanbieden of die in de communicatie beide varianten willen tonen, wordt aanbevolen twee complete parametersets aan te leveren. De verschillen dienen minimaal de drie elementen uit §5.13.1 te omvatten. De calculator voert de berekening vervolgens twee keer uit, één keer per parameterset, en rapporteert per scenario (π^DB, regime).

Hiermee ontstaat een compacte maar rijke vergelijking: de deelnemer ziet zowel het effect van de transitie op zich (pre versus post) als het effect van de regimekeuze (SPR versus FPR), zonder dat de rekenmodule zelf complexere logica hoeft te bevatten.

---

## §6. Koppelingen en afhankelijkheden

### §6.1 Keten 1 → 2 → 3

De drie eerste modules vormen een dataketen; elke module consumeert output van de voorgaande:

| Van | Naar | Doorgegeven grootheden |
|---|---|---|
| Module 1 | Module 2 | KV (persoonlijke kapitaalwaarde), leeftijd x₀ |
| Module 2 | Module 3 | potje (ppkTotal), buffer-aandeel; indirect KV en vpvTotal |
| Module 1 | Module 3 | levensverwachting `lifeExp(x₀)` voor plot-horizon, leeftijd x₀ |

De keten impliceert dat module 3 niet aangeroepen kan worden zonder dat module 2 gelopen heeft, en module 2 niet zonder module 1. In de UI vertaalt dit zich naar een lineaire scherm-volgorde 1 → 2 → 3 met optionele terugsprongen.

### §6.2 Module 4 parallel

Module 4 gebruikt **geen** output van modules 1, 2 of 3. Zij leest rechtstreeks uit deelnemersinvoer en fondsparameterset. Dit is een bewuste architecturale keuze: de waarderingsgrondslagen van module 4 (generatietafel q_{x,t}, RTS, indexatiescenario-combinaties) zijn fundamenteel anders dan de vereenvoudigde grondslagen van modules 1-3 (leeftijdstafel, vlakke rente, slider-inflatie). Als module 4 zou proberen hergebruik te maken van module 1's KV, zou zij onzuivere grondslagen importeren en de consistentievoorwaarde uit §5.8 schenden.

In de UI kan module 4 daardoor als zelfstandig scherm of alternatieve view naast de keten staan. Een gebruiker kan module 4 bereiken zonder eerst modules 1-3 te doorlopen.

### §6.3 Gedeelde bronnen

Alle vier modules delen twee bronnen:

- **Deelnemersinvoer** — leeftijd, pensioenbedragen, optioneel geslacht en partnerdata. Een wijziging hierin beïnvloedt (potentieel) alle vier de modules.
- **`FONDS_DATASET`** — de parameter-bron. Maar de modules gebruiken **verschillende deelverzamelingen**; een wijziging in bijvoorbeeld `beleid.spreidingN` raakt alleen module 2, een wijziging in `actuarieel.generatietafel` raakt primair module 4 (en module 1 bij verrijking).

Deze scheiding is waardevol bij dataset-curatie: niet elk fonds hoeft elk veld gepubliceerd te hebben om de engine deels te laten werken. In §5.10's terminologie: een fonds kan in "benaderingsmodus" in modules 1-3 draaien terwijl module 4 in "demonstratiemodus" staat.

---

## §7. Consistentie-eisen

### §7.1 Binnen module 4

`calculator_specificatie.docx` §5.8 (overgenomen als §5.8 van deze spec) formuleert het expliciet: V_x^DB en V_x^Wtp moeten onder identieke grondslagen berekend worden (zelfde RTS, generatietafel, f, m, ω). Alleen π^DB/π^Wtp en ρ^DB/ρ^Wtp verschillen. Dit is een wiskundige hygiëne-eis die de module intern bewaakt via een shared-grondslagen-structuur. Schending ervan maakt Δ interpretatie-loos.

### §7.2 Binnen modules 1-3

Er is geen formele consistentie-eis, maar de huidige code gebruikt consistent dezelfde Q-tafel en dezelfde rente-slider voor alle drie modules. Dat hoeft niet zo te blijven — module 3 zou bijvoorbeeld een andere projectierente kunnen gebruiken dan module 1. De huidige consistentie is *pragmatisch* (UI-zuinig, één slider), niet *conceptueel* (de modules beantwoorden verschillende vragen met legitieme reden om verschillende grondslagen te hanteren). Aanbevolen voor interpretatie-zuiverheid: één rente-slider aanhouden tenzij er explicite reden is om te differentiëren.

### §7.3 Tussen modules

**Er is één harde consistentie-eis tussen modules** (v1.2, besluit §11.4): annuïteitsconventie is uniform **arrears, m=12** in alle vier de modules. Concreet betekent dit dat ä(x, r) in §2.5 (M1), §3.5 (M2, via KV-herleiding), §4.5 (M3, via U₀-omzetting) en §5.5 (M4, V_DB en V_Wtp) dezelfde functionele vorm heeft; alleen de rente (i/proj/RTS, §11.3) en de sterftetafel (leeftijdstafel in M1-3 vs generatietafel in M4, §11.10) verschillen per module. Dit is een opzettelijke keten-coherentie-keuze die het 0,5–1%-artefact tussen scherm 1 en scherm 4 elimineert.

**Narratief-verankering (v1.6, §1.1 kompas).** Cross-module consistentie is geen doel op zich maar dient het narratief *nu → invaren → straks* plus de regime-split op scherm 4. Waar KV (scherm 1) en V_DB (scherm 4) dezelfde vraag beantwoorden ("aanspraak nu onder DB-voortzetting"), moeten zij bij identieke aannames hetzelfde getal opleveren — dat is de ankerfunctie. Waar zij verschillende vragen beantwoorden (M1: kale papieren aanspraak; M4: regime-specifieke waardering inclusief indexatie), is een informatief verschil wenselijk — dat is de pedagogische payload. Deze spec-versie maakt de structurele congruentie expliciet; de numerieke gelijkheid hangt af van welke parameters gelijk gekozen worden (zie onder).

**Voor overige grondslagen geen consistentie-eis.** Module 1's KV en module 4's V_DB blijven in principe verschillende grootheden (leeftijdstafel vs generatietafel, geen partner vs mogelijk partner, geen kostenopslag vs ρ^DB). Dit is architecturaal verdedigbaar maar **communicatie-gevoelig**:

- De gebruiker ziet op scherm 1 "KV = €130k" en op scherm 4 "V_DB = €125k" en vraagt: welke klopt?
- Antwoord: allebei, onder hun eigen aannames. De UI moet dit duidelijk maken — niet door te verbergen, maar door uit te leggen dat de modules verschillende vragen beantwoorden onder verschillende grondslagen.

Een alternatief zou zijn dat de UI bij aanwezigheid van module 4 óók de module-1-KV herberekent onder module-4-grondslagen (generatietafel, eventueel partner), zodat de getallen overeenkomen. Dat schendt echter de module-zelfstandigheid en maakt module 1 afhankelijk van de parameterset-completeness die module 4 vereist. In v1.2 wordt hiervoor **niet** gekozen voor generatietafel/partner; de annuïteitsconventie is wél geüniformeerd omdat het 1%-artefact communicatief groter is dan de grondslag-nuance. Zie cross-module reviewpunt §10.1.

---

## §8. Parameterset-overlap

`SCHEMA_v1.md` dekt modules 1-3 pragmatisch (met AG2022-leeftijdstafel als benadering). Module 4 vereist uitbreiding. De volgende tabel toont per module-4-veld de status in `SCHEMA_v1.md` en de actie die nodig is voor `SCHEMA_v2.md` (sessie 2):

| Spec-veld module 4 | Status in SCHEMA v1 | Actie voor SCHEMA v2 |
|---|---|---|
| `φ` toedelingsfactor | Niet expliciet; impliciet via DG × overschot in module 2 | Nieuw veld of afleid-regel uit bestaande |
| `RTS` rentetermijnstructuur | `reserveringenFaseB.rtsCurve = null` | Invullen als vector[decimal] |
| `q_{x,t}` generatietafel | `actuarieel.sterftekansTabelId` verwijst naar 1D-tafel | Uitbreiden naar 2D of aparte sterftetabel-resource |
| `f(x,g)` ervaringssterftefactor | Niet aanwezig | Nieuw veld in `actuarieel` |
| `π^DB`, `π^Wtp` scenario's | Niet aanwezig (`inflatieVerwacht` is één waarde) | Nieuwe sectie `scenarios` met indexatiecombinaties |
| `ρ^DB`, `ρ^Wtp` kostenopslagen | Niet aanwezig | Nieuwe velden in `beleid` of `actuarieel` |
| `m` betalingsfrequentie | Niet aanwezig | Nieuw veld in `actuarieel` |
| `ω` eindleeftijd | Hardcoded `MAX_AGE = 100` | Nieuw veld in `actuarieel` |
| `g` geslacht (deelnemersinvoer) | n.v.t. (deelnemersinvoer) | Nieuwe deelnemersinvoer, Q_M en Q_V tafels nodig |
| `B_PP`, `y₀`, `g_y` partner (deelnemersinvoer) | n.v.t. | Nieuwe deelnemersinvoer |

Daarnaast verzoeken de *gereserveerde velden* uit modules 1-3 om schema-uitbreiding:

| Spec-veld modules 1-3 | Module | Actie voor SCHEMA v2 |
|---|---|---|
| `bufferTrigger` | 3 | Enum-veld in `beleid` |
| `correlatieRenteInflatie` | 3 | Veld in `defaults` |
| `lifecycle-profiel` | 3 | Object-veld in `defaults` of nieuwe sectie `lifecycles` |
| `percentielen` | 3 | Engine-constant; kan ook dataset-overridbaar worden |
| `annuïteitsconventie` | 1, 4 | Enum-veld in `actuarieel` |

Het schema wordt de **som** van de vier module-behoeftes, niet de max. Geen conflicten, wel substantiële uitbreiding. `SCHEMA_v2.md` volgt dus een uitbreidingsstrategie: alle v1-velden blijven; nieuwe velden met defaults die het v1-gedrag reproduceren; nieuwe `herkomst`-entries voor de uitbreidingen.

---

## §9. Regeling-dimensie per module

Het begrip "regeling" werkt verschillend in verschillende modules:

| Module | Regelingsdimensie | Opties | Reden |
|---|---|---|---|
| 1 — Huidige waarde | n.v.t. | — | KV is regime-agnostisch |
| 2 — Potje | Indirect via parameters | — | Compensatiedepot en bijstort hangen samen met transitieplan, maar de berekeningslogica is gelijk |
| 3 — Uitkeringsbenadering | **drie** opties | FPR / SPR-clean / SPR-hybride | Inner loop verschilt: FPR-update-formule, SPR met RTS en AG-herziening, SPR-hybride met rente-afdekking |
| 4 — Waardevergelijking | **twee** opties | SPR / FPR | Volgens §5.13: differentiatie via parametersets (verschillende φ, π^Wtp, ρ^Wtp, reserveringen), niet via module-wiskunde |

Dit creëert een UI-vraag: kunnen de regeling-keuzes op module 3 en module 4 gekoppeld worden, of zijn het aparte selectors? Clean/hybride-onderscheid bestaat niet in module 4 — dat betekent dat als de gebruiker op module 3 "SPR-clean" kiest, module 4 die automatisch naar "SPR" (generiek) vertaalt.

**Voorgestelde resolutie** (ter goedkeuring, niet definitief):

E�n regeling-selector op top-niveau die twee waarden heeft (SPR, FPR); binnen SPR kiest module 3 tussen clean en hybride via een sub-selector op scherm 3. Module 4 ziet alleen de top-niveau keuze.

Dit sluit aan bij de docx-visie (§5.13): SPR en FPR zijn twee parametersets, en een specifieke SPR-implementatie (clean of hybride) is een invulling *binnen* de SPR-parameterset die alleen module 3 relevant vindt. De regeling-pill in de UI (R9.30 infrastructure) kan hiervoor al dienen, met een dropdown-variant in Fase B.

Zie open vraag §11.2 over de precieze UI-structuur.

---

## §10. Cross-module reviewpunten

Deze sectie verzamelt reviewpunten die **meerdere modules raken** en daarom niet natuurlijk passen in een enkel module-reviewpunten-blok. Zij vragen om een UI- of architecturale beslissing, geen module-interne aanpassing.

### §10.1 Communicatie van module-onafhankelijkheid

Modules 1 en 4 leveren beide een waardering van de huidige aanspraak. In v1.3 is de dekking-dimensie substantieel geüniformeerd: M1 bevat nu net als M4 zowel OP als NP (via §11.5 besluit, zij het met onafhankelijke-levens-aanname i.p.v. M4's joint-life). Resterende grondslagenverschillen zijn: leeftijdstafel (M1) vs generatietafel (M4), onafhankelijke levens (M1) vs joint-life (M4), zonder versus met kostenopslag. De annuïteitsconventie is in v1.2 geüniformeerd (arrears m=12). Resterende getallenverschillen zullen typisch 2–5% bedragen. De UI moet deze discrepantie niet verbergen maar uitleggen:

- Module 1 beantwoordt "wat is uw pensioen *nu* waard onder eenvoudige grondslagen?"
- Module 4 beantwoordt "wat is uw aanspraak *pre versus post transitie* waard onder zuivere actuariële grondslagen?"

De UI-tekst moet expliciet benoemen waarom de getallen verschillen, niet alleen dát ze verschillen. Alternatieve invulling: één getal prominent tonen, het andere in een deepdive-laag. Dit is een UX-beslissing die in deze spec niet wordt genomen.

**Concreet voorbeeld van informatief verschil (v2.2.0).** Zelfs onder volledig identieke grondslagen (zelfde x₀, g, r, m, π, ρ, φ) blijft een klein verschil tussen KV (M1) en V_x^DB (M4-linkerkant) bestaan: M1-3 gebruikt AG2024 als periode-snapshot (t₀=2026), M4 als cohort-tafel (diagonaal per kalenderjaar). Voor een 67-jarige in 2026 bedraagt dit effect <1% op de annuïteitsfactor. Dit is geen rekenartefact maar een inhoudelijke dimensie — momentopname versus toekomstgerichte prognose — en moet conform §1.1 expliciet worden benoemd in plaats van verborgen. Zie §5.12.7 voor de volledige uitwerking inclusief voorstel-tekst voor UI-disclosure.

### §10.2 Eén of meer rente-parameters

Module 1 gebruikt `r` voor KV-discontering. Module 3 gebruikt `proj` voor startuitkering-annuïteit en `μ` voor Monte Carlo rendement. Module 4 gebruikt `RTS` (of fallback vlakke `i`). In de huidige code zijn `r` en `proj` afzonderlijke sliders; `μ` ook; `RTS` bestaat nog niet.

Een puristische lezing is: elke module kiest zijn eigen rente, want zij beantwoorden verschillende vragen. Een pragmatische lezing is: de gebruiker verwacht dat "de rekenrente" één ding is. v1 houdt de afzonderlijke sliders, conform de huidige code, met uitleg in de UI dat deze inhoudelijk verschillende grootheden representeren. Zie open vraag §11.3.

### §10.3 Sterftetafel-nomenclatuur

~~Module 1 gebruikt in de huidige code een 1D-tafel onder de naam `AG2022` (feitelijk een gemengde-populatie benadering). Module 4 specificeert een echte 2D-generatietafel q_{x,t} onder dezelfde naam.~~

**Opgelost in v1.7 (besluit §11.16, 23-04-2026 11:58):** beide modules gebruiken nu dezelfde AG2024-bron — de officiële prognosetafel per geslacht uit de KAG-publicatie van 12-09-2024. Slechts de *gebruikswijze* verschilt:
- **M1-3**: periode-snapshot (één kolom `t₀`). Didactisch eenvoudig.
- **M4**: cohort (diagonaal q_{x+t, t₀+t, g}). Actuarieel zuiver voor waardering van aanspraken over de volledige resterende levensduur.

SCHEMA v2 krijgt één veld `actuarieel.sterftekansTabelId = 'AG2024'` met herkomst `publiek` (officiële AG-publicatie). De R9.30-mengtafel (voorheen onder de naam `AG2022`) is gedeprecieerd; zie §11.16 voor volledige onderbouwing.

### §10.4 Annuïteitsconventie due versus arrears

~~Module 1 hanteert due, module 4 arrears. Voor een individuele gepensioneerde is het numerieke verschil beperkt (~0,5-1% op KV/V_DB) maar systematisch. Drie resolutie-opties:~~

~~- **Status quo.** Due in modules 1-3 (consistent met huidige code), arrears in module 4 (consistent met docx-spec). Communicatie via UI.~~
~~- **Uniform due.** Module 4 herformuleren naar due-notatie. Licht afwijking van docx-spec; vereist aanpassing van alle formules in §5.5.4.~~
~~- **Uniform arrears.** Modules 1-3 herformuleren naar arrears. Licht afwijking van huidige code; vereist kleine aanpassing in `annuityTo` en `lifeExp`.~~

~~In v1 wordt status quo aangehouden. Alternatieven zijn open vragen (§11.4).~~

**Opgelost in v1.2 (besluit §11.4, 23-04-2026 09:53):** uniform arrears m=12 cross-module. Rationale: keten-coherentie (scherm 1 → 2 → 3 → 4) weegt zwaarder dan code-stabiliteit; arrears m=12 representeert SSPF-uitbetalingspraktijk direct. Doorwerking: §2.3, §2.5, §2.6, §2.10, §3.5, §4.5, §7.3. Numerieke impact: KV/potje/U₀ ~0,5–1% lager dan R9.30.

### §10.5 φ expliciet versus impliciet

Module 2 berekent de toedeling empirisch via ppkBase + ppkSurplus + ppkComp. Module 4 berekent de toedeling via K_x = φ(x) · V_x^Wtp. Dit zijn twee verschillende wiskundige routes naar hetzelfde conceptuele getal ("wat krijg je mee"). Voor gebruikersbegrip is het belangrijk dat de UI één van beide als primair toont en de relatie met het andere uitlegt.

Een *brugveld* φ_afgeleid kan in module 2 worden berekend als ppkTotal / V_x^Wtp (na berekening van V_x^Wtp in module 4), en vice versa kan een *module-2-achtige decompositie* in module 4 worden getoond om de potje-aard zichtbaar te maken. Beide zijn communicatie-hulpmiddelen, niet wiskundige vereisten.

### §10.6 Stochastisch versus deterministisch

Module 3 is stochastisch (MC met 2000 paden). Module 4 is deterministisch (puntwaardering). Voor een eerlijk gebruikers-beeld moet duidelijk zijn dat module 3's p50 **niet** gelijk staat aan module 4's V_x^Wtp / ä(x₀, proj) of iets vergelijkbaars: de grootheden zijn verschillend gedefinieerd en de getallen kunnen substantieel afwijken. UI-presentatie moet dit onderscheid zichtbaar maken.

---

## §11 OPEN_VRAGEN

Tijdens het schrijven van deze specificatie zijn beslispunten geïdentificeerd die impact hebben op SCHEMA v2, UI-structuur of rekenuitkomsten en die **niet** door de engine-spec zelf zijn beslist. Ze worden hieronder expliciet belegd bij de opdrachtgever (Hans). Elke open vraag noemt het probleem, de opties, en — waar van toepassing — een voorlopige v1-keuze die gereproduceerd wordt als er geen actie volgt.

### §11.1 φ expliciet of impliciet in module 2

**Probleem.** Module 4 gebruikt φ(x) als normatieve toedelingsfactor (K_x = φ(x) · V_x^Wtp). Module 2 leidt de toedeling empirisch af uit ppkBase + ppkSurplus + ppkComp, zonder φ als expliciete parameter. Voor gebruikersbegrip en auditbaarheid kan het nuttig zijn φ expliciet te tonen (en eventueel als tuning-parameter aan te bieden).

**Opties.**
1. **Impliciet (v1-default).** Module 2 rekent zoals huidige code; φ wordt nergens getoond.
2. **Afgeleid en getoond.** Engine berekent φ_afgeleid = ppkTotal / V_x^Wtp en toont dit naast de decompositie. Geen impact op berekening.
3. **Parametrisch.** φ wordt inputparameter in module 2; ppkTotal = φ · V_x^Wtp; de R9.30-decompositie vervalt of wordt validatiekanaal.

**Voorlopige v1-keuze.** Optie 1. Wijziging vereist update van SCHEMA v2 en UI-rendering.

**Besluit Hans 23-04-2026 09:24: Optie 2.** Engine berekent φ_afgeleid = ppkTotal / V_x^Wtp en toont dit als output-veld naast de R9.30-decompositie (ppkBase, ppkSurplus, ppkComp). Geen impact op de berekening van ppkTotal zelf. Consequenties:
- **§3.4 (output module 2)** krijgt veld `phiDerived` (decimaal, typisch in [0, 1.2]); zie §3.4 v1.1-aanvulling.
- **§3.5 (formules)** krijgt afleidingsregel; zie §3.5 v1.1-aanvulling.
- **Referentie V_x^Wtp.** φ_afgeleid is pas berekenbaar als module 4 de Wtp-waarde heeft geleverd; in standalone-module-2-modus is het veld `null`. Alternatief: gebruik V_x^Wtp uit module 1 (KV) als proxy; dat moet Hans vóór SCHEMA v2 besluiten (zie §11.12 hieronder, nieuw).
- **SCHEMA v2**: output-contract module 2 krijgt optioneel veld `phiDerived`, met `null` bij ontbreken M4-output.
- **UI**: φ_afgeleid getoond als aanvullend getal bij potje-decompositie; geen invoerveld.

### §11.2 Regeling-selector: structuur en reikwijdte

**Probleem.** De regeling-dimensie speelt verschillend in verschillende modules. Module 1 en 2 zijn regeling-onafhankelijk; module 3 heeft drie varianten (FPR, SPR-clean, SPR-hybride); module 4 heeft er twee (DB-basis: FPR of SPR). Zie §9 voor volledige mapping.

**Opties.**
1. **Top-level SPR/FPR + sub-selector in M3.** Gebruiker kiest eerst fondstype op SCHEMA-niveau; binnen M3 kiest men desgewenst tussen clean en hybride (alleen zichtbaar bij SPR).
2. **Module-3-eigen selector.** M3 heeft eigen driewaardig veld; M4 neemt over op basis van consistentie-regel (FPR ↔ FPR, SPR-* ↔ SPR).
3. **Per-module selector.** M3 en M4 krijgen onafhankelijke selectors; inconsistente combinaties worden toegestaan maar gemarkeerd.

**Voorlopige v1-keuze.** Optie 1, met SSPF hardcoded op FPR zoals vastgelegd in FONDS_DATASET. Wijziging wordt relevant zodra tweede fondsprofiel wordt toegevoegd.

**Besluit Hans 23-04-2026 09:24: Optie 1 bevestigd als startpunt.** SCHEMA v2 krijgt top-level veld `regeling` met enum {FPR, SPR}, binnen M3 een optionele sub-selector {clean, hybride} die alleen zichtbaar is bij `regeling = SPR`. SSPF-profiel hardcoded op FPR. Review bij toevoeging tweede fondsprofiel.

**M4-pendant (v2.2.4-aanvulling).** De top-level regeling-selector bepaalt welke fondsparameterset aan M4 wordt aangeboden, niet welke interne logica M4 uitvoert — M4 blijft regime-agnostisch. Zie §5.12.4 (v2.2.4) voor de formalisering van accommodatie-via-parametersets als v1-aanpak, en §5.13 voor de specificatie van welke parameters tussen SPR en FPR verschillen. Samen vormen §11.2 (top-level architectuur), §5.12.2 (bronverantwoordelijkheid samensteller), §5.12.4 (regime-verschillen in parameterset-inhoud) en §5.13 (welke parameters) het complete regeling-contract.

### §11.3 Rente-parameters: enkel versus meervoudig

**Probleem.** Zie §10.2. Module 1 gebruikt één projectie-rente i voor KV en annuïteit. Module 3 scheidt projectierente (proj) van scenario-spreiding rond RTS (drift = rts − risicopremie). Module 4 introduceert nog RTS als derde grootheid (in §5.4.2 en §5.7.2 voor DB-waardering).

**Opties.**
1. **Eén i, cascade-gebruik.** i wordt in alle modules dezelfde waarde; FPR/RTS/proj zijn alias of afgeleid.
2. **Drie onafhankelijke parameters.** i (M1), proj (M3), RTS (M3/M4) zijn losstaande inputs; consistentie is adviserend.
3. **Twee parameters.** i = proj cross-module; RTS is aparte curve voor DB-waardering.

**Voorlopige v1-keuze.** Optie 2 met documentatie-plicht: UI toont waarden van alle drie en biedt een "synchroniseer"-optie. SCHEMA v2 houdt drie velden.

**Besluit Hans 23-04-2026 09:24: Optie 2 bevestigd.** SCHEMA v2 bevat drie losstaande rente-velden (`i`, `proj`, `rtsCurve`-samenvattende scalair of curve), met een cross-module consistentie-advies (niet-blokkerende warning bij grote afwijking). UI biedt een "synchroniseer"-knop voor snelle uniforme instelling.

**Verfijning v2.1 (23-04-2026 13:40).** UI-implementatie geconcretiseerd: **Optie 3 — één primaire rente-slider met ontkoppelings-toggle**. De drie velden blijven structureel aanwezig in SCHEMA v2, maar in default-UI-gedrag zijn ze gekoppeld aan één "discontovoet"-slider (startwaarde 2% uit FONDS_DATASET). Een "Geavanceerd"-toggle laat de gebruiker per-module afwijkende rentes zetten voor audit/debug/power-user-doeleinden. Rationale: de drie parameters beantwoorden conceptueel dezelfde vraag ("wat is een euro van morgen waard in geld van vandaag?"); drie onafhankelijke default-sliders zou de gebruiker drie keer dezelfde beslissing laten maken zonder didactische meerwaarde. De ontkoppelings-toggle behoudt echter de analytische flexibiliteit die §11.3-besluit 09:24 voorschreef. `μ` (M3 Monte Carlo verwachtingswaarde rendement) blijft expliciet apart — dat is rendement, niet discontering.

### §11.4 Annuïteitsconventie: due versus arrears

**Probleem.** Zie §10.4. Modules 1-3 gebruiken due (betaling begin jaar), module 4 gebruikt arrears (betaling eind jaar). Numeriek verschil: ~0,5-1% op KV/V-waarden.

**Opties.**
1. **Status quo (v1-default).** Beide conventies naast elkaar; UI vermeldt dit bij waardevergelijking.
2. **Uniform due.** Module 4 herformuleren (alle ä's in §5.5.4, §5.7.1, §5.7.2).
3. **Uniform arrears.** Modules 1-3 herformuleren (annuityTo, lifeExp).

**Voorlopige v1-keuze.** Optie 1. Wijziging vereist doc-update en eventueel code-aanpassing in R9-serie.

**Besluit Hans 23-04-2026 09:53: Optie 3 — uniform arrears, m=12.** Wijziging t.o.v. voorlopige v1-keuze. Rationale: scherm 4 is het eindproduct en de docx-M4-spec schrijft arrears voor; modules 1-3 moeten meebewegen, niet andersom. Arrears m=12 representeert SSPF-uitbetalingspraktijk (maandelijks achteraf) direct en elimineert het 0,5–1%-conventie-artefact tussen scherm 1 (KV) en scherm 4 (V_DB). Keten-coherentie weegt zwaarder dan code-stabiliteit. Consequenties:
- **§2.3 (M1 input-schema)**: `annuïteitsconventie` default wordt `arrears` (actief); `m` wordt actief met default 12.
- **§2.5 (M1 formules)**: arrears m=12 als primaire berekening; R9.30-baseline (due jaarbasis) behouden als debug-referentie.
- **§2.6 (M1 aannames)**: aanname 4 herschreven.
- **§2.10 (M1 reviewpunten)**: eerste reviewpunt gemarkeerd als opgelost.
- **§3.5 (M2 formules)**: KV-herleiding verwijst naar v1.2 arrears m=12.
- **§4.5 (M3 formules)**: U₀-annuïteit expliciet arrears m=12; projectie-stap blijft jaarbasis.
- **§7.3 (consistentie-eisen)**: annuïteitsconventie nu harde cross-module eis.
- **§10.4 (cross-module reviewpunt)**: gemarkeerd als opgelost.
- **SCHEMA v2**: `annuïteitsconventie` en `m` verplicht met defaults `arrears` en 12.
- **Code-migratie R9.30**: `annuityTo` herschrijven van jaarbasis-som naar maandbasis-som (12·T_eff termijnen, interpolatie van overlevingskansen). Kleine code-wijziging, substantieel effect op getallen (~0,5–1% lager).

### §11.5 Partneruitbreiding in module 1

**Probleem.** Module 1 rekent huidige waarde voor één persoon (gepensioneerde zelf). Voor volledige actuariële waarde van pensioenaanspraak moet nabestaandenpensioen (y₀, g_y) ook als KV-component worden opgenomen, met partner-sterftetafel en mogelijk correlatie tussen levens.

**Opties.**
1. **Niet opnemen (v1-default).** Module 1 rekent alleen eigen OP/AP; NP valt buiten M1-scope. M4 rekent wel met y₀.
2. **Aparte KV-regel.** Module 1 krijgt tweede output KV_NP = y₀ · ä_nabest(x, x_partner); totale KV = KV_eigen + KV_NP.
3. **Volledig joint-life.** Engine rekent joint-life annuïteit met correlatie; vereist partner-leeftijd en -geslacht als input.

**Voorlopige v1-keuze.** Optie 1. Consistent met huidig R9.30-gedrag. Partner wordt wel al als input geanticipeerd in SCHEMA v2 (gereserveerd veld).

**Besluit Hans 23-04-2026 09:59: Optie 2 — aparte KV-regel NP.** Wijziging t.o.v. voorlopige v1-keuze. Rationale: SSPF-gepensioneerden hebben vrijwel altijd NP; niet-tonen onderschat KV met 30–50% en is actief misleidend voor een publieke calculator. Optie 2 herbruikt bestaande M1-annuïteit-engine zonder nieuwe wiskunde en maakt M1 grondslag-congruent met M4 op de partner-as. Consequenties:
- **§2.1 (vraag)**: expliciet OP+NP-aanspraak in v1.3.
- **§2.2 (input deelnemer)**: velden `heeftPartner`, `y₀`, `x_partner` actief; `g_y` gereserveerd.
- **§2.4 (output)**: KV uitgesplitst in `KV_OP`, `KV_NP`, `KV` (totaal); annuïteitsfactor en `lifeExp` ook voor partner.
- **§2.5 (formules)**: `KV_OP = pen · ä(x₀, r)`, `KV_NP = y₀ · ä(x_partner, r)`, totaal = som.
- **§2.6-§2.10**: aannames, fallbacks, validaties, scope, reviewpunten aangepast.
- **§10.1**: cross-module getallenverschil afgenomen van 2–10% naar 2–5%.

**Impliciete sub-defaults in v1.3** (zie header-noot; bevestiging gewenst in volgende open-vraag-ronde):
1. **Partner-sterftetafel**: zelfde AG2022-leeftijdstafel-gemengd als deelnemer. Geslacht-differentiatie (`g_y` ≠ `gemengd`) is gereserveerd conform §11.10 besluit.
2. **Correlatie tussen levens**: 0 (onafhankelijke levens). Gedeelde leefstijl/gezondheid wordt niet gemodelleerd.
3. **NP-fallback**: 70% van OP bij onbekende `y₀` (wettelijke Nederlandse ratio sinds WVPS 1998).
4. **Latent versus ingegaan NP**: v1.3 behandelt beide als ingegaan (pragmatische bovengrens). Joint-life differentiatie is v2-reservering.

**Migratie-impact R9.30.** UI krijgt partner-invoerblok (leeftijd, geslacht optioneel, y₀ met 70%-fallback-knop). `module1`-aanroep wordt twee keer uitgevoerd bij `heeftPartner=true` (eigen + partner). Output-contract breekt: R9.30-consumers die `KV` als scalair lezen moeten migreren naar `{KV, KV_OP, KV_NP}`.

### §11.6 BufferTrigger-conventie

**Probleem.** Module 3 hanteert buffer-mechaniek met een trigger die bepaalt wanneer de buffer wordt aangesproken. De keuze tussen koopkracht-anker, rendement-anker, projectie-anker, of gecombineerd anker raakt frequentie en omvang van buffer-trekkingen, en daarmee de communicatie van risico via `bufEnd`, `shortfall`, `fullyCov`/`partCov`/`notCov` (output §4.4).

**Opties.**
1. **`effR < inf` (koopkracht-trigger, R9.30-conform).** Buffer bij koopkrachttekort; spiegelt de huidige indexatie-praktijk van SSPF.
2. **`effR < 0` (rendement-trigger).** Strenge variant; buffer alleen bij absolute verliezen. Onderverbruik van buffer bij positief-maar-onvoldoende rendement.
3. **`effR < proj` (projectie-trigger).** Wiskundig zuiver op de FPR-update-formule `U_{t+1} = U_t · (1+effR_final)/(1+proj)`: triggert precies wanneer de uitkering nominaal zou dalen. Negeert inflatie.
4. **`effR < proj + inf` (gecombineerd anker, genoemd in §4.10 reviewpunt).** Combineert koopkracht-bewustzijn (Optie 1) en projectie-anker (Optie 3). Riskeert snelle buffer-uitputting bij `proj=2%, inf=2%`: trigger pas vanaf `effR<4%`.

**Besluit Hans 23-04-2026 16:14: Optie 1 — `effR < inf` als default, alle vier opties als enum structureel beschikbaar.** Rationale (drie lagen):

(a) **Educatief-narratief-anker.** SSPF-design hanteert eenmalige RDR-buffer bij invaren met 5-jaars rolling rendementsdemping. SSPF-gepensioneerden willen hun WTP-uitkering vergelijken met de huidige indexatie-praktijk ("kreeg ik vroeger indexatie ja/nee" ↔ "wordt mijn buffer aangesproken om koopkracht te behouden ja/nee"). De koopkracht-trigger spiegelt precies dat anker. Optie 3 zou wiskundig zuiverder zijn maar mist het indexatie-narratief; Optie 4 zou indexatie dubbel ankeren.

(b) **Spec-met-reserveringen (§12.5).** R9.30 implementeert Optie 1; v1-default reproduceert dat exact. Anders dan bij `ρ=0,02` (waar bewust van §12.5 is afgeweken op publieke-uitlegbaarheid-grond) is hier geen vergelijkbaar harde reden om af te wijken: de huidige output-structuur communiceert al wat de buffer doet, ongeacht trigger-keuze.

(c) **Bronhoudbaarheid.** SSPF-reglement of bestuursnotitie zou later een andere trigger-keuze kunnen vereisen; door de structuur (vier-waardes enum) nu te leggen kan dat zonder spec-revisie. Identieke aanpak als bij `f` (v1.4) en `bufferTrigger` zelf was al als gereserveerd enum-veld in §4.3 opgenomen.

**Aanpalend besluit dempJaren = 5.** SSPF-design specificeert 5-jaars rolling-gemiddelde rendementsdemping (jaar-2-vaststelling-na-invaren elk jaar opnieuw); dit is exact wat het bestaande `effR_t = mean(window_t)`-mechanisme implementeert. Placeholder "dataset" in §4.3 vervangen door concreet `dempJaren=5`.

**Aanpalend reviewpunt RDR-uitputtingsmechaniek (geparkeerd).** R9.30-implementatie (`trekking = min(tekort, buffer_t)`, volledig tekort tot bufferbodem) is v1-default; SSPF-design hanteert mogelijk ander uitputtingsregime maar mechanisme onbekend bij Hans. Geparkeerd in §4.10 voor latere bron-onderzoeks-ronde.

**Doorwerking:** §4.3 (`dempJaren=5`, `bufferTrigger` actief, vier enum-waardes), §4.5 (buffer-mechaniek-blok herschreven met trigger-formule per enum-waarde + RDR-noot), §4.6 (aanname 16), §4.10 (Buffer-trigger-formule opgelost; nieuw RDR-uitputtingsmechaniek-reviewpunt geparkeerd). Geen numerieke wijziging op default-pad.

### §11.7 Correlatie rendement-inflatie

**Probleem.** Module 3 simuleert rendement (`r_t` via GBM, §4.5) en inflatie (`inf`, deterministische slider) als onafhankelijk. Het reviewpunt zit op twee niveaus tegelijk:
1. **Stochastiek-niveau.** `inf` is deterministisch in v1 — om correlatie überhaupt te kunnen modelleren moet `inf` eerst stochastisch worden.
2. **Correlatie-niveau.** Pas dán is `ρ_{r,inf}` betekenisvol als parameter.

Economisch is correlatie tussen nominale rendementen en inflatie doorgaans positief (hogere inflatie → hogere nominale rente → hogere nominale rendementen op vastrentende waarden), maar magnitude is contextafhankelijk. Voor SSPF (gepensioneerden, real-rendementsfocus) is bovendien de correlatie tussen *real* rendement en inflatie de relevantere maatvoering, en die is vaak licht negatief.

**Opties.**
1. **`ρ = 0` als v1-default, deterministische `inf`.** Reproduceert R9.30-gedrag exact. Reservering-veld blijft in §4.3 zonder operationele werking. Pragmatisch maar laat onzekerheidsdimensie ongemodelleerd.
2. **`ρ = 0,3` als vaste consensus-waarde, vereist stochastische `inf`.** Substantiële uitbreiding van §4.5-MC (twee gecorreleerde processen via Cholesky). Numerieke impact ~5–15% smaller p10-p90 bandbreedte op real uitkering, maar magnitude zonder SSPF-specifieke kalibratie speculatief.
3. **`ρ` parametrisch als veld, default 0, structuur stochastische `inf` als reservering.** Veld `correlatieRenteInflatie` blijft, expliciet gekoppeld aan nieuw gereserveerd `inflatieStochastiek` (sub-velden `μ_inf`, `σ_inf`). Beide null in v1; activering is gekoppeld v2-pad.
4. **Documentatie-only patch.** Erken in §4.6 dat `inf` deterministisch is en correlatie irrelevant; haal `correlatieRenteInflatie` uit §4.3. Versimpelt spec.

**Besluit Hans 23-04-2026 16:34: Optie 3 — parametrische structuur met expliciete koppeling, default 0.** Rationale (drie lagen):

(a) **Spec-met-reserveringen (§12.5)** wordt strikter gerespecteerd dan in Optie 4. v1-default 0 reproduceert R9.30-gedrag exact (omdat `inf` deterministisch is en correlatie irrelevant blijft). Verwijderen van het reservering-veld zou een gemiste structuurkans zijn die later met SCHEMA-revisie hersteld moet worden.

(b) **Eerlijke afhankelijkheids-administratie.** Optie 3 maakt expliciet dat *twee* dingen samen geactiveerd moeten worden — dit is goed voor toekomstig-Hans en voor latere implementatoren. Identieke "gekoppeld v2-pad"-structuur als bij `RTS`/`agHerzienPeriode`/`renteAfdekkingFactor` voor SPR-varianten in §4.9.

(c) **Geen numerieke wijziging, geen SSPF-bron-afhankelijkheid.** Optie 2 zou een speculatieve correlatie-waarde introduceren zonder SSPF-specifieke kalibratie; Optie 3 vermijdt dat. Bron-onderzoek (DNB-FTK-publicaties over scenario-correlatie, AG-stochastische-set-parameters) is een eigenstandige ronde voor latere parking, parallel aan RDR-uitputtingsmechaniek-parking uit v2.1.6.

**Doorwerking:** §4.3 (`correlatieRenteInflatie`-rij toelichting uitgebreid; nieuw veld `inflatieStochastiek` gereserveerd object), §4.5 (deterministische-inf-noot na rendementsgeneratie), §4.6 (aanname 17), §4.10 (reviewpunt herschreven van open vraag naar gekoppelde v2-uitbreiding). Geen numerieke wijziging op default-pad.

### §11.8 Lifecycle-rente (variabele RTS per leeftijd)

**Probleem.** Module 3 hanteert in v1 één scalar `proj` voor projectierendement (§4.3, §4.5: `U₀ = ppk_OP / ä(x₀, proj, g)`, update `U_{t+1} = U_t · (1+effR_final)/(1+proj)`). Module 4 specificeert RTS als curve. Onder Wtp-praktijk wordt het beleggingsrisico afgebouwd naarmate de gepensioneerde ouder wordt ("lifecycle"), met `μ(x)` en `σ(x)` per leeftijd. Voor SSPF specifiek is dit niet relevant (collectieve toedeling, vast 60/40-portfolio, geen individuele profielkeuze door gepensioneerden), maar de spec moet ook andere Wtp-fondsen kunnen beschrijven.

**Naamgevings-verwarring vooraf.** §4.3 had één veld `RTS` (vector, voor SPR-hybride rentetermijnstructuur), terwijl §11.8 in oude versie `rtsCurve` noemde voor FPR-lifecycle. Twee verschillende concepten met overlappende naamgeving — wordt in v2.1.8 expliciet onderscheiden.

**Opties.**
1. **Vlakke rente (v1-default), `rtsCurve` blijft gereserveerd null.** Eén `proj`-scalar voor alle leeftijden. Reproduceert R9.30-gedrag. Adequaat voor SSPF; gereserveerde velden blijven voor latere Wtp-fondsen.
2. **Parametrische curve.** SCHEMA-veld `rtsCurve` als `[{leeftijd, waarde}, ...]`. Activering vereist substantiële uitbreiding §4.5 (lookup `proj(x_t)` per tijdstap). Numerieke impact substantieel maar zonder SSPF-bron speculatief.
3. **Formule-gedreven.** `RTS(x) = α − β·(x − x₀)`. Compacter maar functievorm contestabel; past slecht bij Nederlandse pensioenpraktijk (typisch tabel-gespecificeerd).
4. **Vlakke rente + expliciete koppeling met `lifecycle-profiel` (parallel aan v2.1.7-pattern).** Vlakke rente als v1-default (Optie 1), maar de drie velden `proj` (scalar), `lifecycle-profiel` (μ/σ per leeftijd), en nieuw `rtsCurve` (proj per leeftijd) vormen een gekoppelde v2-bundel die hen alle drie tegelijk activeert.

**Besluit Hans 23-04-2026 16:55: Optie 4 — vlakke rente met expliciete bundel-koppeling**, plus drie verfijningen op basis van SSPF-portfolio-input.

**Drie-laags rationale:**

(a) **Pattern-consistentie met v2.1.7.** Zoals `correlatieRenteInflatie` zonder `inflatieStochastiek` betekenisloos is, is `rtsCurve` zonder `lifecycle-profiel` semantisch incompleet (en omgekeerd). De spec wordt strikter door deze afhankelijkheid expliciet te maken.

(b) **SSPF-realisme + spec-met-reserveringen (§12.5).** SSPF-design: collectieve toedelingskring, vast portfolio 60% matching / 40% rendement-seeking, geen individuele lifecycles, geen profielkeuze door gepensioneerden. Default `proj`-scalar reproduceert dit regime exact. Reserveringen blijven beschikbaar voor andere Wtp-fondsen zonder dat v1-spec wordt opgeklopt met speculatieve curve-data.

(c) **Architecturale eerlijkheid.** Een latere implementator die alleen `rtsCurve` activeert zonder `lifecycle-profiel` zou een spec-incoherent fonds modelleren. Optie 4 voorkomt dat door bundel-activatie expliciet te maken.

**Verfijning A — μ/σ-defaults concreet (Keuze A1, Hans 23-04-2026 16:55).** Placeholder "dataset" in §4.3 vervangen door indicatieve SSPF-60/40-waardes: `μ = 0,045` (4,5%), `σ = 0,08` (8%). Indicatief karakter expliciet — SSPF-bestuursnotitie of officiële Wtp-richtlijn kan deze later vervangen zonder spec-revisie. Parallel aan `dempJaren=5` in v2.1.6 en `f=1,0` in v1.4: placeholder vervangen door bron met upgrade-pad.

**Verfijning B — RTS-distinctie expliciet (Keuze "Ja", Hans 23-04-2026 16:55).** Twee orthogonale concepten in §4.3:
- **`RTS`** (vector zero-coupon rentes per looptijd): SPR-hybride rente-afdekking; gebruikt in §5.5 M4-koopsomfactoren; gereserveerd voor SPR-uitwerking Fase B.
- **`rtsCurve`** (vector `[{leeftijd, proj}, ...]`): FPR-lifecycle-projectierente; gekoppeld aan `lifecycle-profiel`; gereserveerd voor v2-Wtp-fondsen met lifecycle-beleggen.

Beide gereserveerd in v1, beide null. Conceptueel orthogonaal — geen activerings-relatie tussen SPR-RTS en FPR-rtsCurve.

**Verfijning C — SSPF-context in scope-voorbehoud.** §4.6 aanname 18 noteert expliciet dat geen-individuele-keuze-en-geen-lifecycle SSPF-specifiek is; andere Wtp-fondsen kunnen wel individuele profielkeuze hanteren.

**Doorwerking:** §4.3 (vier rij-aanpassingen + één nieuw veld), §4.5 (vlakke-rente-noot na deterministische-inf-noot), §4.6 (aanname 18), §4.10 (Lifecycle-profiel-reviewpunt herschreven). Numerieke impact: `μ`/`σ`-defaults verschuiven van placeholder naar indicatieve concretisering; impact alleen voor datasets die placeholders gebruikten.

### §11.9 Plot-horizon: levenslang versus sterfleeftijd-cap

**Probleem.** Module 3 capt in v2.1.8 de berekening hard op `min(ω, ⌈lifeExp(x₀)⌉)` (§4.5). Drie problemen: (a) de cap is op **verwachte** sterfleeftijd (mediaan), waardoor per definitie de helft van het cohort tail-gemist wordt; (b) §4.6 aanname 11 ("FPR-paden = uitkering *als* deelnemer nog leeft") wordt visueel verborgen; (c) zonder reden gooit het informatie weg die al berekend is. Voor presentatie is een cap zinvol; voor berekening niet.

**Opties.**
1. **Tot ω (geen cap).** Maximale informatie, grafiek compact-onvriendelijk.
2. **Tot leeftijd met overlevingskans > 1%** (~100 jaar). Statistisch eerlijke compromis.
3. **Tot lifeExp + 10 jaar.** Dynamisch op individu, R9.30-conform met tail-extensie.
4. **Optie 1 voor berekening, UI-cap als presentatie-laag, default configureerbaar.** Engine berekent altijd tot ω (geen informatie-verlies); UI past `plotHorizonRule`-enum toe als presentatie-cap met v1-default `'lifeExpPlus10'`.

**Besluit Hans 23-04-2026 17:05: Optie 4 — engine-berekening tot ω, UI-cap als presentatie-laag.** Vier enum-waardes voor `plotHorizonRule`: `'lifeExpPlus10'` (default), `'omega'`, `'coverage1pct'`, `'lifeExpExact'`.

**Drie-laags rationale:**

(a) **Pattern-consistentie met v2.1.6/v2.1.7/v2.1.8.** Alle drie hanteerden hetzelfde patroon: één default voor R9.30-conformiteit, alternatieven als enum-veld voor latere bron-keuze. Voor plot-horizon is het patroon nog stricter passend omdat de keuze écht UI-presentatie is, niet engine-mechaniek.

(b) **Behoud van informatie in de berekening.** Geen-numerieke-wijziging-op-default-pad zolang UI default cap toepast; extra paden beschikbaar voor power-users (debug-mode, alternatieve UI-keuzes, onderzoeks-uitvoer) zonder gebruiker-default te veranderen.

(c) **§4.6 aanname 11 wordt scherper toonbaar.** Bij levenslang-tot-ω plot zien power-users dat p10/p50/p90-banden tot allerlaatste tijdstap doorlopen, wat impliciete-mortality-pooling-aanname (aanname 5) visualiseert. Bij hard-gecapte plot is dit minder zichtbaar.

**Doorwerking:** §4.3 (nieuw veld `plotHorizonRule`, status `actief`, default `'lifeExpPlus10'`), §4.4 (`years` blijft engine-output; nieuwe `years_display` en `endAge_display` voor UI-cap), §4.5 (horizon-blok herschreven met scheiding berekening/presentatie), §4.6 (aanname 12 herschreven; nieuwe aanname 19 over UI-cap-default), §4.10 (Plot-horizon-reviewpunt opgelost gemarkeerd). Numerieke impact: geen op berekening; UI-default `'lifeExpPlus10'` toont +10 jaar meer tail dan v2.1.8-cap, wat de tail van langlevenden zichtbaar maakt zonder de plot oncomfortabel breed te maken.

### §11.10 Sterftetafel-default in SCHEMA v2

**Probleem.** Zie §10.3. Huidige `AG2022`-naam verwijst naar gemengde-populatie leeftijdstafel; module 4 eist generatietafel per geslacht.

**Opties.**
1. **Twee resources naast elkaar.** `AG2022-leeftijdstafel-gemengd` (M1-3 default, v1) en `AG2022-generatietafel-per-geslacht` (M4 default, v2).
2. **Alleen generatietafel.** Ook M1-3 migreren; breekt v1-reproduceerbaarheid.
3. **Configureerbaar per module.** Elke module kiest eigen tafel via SCHEMA-veld.

**Voorlopige v1-keuze.** Optie 1. Nomenclatuur moet in SCHEMA v2 verankerd.

**Besluit Hans 23-04-2026 09:24: Optie 1 bevestigd.** SCHEMA v2 introduceert twee expliciete resource-namen: `AG2022-leeftijdstafel-gemengd` (default voor M1-3, reproduceert R9.30) en `AG2022-generatietafel-per-geslacht` (default voor M4). Velden `sterftetafel.m1m3` en `sterftetafel.m4` in de fondsparameterset; beide non-null in v2. De huidige `AG2022`-naam wordt in v1 gelijkgetrokken met `AG2022-leeftijdstafel-gemengd`.

**Update v1.7 (23-04-2026 11:58, via §11.16 besluit).** De "twee resources naast elkaar"-architectuur is conceptueel behouden maar pragmatisch geherformuleerd: in plaats van twee *tabellen* is er nu één AG2024-bron met twee *gebruikswijzen*. Dit is simpeler voor SCHEMA v2 (één veld `actuarieel.sterftekansTabelId = 'AG2024'`) én behoudt de onderliggende logica van §11.10: M1-3 gebruikt periode-snapshot (één kolom), M4 gebruikt cohort (diagonaal). Beide halen uit dezelfde officiële bron. De AG2022-namen in de bovenstaande tekst zijn historisch; vanaf v1.7 gebruikt de engine AG2024.

### §11.11 Overige, niet-blokkerende punten

- **Spreiding-methodiek DNB:** de huidige implementatie gebruikt een specifieke bell-curve variant. Documentatie van de exacte curve-parameters en herleiding naar DNB-publicatie ontbreekt in bronbestanden.
- **Unit-tests:** vaste numerieke assertions per module (x=67, x=75, x=85 met vaste parameters) ontbreken. Aanbevolen onderdeel van SCHEMA v2 of een separate TEST_FIXTURES v1.
- **Seed-beheer Monte Carlo:** huidig R9.30 hanteert vaste seed per sessie; reproduceerbaarheid tussen sessies onbekend. Specificeren in SCHEMA v2.
- **Presentatie-eenheden:** bedragen in euro nominaal versus reëel (koopkracht); de engine rekent nominaal, UI mag omrekenen.

### §11.12 Referentie V_x^Wtp voor φ_afgeleid in standalone-modus (opgeworpen door besluit §11.1)

**Probleem.** Besluit §11.1 (Optie 2) vereist dat module 2 φ_afgeleid = ppkTotal / V_x^Wtp berekent. Wanneer de engine alleen modules 1-3 draait (zonder module 4-output beschikbaar), is V_x^Wtp niet berekend. Vraag: wat is dan de referentie? Aanvullend (v2.1.3): na v2.0 geoormerkte OP/NP-structuur, welke granulariteit(en) produceert M2 voor phiDerived?

**Opties.**
1. **`null`-fallback.** `phiDerived = null` als M4-output ontbreekt; UI toont "niet beschikbaar".
2. **KV als proxy.** Gebruik KV uit module 1 als Wtp-referentie; φ_afgeleid = ppkTotal / KV. Inhoudelijk onzuiver (KV is leeftijdstafel-gebaseerd, V_x^Wtp is generatietafel-gebaseerd) maar levert altijd een getal.
3. **M4 altijd aanroepen.** In v1.1+ wordt M4 altijd geëvalueerd bij M2-evaluatie; koppeling tussen M2 en M4 wordt verplicht.
4. **Component-varianten** (v2.1.3, nieuwe sub-dimensie). Berekent naast `phiDerived` ook `phiDerived_OP = ppk_OP / V_x^Wtp_OP` en `phiDerived_NP = ppk_NP / V_x^Wtp_NP`. Vereist dat M4 zijn OP/NP-breakdown uit presentatie-laag naar berekeningslaag promoveert.

**Voorlopige keuze (v1.1).** Optie 1 (null-fallback).

**Besluit Hans 23-04-2026 14:44 (patch v2.1.3): Optie 1 bevestigd + Optie 4 afgewezen voor v1.**

- **Optie 1 bevestigd als fallback-gedrag**: bij standalone-M2-modus (M4 niet geëvalueerd) levert M2 `phiDerived = null`. UI toont "niet beschikbaar". Rationale: eerlijk signaal dat de decoratie M4-afhankelijk is.
- **Optie 2 afgewezen**: KV-proxy zou precies de tafelmismatch (periode-snapshot M1-3 vs cohort M4) introduceren die de phiDerived-metriek juist bedoelt te controleren. "Altijd een getal" is hier een kwaliteitsprobleem, geen voordeel.
- **Optie 3 afgewezen**: botst met modulaire architectuur §6.2 ("Module 4 parallel"). M2 hoort standalone draaibaar te blijven.
- **Optie 4 afgewezen voor v1**: component-varianten vragen dat M4 zijn OP/NP-breakdown primair maakt; M4-docx-spec behandelt het als presentatie-laag. Een v1-phiDerived_OP zou daarmee een M2-primair (`ppk_OP`) koppelen aan een M4-secundair — brug-ambiguïteit die §1.1-ankerfunctie schaadt. In v2 heropenbaar indien M4-breakdown promoveert tot berekeningslaag.

Consequenties:
- **§3.4 output-contract**: `phiDerived`-rij aangescherpt met expliciete `ppkTotal / V_x^Wtp_totaal`-formule en "geen component-varianten in v1"-annotatie.
- **§3.5 Afgeleide-toedelingsfactor-blok**: toelichting uitgebreid met rationale voor totaal-granulariteit.
- **SCHEMA v2**: output-contract M2 blijft bij één `phiDerived` (optioneel, `null`-mogelijk); geen `phiDerived_OP`/`phiDerived_NP`.
- **UI**: phiDerived als één decoratief getal naast de R9.30-decompositie; géén toggle voor componenten.
- **Upgrade-pad**: als M4 in v2 naar primaire OP/NP-berekening gaat, is deze beslissing heropenbaar met toevoeging component-varianten zonder v1-breuk.

**Toetsing aan narratief kompas (§1.1).** Dit besluit maakt de brug M2↔M4 maximaal zuiver door één overspanning te leggen op een dimensie waar beide modules primair rekenen. De geoormerkte OP/NP-structuur binnen M2 behoudt zijn eigen educatieve werk via de output-velden `ppk_OP` en `ppk_NP`; phiDerived hoeft die informatie niet te dupliceren. Decoratieve getallen moeten decoratief blijven.

**Scherm-4-heropening afgesloten (patch v2.2.7, 23-04-2026 19:53): Optie A — v2.1.3-besluit bevestigd; OP/NP-breakdown M4 blijft presentatie-laag in v1.** Drie kern-elementen:

1. **V2.1.3-besluit bevestigd.** De scherm-4-sessie heeft het heropen-punt uit v2.1.3 expliciet herzien en concludeert dat M4's OP/NP-breakdown in v1 presentatie-laag blijft. `V_x^Wtp` (en `V_x^DB`, `K_x`, `Δ`) worden als totaal-output berekend conform §5.5; OP en NP zijn twee termen binnen de sommatie (§5.5.5), niet aparte output-velden. Een UI-laag kan desgewenst per-component bijdragen tonen maar uit de berekening zelf, niet uit een primaire output-veld.
2. **Optie 4 blijft v2-pad met expliciete heroverwegings-voorwaarden.** Promotie tot berekeningslaag (Optie 4) wordt heropend indien zich één of meer van de volgende omstandigheden voordoen: (a) *gebruikerstest onthult vraag naar component-inzicht* — SSPF-gepensioneerden vragen expliciet om "hoeveel van mijn Wtp-waardering zit in OP vs NP?" als primair getal, niet als afgeleide; (b) *actuariële reviewer adviseert component-primaire output* — een externe review van de publieke calculator markeert de afwezigheid van `V_x^Wtp_OP` en `V_x^Wtp_NP` als audit-defect; (c) *SSPF-communicatiebehoefte* — het fonds kiest voor een UI-ontwerp waarin OP/NP als twee kolommen naast elkaar staan in plaats van als decompositie-toelichting, wat de breakdown-als-primary noodzakelijk maakt. Onder een van deze voorwaarden activeert v3.0 zowel §5.5 (aparte V_x^Wtp_OP/NP-output) als §3.4 (phiDerived_OP/NP in M2).
3. **SCHEMA v2 anker gezet.** M4-output is in SCHEMA v2 één-niveau (totaal voor V_x^DB, V_x^Wtp, K_x, Δ). M2-output houdt geoormerkte OP/NP-structuur zoals vastgelegd in v2.0. phiDerived blijft scalar (één veld) per v2.1.3. Dit geeft SCHEMA-schrijvers duidelijkheid: bij cross-module koppelingen is ppkTotal ↔ V_x^Wtp_totaal het ankerpaar, niet component-niveau.

**Doorwerking.** §5.2 Component 3 Rekenmodule uitgebreid met expliciete v2.2.7-status dat OP/NP-breakdown in v1 presentatie-laag is en geen primaire output. Geen SCHEMA-impact; geen formule-wijziging; geen nieuwe velden. Numerieke impact: geen. **Met deze patch is scherm 4 volledig afgerond en zijn alle acht open punten gesloten.**

### §11.13 Ervaringssterftefactor `f` — structurele activering

**Probleem.** AG2022-leeftijdstafel-gemengd beschrijft de gehele Nederlandse bevolking. Pensioenfondsdeelnemers (typisch hoger opgeleid, hogere inkomens, betere toegang tot zorg) hebben systematisch lagere sterfte dan de bevolking. De factor `f(x,g)` corrigeert dit multiplicatief: `q^fonds = f · q^AG`. Voor SSPF-achtige populaties is `f` typisch 0,85–0,95.

**Opties.**
1. **`f = 1,0` (status quo R9.30).** KV systematisch onderschat voor SSPF met 2–4%.
2. **Vaste scalar `f_SSPF` als SCHEMA-veld.** Eén getal in FONDS_DATASET; default 1,0 totdat SSPF-bron beschikbaar.
3. **Leeftijdsafhankelijke `f(x)`.** Map per leeftijd; nauwkeuriger maar vereist gedetailleerde bron.
4. **Gender+leeftijdsafhankelijke `f(x,g)`.** Volledig; overkill zolang `g` gemengd blijft.

**Voorlopige v1-keuze.** Optie 1. Activering vereist SCHEMA v2 wijziging.

**Besluit Hans 23-04-2026 10:05: Optie 2.** Wijziging t.o.v. voorlopige v1-keuze — maar **structureel**, niet **numeriek**. SCHEMA v2 krijgt veld `actuarieel.ervaringsSterfte` (scalar). FONDS_DATASET.SSPF heeft hem op 1,0 als placeholder totdat een bronhoudbare SSPF-specifieke waarde beschikbaar is (Implementatieplan, jaarverslag, AG2022-fondsklasse-factor). Toekomstige activatie van een niet-1,0-waarde is dan een data-wijziging, geen spec-wijziging. Consequenties:
- **§2.3 (M1 parameterset)**: `f` status van `gereserveerd` → `actief (v1.4)` met toelichting.
- **§2.6 (aanname 3)**: herschreven van "geen f" naar "f als structurele parameter, placeholder-waarde 1,0".
- **§6.3/§8**: `f` is een gedeelde parameter die alle modules raakt (via q → ℓ → ä).
- **SCHEMA v2**: veld `actuarieel.ervaringsSterfte` verplicht (met default 1,0).
- **Geen numerieke impact op KV/potje/U₀** zolang `f = 1,0`.
- **Follow-up actie voor Hans**: opzoeken SSPF-specifieke waarde in Implementatieplan of jaarverslag; als gevonden, FONDS_DATASET-update zonder spec-revisie. Typisch verwacht: 0,90–0,95.

### §11.14 Kostenopslag ρ — structurele activering met niet-nul default

**Probleem.** Actuarieel zuivere KV is `(1+ρ) · pen · ä(x,r)` met `ρ` de uitvoeringskostenopslag. R9.30 rekent met `ρ=0`, wat de "kale" deelnemer-aanspraak geeft maar de VPV-equivalent onderschat. Bij WTP-transitie wordt potje berekend op VPV-basis (inclusief kosten), waardoor de daaruit volgende uitkering lager uitvalt dan scherm-1-KV deed vermoeden. Gepensioneerde ziet "mijn pensioen was €130k waard maar na WTP krijg ik minder" zonder begrijpelijke oorzaak.

**Opties.**
1. **ρ=0 (status quo).** Kale aanspraak; cross-module discrepantie met M4 waar ρ^DB > 0.
2. **Structurele scalar met waarde 0.** Veld actief in SCHEMA, numeriek gelijk aan Optie 1.
3. **Actieve scalar met niet-nul default.** ρ direct als dataset-veld met waarde, bijv. 0,02–0,03.
4. **Afgeleid uit fondsdata met fallback-ladder.** `ρ = c_jaar × ä(x,r)` waar `c_jaar = uitvoeringskostenJaarlijks / fondsvermogen`; secundair direct `kostenOpslagPct`; ultiem een vaste default.

**Voorlopige v1-keuze.** Optie 1. Activering vereist SCHEMA v2 wijziging én bewuste afwijking van reproduceerbaarheid-principe.

**Besluit Hans 23-04-2026 10:24: Optie 4 — afgeleid met fallback-ladder, ultieme default 0,02.** Wijziging t.o.v. voorlopige v1-keuze én **bewuste afwijking van spec-met-reserveringen-principe** (§12.5). Rationale: "dan reken je rijk" — ρ=0 is niet-conservatief en introduceert een uitlegbaarheidsprobleem bij de WTP-uitkomst. Variant A (`ρ = c_jaar × ä`) is didactisch uit te leggen ("0,25% kosten/jaar × 14,5 jaar verwachte duur"), bronhoudbaar (jaarlijkse uitvoeringskosten staan in SSPF-jaarverslag) en leeftijdsafhankelijk op correcte wijze (jongere gepensioneerden dragen langer de kostenlast). Consequenties:
- **§2.3 (M1 parameterset)**: `ρ` status `actief (v1.5)`, default 0,02.
- **§2.5 (formules)**: afleidingsformule `ρ = c_jaar × ä(x, r)` primair; fallback-ladder toegevoegd.
- **§2.6 (aanname 5)**: kostenopslag expliciet als niet-nul default; afwijking van reproduceerbaarheid.
- **§2.7 (fallbacks)**: drie-traps ladder (afgeleid > direct dataset > 0,02).
- **§2.8 (validaties)**: ρ-bereik 0–20%, waarschuwing > 10%.
- **§2.10 (reviewpunten)**: kostenopslag-reviewpunt gemarkeerd als opgelost.
- **§10.1 (cross-module)**: getallenverschil M1↔M4 verder verkleind; typisch nog 1–3% (vs 2–5% in v1.4).
- **SCHEMA v2**: nieuwe velden `financieel.uitvoeringskostenJaarlijks` (optioneel) en `beleid.kostenOpslagPct` (optioneel); `ρ` wordt niet direct als input opgenomen maar afgeleid.
- **Doorwerking M2, M3, M4**: M2 gebruikt KV-formule uit M1, dus automatisch. M3 gebruikt KV-input uit M2, dus automatisch. M4 heeft eigen `ρ^DB` en `ρ^Wtp`; geen wijziging.
- **Numerieke impact**: KV ~2% hoger dan v1.4 bij placeholder-fallback; tot ~3–5% als SSPF-bron hogere `c_jaar` oplevert.
- **Follow-up actie voor Hans**: opzoeken SSPF `uitvoeringskostenJaarlijks` in jaarverslag; FONDS_DATASET-update zonder spec-revisie.

**Afwijking van §12.5 principe.** In alle eerdere besluiten (§11.1, 11.4, 11.5, 11.13) reproduceren default-waarden het R9.30-gedrag. §11.14 breekt dit bewust: ρ=0,02 is geen reproductie maar een conservatieve correctie. De afwijking is gemotiveerd door publieke-communicatie-integriteit en wordt expliciet in §12.5 genoteerd.

### §11.15 Indexatie π op aanspraak tijdens waardering

**Probleem.** Module 1 waardeert de aanspraak nominaal (`π=0`) terwijl module 4 met twee indexatiescenario's werkt (`π^DB`, `π^Wtp`). Als scherm 1 ook met indexatie zou rekenen, verandert KV in een regime-variant en verliest scherm 1 zijn ankerfunctie voor "de aanspraak nu".

**Opties.**
1. **π=0 status quo in M1.** Zuivere nominale aanspraak.
2. **Structurele scalar met waarde 0.** Veld actief, numeriek gelijk aan 1.
3. **Vaste niet-nul default** (bv. 0,015 "verwachte indexatie").
4. **Twee waardes conform M4** (π^DB, π^Wtp in M1).
5. **π dynamisch afgeleid uit fondsbeleid.**

**Voorlopige v1-keuze.** Optie 1.

**Besluit Hans 23-04-2026 11:32: Optie 2 — structurele scalar, waarde 0 als bewust anker.** Reproduceert R9.30-gedrag (geen afwijking van §12.5). Rationale: volgt uit narratief kompas (§1.1). Scherm 1 is het anker voor "nu, kale papieren aanspraak"; indexatie-effecten horen thuis op scherm 3 (via projectierendement) en scherm 4 (via π^DB en π^Wtp). Als π ook in M1 een niet-nul waarde zou krijgen, wordt scherm 1 één van de regime-varianten en verliest scherm 4 zijn pedagogische payload. Het numerieke verschil tussen KV (scherm 1) en V_DB (scherm 4) is onder dit besluit precies "wat indexatie onder DB met uw aanspraak doet" — didactisch informatief in plaats van een rekenartefact. Consequenties:
- **§1.1 (narratief kompas)**: expliciet vermeld dat scherm 1 = anker, scherm 4 = regime-split.
- **§2.3 (M1 parameterset)**: `π` status `actief (v1.6)` met waarde 0.
- **§2.6 (aanname 6)**: herschreven van "geen indexatie" naar "π=0 als bewust anker".
- **§7.3 (consistentie-eisen)**: narratief-verankering toegevoegd.
- **SCHEMA v2**: `actuarieel.indexatieWaardering` (of vergelijkbaar) als scalar met default 0. Veld opgenomen voor future-proofing; UI biedt mogelijk een secundaire verkenningsslider zonder de primaire KV te wijzigen.
- **Geen numerieke impact.**

**Toetsing aan narratief kompas.** Dit besluit is het eerste dat expliciet aan §1.1 wordt getoetst. De toets: maakt dit besluit de navigatie *nu → invaren → straks* helderder, of de regime-split op scherm 4 scherper? Antwoord: beide. Scherm 1 blijft "nu, kaal"; scherm 4 toont "nu onder DB (met indexatie-effect)" vs "nu onder WTP (met rendements-effect)". De drie getallen op scherm 1 en scherm 4 vormen een uitlegbare ladder.

**M4-pendant (v2.2.1-aanvulling).** Waar dit besluit de projectie-aanname in M1 formaliseert (π=0 als bewust anker), formaliseert §5.12.1 (v2.2.1) de analoge projectie-aanname in M4: V_x^Wtp als waarde-equivalent onder de aanname dat π^Wtp de verwachte jaarlijkse ontwikkeling correct representeert. Samen vormen §11.15 (M1-zijde) en §5.12.1 (M4-zijde) één cross-module discipline — projectie-aannames zijn expliciet, niet impliciet, en hun karakter staat in UI-disclosure uitgelegd.

### §11.16 Sterftetafel-migratie naar AG2024 met gender-activering

**Probleem.** De R9.30 Q-tafel, gelabeld `AG2022`, is bij inspectie op 23-04-2026 gebleken een ongedocumenteerde mengconstructie te zijn met substantiële systematische afwijkingen van officiële bronnen. Analyse (zie onder) toont dat de tafel onjuist is, niet herleidbaar tot een publieke bron, en voor een publieke calculator niet verdedigbaar. Parallel is AG2022 door het Koninklijk Actuarieel Genootschap vervangen door AG2024 (publicatie 12-09-2024).

**Bewijs van R9.30-onjuistheid.** Vergelijking van R9.30 Q-tafel met AG2024-gemengd (50/50 M/V) voor projectiejaar 2024:

| Zone | Afwijking | Interpretatie |
|---|---|---|
| x=25–62 | R9.30 +35 tot +70% hoger | Onverklaarbaar; mogelijk gender-onbalans of verkeerde bron |
| x=63–66 | R9.30 ≈ AG2024 | Toeval of lokale kalibratie |
| x=67–80 | R9.30 −11 tot −28% lager | Op x=70: R9.30=0,0104 vs AG2024=0,01446 (−28%) |
| x=85+ | R9.30 iets hoger | Marginaal |

De specifieke anomalie Q[62]=0,00945 → Q[63]=0,00748 (daling 21%) is bevestigd als data-entry-fout: AG2024 voor dezelfde leeftijden geeft monotoon stijgend 0,00671 → 0,00749 → 0,00811.

**Opties.**
1. **Status quo R9.30.** Behoud de mengtafel met notitie over afwijkingen.
2. **Kalibreren R9.30.** Handmatig repareren van Q[62]→Q[63] en andere anomalieën.
3. **CBS Kernprognose (86042NED).** Publiek gemengde periode-tafel; niet sector-standaard.
4. **AG2024 per geslacht, gender gemengd houden in v1.** Migreer tafel, behoud `gemengd` als default voor M1-3.
5. **AG2024 per geslacht, gender actief in v1.** Migreer tafel én activeer M/V-keuze voor deelnemer en partner.

**Voorlopige v1-keuze.** Optie 1 met toelichting in reviewpunten. Vermijdt wijzigingen, maar is niet verdedigbaar bij publieke release.

**Besluit Hans 23-04-2026 11:58: Optie 5 — AG2024 met gender-activering.** Educatieve leidraad (bevestigd door Hans: *"de tool heeft ook educatieve waarde"*) geeft de doorslag. Concrete onderbouwing:

1. **R9.30 onacceptabel.** De systematische afwijkingen (−28% op kern-gepensioneerde-leeftijd 70) en bevestigde data-entry-fout (Q[63]) maken de huidige tafel onbruikbaar voor publieke release.
2. **AG2024 is sector-standaard en publiek.** Officiële KAG-publicatie van 12-09-2024, beschikbaar als Excel, herleidbaar naar Commissie Sterfte Onderzoek. Voor een SSPF-publieke calculator de enige verdedigbare bron.
3. **Gender actief is het grootste educatieve moment van de tool.** Het verschil in annuïteitsfactor tussen man en vrouw is 9,7% (ä(65, 2%) = 15,85 man, 17,39 vrouw); in euro op €18k OP en leeftijd 65 een KV-verschil van €28k. Dit is het type verborgen dimensie dat een educatieve tool zichtbaar hoort te maken.
4. **Operationalisering van §11.10.** De eerder besloten "twee tafels naast elkaar" wordt concreet: één AG2024-bron, twee gebruikswijzen (M1-3 periode-snapshot, M4 cohort).

**Consequenties voor M1.**
- **§2.2**: `g` en `g_y` status `gereserveerd` → `actief (v1.7)`; UI dwingt M/V-keuze aan met `gemengd` als expliciete fallback met waarschuwing.
- **§2.2**: `t₀` default van peildatum-jaar wordt expliciet 2026; status `actief (v1.7)`.
- **§2.3**: `sterftekansTabelId` default van `'AG2022'` naar `'AG2024'`. Nieuwe velden `q_{x,t,g}` (2D per geslacht) en afgeleide `q_x` (gemengd via populatie-weging).
- **§2.5**: Overlevingskans-formule herschreven met geslachtsselector; gemengde-fallback-formule expliciet toegevoegd.
- **§2.6**: Aannames 1 en 2 herschreven.
- **§2.7, §2.8**: Fallbacks en validaties voor gender en t₀.
- **§2.10**: Reviewpunten 1 (Q-anomalie) en 2 (leeftijdstafel vs generatietafel) opgelost.

**Consequenties voor M2, M3, M4.**
- **M2 (§3.5)**: KV-formule in decompositie gebruikt nu gender-specifieke ä via M1-output. Geen wijziging aan §3.5-formules zelf; automatische doorwerking via `KV = M1(x₀, g, t₀, r)`.
- **M3 (§4.5)**: Startuitkering decompositief sinds v2.1.4 (`U₀_OP = ppk_OP / ä(x₀, proj, g)` en `U₀_NP = ppk_NP / ä(x_partner, proj, g_y)`) gebruikt nu gender-specifieke annuïteiten via M1-output. Formele administratie van gender-doorwerking in §4.2/§4.3/§4.6/§4.8 toegevoegd in v2.1.5; spiegelgelijk aan §2-administratie van M1.
- **M4 (§5.5)**: M4 was reeds op generatietafel-per-geslacht gespecificeerd (docx-spec). v1.7-consequentie: M4's cohort-interpretatie wordt nu concreet ingevuld met AG2024, niet meer AG2022. **v2.2.0-aanvulling:** de uit deze keuze volgende methodische asymmetrie (M1-3 periode-snapshot vs M4 cohort) is geformaliseerd als bewuste §5.12.7 met UI-disclosure-eis en §10.1-kruisverwijzing; resterend verschil <1% onder identieke grondslagen is informatief conform §1.1 en moet expliciet worden benoemd.

**Consequenties voor SCHEMA v2.**
- Veld `actuarieel.sterftekansTabelId = 'AG2024'` met herkomst `publiek`.
- Veld `actuarieel.q` als 2D-map per geslacht (of referentie naar AG2024-bestand).
- Veld `demografie.genderWegingNL` als map leeftijd → (w_M, w_V) voor fallback-mengtafel. Bron: CBS.
- FONDS_DATASET hoeft niets gender-specifieks in zich te hebben; deelnemer-invoer levert `g` en `g_y`.

**Drie v1.3 sub-defaults die nu geoperationaliseerd zijn.**
- **Partner-sterftetafel**: AG2024 per `g_y` — partner krijgt eigen geslacht-specifieke tafel, niet de tafel van de deelnemer.
- **Correlatie tussen levens**: 0 bevestigd (onafhankelijke levens, pragmatische bovengrens).
- **NP-fallback**: 70% van OP bevestigd (wettelijke Nederlandse ratio).

**Numerieke impact (65-jarige SSPF-gepensioneerde, €18k OP, r=2%, jaarbasis due voor indicatie):**

| Scenario | ä(65) | KV |
|---|---|---|
| R9.30 (v1.6 baseline) | 17,05 | €306.884 |
| AG2024 man | 15,85 | €285.268 (−7,0%) |
| AG2024 vrouw | 17,39 | €313.093 (+2,0%) |
| AG2024 gemengd fallback | 16,58 | €298.364 (−2,8%) |

Netto: gebruiker krijgt een accurater, verdedigbaar cijfer; het precieze getal hangt van de gender-keuze af. De tool maakt de verschillen zichtbaar.

**Toetsing aan narratief kompas.** Deze wijziging maakt alle drie de momenten (nu, invaren, straks) helderder: scherm 1 toont een gender-accurate KV als anker; M2-potje wordt op die basis herverdeeld; M3-projectie projecteert vanuit een juist startpunt; M4 vergelijkt DB/WTP op dezelfde tafel. Bovendien onthult de tool een dimensie (gender-effect) die de gebruiker waarschijnlijk niet kende. Educatieve en technische eisen lijnen op.

**Follow-up acties voor Hans (niet-blokkerend).**
- AG2024-dataset embedden in FONDS_DATASET of als separate resource-file in de code-repo.
- CBS-populatie-weging voor `demografie.genderWegingNL` opzoeken (CBS Statline, bevolkingsopbouw per leeftijd/geslacht 2026).
- SSPF-specifieke M/V-verdeling opzoeken voor eventuele SSPF-interne gemengde fallback (v2-overweging).

**v3.0.1-update (05-05-2026 18:55) — UI-laag-restrictie 'gemengd'.** Aanleiding: gebruikersfeedback (Hans, 70M+70M-test op v3.0-build) dat `'gemengd'` als dropdown-keuze betekenisloos is voor een eindgebruiker. Een mens kent zichzelf en zijn/haar partner; de 95/5-prior is fonds-niveau (zie §11.17), niet persoons-niveau. De v1.7-implementatie (`GenderSchema = z.enum(['M', 'V', 'gemengd'])`) zette `'gemengd'` voor *alle drie* de invoer-paden — UI-dropdown, batch-validatie, en engine-cohort-proxy — terwijl het alleen voor de laatste twee bedoeld is. **Wijziging v3.0.1:** UI-laag (`src/ui.m1.ts` `renderInputField`) filtert `'gemengd'` uit alle dropdown-opties; eindgebruiker ziet alleen `M`/`V`. SCHEMA-defaults `M1.deelnemer.g` en `M1.deelnemer.g_y` schuiven van `'gemengd'` naar `'M'` zodat een ongekozen veld niet stilletjes als 'gemengd' eindigt. **Engine-laag onveranderd:** `q(x, t0, g, ...)` accepteert nog steeds `'gemengd'` met SSPF-prior; M2 `cwStarProfile`/`kvProfile` blijven cohort-mid-proxy via `'gemengd'` aanroep gebruiken (§11.17 v1.9-besluit ongewijzigd); SCHEMA-niveau-batch-validatie kan nog steeds `'gemengd'` zetten voor anonieme records. **Numerieke impact:** nul op v3.0-ankers (alle tests gebruiken expliciet `'M'`/`'V'`). **Onderbouwing keuze "verbergen" boven "waarschuwen":** v1.7-spec voorzag SCHEMA-uiDisclosure met UI-waarschuwing ("UI toont waarschuwing bij `gemengd` voor bekend-geslacht gebruik") maar de UI implementeerde die waarschuwing niet — twee jaar lang stond `'gemengd'` zonder context naast `'M'`/`'V'` in de dropdown. Bij gebruikerstest bleek dat verklaring-via-disclosure de cognitieve last verhoogt (gebruiker moet eerst lezen wát `'gemengd'` doet voordat hij weet dat hij het niet moet kiezen) terwijl simpelweg verbergen de juiste signalering geeft (er is geen keuze, dus geen verkeerde keuze mogelijk). De informatie blijft toegankelijk via SCHEMA-introspectie en spec voor wie het wil weten. Zie patch v3.0.1-changelog.

### §11.17 SSPF-gender-weging voor fallback en cohort-normalisatie (v1.9)

**Probleem opgeworpen door v1.7 besluit §11.16.** Gender-activering in M1 gebruikt in v1.7 een CBS-populatie-weging als fallback voor `g=gemengd` en voor cohort-normalisatie ν(N) in M2. Voor SSPF is deze neutrale Nederlandse weging niet representatief — Shell-werknemers uit de relevante periodes waren overwegend mannen, dus ook de SSPF-gepensioneerde-populatie is M-gedomineerd. Een neutrale fallback-waarde zou bij onvolledige invoer systematisch verkeerd rekenen.

**Opties.**
1. **CBS-populatie-weging (v1.7-default).** ~45% M / 55% V voor 65+. Neutraal maar niet representatief voor SSPF.
2. **Expert-prior SSPF.** Placeholder 95/5 voor deelnemer en 5/95 voor partner-gegeven-M-deelnemer, tot SSPF-jaarverslag data levert.
3. **Direct uit SSPF-jaarverslag.** Exacte M/V-verdeling per cohort en totaal; accurate maar vereist data-aanlevering.

**Besluit Hans 23-04-2026 13:21: Optie 2 — SSPF-expert-prior als v1-placeholder.** Consequenties:

**Waarden v1.9 placeholder (bronhoudbaar, upgradable):**
- `demografie.genderWegingSSPF.deelnemer = (w_M=0.95, w_V=0.05)` — voor fallback `g=gemengd` en voor cohort-normalisatie ν(N)
- `demografie.genderWegingSSPF.partnerGegevenM = (w_M=0.05, w_V=0.95)` — voor fallback `g_y=gemengd` als deelnemer M is
- `demografie.genderWegingSSPF.partnerGegevenV = (w_M=0.50, w_V=0.50)` — voor fallback `g_y=gemengd` als deelnemer V is (kleinere groep, zwakke prior)

**Waar gebruikt:**
- **M1 fallback `g=gemengd`**: `q^mix_{x,t₀} = w_M · q^{AG2024}_{x,t₀,M} + w_V · q^{AG2024}_{x,t₀,V}` met SSPF-weging.
- **M1 fallback `g_y=gemengd`**: idem, conditioneel op `g`.
- **M2 cohort-normalisatie ν(N)**: `s̄(x̄_c, N)` gebruikt `deelnemer`-weging.

**Vervangt v1.7-keuze.** De `demografie.genderWegingNL` (CBS) blijft beschikbaar in FONDS_DATASET als optioneel veld voor niet-SSPF-fondsen; v1.9 gebruikt default de SSPF-weging.

**Numerieke impact.**
- Voor M-deelnemer die `g=M` invult: geen effect (gender-specifiek).
- Voor V-deelnemer die `g=V` invult: ν(N) is nu berekend met 95%-M-populatie, marginaal andere ppkSurplus (~0,3%) dan bij CBS-neutrale weging.
- Voor gebruiker die `g=gemengd` kiest bij M-deelnemer: bijna-identieke uitkomst als `g=M` (95% weging).
- Voor gebruiker die `g=gemengd` kiest bij V-deelnemer: substantieel andere uitkomst dan `g=V` (want prior trekt naar M). **Waarschuwing in UI is essentieel**.

**Upgrade-pad.**
- v1.9: placeholder 95/5.
- v1.10 (of later): SSPF-jaarverslag-data vervangt placeholder. Spec-revisie niet nodig; alleen FONDS_DATASET-update.
- v2: potentieel cohort-specifieke weging (oudere cohorten historisch nog M-dominanter).

### §11.18 NP-integratie: geoormerkt binnen één persoonlijk pensioenvermogen

**Probleem (cross-screen punt 2).** Module 2 berekent het potje op basis van KV uit M1. M1 produceert sinds v1.3 twee aparte outputs: KV_OP (eigen aanspraak) en KV_NP (nabestaandenaanspraak). De vraag is hoe de potje-berekening deze twee aanspraken behandelt: apart (twee parallelle potjes), samen (één totaal), of geoormerkt (één totaal met label-administratie).

**Empirische onderbouwing.** Op 23-04-2026 is het SSPF-transitieplan (juli 2024) en gerelateerde WTP-bronnen onderzocht. Bevindingen:
- WTP-wetgeving: *"Invaren is het standaardpad. Dit standaardpad geldt voor alle bestaande pensioenregelingen die worden uitgevoerd door het pensioenfonds, dus ook voor het nabestaandenpensioen"* (werkenaanonspensioen.nl).
- SSPF-communicatie aan oud-collega's: *"Het ouderdomspensioen en het nabestaandenpensioen blijven levenslang en het pensioenvermogen wordt collectief belegd."*
- PostNL-transitieplan (analoog): *"Het in het verleden reeds opgebouwde partnerpensioen zal in de nieuwe pensioenregeling worden gehandhaafd als persoonlijk pensioenvermogen en worden geoormerkt t.b.v. nabestaandenpensioen."*

Daarmee is vastgesteld: de feitelijke SSPF-praktijk is NP-integratie in persoonlijk pensioenvermogen met geoormerkte administratie. Een apart NP-depot of aparte verzekeringsdekking is niet het gekozen pad.

**Opties.**
1. **Alleen KV_OP in potje.** NP-aanspraak blijft buiten M2/M3 en is aparte verzekering. Strijdig met WTP-standaardpad.
2. **KV_totaal in potje, geen OP/NP-zichtbaarheid.** Simpel maar verliest UPO-herkenbaarheid.
3. **Twee aparte potjes (OP en NP volledig parallel).** Maximale scheiding; niet conform SSPF-regime (overcomplicatie).
4. **Eén potje met geoormerkte OP/NP-componenten.** Matcht SSPF-regime; behoudt educatieve transparantie.

**Besluit Hans 23-04-2026 13:35: Optie 4 — geoormerkte OP/NP binnen één persoonlijk pensioenvermogen.** Dit volgt het standaard-invaarpad van de WTP en sluit aan bij de feitelijke SSPF-implementatie. Consequenties:

**Engine-structuur (M2 = §3).**
- `ppkTotal` = decompositie over KV_totaal (ppkBase + ppkSurplus + ppkComp).
- `ppk_OP` en `ppk_NP` als geoormerkte subcomponenten — aparte output-velden.
- `ppkBase`-splitsing is lineair: `ppkBase_OP / ppkBase_NP = KV_OP / KV_NP`.
- `ppkSurplus`-splitsing is actuarieel: elk deel gebruikt de eigen `sFactor` (deelnemer-leven voor OP, partner-leven voor NP). Niet puur lineair.
- `ppkComp` gaat volledig aan OP — het compensatiedepot is deelnemer-compensatie, geen NP-compensatie.
- **Partner afwezig** (`heeftPartner=false`): `KV_NP = 0 → ppk_NP = 0 → ppkTotal = ppk_OP`. Reduceert terug tot v1.x-eenkanaalgedrag.

**Engine-structuur (M3 = §4).**
- `U₀` wordt berekend uit `ppkTotal` (niet uit ppk_OP alleen).
- Interne boekhouding: bij overlijden deelnemer in projectie wordt NP-dekking geactiveerd uit het geoormerkte ppk_NP-deel. Detailimplementatie in scherm-3-sessie.
- `ä(x₀, proj, g)` voor OP-levenspad; eventueel `ä(x_partner, proj, g_y)` voor latent-NP-pad.

**Engine-structuur (M4 = §5).**
- V_DB en V_Wtp blijven geaggregeerde waarderingen conform docx-spec.
- Optionele breakdown naar OP/NP in presentatie-laag (UI) voor transparantie; berekening blijft op totaal.

**UI-structuur.**
- **Scherm 1**: twee regels KV_OP en KV_NP (UPO-herkenbaar), totaal KV als optionele regel.
- **Scherm 2**: ppkTotal als hoofdgetal, met decompositie (base+surplus+comp) en OP/NP-breakdown als deepdive.
- **Scherm 3**: één uitkeringspad; deepdive toont dat NP-dekking latent in kapitaal zit.
- **Scherm 4**: V_DB en V_Wtp totaal; optionele OP/NP-split.

**Numerieke impact.**
- `ppkTotal` voor deelnemer met partner: ≈ som die je zou krijgen bij Optie 2 (KV_totaal). Dus substantieel hoger (~30-50%) dan bij Optie 1 (alleen OP), want NP-waarde komt mee.
- Getal blijft consistent met V_DB en V_Wtp van M4 (die ook OP+NP omvatten, §5.4 docx).
- Voor gebruiker zonder partner: geen impact; `heeftPartner=false` reduceert naar v1.x-gedrag.

**Consistentie met eerdere besluiten.**
- §11.1 (φ afgeleid): `phiDerived = ppkTotal / V_x^Wtp_totaal` werkt op totalen, blijft geldig.
- §11.4 (arrears m=12): geldt voor alle annuïteiten, inclusief partner-annuïteit voor NP.
- §11.5 (partneruitbreiding M1): KV_OP/KV_NP-structuur blijft intact, wordt in M2 doorgegeven.
- §11.16 (AG2024+gender): `g` voor deelnemer, `g_y` voor partner — beide actief in de geoormerkte splitsing.

**Toetsing aan narratief kompas (§1.1).** Dit besluit maakt de overgang *nu → invaren* pedagogisch sluitend: gebruiker ziet op scherm 1 twee UPO-aanspraken, ziet op scherm 2 dat ze één persoonlijk vermogen worden met behoud van NP-label, en ziet op scherm 3 één uitkeringspad waarin NP latent meegaat. Drie momenten, heldere overgang, conform werkelijke SSPF-implementatie.

**Follow-up (detailwerk voor scherm-2- en scherm-3-sessies).**
- ~~Exacte berekeningsvolgorde binnen ppkSurplus-OP/NP-splitsing.~~ **Opgelost via patch v2.1.1 (23-04-2026 14:12)**: Optie A1 — actuarieel bottom-up met één ν(N) op SSPF-deelnemer-weging. Zie §3.5 en §3.6 aanname 12.
- ~~Interne bookkeeping M3 voor NP-schakel bij deelnemer-overlijden.~~ **Opgelost via patch v2.1.4 (23-04-2026 15:22)**: Optie A — impliciete annuïteit-splitsing. `U₀_OP = ppk_OP / ä(x₀, proj, g)` en `U₀_NP = ppk_NP / ä(x_partner, proj, g_y)` als deepdive-decompositie; hoofdpad `U₀ = U₀_OP`; geen expliciete overlijdens-event in MC. Mortality pooling impliciet via beide annuïteiten. Joint-life als v2-reservering (§4.9, spiegel §2.10). Zie §4.4, §4.5, §4.6 aanname 14, §4.7.
- UI-design voor OP/NP-breakdown op schermen 2, 3, 4.

**Status-update v3.0 (05-05-2026).** OP/NP-decompositie binnen M2 wordt onder v3.0 wiskundig automatisch via lineariteit afgedwongen, niet langer via aanname-niveau. Onder R9.30 (v2.1.1-mechaniek) was de sluitingscontrole `ppk_OP + ppk_NP = ppkTotal` afhankelijk van een **bottom-up som-conventie** waarin elk OP/NP-deel zijn eigen `sFactor` toegekend kreeg (gender-specifiek deelnemer-leven respectievelijk partner-leven), en een aparte aanname (§3.6 aanname 12) garandeerde dat ν(N) uniform was over OP en NP zodat de KV-decompositie additief bleef. Onder v3.0 wet-canoniek geldt:

```
ppk_OP = KV_OP + x_fonds · cw_star_op  [+ ppkComp, alleen OP]
ppk_NP = KV_NP + x_fonds · cw_star_np
ppk    = KV    + x_fonds · CW_star    [+ ppkComp]
       = (KV_OP + KV_NP) + x_fonds · (cw_star_op + cw_star_np) + ppkComp
       = ppk_OP + ppk_NP                          (per constructie exact)
```

De fonds-x_fonds is per definitie één scalar voor het hele fonds (art. 3 bijlage 2a); de OP/NP-uitsplitsing volgt **automatisch** uit de lineariteit van de wet-formule `ppk = KV + x · CW_star`. Geen aparte sFactor-aannames per leven nodig; geen ν(N)-uniformiteit aanname nodig (er is geen ν(N) meer onder v3.0). Sluitingscontrole machine-precisie zonder voorwaarden.

**Consequentie voor §3.6 aanname 12:** vervalt structureel onder v3.0 omdat ν(N) niet meer wordt gebruikt. Zie §3.6-update v3.0 voor herziene aanname-set.

**Geoormerkte structuur (v2.0 besluit) blijft inhoudelijk geldig.** De v2.0-keuze "één potje met geoormerkte OP/NP-componenten" is niet veranderd; alleen de wiskundige onderbouwing is verschoven van aanname-niveau naar lineariteit-niveau. UI-decompositie (`ppk_OP`, `ppk_NP` als aparte velden) en SSPF-praktijk-conformiteit (WTP-standaardpad voor NP) zijn ongewijzigd. Latent-NP-mechanisme M3 (§11.18 follow-up bullet 2 + §4.6 aanname 14) ongewijzigd onder v3.0.

**Cross-module-status v3.0.** M2 OP/NP-decompositie staat nu wiskundig zuiver. M3 NP-schakel via `U₀_OP` en `U₀_NP` (v2.1.4) gebruikt impliciete annuïteit-splitsing met joint-life-bovengrens; v2.2.11 vervangt M1-bovengrens door joint-life-formule maar M3 §4.5-formule volgt nog v1.3-bovengrens (asymmetrie-status). v3.0 raakt deze asymmetrie niet — M3 en M4 ongewijzigd. v2.2.11-asymmetrie-resolutie (§4.9, §5.12.3) blijft openstaand voor latere release.

---

### §11.19 SSPF-`vpvAftrekPct`-kalibratie (v2.2.10)

**Status:** placeholder-default actief (0,10 ABN-conservatief), bron-onderzoek SSPF nodig voor productie-kalibratie.

**Achtergrond.** Patch v2.2.10 introduceert `vpvAftrekPct` als bundle-aftrek-fractie van `vpvTotal` voor alle bestemmingsreserveringen behalve `compensatiedepot` (VEV, operationele reserve, solidariteitsreserve, inhaalindexatie). De default 0,10 is gebaseerd op ABN AMRO Pensioenfonds-publicatie (transitieplan 17-10-2024 + implementatieplan 22-09-2025), wiskundig geverifieerd via de in CRM-2026-34 dossier 2025-0107 aangehaalde ABN-toelichting bij dekkingsgraden 115%/125%/135% (`5%/15%/25% verdeelbaar overschot ↔ aftrek = 0,10·vpvTotal`).

**Probleem.** ABN's gepubliceerde 0,10 is gekalibreerd op een gemengd-leeftijds-fonds (actieven + gepensioneerden). SSPF is structureel anders: gesloten fonds, geen actieve deelnemers, voornamelijk gepensioneerden. Implicaties:

- **DRS-compensatie-aandeel.** ABN's bundle bevat compensatiedepot voor actieven (substantieel deel van de 10%); SSPF heeft geen DRS-compensatie-doelgroep dus dit aandeel is structureel kleiner of nul. Argument voor lager `vpvAftrekPct` voor SSPF.
- **Inhaalindexatie.** SSPF heeft als gesloten fonds een ander indexatie-pad dan ABN; inhaalindexatie-aandeel kan groter of kleiner zijn — bron-onderzoek vereist.
- **Solidariteitsreserve.** Onder SPR (solidaire premieovereenkomst) zit hier 3-15%; onder FPR (flexibele premieovereenkomst) speelt dit niet of beperkt. SSPF-regelingskeuze bepaalt dit aandeel direct.
- **VEV.** Vereist eigen vermogen ~ 25% van vpv onder huidige regels; bij invaren wordt deze norm losgelaten en is de relevante onderhouds-buffer kleiner. SSPF-specifiek niveau onbekend.

**Mondelinge bron.** Hans (Innovation Nestor SSPF) heeft "wel eens 6% gehoord" als SSPF-aftrek-niveau in interne overleggen. Dit is **niet** een geverifieerde bron en mag niet als default in de SCHEMA — placeholder blijft 0,10 conservatief. 6% zou kwalitatief consistent zijn met "geen DRS-compensatie + lager inhaalindexatie-aandeel + geen actieven-toekomstige-opbouw-component", maar zonder bron is dit speculatie.

**Default-keuze rationale.** Default 0,10 (ABN-conservatief) boven SSPF-vermoeden 0,06, parallel aan §11.14 v1.5-rationale (ρ=0,02 ultieme default ondanks dat ρ=0 R9.30-conform zou zijn): **publieke calculator moet "rekent rijk"-asymmetrie vermijden**. Een te lage `vpvAftrekPct` zou potje en uitkering in de calculator hoger laten uitvallen dan in werkelijkheid het geval is, met uitlegbaarheidsprobleem bij echte WTP-uitkomst. Boven SSPF-niveau is in dit opzicht conservatief.

**Bron-onderzoek-instructies.** Te raadplegen voor SSPF-kalibratie:

- SSPF-jaarverslag (laatste editie) — sectie reserves en bestemmingen
- SSPF-transitieplan (publiek of conceptdocument) — bundle-toelichting analoog aan ABN
- SSPF-implementatieplan (zodra publiek) — definitieve bundle-cijfers per dekkingsgraad-scenario
- DNB-publicaties over SSPF-specifieke buffer-eisen
- Sociale-partner-overleg-stukken (indien publiek toegankelijk)

**Vervangings-pad.** Bij vondst van geverifieerde SSPF-bron kan de placeholder-default worden vervangen via `fondsdataset.ts` SSPF-placeholder zonder spec-revisie of SCHEMA-bump. Latere precisering (bijvoorbeeld DG-afhankelijke variatie of componenten-decompositie) zou wel SCHEMA-uitbreiding vergen.

**Numerieke gevoeligheid.** Bandbreedte SSPF-onderzoek 0,06-0,10 levert verdeelbaar-bereik van `fondsvermogen − 0,06·vpvTotal − compensatiedepot − buffer + bijstort` tot `fondsvermogen − 0,10·vpvTotal − …`. Bij DG=1,15 vertegenwoordigt dit een verschil van ongeveer 4 procentpunten in `verdeelbaar/fondsvermogen`. Doorwerking naar individuele `ppkTotal` voor 67-jarige SSPF-default-deelnemer (R9.30-baseline KV ≈ €808.815): puntschatting bandbreedte ±3% ppkTotal afhankelijk van uiteindelijke kalibratie. Materieel maar niet dramatisch — ondersteunt placeholder-aanpak met latere bron-vervanging.

### §11.20 Broken-heart-multiplier bron-onderzoek (v2.2.11)

**Status:** placeholder-default actief (gender-asymmetrisch `bh(0,M)=1,50`, `bh(0,V)=1,25`, lineair dempend over 5 jaar), bron-verificatie nodig voor productie-gebruik.

**Achtergrond.** Patch v2.2.11 activeert M1 joint-life-formule met broken-heart-correctie op KV_NP-berekening. De broken-heart-multiplier `bh(τ, g_y)` modelleert verhoogde sterftekans van een overlevende partner na overlijden van de eerste — een goed-gedocumenteerd actuarieel fenomeen waar weduwen/weduwnaars tijdelijk hogere mortaliteit vertonen dan algemene-populatie-leeftijdsgenoten. De v1-aanname was strict-onafhankelijke levens (impliciet `bh ≡ 1`); v2.2.11 nuanceert dit met tijds-afhankelijke schock dempend over enkele jaren.

**Probleem.** De default-parametrisering in v2.2.11 — `bh(0,M)=1,50`, `bh(0,V)=1,25`, 5-jaars lineaire demping — is uit geheugen geciteerd door spec-auteur (Claude) als "AG-2018-rapport-Spreiding-overlijdenstijden". Deze bron is **niet** geverifieerd in de spec-sessie; het rapport is niet ingezien, en de exacte cijfers reciteert Claude expliciet uit geheugen. De keuze is daarmee een Werkafspraak-12-conforme placeholder met expliciet bron-onderzoek-pad, niet een gestaafde wetenschappelijke onderbouwing.

**Beoogde primaire bron.** Aktuariëel Genootschap (AG), rapport over spreiding van overlijdenstijden bij echtparen — vermoedelijk uit reeks publicaties rondom AG-prognosetafels. Te zoeken in AG-publicatieregister (https://www.ag-ai.nl) of via SSPF/Pensioenfederatie-toegang. Bij vondst gewenste vorm:
- Tabel `bh(τ, g)` voor τ ∈ [0..5] of langer
- Of formule met decay-rate λ (exponentieel: `bh(τ) = 1 + (bh₀ − 1) · exp(−λτ)`)
- Gender-asymmetrie ja/nee — als bron alleen gender-symmetrische factor geeft, default-parametrisering `bh₀(M) = bh₀(V)` gelijkstellen.

**Alternatieve bronnen (secundaire ladder).**

- **CBS-langlevenstudies** — Nederlandse data over weduwe/weduwnaar-mortaliteit; CBS publiceert demografische analyses die broken-heart-effect impliciet bevatten via vergelijking partner-status-cohorten.
- **Bowers et al. (1997, "Actuarial Mathematics")** — klassieke actuariële tekst, US-data 1990s, factoren 1,30 jaar 1 / 1,15 jaar 2 / 1,05 jaar 3. Ouder dan AG2024, niet-NL, maar gedocumenteerd en stabiel referentiepunt.
- **Algemeen Pensioenfonds-rapporten** — APF-publicaties over invaar-modellering kunnen broken-heart-aannames bevatten (DPS, ABP, Aegon Cappital).
- **Conservatieve fallback** — bij geen bevestigde bron: gender-symmetrische `bh(0)=1,20`, 3-jaars lineaire demping (afgevlakt-Bowers).

**Hans-actie.** AG-2018-rapport opvragen (eerste prioriteit). Bij niet-vinden: CBS-langlevenstudies als secundaire bron raadplegen. Bij niet-vinden: Bowers-1997-cijfers bevestigen als documenteerbare-maar-oude default. Bij twijfel: conservatieve fallback gebruiken.

**Default-keuze rationale (v2.2.11 placeholder).** Gender-asymmetrische 1,50/1,25 met 5-jaars demping is een pragmatische middenweg tussen Bowers-symmetrisch-aflopend (te conservatief, niet-NL) en strict-onafhankelijk (overschat KV_NP). Deze placeholder maakt het broken-heart-effect zichtbaar zonder claim op definitieve kalibratie. Bij bron-vervanging is engine-update minimaal: `bh()`-functie aanpassen, geen SCHEMA- of spec-revisie nodig.

**Vervangings-pad.** Bij vondst van geverifieerde bron kan de `bh()`-implementatie in `engine.m1.ts` worden vervangen zonder spec-major-bump. Bij significante afwijking (factoren > 1,75 of < 1,10, of niet-lineaire demping) hoort de bron-citatie in §2.5 + §11.20 te worden bijgewerkt. Bij bron-confirmatie van AG-2018 wordt §11.20-status aangepast naar "geverifieerd, productie-actief".

**Numerieke gevoeligheid.** Bandbreedte default-parametrisering vs Bowers-symmetrisch-1,30/1,15/1,05 levert KV_NP-verschil van ~5-10 procentpunten op de joint-life-formule. Voor Henk-Anna-typisch (x=68M, x_partner=66V) komt KV_NP uit op ongeveer:
- v2.2.11-default (asymmetrisch 1,50/1,25 met 5-jaars demping): ~€90k-€100k
- Bowers-symmetrisch (1,30 met 3-jaars demping): ~€100k-€110k
- Strict-onafhankelijk (bh ≡ 1, joint-life zonder schok): ~€115k-€125k
- v1.3-bovengrens (oude formule, geen joint-life): ~€237k

Doorwerking naar KV-totaal: bandbreedte ±2-4% afhankelijk van bh-kalibratie. Dominante effect is de joint-life-overstap zelf (~€237k → ~€100k); broken-heart-correctie binnen joint-life-formule is tweede-orde verfijning op die basis.

**Cross-module status.** §11.20-bron-onderzoek is M1-specifiek voor v2.2.11; bij M3/M4-implementatie zal dezelfde bh-kalibratie worden hergebruikt (engine-shared-functie), zonder afzonderlijk bron-onderzoek per module. v2.2.3-werkafspraak ("gekoppeld v2-pad") wordt daarmee in v2.2.11 procedureel ondersteund: bron beheerd op één plek, activering per module gefaseerd.

### §11.21 Spreidings-formule canoniciteit-onderzoek (v2.2.13 → v3.0 resolutie)

**Status (v3.0, 05-05-2026):** **bron-bevestigd, implementatie-aanpassing voltooid.** Bron-ladder-trap (1) leverde eenduidig antwoord; trappen (2)-(6) niet meer noodzakelijk. R9.30-DNB-formule vervangen door wet-canonieke standaardregel; oude formule behouden via `computeM2_R930_LEGACY` voor regressie.

**Status v2.2.13 (historisch).** §3.5 R9.30-DNB-formule actief, alternatieve formuleringen opengelaten voor bron-bevestiging; niet gekoppeld aan externe SSPF-bestuurlijke-deadline.

**Achtergrond.** Hans Haringa (Innovation Nestor SSPF) verstrekte op 05-05-2026 een externe modelspecificatie ("Bijlage 2 — Modelspecificatie", drs. ing. H. Haringa, Assen 02-05-2026, bijlage bij vragen aan SSPF-bestuur over spreidingstermijn) met een formele uitwerking van bijlage 2a Regeling Pensioenwet. Dit document hanteert een lineaire spreidings-formule:
```
q(h, N) = h/N    voor h ≤ N
        = 1      voor h > N

KS_voor(i, h) = U_i · S(h | x_i) · 𝟙{x_i + h ≥ Pl}
KS_na(i, h)  = KS_voor(i, h) · (1 + q(h, N) · x*)
PV(i)        = Σ_h KS_na(i, h) · v(h)
```
met `x*` als fonds-niveau-schalingsfactor: `x* = (M − CW_voor) / CW*`, `M = DG · CW_voor · (1 − W)`, `CW_voor = Σ_i Σ_h KS_voor(i, h) · v(h)`, `CW* = Σ_i Σ_h KS_voor(i, h) · q(h, N) · v(h)`.

Onze huidige §3.5 hanteert R9.30-DNB-formule met cohort-gewogen `dnbShareFactor(x, N) = 1 − ν(N) · ...` en kvProfile-aanpak. **De twee formules zijn niet equivalent** en leveren systematisch verschillende uitkomsten op identieke inputs.

**Probleem.** Onze spec-claim "§3.5 R9.30-conform" verwijst impliciet naar bijlage 2a Regeling Pw (de wettelijke standaardregel) als juridische basis, maar of R9.30-DNB-formule een correcte implementatie is van die wettelijke tekst, of een afgeleide vereenvoudiging, is op 05-05-2026 niet bron-bevestigd. Q-D-numerieke verkenning (Claude, 05-05-2026, script `/tmp/qd_v2.ts`) toont dat de twee formules op identieke demografie en sterftetafel verschillende resultaten geven. Onderstaand de bevindingen.

**Q-D-meet-bevindingen (05-05-2026, AG2024-sterftetafel, vlakke r=0,025, fonds-demografie SSPF-gesloten-preset, U=€30k uniform per cohort, W=0,10):**

DG = 1,15 (SSPF-typisch), spreidingstermijn N = 10:
| Leeftijd | R9.30-DNB-opslag | Bijlage-2-lineair-opslag | Δ |
|---|---|---|---|
| 67 (SSPF-anker) | +5,32% | +3,59% | +1,73 procentpunten |

DG = 1,35, vergelijking N = 10 vs N = ∞ (proxy via N = 1000) onder bijlage-2-lineair:
| Leeftijd | Lineair N=10 | Lineair N=∞ | Δ binnen formule |
|---|---|---|---|
| 52 | +31,17% | +56,51% | +25,3 procentpunten |
| 57 | +31,17% | +45,06% | +13,9 procentpunten |
| 62 | +29,00% | +33,61% | +4,6 procentpunten |
| 67 | +22,03% | +22,16% | +0,1 procentpunten |
| 72 | +20,30% | +18,49% | −1,8 procentpunten |
| 87 | +12,13% | +9,10% | −3,0 procentpunten |

**Interpretatie:** N-keuze (10 vs ∞) heeft substantieel effect op jongere cohorten (52-jarige: ~25 procentpunten extra opslag onder N=∞), marginaal effect op SSPF-typische 67-jarige (~0,1 procentpunten), en lichte negatieve impact op zeer-oude cohorten. Voor een SSPF-context (gesloten gepensioneerden-fonds, doelgroep 65-89) is N-keuze daarom kwantitatief minder dominant dan de formule-keuze (R9.30 vs lineair-bijlage2) zelf.

**Beoogde primaire bron-ladder (vragen aan §11.21 in volgorde):**
1. **Bijlage 2a Regeling Pensioenwet** (`wetten.overheid.nl`). Vraag: bevat de bijlage een wiskundige formule, of een kwalitatieve beschrijving die implementatie-vrijheid laat? Als formele formule: matcht `q(h, N) = h/N` of een R9.30-equivalent?
2. **DNB-Q&A's invaren / Wtp**. Vraag: heeft DNB de spreidings-formule expliciet ge-formuleerd in een Q&A? Idem voor de juridische status van R9.30 als referentie-implementatie.
3. **Pensioenfederatie-implementatieleidraad**. Vraag: empirische sector-praktijk; welke formule-vorm wordt door fondsen toegepast?
4. **AG-rapporten over invaar-modellering**. Aktuariëel Genootschap-richtlijnen voor numerieke invulling.
5. **Transitieplannen ABN AMRO Pensioenfonds, ABP, PMT, PFZW** als empirische bevestiging van praktijk.
6. **Wetenschappelijke literatuur** (Cardano/Aon/Mercer-studies, Tijdschrift voor Pensioenvraagstukken) als context.

**Stop-criteria.** Zodra (1) of (2) eenduidig antwoord geeft, lager-rangschikte bronnen worden niet meer geraadpleegd. Als (1)+(2) ambigu zijn, doorgaan tot (5) en empirische consensus rapporteren.

**Wat §11.21 niet doet.** Geen implementatie-keuze, geen alternatieve-formule-toevoeging, geen casual-UI-toggle, geen 67%-cap-implementatie. Allemaal gereserveerd voor v2.2.14+ na bron-resultaat. Onze R9.30-DNB-formule blijft ongewijzigd actief in v2.2.13.

**Hans-actie.** Bron-onderzoek-ladder afwerken; bij vondst van eenduidig antwoord §11.21-status updaten naar "bron-bevestigd, productie-actief" of "implementatie-aanpassing nodig". Bij ambiguïteit-na-bronnen: documenteer onzekerheid + behandel beide formules als parallelle interpretaties met disclaimer.

**Cross-module status.** §11.21 is M2-specifiek voor v2.2.13. M3 (§4.5 U₀-decompositie) en M4 (§5.x-projecties) gebruiken `ppk*`-input uit M2-keten en zijn daarmee mechanisch geraakt door §3.5-formule-keuze, maar bevatten geen eigen spreidings-mechaniek die separaat onderzoek vereist.

**Loskoppeling SSPF-traject.** Het 02-05-2026 SSPF-vragen-document (Hans, relatienummer xyz620620) gebruikt zijn eigen bijlage-2-modelspecificatie als illustratief instrument voor het SSPF-bestuur. Onze calculator is parallel onderzoeksinstrument, geen onderdeel van het SSPF-traject. §11.21 staat daarmee los van externe deadlines; v2.2.14+ kan op eigen onderzoeks-tempo volgen.

**Numerieke gevoeligheid.** Bandbreedte tussen R9.30-DNB en bijlage-2-lineair op individueel niveau is ~1,7-7 procentpunten opslag voor SSPF-typische 67-jarige (afhankelijk van DG en demografie); voor jongere cohorten in fondsen met actieven groter (tot tientallen procentpunten). Dominantie effect-grootte is formule-keuze, niet sterftetafel-keuze (Gompertz vs AG2024 levert <5% verschil; formule-keuze 7-25% afhankelijk van leeftijdsprofiel). De effect-asymmetrie tussen leeftijdscohorten verklaart waarom N-keuze (binnen één formule) bestuurlijk verschillende kanten op tilt voor verschillende fondstypes.

---

**Bron-resultaat-blok v3.0 (05-05-2026).** Bron-onderzoek-trap (1) afgerond met **eenduidig antwoord**: de wettelijke standaardregel uit Bijlage 2a Regeling Pw artikel 2 + 3 beschrijft een **per-kasstroom-aanpassings-formule met staircase q(h)**, zoals in de bijlage-2-modelspecificatie van Hans (drs. ing. H. Haringa, 02-05-2026). De wettekst (Stcrt 2023-17726, Stcrt 2024-42208 zoals geconsolideerd in [InView/Wolters Kluwer](https://www.inview.nl/openCitation/id4f0c9944e7fe40c98c54dc5de0e7d348/regeling-pensioenwet-en-wet-verplichte-beroepspensioenregeling-bijlage-2a)) geeft:

- **Art. 2 lid 1 (KS-aanpassing):** `KS_na(i, h) = KS_voor(i, h) · (1 + q(h) · x)` waarbij `q(h)` "een jaarlijks trapsgewijs stijgende functie" is (formule-afbeelding `stcrt-2024-42208_01.jpg`); de tekst beschrijft expliciet `[h]` als "op hele jaren neerwaarts afgeronde looptijd" en `N` als "spreidingstermijn in jaren, die gelijk is aan tien jaar". DNB-Q&A "spreidingstermijn standaardregel" (23-06-2025) en de DNB-Factsheet "Omrekenmethoden en aanwenden vermogen" (19-02-2024) bevestigen kwalitatief dat na N jaar volledig overschot wordt toegekend en gedurende N jaar gespreid (= staircase met cap 1).
- **Art. 3 (schalingsfactor):** `x = (M − P − CW_voor) / CW*` waar M het beschikbaar vermogen is en P de premieovereenkomst-waarde (in Model C: 0). Wettelijke formule en bijlage-2-modelspecificatie identiek op naam-conventie na (`x*` versus `x`).

**Conclusie bron-onderzoek.** Onze v2.x R9.30-formule (`sFactor·ν(N)` op kapitaal-niveau) is **fundamenteel anders gestructureerd** dan de wet (`(1+q·x)` op kasstroom-niveau) — niet een afgeleide vereenvoudiging maar een aparte wiskundige aanpak. De spec-claim "§3.5 R9.30-conform" was niet bron-houdbaar; "R9.30" verwijst aantoonbaar naar onze interne 21-04-2026-baseline (`21-04-2026_2216.html`), niet naar een externe DNB-bron. Trappen (2) DNB-Q&A's, (3) Pensioenfederatie, (4) AG-rapporten, (5) transitieplannen, (6) wetenschappelijke literatuur — niet meer noodzakelijk geraadpleegd nu trap (1) eenduidig antwoord gaf (stop-criterium uit oorspronkelijke v2.2.13-spec gerespecteerd).

**Implementatie-resolutie v3.0 (Optie A).** Volledige overstap naar wet-canonieke formule. Wiskundige kern via lineariteit:
```
ppk(i) = KV(i) + x_fonds · CW_star(i)            wet-canoniek (zie §3.5)
```
Numerieke uitkomst voor SSPF-anker (67M+65V+€30k OP+€21k NP, DG=1,15, vpvAftrekPct=0,10, demografie-preset 'gesloten', N=10):
- v3.0 wet-canoniek: M2 ppkTotal **€ 574.369** (Δ +5,76% t.o.v. KV € 543.096)
- v2.2.11 R9.30-legacy: M2 ppkTotal € 572.166 (Δ +5,35%)
- v3.0 N=1000 educatieve: M2 ppkTotal € 580.519 (Δ +6,89%)

Δ v3.0 vs R9.30-legacy = +€ 2.203 = **+0,4%** voor SSPF-67M-anker (klein voor SSPF-doelgroep, conform Q-D-test-bevinding "+1,73 procentpunten verschil voor 67-jarige" hierboven). Voor jongere cohorten en hogere DG kan het verschil oplopen tot 25 procentpunten (Q-D-test 52M+DG=1,35).

**Wettelijke uitwijkmogelijkheid art. 2 lid 3 Bijlage 2a:** een fonds kan een kortere spreidingstermijn hanteren (altijd toegestaan) of een langere (alleen bij DG > 100%). Onze SCHEMA accepteert `spreidingN` in [0, 1000]; UI biedt radio-keuze N=10 (wettelijke standaard) en N=1000 (proxy voor oneindige spreiding, **educatieve N=∞-vergelijking** die laat zien hoeveel van de leeftijdsongelijke verdeling specifiek aan de stylering van indexatie-blootstelling-historie toe te schrijven is — bij N=∞ wordt de verdeling bijna proportioneel aan KV).

**Behoud R9.30-legacy.** De oude formule blijft beschikbaar via `computeM2_R930_LEGACY`-export (engine.m2.ts) voor regressie-vergelijking tegen v2.2.11+12-ankers en voor audit-doeleinden. De twee formules kunnen tegelijk worden uitgevoerd op identieke input. Dit is Knelpunt G uit het v3.0-implementatie-plan; voldoet aan werkafspraak 12-eis dat oude functionaliteit niet zonder reden wordt verwijderd.

**Loskoppeling SSPF-bestuurlijke-traject.** §11.21 v3.0-resolutie blijft bewust ontkoppeld van het 02-05-2026 SSPF-vragen-document (Hans, relatienummer xyz620620). Onze calculator is parallel onderzoeksinstrument; v3.0 implementatie volgt eigen bron-houdbaarheid-tempo, niet externe deadline. Het SSPF-traject werkt met de bijlage-2-modelspecificatie als illustratief instrument; v3.0 implementeert dezelfde wettelijke formule onder onze eigen test- en kwaliteitseisen.

**Cross-module status v3.0.** §11.21-resolutie raakt M2-formule. M3 (§4.5) en M4 (§5.x) ontvangen `ppk*`-input uit M2-keten en zijn daarmee numeriek geraakt door de v3.0-formule-overstap (M2-anker schuift), maar bevatten geen eigen spreidings-mechaniek — geen separaat onderzoek nodig. v2.2.11-asymmetrie-status M3+M4 (§4.9, §5.12.3) blijft openstaand voor latere release.

---

## §12 Werkafspraken en metadata

Deze sectie legt de afspraken vast waaronder deze specificatie is geschreven en die van toepassing blijven op afgeleide documenten (SCHEMA v2, implementatie, review-rondes).

### §12.1 Taal en stijl

Nederlands, technisch-toegankelijk. Actuariële notatie (ä, q_{x,t}, φ) wordt gebruikt waar het toegevoegde waarde heeft; formules worden altijd begeleid door een inhoudelijke beschrijving. Engelstalige termen blijven in de oorspronkelijke vorm wanneer dat veldnaam of technische term is (bv. `ppkSurplus`, `annuityTo`, `curtate`).

### §12.2 Tijdstempels

Alle tijdstempels in header, versielogs en commentaren volgen het formaat `dd-mm-yyyy HH:MM` in Europe/Amsterdam. Commando: `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`. Deze spec draagt timestamp 23-04-2026 09:24 in de header (v1.1); v1 droeg 23-04-2026 00:15.

### §12.3 File-output en delen

Werkbestanden in `/home/claude/`; deliverables in `/mnt/user-data/outputs/`; delen via `present_files`. Geen code-wijzigingen in het R9-productiebestand (`21-04-2026_2216.html`) vanuit deze spec-sessie; alle voorgestelde aanpassingen worden expliciet beschreven en wachten op Hans' go.

### §12.4 Beslissingen met impact

Beslissingen die SCHEMA v2, UI-structuur of rekenuitkomsten raken worden **niet** door de engine of de specificatieschrijver genomen, maar voorgelegd aan Hans met analyse, opties en aanbeveling. Deze spec volgt dat principe: open vragen staan in §11 met een voorlopige v1-keuze die huidig R9.30-gedrag reproduceert, maar geen van deze keuzes is onomkeerbaar.

### §12.5 Spec-met-reserveringen principe

v1 van de engine reproduceert huidig R9.30-gedrag als default. Waar module 4 verfijningen voorschrijft die in modules 1-3 nog niet zijn geïmplementeerd (geslacht, generatietafel, partner, lifecycle-rente, expliciete φ), worden deze in de spec als **gereserveerd veld** met expliciete default opgenomen. Activering van een gereserveerd veld is een v2-actie en vereist:

- SCHEMA v2 wijziging (veld niet-null, met bereik-validatie);
- UI-element voor invoer/presentatie;
- unit-test dat v1-default bij lege waarde bewaart;
- documentatie-update in deze spec.

**Bewuste afwijking van dit principe in v1.5 (besluit §11.14).** De kostenopslag `ρ` krijgt in v1.5 een niet-nul default (0,02 cumulatief) die het R9.30-gedrag (ρ=0) **niet** reproduceert. Rationale: ρ=0 is niet-conservatief ("rekent rijk") en creëert een uitlegbaarheidsprobleem bij de WTP-transitie — gepensioneerden zien scherm-1-KV gevolgd door lagere uitkering op scherm 3, zonder begrijpelijke oorzaak. Publieke-communicatie-integriteit weegt hier zwaarder dan strikte reproduceerbaarheid. Dit is de enige bewuste afwijking in v1.x; alle andere beslissingen houden vast aan het principe.

### §12.6 Versionering

Deze specificatie is v1. Wijzigingen die leiden tot andere getallen of structureel ander gedrag verhogen het major-versienummer (v2, v3, ...). Aanvullingen die backward-compatible zijn (nieuwe velden met defaults, verduidelijkingen, reviewpunt-resoluties) verhogen alleen patch-nummer (v1.1, v1.2). Deze spec is het normatieve anker waaraan SCHEMA v2 en toekomstige implementatie-iteraties getoetst worden.

### §12.7 Succescriteria voor deze spec

Deze spec is succesvol als:

1. Hans alle vier modules herkent en de onderlinge relaties kan uitleggen zonder terug te hoeven naar `ARCHITECTUUR_v1.md`, `DESIGN_engine_v0.md` of `calculator_specificatie.docx`.
2. Op basis van deze spec SCHEMA v2 geschreven kan worden zonder nieuwe inhoudelijke beslissingen (alle beslispunten staan in §11).
3. Een externe reviewer (actuaris, jurist, IT-auditor) kan per module beoordelen of de gekozen benadering adequaat is voor de betreffende discipline.
4. Een implementator kan per module de benodigde inputs, outputs, formules, aannames en validaties rechtstreeks afleiden zonder aanvullende context.

---

*Einde ENGINE_SPECIFICATIE_v1.md*
