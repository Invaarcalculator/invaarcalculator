/**
 * Verificatie: ABN-vergelijking met productie-engine v3.0.129.
 *
 * Berekent voor leeftijden 65/75/85/95, bij DG=135%, geen partner, SSPF-defaults
 * voor overige parameters, de opslag (ppkTotal - KV) / KV onder:
 *   - N = 10  (wettelijke default, identiek aan ABN-keuze)
 *   - N = 1000 (proxy levenslang, SSPF-keuze conform impl.plan §5.6)
 *
 * Doel: produceer een ABN-vergelijkingstabel met de werkelijke productie-engine,
 * ter vervanging van de Bijlage-2-model-tabel uit de SSPF-vragenbrief.
 *
 * Productie-engine bevat (in tegenstelling tot Bijlage-2-vereenvoudigd model):
 *   - AG2024-prognosetafel per geslacht
 *   - Cascade-aftrek 6,7% (dynamisch berekend uit cascadeOverrides)
 *   - SSPF-gesloten cohort-preset 25k deelnemers
 *   - Arrears m=12 maandbetalingen
 *   - Bijstort €500 mln SSPF-keuze (DG≥135%)
 *
 * Belangrijke keuze: heeftPartner=false. ABN publieke cijfers zijn cohort-
 * gemiddelden zonder partner-specifieke split; voor eerlijke vergelijking
 * draaien we OP-only.
 */
import { FONDS } from './fondsen/sspf/fonds.config'
import * as fs from 'fs'
import * as path from 'path'

const ag2024Data = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'ag2024.json'), 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag2024Data }

import { computeM1 } from './src/engine.m1'
import { computeM2 } from './src/engine.m2'
import { M1, M2 } from './src/schema.v2'

function dobForExactAge(years: number, peildatum: string): string {
  const peil = new Date(peildatum)
  const dob = new Date(peil)
  dob.setFullYear(peil.getFullYear() - years)
  return dob.toISOString().slice(0, 10)
}

const PEILDATUM = new Date().toISOString().slice(0, 10)

function computeOpslag(leeftijd: number, spreidingN: number, dekkingsgraad: number, metPartner: boolean): {
  opslag: number, KV: number, ppkTotal: number, KV_NP: number,
} {
  // Partner-aanname (consistent met modelspec §9 cohort-proxy): 3 jaar jonger, vrouw, y0 = 70% van pen
  const partnerAge = metPartner ? leeftijd - 3 : null
  const deelnemer = {
    x0: leeftijd,
    pen: 100000,
    g: 'M' as const,
    heeftPartner: metPartner,
    y0: metPartner ? 70000 : null,
    x_partner: partnerAge,
    g_y: 'V' as const,
    dob: dobForExactAge(leeftijd, PEILDATUM),
    dob_partner: metPartner ? dobForExactAge(partnerAge!, PEILDATUM) : null,
    hooglaagActief: false,
    pen_laag: null,
    x_knip: null,
    dob_knip: null,
  }

  const p1 = M1.parameterset.parse({ ...FONDS.m1 })
  const m2Raw = { ...FONDS.m2 }
  // Cascade-aggregatie (zoals ui.app.ts:287)
  const cascade = FONDS.aanwendingsCascade
  const vpvForCascade = m2Raw.vpvTotal > 0 ? m2Raw.vpvTotal : m2Raw.fondsvermogen / m2Raw.dekkingsgraad
  m2Raw.vpvAftrekPct = cascade.wettelijkeReservesPct + (cascade.rdrBedrag + cascade.compensatiedepotBedrag) / vpvForCascade
  // Overrides voor scenario
  m2Raw.dekkingsgraad = dekkingsgraad
  m2Raw.spreidingN = spreidingN
  const p2 = M2.parameterset.parse(m2Raw)
  const d = M1.deelnemer.parse(deelnemer)

  const m1Out = computeM1(d, p1, { spreidingN: p2.spreidingN })
  const k = M2.ketenInput.parse({
    KV: m1Out.KV,
    KV_OP: m1Out.KV_OP,
    KV_NP: m1Out.KV_NP,
    cw_star_op: m1Out.cw_star_op ?? 0,
    cw_star_np: m1Out.cw_star_np ?? 0,
  })
  const m2Out = computeM2(d, k, p2)

  const opslag = (m2Out.ppkTotal - m1Out.KV) / m1Out.KV
  return { opslag, KV: m1Out.KV, ppkTotal: m2Out.ppkTotal, KV_NP: m1Out.KV_NP }
}

console.log('ABN-vergelijking — productie-engine v3.0.129')
console.log('Scenario-basis: man, pen=€100.000, DG=135%, bijstort €500mln, cascade 6,71%')
console.log('SSPF-defaults: AG2024-M, r=2,5%, f=0,90, m=12, demografie "gesloten"')
console.log('')
console.log('=== Tabel A — OP-only (vergelijkbaar met ABN-publieke cohort-cijfers) ===')
console.log('')
console.log('| Leeftijd | ABN N=10 (publiek) | SSPF N=10 (engine) | SSPF N=1000 (engine, SSPF-keuze) | Δ (N=10 → N=1000) |')
console.log('|---|---|---|---|---|')

const abnPublic: Record<number, number> = { 65: 24, 75: 20, 85: 17, 95: 12 }
const leeftijden = [65, 75, 85, 95]

for (const leeftijd of leeftijden) {
  const n10 = computeOpslag(leeftijd, 10, 1.35, false)
  const n1000 = computeOpslag(leeftijd, 1000, 1.35, false)
  const abn = abnPublic[leeftijd]
  const delta = (n1000.opslag - n10.opslag) * 100
  const fmt = (x: number) => (x * 100).toFixed(1) + '%'
  console.log(`| ${leeftijd} jaar | ${abn}% | +${fmt(n10.opslag)} | +${fmt(n1000.opslag)} | ${delta >= 0 ? '+' : ''}${delta.toFixed(1)} pp |`)
}

console.log('')
console.log('=== Tabel B — OP+PP met partner (y0=€70.000, vrouw 3j jonger dan deelnemer) ===')
console.log('')
console.log('| Leeftijd | Partner-leeftijd | SSPF N=10 (engine) | SSPF N=1000 (engine, SSPF-keuze) | Δ (N=10 → N=1000) |')
console.log('|---|---|---|---|---|')

for (const leeftijd of leeftijden) {
  const n10 = computeOpslag(leeftijd, 10, 1.35, true)
  const n1000 = computeOpslag(leeftijd, 1000, 1.35, true)
  const delta = (n1000.opslag - n10.opslag) * 100
  const fmt = (x: number) => (x * 100).toFixed(1) + '%'
  console.log(`| ${leeftijd} jaar | ${leeftijd - 3} jaar V | +${fmt(n10.opslag)} | +${fmt(n1000.opslag)} | ${delta >= 0 ? '+' : ''}${delta.toFixed(1)} pp |`)
}

console.log('')
console.log('=== Debug-cijfers ===')
console.log('')
console.log('OP-only:')
for (const leeftijd of leeftijden) {
  const n10 = computeOpslag(leeftijd, 10, 1.35, false)
  const n1000 = computeOpslag(leeftijd, 1000, 1.35, false)
  console.log(`  ${leeftijd}j: KV=€${Math.round(n10.KV).toLocaleString('nl-NL')} (KV_NP=€${Math.round(n10.KV_NP).toLocaleString('nl-NL')}), N=10 ppkTotal=€${Math.round(n10.ppkTotal).toLocaleString('nl-NL')}, N=1000 ppkTotal=€${Math.round(n1000.ppkTotal).toLocaleString('nl-NL')}`)
}
console.log('')
console.log('OP+PP:')
for (const leeftijd of leeftijden) {
  const n10 = computeOpslag(leeftijd, 10, 1.35, true)
  const n1000 = computeOpslag(leeftijd, 1000, 1.35, true)
  console.log(`  ${leeftijd}j (partner ${leeftijd - 3}V): KV=€${Math.round(n10.KV).toLocaleString('nl-NL')} (KV_NP=€${Math.round(n10.KV_NP).toLocaleString('nl-NL')}), N=10 ppkTotal=€${Math.round(n10.ppkTotal).toLocaleString('nl-NL')}, N=1000 ppkTotal=€${Math.round(n1000.ppkTotal).toLocaleString('nl-NL')}`)
}
