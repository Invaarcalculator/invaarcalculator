# HANDOFF v3.0.37 — Invaarcalculator® release-klaar (engine-bug-fix)

**Datum:** Do 7 mei 2026
**Versie:** v3.0.37
**Status:** Release-klaar, ENGINE-BUG GEFIXT
**Werkdir:** `/home/claude/Keep-14/`

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip:
  unzip /mnt/user-data/outputs/Keep-14_v3.0.37_complete.zip -d /home/claude/

Build calculator naar /mnt/user-data/outputs/calculator.html:
  cd /home/claude/Keep-14 && npx tsx build.calc.ts

Volledige regression-suite:
  npx tsx test_browser_calc.ts        # 8/8 ✓ verwacht
  npx tsx src/test_engine.m2.ts        # M1+M2 sluitingscontroles
  npx tsx test_v3_cascade.ts           # 3 cascade-ankers
  npx tsx test_hans_replication.ts     # Hans-tabel replicatie
```

**Werkafspraken:**
- Stap-voor-stap, één wijziging per turn (Werkafspraak 12)
- Alle SSPF-parameter-wijzigingen voorzien van bron-citaat in `fondsdataset.ts`
- Engine-baseline ankers verschoven door v3.0.37 fix; nieuwe ankers in §3
- "Persoonlijk pensioenvermogen" canonical in UI; geen "potje"
- UI fonds-agnostisch in publieke tekst; SSPF expliciet alleen in `fondsdataset.ts` comments
- **HANDOFF altijd in werkdir én zip** (Werkafspraak 13, 06-05-2026):
  Schrijf HANDOFF_vX.Y.Z.md ALTIJD eerst naar `/home/claude/Keep-14/HANDOFF_vX.Y.Z.md`,
  daarna kopiëren naar `/mnt/user-data/outputs/`. Bij het zippen wordt de werkdir
  ingepakt — als HANDOFF alleen in /outputs/ staat zit hij NIET in de zip-restore.
  Volgende sessie heeft dan geen handover bij unzip.

---

## 2. v3.0.37 — TWEE BUG-FIXES

**Aanleiding:** Hans observeerde dat onze engine bij N=∞ HOGER PPV gaf dan bij N=10 voor 70-jarige (€678.402 vs €651.122) — tegengesteld aan eigen modeldoorrekening (Bijlage 1 van notitie 02-05-2026: -5,3% bij DG=135%).

### Fix 1: cwStarProfile shift voor age<65

**Bug:** voor actief proxy-cohort (age<65) werd q "gereset" op pensioneringsmoment via `annuityWithQ(65, N_eff = N - (65-age))`. Wettelijk onjuist — Bijlage 2a Pw art. 2 meet h vanaf invaarmoment, niet vanaf pensionering.

**Fix:** nieuwe helper `annuityWithQShifted(x, ..., shift)` in `engine.m1.ts`. q wordt nu gemeten op globale tijdsas (h_global = t + shift). Voor 27-jarige bij N=∞: ratio cw_star/kv 0,011 → 0,050 (factor 5× hoger, correct).

**Locatie:** `src/engine.m1.ts` regel ~252 (nieuwe helper), `src/engine.m2.ts` regel ~327 (cwStarProfile aanroep).

### Fix 2: NP-component in fonds-proxy

**Bug:** `computeFondsXStar` berekende `cw_voor_proxy` en `cw_star_proxy` alleen voor OP-component, terwijl individu OP+NP kreeg. Dimensieconflict: `vpvTotal` is fondsbreed (omvat alle aanspraken inclusief NP), maar `ratio` was OP-only.

**Inzicht (Hans):** er wordt ÉÉN persoonlijk pensioenvermogen ingevaren per persoon, niet OP en NP apart. Fonds-noemer moet daarom NP omvatten.

**Fix:** proxy-cohort-loop in `computeFondsXStar` includeert nu NP-component via `jointLifeAnnuity` + `jointLifeAnnuityWithQ`. Aanname: 100% gehuwd, partner 3j jonger, ander geslacht, NP-aandeel 0,7 (typisch UPO). **Geen partnerFRACTIE-aanname nodig** — gaat om tijd-structuur, niet om hoeveel mensen partner hebben.

**Locatie:** `src/engine.m2.ts` regel ~395-428 (computeFondsXStar uitbreiding).

### Resultaat Hans-replicatie (uniform demografie, DG=1.35, aftrek=0.10)

| Leeftijd | Verschil onze engine | Hans verwacht | Status |
|---|---|---|---|
| 30 | +4,2pp | +40,5pp | ✓ richting, magnitude lager (geen 67%-randvoorwaarde) |
| 40 | +1,4pp | +27,0pp | ✓ richting |
| 50 | -2,4pp | +12,0pp | ✗ richting (overgangsgebied) |
| 60 | -5,7pp | -1,7pp | ✓ |
| 65 | -7,0pp | -4,5pp | ✓ |
| 70 | -7,8pp | -5,3pp | ✓ |
| 75 | -7,9pp | -6,0pp | ✓ |
| 80 | -7,1pp | -6,2pp | ✓ |
| 85 | -5,8pp | -5,9pp | ✓ |
| 90 | -4,3pp | -5,2pp | ✓ |

7/10 ✓ (richting + binnen 5pp). Pensioengerechtigden 60-90 alle 7 correct. Jongere cohorten 30-50 hebben kleinere magnitude dan Hans — verklaring: 67%-randvoorwaarde (art. 150n lid 4 Pw) niet gemodelleerd in onze engine, maar wordt in werkelijkheid wél door fondsen toegepast.

### SSPF-realistische scenario's (gesloten demografie, 6% aftrek, DG=1.35)

| Casus | N=10 | N=∞ | Verschil |
|---|---|---|---|
| **UI-default 70M+65V+€21k NP** | **29,4%** | **29,4%** | **0,0pp** |
| 70M alleen | 26,3% | 23,1% | -3,2pp ✓ |
| 75M+70V | 27,2% | 24,6% | -2,6pp ✓ |
| 80M+78V | 22,9% | 17,9% | -4,9pp ✓ |
| 50M+47V | 33,7% | 47,4% | +13,7pp |

UI-default casus: 0pp verschil. Bij gesloten fonds is 70-jarige relatief mediaan; effect klein maar wel correct teken.

---

## 3. Numerieke ankers

### UI-default-ankers (na v3.0.37)

**Input:** x0=70, M, partner V x_partner=65, OP €30k, NP €21k, DG=1.35, r=2.5%, aftrek=6%, spreiding=∞

| KPI | Waarde |
|---|---|
| **KV M1** | € 490.091 |
| **PPV M2** | € 624.875 |

(Was vóór v3.0.37: € 678.402 — daling van €53.527 door bug-fix.)

### Engine-baseline-ankers (regression, na v3.0.37)

`test_v3_cascade.ts` (x0=67, DG=1.15, r=0.02, aftrek=0.10, partner V 65j NP €21k):

| Anker | Waarde |
|---|---|
| KV (M1) | € 543.096 |
| ppkTotal v3.0 N=10 | € 569.457 |
| ppkTotal v3.0 N=∞ | € 569.889 |
| ppkTotal R9.30-legacy | € 572.166 (ongewijzigd) |

`test_engine.m2.ts` (x0=67 zonder partner, DG=1.15, aftrek=0.10, N=10):

| Anker | Waarde |
|---|---|
| ppkBase (= KV) | € 421.306 |
| ppkSurplus | € 33.843 |
| ppkTotal | € 455.149 |
| Onderdekking DG=0.85 | € 347.534 |

---

## 4. SSPF-parameterset (eind v3.0.37)

`src/fondsdataset.ts` SSPF_M1_PLACEHOLDER + SSPF_M2_PLACEHOLDER:

| Parameter | Waarde | Bron |
|---|---|---|
| `r` | 0.025 (2,5%) | SSPF-presentatie 14-04-2026, DNB UFR-curve eind 2025 |
| `fondsvermogen` | 26.000 mln € | SSPF-presentatie 14-04-2026 |
| `dekkingsgraad` | 1.35 | Website 31-03-2026 + presentatie eind 2025 |
| `vpvAftrekPct` | 0.06 | Implementatieplan 15-07-2025 §5 |
| `spreidingN` | 1000 | Implementatieplan 15-07-2025 §5.6 (levenslang) |
| `N_deelnemers` | 26.000 | Presentatie 14-04-2026 deelnemersbestand |
| Demografie | preset:'gesloten' | Geaccepteerd als proxy |
| `compensatiedepot` | 0 | Bewust nul |
| `compensatieMu/Sigma` | 55/8 | Numeriek inert |
| `ervaringsSterfte` | 1.0 | Numeriek inert |

**NP-proxy-aanname (v3.0.37, hardcoded in `engine.m2.ts`):** elk proxy-cohort krijgt fictieve partner 3j jonger, ander geslacht, NP-aandeel 0,7.

---

## 5. UI-architectuur eind v3.0.37 (= v3.0.36 layout)

```
Invaarcalculator®                          [Uitleg]

┌─ Mijn pensioenfonds ─────────────────────┐
│  ⦿ SSPF        ◯ Fonds 2                 │
└──────────────────────────────────────────┘

┌─ Uw huidige aanspraak (rood) ────────────┐
│  Sliders + KPI met sub-blokken           │
└──────────────────────────────────────────┘

┌─ Uw persoonlijk pensioenvermogen (groen)─┐
│  Sliders DG/aftrek/spreidings-radio      │
└──────────────────────────────────────────┘

Vragen of opmerkingen: hans@invaarcalculator.nl · Disclaimer
Release 3.0.37 · 07-05-2026 · CC BY-NC 4.0 · Innovation Nestor
```

---

## 6. Modules-overzicht (v3.0.37)

| Bestand | Functie | Wijziging v3.0.37 |
|---|---|---|
| `src/engine.m1.ts` | Joint-life NP, annuityWithQ | + `annuityWithQShifted` |
| `src/engine.m2.ts` | Wet-canoniek v3.0 | `cwStarProfile` shift-fix + NP-proxy |
| `schema.v2.ts` | Zod-SCHEMA + FIELD_REGISTRY | Geen |
| `src/ui.shared.ts` | Pure helpers | Geen |
| `src/ui.m1.ts` | Standalone scherm 1 (legacy) | Geen |
| `src/ui.m2.ts` | renderM2KPI/Sliders/Audit | Geen |
| `src/ui.app.ts` | Gebundelde calculator | RELEASE_VERSION → 3.0.37 |
| `src/fondsdataset.ts` | SSPF + FONDSEN-registry | Header-doc v3.0.37 |
| `build.calc.ts` | HTML-template + CSS | Geen |
| `test_hans_replication.ts` | Hans-tabel replicatie | NIEUW |

---

## 7. Tests-status v3.0.37

| Test | Status |
|---|---|
| `test_browser_calc.ts` | 8/8 ✓ (M2-anker bijgewerkt naar €624.875) |
| `src/test_engine.m2.ts` | Sluitingen 0,000e+0 ✓ |
| `test_v3_cascade.ts` | R9.30-legacy €572.166 ✓ |
| `test_smoke.ts` | 17 SCHEMA-smoke ✓ |
| `test_ui_spreidingN.ts` | 7 UI-tests ✓ |
| `test_cw_star.ts` | 4 cw_star-tests ✓ |
| `test_hans_replication.ts` | 7/10 ✓ (60-90 alle ✓; richting alle 10 ✓) |

---

## 8. M1 BEPERKING (toekomstige fix)

Voor actieve deelnemer (x0<65) berekent M1 KV via `annuity(x0, ...)` zonder pre-pensioen-shift. KV wordt overschat (50-jarige met pen=€30k krijgt KV ≈ €663k ipv ~€350k juist).

**Niet relevant voor publieke tool** — slider-min x0=69. Wel iets om bij M3/M4-uitbreiding te fixen.

---

## 9. Open punten / volgende sessie

| # | Onderwerp | Status | Prioriteit |
|---|---|---|---|
| 1 | **Hosting-deployment naar invaarcalculator.nl** | Hans's keuze | **Hoog** |
| 2 | "Fonds 2" met echte ABN-data invullen | UI-mechaniek staat | Middel |
| 3 | Cosmetisch: aftrek-stand "6.0%" → "6,0%" | Bekend | Laag |
| 4 | iPad-issue (HTML opent niet) | Onbekend | Onbekend |
| 5 | M1 KV-fix actieve deelnemer (pre-pensioen-shift) | Niet relevant publiek | Strategisch |
| 6 | 67%-randvoorwaarde art. 150n lid 4 Pw modelleren | Onbekend | Strategisch |
| 7 | M3 (uitkeringsfase, Monte Carlo) | Latere release | Strategisch |
| 8 | M4 (DB vs WTP-regime-vergelijking) | Latere release | Strategisch |

---

## 10. Outputs in /mnt/user-data/outputs/

- `calculator.html` (235 KB) — single-file calculator
- `Keep-14_v3.0.37_complete.zip` (24 MB) — volledige werkdir-restore
- `HANDOFF_v3.0.37.md` (dit bestand)

**Restore:**
```bash
unzip /mnt/user-data/outputs/Keep-14_v3.0.37_complete.zip -d /home/claude/
cd /home/claude/Keep-14
npx tsx build.calc.ts
npx tsx test_browser_calc.ts | grep -c ✓   # → 8
npx tsx test_hans_replication.ts            # → 7/10 (60-90 alle ✓)
```
