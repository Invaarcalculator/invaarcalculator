#!/usr/bin/env node
/**
 * Build calculator.html — single-file artefact met scherm 1 + scherm 2 (M1+M2).
 *
 * Pendant van build.ts (M1-only scherm1.html). Hergebruikt esbuild-bundle-flow.
 *
 * Verschillen vs build.ts:
 *   - entry: src/ui.app.ts (orkestratie M1+M2) i.p.v. src/ui.m1.ts
 *   - bundle bevat extra: engine.m2 + ui.m2 + M2-block schema + M2-fondsdataset
 *   - HTML-template uitgebreid met M2-CSS (KPI-M2, M2-controls, modtag, cohort-table)
 *   - title + subtitle aangepast naar M1+M2
 */

import * as esbuild from 'esbuild'
import * as fs from 'fs'
import * as path from 'path'

const BUILD_DIR = '/home/claude/Keep-14'
// v3.0.128: OUT_HTML met versienummer in filename (`calculator_v3.0.x.html`).
// Definitie verplaatst naar binnen build() omdat het versienummer pas
// beschikbaar is ná extractie uit src/ui.app.ts (regel ~46).

// v3.0.76: build-time-fondsinjectie. Welk fonds wordt gebouwd kies je via
// --fonds=<id>. Default 'sspf'. De alias '~fonds' in fondsdataset.ts wordt
// door esbuild vervangen door /fondsen/<id>/fonds.config.ts.
function parseFondsArg(): string {
  const arg = process.argv.find((a) => a.startsWith('--fonds='))
  return arg ? arg.slice('--fonds='.length) : 'sspf'
}
const FONDS_ID = parseFondsArg()
const FONDS_CONFIG_PATH = path.join(BUILD_DIR, `fondsen/${FONDS_ID}/fonds.config.ts`)
if (!fs.existsSync(FONDS_CONFIG_PATH)) {
  throw new Error(`Fonds-config niet gevonden: ${FONDS_CONFIG_PATH}\nGebruik --fonds=<id> waarbij <id> een map onder /fondsen/ is.`)
}

async function build(): Promise<void> {
  console.log('=== Build calculator.html (M1 + M2 gebundeld) ===\n')
  console.log(`  Fonds: ${FONDS_ID} (${FONDS_CONFIG_PATH})\n`)

  // v3.0.108: extract RELEASE_VERSION uit ui.app.ts voor CSS-injectie van de
  // print-rapport @page-footers. Bron-van-waarheid blijft de constante in
  // ui.app.ts (Werkafspraak 16 bump-anchor); build leest hem alleen.
  const uiAppSource = fs.readFileSync(path.join(BUILD_DIR, 'src/ui.app.ts'), 'utf-8')
  const versionMatch = uiAppSource.match(/const RELEASE_VERSION\s*=\s*'([^']+)'/)
  if (!versionMatch) {
    throw new Error('Kan RELEASE_VERSION niet vinden in src/ui.app.ts (verwachte vorm: const RELEASE_VERSION = \'x.y.z\')')
  }
  const releaseVersion = versionMatch[1]
  console.log(`  Release: v${releaseVersion}\n`)

  // v3.0.128: OUT_HTML met versienummer voor herkenbare downloads
  // (`calculator_v3.0.127.html`). Vergemakkelijkt versie-archivering en
  // herkenning bij "download all"-bundels in de chat-interface.
  const OUT_HTML = `/mnt/user-data/outputs/calculator_v${releaseVersion}.html`

  // v3.0.102: lees fonds.label voor template-substitutie in topline + title.
  // v3.0.103: ook fonds.shortLabel voor compacte UI-contexten ("Voor wie
  // SSPF-pensioen ontvangt"). Fallback naar 'het fonds' als shortLabel niet
  // gezet is.
  // Dynamic import van .ts-file werkt via tsx (die we al gebruiken om dit
  // build-script te runnen).
  const fondsModule = (await import(FONDS_CONFIG_PATH)) as { FONDS: { label: string; shortLabel?: string } }
  const fondsLabel = fondsModule.FONDS.label
  const fondsShort = fondsModule.FONDS.shortLabel ?? 'het fonds'

  // 1. Bundle ui.app.ts + alle deps
  console.log('[1/4] Bundel TypeScript via esbuild (entry: ui.app.ts)...')
  // v3.0.38: stempel bouwdatum (dd-mm-yyyy) in bundle via esbuild define.
  // Vervangt de hardcoded RELEASE_DATE-constante in ui.app.ts.
  const today = new Date()
  const dd = String(today.getDate()).padStart(2, '0')
  const mm = String(today.getMonth() + 1).padStart(2, '0')
  const yyyy = today.getFullYear()
  const buildDate = `${dd}-${mm}-${yyyy}`
  const result = await esbuild.build({
    entryPoints: [path.join(BUILD_DIR, 'src/ui.app.ts')],
    bundle: true,
    format: 'iife',
    platform: 'browser',
    target: 'es2020',
    minify: true,
    write: false,
    logLevel: 'warning',
    define: {
      __BUILD_DATE__: JSON.stringify(buildDate),
    },
    // v3.0.76: alias ~fonds → de gekozen fonds-config.
    alias: {
      '~fonds': FONDS_CONFIG_PATH,
    },
  })
  const bundle = result.outputFiles[0].text
  console.log(`  Bundle: ${(bundle.length / 1024).toFixed(1)} KB (minified), build-date: ${buildDate}`)

  // 2. AG2024
  console.log('[2/4] Lees AG2024 data...')
  const ag2024 = fs.readFileSync(path.join(BUILD_DIR, 'ag2024.json'), 'utf-8')
  console.log(`  AG2024: ${(ag2024.length / 1024).toFixed(1)} KB`)

  // 2b. Modelspecificatie-PDF (v3.0.107: bijlage 2 — actuariële modelspecificatie)
  // Base64-encodeer en injecteer als window.__MODELSPEC_PDF__ voor de
  // "Modelspecificatie"-knop. Bestand wordt extern gegenereerd via pdfLaTeX
  // (zie BIJLAGE2_MODELSPECIFICATIE_*.tex naast deze build); de PDF moet als
  // `modelspecificatie.pdf` in BUILD_DIR staan. Bij ontbreken: build faalt
  // hard (geen stille fallback — versie-mismatch is risico).
  console.log('[2b/4] Lees modelspecificatie-PDF...')
  const pdfPath = path.join(BUILD_DIR, 'modelspecificatie.pdf')
  if (!fs.existsSync(pdfPath)) {
    throw new Error(`Modelspecificatie-PDF ontbreekt op ${pdfPath}. Run pdflatex op de .tex en plaats het resultaat hier.`)
  }
  const pdfBuffer = fs.readFileSync(pdfPath)
  const pdfBase64 = pdfBuffer.toString('base64')
  console.log(`  PDF: ${(pdfBuffer.length / 1024).toFixed(1)} KB raw → ${(pdfBase64.length / 1024).toFixed(1)} KB base64`)

  // 3. HTML-template
  console.log('[3/4] Wrap in HTML-template...')
  const html = `<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Invaarcalculator® · Voor wie ${fondsShort}-pensioen ontvangt na de AOW-leeftijd</title>
<style>
  /* ─── Reset ─────────────────────────────────────────────────── */
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  button { font: inherit; color: inherit; }

  /* ─── Design tokens (overgenomen uit invaarcalculator.nl 21-04-2026) ── */
  :root {
    --bg:    #f4f4f2;
    --card:  #fff;
    --surf:  #f0efed;
    --txt1:  #1a1a1a;
    --txt2:  #6b7280;
    --bdr:   rgba(0,0,0,0.10);
    --bdr2:  rgba(0,0,0,0.18);
    --red:   #D4001A;
    --blue:  #1a6db5;
    --green: #1a8a45;
    --amber: #C07A00;
    --r6:  6px;
    --r8:  8px;
    --r12: 12px;
    /* v3.0.91: numerieke font-size tokens — 3-laags schaal voor alle getal-
       renderingen in de UI. Vervangt 9-tal verschillende sizes (10/11/12/13/
       15/18/22/26-mobile/32). Type-ratio 28/16/12 = 1,75× / 1,33×.
         --num-l : anker-waarden (M1 KV, M2 ppkTotal) — gelijk-prominent
         --num-m : sub-aggregaten (formule-componenten, KV-decompositie, cascade-totaal)
         --num-s : detail (cascade-rijen, tabel-cellen, footer, mod-tags, slider-markers) */
    --num-l: 28px;
    --num-m: 16px;
    --num-s: 12px;
  }

  /* ─── Base ──────────────────────────────────────────────────── */
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 14px;
    color: var(--txt1);
    background: var(--bg);
    min-height: 100vh;
    padding: 24px 16px 48px;
    line-height: 1.45;
  }
  .wrap, body > .topline, body > #app, body > footer {
    max-width: 960px;
    margin-left: auto;
    margin-right: auto;
  }
  body > .topline h1,
  body > h1 {
    font-size: 18px;
    font-weight: 600;
  }
  body > h1 { margin-bottom: 14px; }

  h2 {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 6px;
    color: var(--txt1);
  }
  h3 {
    font-size: 13px;
    font-weight: 600;
    color: var(--txt1);
    margin-top: 14px;
    margin-bottom: 8px;
  }
  p { font-size: 13px; color: var(--txt2); line-height: 1.55; }
  a { color: var(--blue); }

  /* ─── View-toggle (zichtbaar wanneer audit unlocked) ────────── */
  .view-toggle {
    display: flex;
    gap: 8px;
    margin-bottom: 14px;
  }
  .view-toggle button {
    flex: 1;
    padding: 8px 14px;
    border: 0.5px solid var(--bdr2);
    background: var(--card);
    cursor: pointer;
    border-radius: var(--r8);
    font-size: 13px;
    color: var(--txt1);
  }
  .view-toggle button.active {
    background: var(--txt1);
    color: #fff;
    border-color: var(--txt1);
  }

  /* ─── Pane = Card ───────────────────────────────────────────── */
  .pane {
    background: var(--card);
    border: 0.5px solid var(--bdr);
    border-radius: var(--r12);
    padding: 18px 20px;
    margin-bottom: 14px;
  }
  .pane.casual.pane-m1 { border-left: 3px solid var(--green); }
  .pane.casual.pane-m2 { border-left: 3px solid var(--red); }
  .pane.casual.pane-m12 { border-left: 3px solid var(--amber); }
  .pane.audit          { border-left: 3px solid var(--amber); }

  /* v3.0.79: M1/2-pane "Wat is er te verdelen?" — cascade-tabel met inline
     sliders, afwijking-markers, reset-knop. */
  .pane-m12 .m12-intro {
    color: var(--txt2);
    font-size: 12px;
    line-height: 1.4;
    margin: 0 0 12px 0;
  }
  .cascade-table {
    display: flex;
    flex-direction: column;
    gap: 10px;
    /* v3.0.115: margin-bottom: 14px verwijderd — niks onder cascade-table
       in pane-m12, pane-padding alleen al geeft genoeg lucht naar de bottom. */
  }
  .cascade-row {
    display: grid;
    grid-template-columns: 1fr auto;
    grid-template-rows: auto auto auto;
    gap: 4px 12px;
    align-items: baseline;
    padding-bottom: 8px;
    border-bottom: 0.5px dashed var(--bdr);
  }
  .cascade-row .cascade-label {
    grid-column: 1;
    grid-row: 1;
    font-size: 12px;
    color: var(--txt2);
    text-transform: uppercase;
    letter-spacing: 0.4px;
  }
  .cascade-row .cascade-val {
    grid-column: 2;
    grid-row: 1;
    text-align: right;
    font-size: var(--num-s);
  }
  .cascade-row .cascade-slider {
    grid-column: 1 / span 2;
    grid-row: 2;
    width: 100%;
  }
  /* v3.0.84: begin/eind-waardes onder cascade-sliders */
  .cascade-row .cascade-markers {
    grid-column: 1 / span 2;
    grid-row: 3;
    display: flex;
    justify-content: space-between;
    font-size: var(--num-s);
    color: var(--txt2);
    margin-top: 2px;
  }
  /* v3.0.84: cascade-context rij (DG) — geen plus/minus, contextuele
     parameter; visueel wat gedempter dan input-rij. */
  .cascade-context .cascade-label {
    color: var(--txt2);
  }
  .cascade-subtotal,
  .cascade-total {
    border-bottom: none;
    border-top: 0.5px solid var(--txt2);
    padding-top: 6px;
    margin-top: 2px;
  }
  /* v3.0.115: cascade-total is altijd de laatste rij; padding-bottom (8px
     uit .cascade-row) verwijderen scheelt witruimte boven de pane-bottom. */
  .cascade-total {
    padding-bottom: 0;
  }
  .cascade-total {
    border-top: 1px solid var(--txt1);
  }
  .cascade-total .cascade-label {
    color: var(--txt1);
  }
  /* v3.0.82: cascade-getallen amber, consistent met M1=groen / M2=rood */
  .pane-m12 .cascade-val strong {
    color: var(--amber);
  }
  .cascade-total .cascade-val strong {
    font-size: var(--num-m);
  }
  /* v3.0.83: tekort (negatief overschot) krijgt rood — bij DG ≤ 100% of
     bij negatief verdeelbaar overschot na reserves. */
  .pane-m12 .cascade-negatief .cascade-val strong {
    color: var(--red);
  }
  .pane-m12 .cascade-negatief .cascade-label {
    color: var(--red);
  }
  .afwijk-marker {
    display: inline-block;
    color: var(--amber);
    font-size: 14px;
    line-height: 1;
    margin: 0 4px;
    cursor: help;
  }
  .pane-afwijk-banner {
    display: inline-block;
    background: var(--amber);
    color: white;
    font-size: 11px;
    line-height: 14px;
    padding: 2px 10px;
    border-radius: var(--r6);
    margin-left: 8px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    vertical-align: middle;
    min-width: 6em;
    text-align: center;
  }
  /* v3.0.101: Reset-knop naast Bewerkt-marker in pane-header; identieke
     compacte pill-styling als de banner (zelfde padding/line-height/min-width)
     maar inverse kleuren — banner = amber bg + white tekst, reset = card bg +
     txt1 tekst. Beide visueel even hoog en even breed. */
  .reset-cascade-btn {
    display: inline-block;
    background: var(--card);
    color: var(--txt1);
    border: 1px solid var(--bdr);
    border-radius: var(--r6);
    font: inherit;
    font-size: 11px;
    line-height: 14px;
    padding: 2px 10px;
    margin-left: 8px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    vertical-align: middle;
    min-width: 6em;
    text-align: center;
    cursor: pointer;
  }
  .reset-cascade-btn:hover {
    border-color: var(--txt1);
    background: var(--surf);
  }

  /* v3.0.34: fondskeuze-radios — naast elkaar, klikbare hele label */
  .fonds-radios {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: 6px;
  }
  .fonds-radio {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 14px;
    border: 0.5px solid var(--bdr2);
    border-radius: var(--r8);
    cursor: pointer;
    background: var(--card);
    font-size: 13px;
    user-select: none;
  }
  .fonds-radio:hover { background: var(--surf); }
  .fonds-radio:has(input:checked) {
    background: var(--surf);
    border-color: var(--txt1);
    font-weight: 600;
  }
  /* v3.0.38: wrapper houdt fonds-radio + ?-knop visueel bij elkaar zonder dat
     klik op ? de radio toggelt (help-icon staat buiten het <label>). */
  .fonds-radio-row {
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  /* v3.0.47: bij één fonds geen radios maar fondsnaam + ?-knop */
  .fonds-single {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .fonds-single .fonds-name {
    font-weight: 600;
    color: var(--txt1);
  }

  .intro {
    color: var(--txt2);
    font-size: 13px;
    margin-bottom: 14px;
    line-height: 1.55;
  }

  /* ─── Form fields ───────────────────────────────────────────── */
  .form { margin-bottom: 14px; }
  .field {
    display: grid;
    grid-template-columns: 220px 1fr;
    column-gap: 14px;
    align-items: center;
    padding: 6px 0;
    border-bottom: 0.5px solid var(--bdr);
  }
  .field:last-child { border-bottom: none; }
  .field > label {
    font-size: 11px;
    color: var(--txt2);
    text-transform: uppercase;
    letter-spacing: 0.4px;
  }
  .field input[type="number"],
  .field input[type="text"],
  .field select {
    padding: 6px 10px;
    font-size: 14px;
    font-weight: 500;
    border: 1px solid var(--bdr2);
    border-radius: var(--r6);
    background: var(--card);
    color: var(--txt1);
    width: 100%;
    max-width: 200px;
    font-family: inherit;
  }
  .field input[type="checkbox"] {
    justify-self: start;
    width: 16px;
    height: 16px;
    cursor: pointer;
  }
  .field input:focus-visible,
  .field select:focus-visible {
    outline: 2px solid var(--txt1);
    outline-offset: 1px;
  }

  /* ─── Radio-groups (gender + spreidingstermijn) ─────────────── */
  .radio-group-inline {
    display: inline-flex;
    gap: 14px;
  }
  .radio-group-inline .radio-inline,
  .radio-group label {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    user-select: none;
    font-size: 13px;
    font-weight: 500;
    color: var(--txt1);
  }
  input[type="radio"] {
    accent-color: var(--green);
    cursor: pointer;
  }
  .pane-m2 input[type="radio"] { accent-color: var(--red); }
  .pane-m12 input[type="radio"] { accent-color: var(--amber); }

  /* ─── Sliders ───────────────────────────────────────────────── */
  input[type="range"] {
    width: 100%;
    margin: 6px 0 0;
    cursor: pointer;
    accent-color: var(--green);
  }
  .pane-m2 input[type="range"] { accent-color: var(--red); }
  .pane-m12 input[type="range"] { accent-color: var(--amber); }

  .rente-control,
  .slider-control {
    margin-top: 14px;
  }
  .slider-control:first-child { margin-top: 0; }
  .slider-control + .slider-control,
  .rente-control + .slider-control {
    padding-top: 14px;
    border-top: 0.5px solid var(--bdr);
  }

  /* v3.0.11: 2-koloms slider-paar voor leeftijd + pensioen bovenaan scherm 1 */
  /* v3.0.111: 2-koloms layout opgeheven — alle sliders in pane-m1 nu full-
     width, consistent met de cascade-rows in pane-m12 die ook full-width zijn.
     grid blijft, grid-template-columns: 1fr (was 1fr 1fr). */
  .slider-pair {
    display: grid;
    grid-template-columns: 1fr;
    gap: 24px;
    margin-bottom: 14px;
    padding-bottom: 14px;
    border-bottom: 0.5px solid var(--bdr);
  }
  .slider-pair .slider-control {
    margin-top: 0;
    padding-top: 0;
    border-top: none;
  }
  /* v3.0.12: partner-block (sliders + radio) */
  .partner-block {
    margin-top: 4px;
  }
  .partner-block .slider-pair {
    margin-bottom: 10px;
    padding-bottom: 10px;
  }
  .partner-block .field {
    border-bottom: 0.5px solid var(--bdr);
    padding-bottom: 8px;
  }

  /* v3.0.57: hoog-laag-blok — toggle + uitklap-velden */
  .hooglaag-block {
    margin-top: 8px;
    margin-bottom: 8px;
  }
  .hooglaag-toggle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    border-bottom: 0.5px solid var(--bdr);
  }
  .hooglaag-toggle .hooglaag-label {
    font-size: 13px;
    color: var(--txt1);
  }
  .hooglaag-toggle .radio-pair {
    display: inline-flex;
    gap: 12px;
    font-size: 13px;
  }
  .hooglaag-fields {
    margin-top: 10px;
  }
  .hooglaag-warn {
    display: inline-block;
    color: var(--red);
    font-size: 11.5px;
    line-height: 1.45;
  }
  @media (max-width: 640px) {
    .slider-pair {
      grid-template-columns: 1fr;
      gap: 14px;
    }
    /* v3.0.72: M2-sliders blijven naast elkaar ook in smalle viewport
       (sidebar-preview, mobiel). DG- en aftrek-slider zijn compacter dan
       M1's slider-pair en passen daarom wel naast elkaar bij krappe
       breedte. Iets kleinere gap voor sidebar-fit. */
    .m2-controls .slider-pair {
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
  }

  /* Slider-label-stand: huidige waarde bold boven */
  .slider-label-stand {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    font-size: 11px;
    color: var(--txt2);
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 2px;
  }
  .slider-label-stand strong {
    font-size: 18px;
    font-weight: 600;
    color: var(--txt1);
    letter-spacing: 0;
    text-transform: none;
  }
  .pane-m2 .slider-label-stand strong { color: var(--red); }
  .pane-m12 .slider-label-stand strong { color: var(--amber); }
  /* v3.0.57: hoog-laag-block */
  .hooglaag-block {
    margin-top: 14px;
  }
  .hooglaag-toggle {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
  }
  .hooglaag-toggle .hooglaag-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    color: var(--txt2);
  }
  .hooglaag-toggle .radio-pair {
    display: inline-flex;
    gap: 12px;
  }
  .hooglaag-toggle .radio-pair label {
    font-size: 13px;
    color: var(--txt1);
    cursor: pointer;
  }
  .hooglaag-fields {
    margin-top: 8px;
    padding-top: 8px;
    border-top: 0.5px dashed var(--bdr);
  }
  .hooglaag-warn {
    color: var(--red);
    font-size: 12px;
    line-height: 1.4;
  }
  .pane-m1 .slider-label-stand strong { color: var(--green); }

  /* v3.0.53: date-input rechts in label, op zelfde regel als labeltekst.
     v3.0.55: terug naar neutrale stijl (zonder donker-thema/hover-toeters).
     Kalender-icoon ervoor draagt de affordance — visueel rustig, klikbaarheid
     blijft duidelijk. Wrap-div .dob-wrap groepeert icoon + input. */
  .slider-label-stand .dob-wrap {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: var(--txt2);
  }
  .slider-label-stand .dob-icon {
    width: 14px;
    height: 14px;
    flex-shrink: 0;
  }
  .slider-label-stand .dob-input {
    font-family: inherit;
    font-size: 11px;
    color: var(--txt1);
    letter-spacing: 0;
    text-transform: none;
    padding: 0 6px;
    border: 0.5px solid var(--bdr);
    border-radius: var(--r6);
    background: var(--card);
    cursor: pointer;
    /* v3.0.96: vaste min-width zodat date-picker en dropdown-pill dezelfde
       visuele breedte krijgen. ~10.5em accommodeert "08-05-1956" + native
       browser-iconen op Chrome/Safari/Firefox.
       v3.0.97: expliciete height ipv padding-y zodat date-input en select
       in alle browsers identieke hoogte krijgen (Chrome/Safari verschillen
       anders door verschillende internal box-models tussen date-input en
       select-element).
       v3.0.98: DOB-breedte gelijkgetrokken aan dropdown-pill (8.4em).
       Op desktop/iPad Safari rendert de date-input "11 May 1956" compact
       genoeg om in 8.4em te passen. Visuele rust gaat boven karakter-ruimte. */
    height: 22px;
    line-height: 22px;
    min-width: 8.4em;
    box-sizing: border-box;
    vertical-align: middle;
  }
  .slider-label-stand .dob-input:focus {
    /* v3.0.97: zachte focus-ring met halfzichtbare border-kleur ipv harde
       donkere txt1-outline. Subtiele affordance, geen visuele schreeuw. */
    outline: 2px solid var(--bdr2);
    outline-offset: 1px;
  }

  /* v3.0.96: dropdown-pill voor geslacht-, hoog-laag- en heeftPartner-
     keuzes. Mirror styling van .dob-input zodat alle ingangen rechts in
     dezelfde kolom uitgelijnd lezen: zelfde padding, border-radius, font-
     size.
     v3.0.97: 20% smaller (8.4em ipv 10.5em) zodat dropdown smaller is dan
     date-picker; date-picker bevat meer karakters en mag breder lezen. */
  .dropdown-pill {
    font-family: inherit;
    font-size: 11px;
    color: var(--txt1);
    letter-spacing: 0;
    text-transform: none;
    padding: 0 6px;
    border: 0.5px solid var(--bdr);
    border-radius: var(--r6);
    background: var(--card);
    cursor: pointer;
    /* v3.0.97: identieke height aan dob-input (22px) zodat de pillen op
       dezelfde regel-baseline staan. */
    height: 22px;
    line-height: 22px;
    min-width: 8.4em;
    box-sizing: border-box;
    vertical-align: middle;
    /* Browser-default-pijltje behouden voor affordance; geen custom chevron
       om CSP-conform en simpel te blijven. */
  }
  .dropdown-pill:focus {
    /* v3.0.97: zelfde zachte focus-stijl als dob-input. */
    outline: 2px solid var(--bdr2);
    outline-offset: 1px;
  }

  /* v3.0.52: leeftijd-caption onder geboortedatum-input — neutraal getint
     (txt2), niet rood-thema, zodat het als afgeleide info leest. */
  .age-caption {
    margin-top: 4px;
    font-size: 12px;
    color: var(--txt2);
    line-height: 1.3;
  }

  /* v3.0.93: verwachte sterfleeftijd-caption, direct onder leeftijd-caption.
     Zelfde stijl als age-caption maar krappere top-margin omdat het visueel
     één blok afgeleide info vormt met de leeftijd. */
  .lifeexp-caption {
    margin-top: 2px;
    font-size: 12px;
    color: var(--txt2);
    line-height: 1.3;
    min-height: 1.3em;
  }

  /* v3.0.58: geslacht-radio onder geboortedatum, compact horizontaal.
     v3.0.61: radio-groep right-aligned (label links, knoppen rechts) zodat
     het visueel uitlijnt met de stand-strong van andere slider-controls.
     v3.0.66: radio-cellen via 2-kolom-grid met vaste breedte zodat bullets
     verticaal uitlijnen tussen rijen (Man/Nee bullets boven elkaar; Vrouw/Ja
     bullets boven elkaar). min-width hielp niet voor "Vrouw" omdat die zelf
     al breder rendert dan 4.5em; grid forceert exacte cellen.
     v3.0.96: radios vervangen door dropdown-pills; .field-inline-radio blijft
     als rij-wrapper (label links, control rechts), maar de child is nu een
     <select>, niet meer een .radio-group-inline grid. CSS-class naam blijft
     ongewijzigd voor backward-compat. */
  .field-inline-radio {
    margin-top: 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    font-size: 13px;
  }
  .field-inline-radio .inline-radio-label {
    color: var(--txt2);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.4px;
  }

  /* v3.0.99: .partner-fields wrapper rondom partner-sliders; heeftPartner-
     dropdown staat erbuiten in partner-block. margin-top voor visuele lucht
     tussen dropdown en sliders. */
  .partner-fields {
    margin-top: 12px;
  }
  .partner-fields[hidden] {
    display: none;
  }

  /* Min/midden/max-markers onder de slider */
  .slider-markers {
    display: flex;
    justify-content: space-between;
    font-size: 10px;
    color: var(--txt2);
    margin-top: 4px;
    padding: 0 2px;
  }
  .slider-markers .marker-min { text-align: left; flex: 1; }
  .slider-markers .marker-mid { text-align: center; flex: 1; }
  .slider-markers .marker-max { text-align: right; flex: 1; }

  .slider-help {
    font-size: 12px;
    color: var(--txt2);
    margin-top: 6px;
    line-height: 1.5;
  }

  /* v3.0.13: help-icon (?) naast slider-labels */
  .help-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    border: 0.5px solid var(--bdr2);
    background: var(--card);
    color: var(--txt2);
    font-size: 10px;
    font-weight: 600;
    cursor: pointer;
    margin-left: 6px;
    padding: 0;
    line-height: 1;
    transition: all 0.15s ease;
    vertical-align: 1px;
  }
  .help-icon:hover {
    background: var(--txt1);
    color: #fff;
    border-color: var(--txt1);
  }
  .help-icon:focus-visible {
    outline: 2px solid var(--txt1);
    outline-offset: 2px;
  }

  /* v3.0.13: help-modal */
  .help-modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.4);
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding: 40px 16px;
    z-index: 1000;
    overflow-y: auto;
  }
  .help-modal {
    background: var(--card);
    border-radius: var(--r12);
    padding: 18px 20px;
    max-width: 520px;
    width: 100%;
    max-height: 80vh;
    overflow-y: auto;
    box-shadow: 0 10px 40px rgba(0,0,0,0.25);
    position: relative;
  }

  /* v3.0.119: sensitivity-modal — wijder dan help-modal voor grafiek-viewport.
     Hergebruikt help-modal-overlay maar eigen container met max-width 800px. */
  .sensitivity-modal {
    background: var(--card);
    border-radius: var(--r12);
    padding: 18px 20px;
    max-width: 800px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 10px 40px rgba(0,0,0,0.25);
    position: relative;
  }

  /* v3.0.119: sensitivity-grafiek inhoud */
  .sens-desc {
    font-size: 12px;
    color: var(--txt2);
    margin: 0 0 18px 0;
    line-height: 1.5;
  }
  .sens-chart-container { margin: 0 0 18px 0; }
  svg.sens-chart {
    display: block;
    width: 100%;
    height: auto;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .sens-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 12px 18px;
    font-size: 12px;
    color: var(--txt2);
    padding: 12px 0 0 0;
    border-top: 0.5px solid var(--bdr);
  }
  .sens-legend-item { display: flex; align-items: center; gap: 6px; }
  .sens-legend-dot {
    display: inline-block;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #1a6db5;
  }
  .sens-legend-line {
    display: inline-block;
    width: 18px;
    height: 2px;
    background: #C07A00;
  }
  .sens-legend-line.dashed {
    background: transparent !important;
    background-image: linear-gradient(to right, #C07A00 0 4px, transparent 4px 7px, #C07A00 7px 11px, transparent 11px 14px, #C07A00 14px 18px) !important;
    opacity: 0.7;
  }
  .sens-summary {
    background: var(--surf);
    border-radius: var(--r8);
    padding: 12px 14px;
    margin-top: 14px;
  }
  .sens-summary-row {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    padding: 3px 0;
  }
  .sens-summary-label { color: var(--txt2); }
  .sens-summary-val {
    font-weight: 600;
    color: var(--blue);
  }
  .sens-meta-note {
    font-size: 11px;
    color: var(--txt2);
    margin: 16px 0 0 0;
    padding-top: 10px;
    border-top: 0.5px dashed var(--bdr);
    line-height: 1.5;
  }
  .help-modal-close {
    position: absolute;
    top: 12px;
    right: 14px;
    background: transparent;
    border: none;
    font-size: 24px;
    line-height: 1;
    color: var(--txt2);
    cursor: pointer;
    padding: 4px 8px;
    border-radius: var(--r6);
  }
  .help-modal-close:hover {
    background: var(--surf);
    color: var(--txt1);
  }
  .help-modal-title {
    font-size: 16px;
    font-weight: 600;
    margin: 0 30px 12px 0;
    color: var(--txt1);
    line-height: 1.3;
  }
  .help-modal-current {
    font-size: 13px;
    color: var(--txt2);
    background: var(--surf);
    padding: 8px 12px;
    border-radius: var(--r6);
    margin-bottom: 16px;
    line-height: 1.5;
  }
  .help-modal-section-h {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    color: var(--txt2);
    margin: 14px 0 6px;
  }
  .help-modal-section-h:first-child { margin-top: 0; }
  .help-modal-section-body {
    font-size: 13px;
    color: var(--txt1);
    line-height: 1.45;
    margin: 0;
  }
  /* v3.0.38: parameter-tabel in fonds-?-modal */
  .help-modal-params {
    width: 100%;
    border-collapse: collapse;
    margin: 8px 0 4px;
    font-size: 12.5px;
  }
  .help-modal-params thead th {
    text-align: left;
    font-weight: 600;
    font-size: 10.5px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    color: var(--txt2);
    border-bottom: 1px solid var(--bdr);
    padding: 6px 8px 6px 0;
  }
  .help-modal-params tbody td {
    padding: 6px 8px 6px 0;
    border-bottom: 0.5px solid var(--bdr);
    color: var(--txt1);
    vertical-align: top;
  }
  .help-modal-params tbody tr:last-child td { border-bottom: none; }
  .help-modal-params td.num {
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
    font-weight: 500;
  }
  .help-modal-params .adj-yes {
    color: var(--green);
    font-weight: 500;
  }
  .help-modal-params .adj-no {
    color: var(--txt2);
  }
  /* v3.0.45: aanwendings-cascade — toont input + plus → subtotal − minus → total */
  .help-modal-cascade {
    width: 100%;
    border-collapse: collapse;
    margin: 8px 0 4px;
    font-size: 12.5px;
  }
  .help-modal-cascade tbody td {
    padding: 5px 8px 5px 0;
    color: var(--txt1);
    vertical-align: top;
  }
  .help-modal-cascade .casc-sign {
    width: 18px;
    text-align: center;
    font-variant-numeric: tabular-nums;
    color: var(--txt2);
    font-weight: 600;
  }
  .help-modal-cascade .casc-val {
    text-align: right;
    white-space: nowrap;
    font-variant-numeric: tabular-nums;
    font-weight: 500;
  }
  .help-modal-cascade .casc-note {
    font-size: 11px;
    color: var(--txt2);
    line-height: 1.4;
    margin-top: 2px;
  }
  .help-modal-cascade .casc-input td,
  .help-modal-cascade .casc-plus td {
    border-bottom: 0.5px solid var(--bdr);
  }
  .help-modal-cascade .casc-subtotal td {
    border-top: 1px solid var(--txt2);
    border-bottom: 0.5px solid var(--bdr);
    font-weight: 600;
    background: var(--surf);
  }
  .help-modal-cascade .casc-minus td {
    border-bottom: 0.5px solid var(--bdr);
  }
  .help-modal-cascade .casc-total td {
    border-top: 1px solid var(--txt1);
    font-weight: 600;
  }
  .help-modal-cascade .casc-total .casc-val {
    color: var(--green);
  }
  .help-modal-section-body.casc-outro {
    margin-top: 10px;
    font-style: italic;
    color: var(--txt2);
  }
  @media (max-width: 640px) {
    .help-modal {
      padding: 18px 20px;
    }
  }

  /* ─── KPI-cards ─────────────────────────────────────────────── */
  .output { margin-top: 14px; }
  .kpi-card {
    background: var(--surf);
    border-radius: var(--r12);
    padding: 14px 18px;
    text-align: left;
  }
  .kpi-label {
    font-size: 11px;
    color: var(--txt2);
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 4px;
  }
  .kpi-value {
    font-size: var(--num-l);
    font-weight: 700;
    color: var(--green);
    line-height: 1.1;
    margin: 4px 0;
  }
  .kpi-m2 .kpi-value { color: var(--red); }
  .kpi-delta {
    font-size: var(--num-s);
    font-weight: 600;
    margin: 2px 0 0;
    color: var(--txt2);
  }
  .kpi-delta.pos { color: var(--green); }
  .kpi-delta.neg { color: var(--red); }

  /* v3.0.85: drielaagse opbouwsom in M2-KPI — laat verband M1 + M1/2 = M2
     visueel zien met dezelfde kleuren als de panes. */
  .kpi-formula {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .kpi-formula-row {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    gap: 12px;
    font-size: 14px;
  }
  .kpi-formula-row .kpi-formula-label {
    color: var(--txt2);
  }
  .kpi-formula-row .kpi-formula-val {
    font-weight: 700;
    font-size: var(--num-m);
    text-align: right;
    white-space: nowrap;
  }
  .kpi-formula-total {
    border-top: 1px solid var(--txt1);
    padding-top: 8px;
    margin-top: 4px;
  }
  .kpi-formula-total .kpi-formula-label {
    color: var(--txt1);
    font-weight: 600;
  }
  .kpi-formula-total .kpi-formula-val {
    font-size: var(--num-l);
  }
  .kpi-m1-color { color: var(--green); }
  .kpi-m12-color { color: var(--amber); }
  .kpi-m2-color { color: var(--red); }
  .kpi-formula-foot {
    margin-top: 10px;
    padding-top: 8px;
    border-top: 0.5px dashed var(--bdr);
    font-size: var(--num-s);
    color: var(--txt2);
    text-align: right;
  }
  /* v3.0.122: secundaire foot-regel voor jaarpensioen-equivalent.
     Geen eigen border, kleinere top-marge — staat direct onder %-regel. */
  .kpi-formula-foot-secondary {
    margin-top: 4px;
    padding-top: 0;
    border-top: none;
    font-size: var(--num-s);
    color: var(--txt2);
    text-align: right;
  }
  .kpi-breakdown {
    font-size: 12px;
    color: var(--txt2);
    margin-top: 12px;
    padding-top: 10px;
    border-top: 0.5px solid var(--bdr);
    display: flex;
    gap: 28px;
  }
  .kpi-sub-label {
    font-size: 10px;
    color: var(--txt2);
    text-transform: uppercase;
    letter-spacing: 0.4px;
  }
  .kpi-sub-value {
    font-size: var(--num-m);
    font-weight: 600;
    color: var(--txt1);
    margin-top: 2px;
  }
  .kpi-foot {
    font-size: var(--num-s);
    color: var(--txt2);
    margin-top: 10px;
    padding-top: 8px;
    border-top: 0.5px solid var(--bdr);
  }

  /* M2-controls block (sliders + radios)
     v3.0.105: border-top weg (visuele divider niet meer nodig).
     v3.0.106: margin-top + padding-top weg zodat M2-spacing aansluit op M1.
     v3.0.112: horizontale padding 18px toegevoegd, BLEEK FOUT — label
     werd verder ingesprongen dan kpi-card-tekst (overshoot).
     v3.0.113: padding terug naar leeg. M2 spreidingN gebruikt nu dezelfde
     edge-uitlijning als M1 (geslacht/hooglaag/partner): label aan pane-
     content-left, dropdown aan pane-content-right via flex space-between. */
  .m2-controls {
  }
  /* v3.0.73: extra witregel tussen sliders/spreiding-radio en KPI-card */
  .m2-output {
    margin-top: 22px;
  }

  /* ─── Audit-pane content ────────────────────────────────────── */
  .meta-note {
    font-size: 11px;
    color: var(--txt2);
    margin-top: 12px;
    padding-top: 8px;
    border-top: 0.5px dashed var(--bdr);
  }
  table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 6px;
    font-size: 12px;
  }
  th, td {
    border-bottom: 0.5px solid var(--bdr);
    padding: 6px 8px;
    text-align: left;
    vertical-align: top;
  }
  th {
    background: var(--surf);
    font-weight: 600;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    color: var(--txt2);
  }
  td.num {
    text-align: right;
    font-variant-numeric: tabular-nums;
    font-family: 'SF Mono', Consolas, monospace;
  }
  tr.display-decompositie td { background: rgba(0,0,0,0.01); }
  tr.display-deepdive td { background: rgba(0,0,0,0.025); color: var(--txt2); }
  tr.display-diagnose td { background: rgba(212,0,26,0.04); color: #884444; }
  tr.cohort-totals td {
    font-weight: 600;
    background: var(--surf);
    border-top: 1px solid var(--bdr2);
  }
  .cohort-table { font-size: var(--num-s); }
  .modtag {
    display: inline-block;
    font-size: var(--num-s);
    padding: 1px 6px;
    margin-right: 5px;
    border-radius: 6px;
    font-family: monospace;
    vertical-align: middle;
  }
  .modtag-shared { background: var(--surf); color: var(--txt2); }
  .modtag-m1 { background: rgba(26,138,69,0.12); color: var(--green); }
  .modtag-m2 { background: rgba(212,0,26,0.10); color: var(--red); }
  .specref {
    font-family: monospace;
    font-size: 11px;
    color: var(--txt2);
  }
  code {
    font-family: monospace;
    background: var(--surf);
    padding: 1px 5px;
    border-radius: 3px;
    font-size: 12px;
  }
  .info {
    cursor: help;
    color: var(--amber);
    font-size: 12px;
    margin-left: 4px;
  }
  .disclosure-list {
    font-size: 12px;
    padding-left: 16px;
    line-height: 1.55;
  }
  .disclosure-list li { margin-bottom: 4px; }
  .error {
    background: rgba(212,0,26,0.06);
    color: var(--red);
    padding: 10px 12px;
    border-radius: var(--r6);
    font-size: 13px;
  }

  /* ─── Topline (h1 + ?-knop) ──────────────────────────────────── */
  .topline {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 14px;
    padding: 0 4px;
    max-width: 960px;
    margin-left: auto;
    margin-right: auto;
  }
  .topline h1 {
    margin-bottom: 0;
    flex: 1;
  }
  /* v3.0.48: doelgroep-ondertitel onder h1 */
  .topline-title {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .topline-title h1 {
    margin: 0;
  }
  .topline-subtitle {
    margin: 0;
    font-size: 13px;
    color: var(--txt2);
    font-weight: 400;
    line-height: 1.3;
  }
  /* v3.0.102: fondsnaam (volledige label) tussen h1 en subtitle. Iets groter
     en in txt1, want het is identificerend, geen subtitle-context. */
  .topline-fondsnaam {
    margin: 0;
    font-size: 13px;
    color: var(--txt1);
    font-weight: 500;
    line-height: 1.3;
  }
  .topline-help-btn {
    flex-shrink: 0;
  }
  /* v3.0.131: verticale stack voor Uitleg + Verantwoording-knoppen */
  .topline-btn-stack {
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
    align-items: stretch;
  }
  .topline-btn-stack .topline-text-btn {
    width: 100%;
    text-align: center;
  }
  /* v3.0.22: Uitleg-tekstknop in topline */
  .topline-text-btn {
    flex-shrink: 0;
    padding: 4px 12px;
    border: 0.5px solid var(--bdr2);
    background: var(--card);
    color: var(--txt1);
    border-radius: var(--r6);
    cursor: pointer;
    font-size: 12px;
    font-weight: 500;
    user-select: none;
  }
  .topline-text-btn:hover {
    background: var(--surf);
    border-color: var(--txt1);
  }
  /* v3.0.130: rode-tekst-variant voor de Verantwoording-knop */
  .topline-text-btn-red {
    color: #c00;
    border-color: #c00;
  }
  .topline-text-btn-red:hover {
    background: #fee;
    border-color: #900;
    color: #900;
  }
  /* v3.0.130: simpele-tabel-styling voor disclaimer-tabellen (ABN-vergelijking) */
  .help-modal-simpletable {
    width: 100%;
    border-collapse: collapse;
    margin: 12px 0;
    font-size: 12px;
  }
  .help-modal-simpletable th,
  .help-modal-simpletable td {
    border: 0.5px solid var(--bdr);
    padding: 6px 8px;
    text-align: left;
    vertical-align: top;
  }
  .help-modal-simpletable th {
    background: var(--surf);
    font-weight: 600;
    color: var(--txt1);
  }
  .help-modal-simpletable td {
    color: var(--txt2);
  }
  /* v3.0.131: footer-link knop in help-modal (Privacy → Verantwoording) */
  .help-modal-footer-link {
    margin-top: 20px;
    padding-top: 14px;
    border-top: 0.5px dashed var(--bdr);
    text-align: right;
  }
  .help-modal-link-btn {
    background: none;
    border: 0.5px solid #c00;
    color: #c00;
    padding: 6px 14px;
    border-radius: var(--r6);
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
  }
  .help-modal-link-btn:hover {
    background: #fee;
    color: #900;
    border-color: #900;
  }

  /* ─── Audit-unlock + footer ─────────────────────────────────── */
  .audit-unlock {
    margin-top: 28px;
    padding-top: 14px;
    border-top: 0.5px dashed var(--bdr);
    font-size: 12px;
    color: var(--txt2);
    max-width: 960px;
    margin-left: auto;
    margin-right: auto;
  }
  .audit-unlock summary {
    cursor: pointer;
    user-select: none;
    color: var(--txt2);
  }
  .audit-unlock summary:hover { color: var(--txt1); }
  .audit-unlock-form {
    display: flex;
    gap: 8px;
    align-items: center;
    margin-top: 8px;
    flex-wrap: wrap;
  }
  .audit-unlock-form input {
    padding: 6px 10px;
    border: 1px solid var(--bdr2);
    border-radius: var(--r6);
    font-size: 13px;
    flex: 1;
    min-width: 160px;
    font-family: inherit;
  }
  .audit-unlock-form button {
    padding: 6px 14px;
    background: var(--txt1);
    color: #fff;
    border: none;
    border-radius: var(--r6);
    cursor: pointer;
    font-size: 12px;
    font-weight: 500;
  }
  .audit-unlock-form button:hover { background: #000; }

  .site-footer {
    margin-top: 32px;
    padding-top: 16px;
    border-top: 0.5px solid var(--bdr);
    font-size: 12px;
    color: var(--txt2);
    text-align: center;
    line-height: 1.6;
  }
  .site-footer p { margin: 3px 0; font-size: 12px; color: var(--txt2); }
  .site-footer .footer-disclaimer { color: var(--txt1); }
  .site-footer .footer-meta { color: var(--txt2); font-size: 11px; }

  /* ─── KPI-flash (subtiele animatie bij Enter-bevestig) ──────── */
  .kpi-card { transition: background 0.3s ease; }
  .kpi-card.flash { animation: kpi-flash 0.45s ease-out; }
  @keyframes kpi-flash {
    0%   { background: var(--surf); }
    25%  { background: rgba(212,0,26,0.10); }
    100% { background: var(--surf); }
  }
  .kpi-m2.flash { animation: kpi-flash-m2 0.45s ease-out; }
  @keyframes kpi-flash-m2 {
    0%   { background: var(--surf); }
    25%  { background: rgba(26,138,69,0.12); }
    100% { background: var(--surf); }
  }

  /* ─── Mobile ────────────────────────────────────────────────── */
  @media (max-width: 640px) {
    body { padding: 16px 12px 40px; }
    body > .topline h1,
    body > h1 { font-size: 16px; }
    .pane { padding: 14px 16px; }
    .field {
      grid-template-columns: 1fr;
      gap: 4px;
    }
    .field input[type="number"],
    .field input[type="text"],
    .field select { max-width: 100%; }
    .kpi-breakdown { gap: 16px; }
    /* v3.0.91: kpi-value mobile-override (was 26px) verwijderd — token
       --num-l (28px) werkt cross-device. */
  }

  /* ─── v3.0.41: Print-knop en print-rapport ───────────────────── */
  /* Knop in de actie-pane onder de M2-output. Bewust subtiel: een
     secundaire actie, niet de hoofd-CTA. */
  .pane.casual.pane-actions {
    border-left: 3px solid var(--txt2);
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
    /* v3.0.104: padding-override 12px 16px verwijderd; erft nu 18px 20px van
       .pane zodat de knoppen op dezelfde linker-rand staan als de h2-titels
       in M1, M1/2 en M2-panes. */
  }
  .pane-actions .action-btn {
    background: var(--surf);
    color: var(--txt1);
    border: 1px solid var(--bdr);
    border-radius: 6px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    font-family: inherit;
  }
  .pane-actions .action-btn:hover {
    background: var(--bdr);
    border-color: var(--txt2);
  }
  .pane-actions .action-btn:focus-visible {
    outline: 2px solid var(--txt1);
    outline-offset: 2px;
  }
  .pane-actions .action-note {
    font-size: 12px;
    color: var(--txt2);
    line-height: 1.45;
    margin: 0;
  }

  /* Verberg het print-rapport in normale weergave; alleen tonen bij print. */
  #print-report { display: none; }

  /* ─── @media print: alleen het rapport tonen ─────────────────── */
  @media print {
    /* Verberg ALLE app-UI tijdens printen. */
    body > *:not(#print-report) { display: none !important; }
    #print-report {
      display: block !important;
      color: #000;
      background: #fff;
      font-family: Georgia, "Times New Roman", serif;
      font-size: 10.5pt;
      line-height: 1.45;
    }
    /* Pagina-marges via @page (niet via body padding, zodat headers/footers
       die de browser zelf invoegt buiten ons rapport blijven).
       v3.0.108: marges verruimd zodat @page margin-boxes (header/footer)
       ruimte hebben. Voorgaande 18mm boven/onder werd 22mm. */
    @page {
      size: A4 portrait;
      margin: 22mm 16mm 22mm 16mm;

      /* v3.0.108: running header en footer in modelspec-PDF-stijl.
         Browser-support: Chromium (Chrome/Edge/Brave/Opera) volledig; Safari
         partieel; Firefox negeert deze regels (body blijft leesbaar zonder
         running header).
         Bottom-right wordt dynamisch ingevuld door triggerPrint() in
         ui.print.ts (versie-string + huidige datum/tijd), zie #print-footer-dynamic. */
      @top-left {
        content: "Invaarcalculator\\2122  \\2014  Persoonlijk overzicht";
        font-family: Georgia, "Times New Roman", serif;
        font-size: 9pt;
        color: #444;
        border-bottom: 0.4pt solid #888;
        padding-bottom: 2mm;
        vertical-align: bottom;
      }
      @top-right {
        content: "Innovation Nestor";
        font-family: Georgia, "Times New Roman", serif;
        font-size: 9pt;
        color: #444;
        border-bottom: 0.4pt solid #888;
        padding-bottom: 2mm;
        vertical-align: bottom;
      }
      @bottom-left {
        content: "Pagina " counter(page) " van " counter(pages);
        font-family: Georgia, "Times New Roman", serif;
        font-size: 9pt;
        color: #444;
        border-top: 0.4pt solid #888;
        padding-top: 2mm;
        vertical-align: top;
      }
    }

    .pr-header h1 {
      font-size: 18pt;
      margin: 0 0 4pt 0;
      font-weight: 700;
    }
    /* v3.0.48: doelgroep-ondertitel in print */
    .pr-subtitle {
      font-size: 11pt;
      font-weight: 400;
      color: #555;
      margin: 0 0 8pt 0;
      border-bottom: 1.5pt solid #000;
      padding-bottom: 4pt;
    }
    .pr-meta {
      font-size: 9.5pt;
      color: #444;
      margin: 0 0 14pt 0;
      line-height: 1.45;
    }

    .pr-section { margin: 0 0 14pt 0; }
    .pr-section h2 {
      font-size: 13pt;
      margin: 0 0 6pt 0;
      font-weight: 700;
      border-bottom: 0.5pt solid #888;
      padding-bottom: 2pt;
    }
    .pr-section h3 {
      font-size: 11pt;
      margin: 10pt 0 4pt 0;
      font-weight: 700;
    }
    .pr-section p { margin: 0 0 6pt 0; }
    .pr-intro { font-size: 9.5pt; color: #333; }

    .pr-table {
      width: 100%;
      border-collapse: collapse;
      margin: 0 0 6pt 0;
      font-size: 10pt;
    }
    .pr-table thead th {
      text-align: left;
      font-weight: 700;
      font-size: 9pt;
      text-transform: uppercase;
      letter-spacing: 0.4pt;
      color: #333;
      border-bottom: 0.5pt solid #888;
      padding: 3pt 6pt 3pt 0;
    }
    .pr-table tbody td {
      padding: 3pt 6pt 3pt 0;
      border-bottom: 0.25pt solid #ccc;
      vertical-align: top;
    }
    .pr-table td.num {
      text-align: right;
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
    }
    .pr-table td.num.strong { font-weight: 700; }

    .pr-formula {
      font-family: "Courier New", Courier, monospace;
      font-size: 9.5pt;
      background: #f6f6f6;
      border: 0.25pt solid #ccc;
      padding: 6pt 8pt;
      margin: 4pt 0 6pt 0;
      white-space: pre-wrap;
      page-break-inside: avoid;
    }
    .pr-note { font-size: 9pt; color: #444; }

    .pr-refs {
      margin: 4pt 0 6pt 18pt;
      padding: 0;
      font-size: 9.5pt;
    }
    .pr-refs li { margin-bottom: 2pt; }

    .pr-pagebreak { page-break-before: always; }

    .pr-disclaimer {
      font-size: 9pt;
      color: #333;
      border-top: 0.5pt solid #888;
      padding-top: 8pt;
      margin-top: 16pt;
    }
    .pr-disclaimer h2 { font-size: 11pt; border: none; }
    .pr-error { color: #900; font-style: italic; }
  }
</style>
</head>
<body>

<div class="topline">
  <div class="topline-title">
    <h1>Invaarcalculator&reg;</h1>
    <p class="topline-fondsnaam">${fondsLabel}</p>
    <p class="topline-subtitle">Voor ${fondsShort}-gepensioneerden na de AOW-leeftijd</p>
  </div>
  <div class="topline-btn-stack">
    <button type="button" class="topline-text-btn" data-help="uitleg">Uitleg</button>
    <button type="button" class="topline-text-btn topline-text-btn-red" data-help="verantwoording">Verantwoording</button>
  </div>
</div>

<div id="js-error-display" style="display:none;background:#fee;border:1px solid #c00;color:#900;padding:12px;border-radius:8px;margin:12px 0;font-family:monospace;font-size:12px;white-space:pre-wrap;line-height:1.5;"></div>

<div id="app"></div>

<!-- v3.0.13: help-modal voor uitleg-popups -->
<div id="help-modal-overlay" class="help-modal-overlay" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="help-modal-title">
  <div class="help-modal">
    <button id="help-modal-close" type="button" class="help-modal-close" aria-label="Sluiten">&times;</button>
    <h2 id="help-modal-title" class="help-modal-title"></h2>
    <div id="help-modal-body" class="help-modal-body"></div>
  </div>
</div>

<!-- v3.0.119: gevoeligheidsgrafiek-modal. Aparte overlay vanwege wijdere
     viewport (max-width 800px ipv 520px voor help-modal). -->
<div id="sensitivity-modal-overlay" class="help-modal-overlay" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="sensitivity-modal-title">
  <div class="sensitivity-modal">
    <button id="sensitivity-modal-close" type="button" class="help-modal-close" aria-label="Sluiten">&times;</button>
    <h2 id="sensitivity-modal-title" class="help-modal-title">Hoe verandert uw aandeel met de dekkingsgraad?</h2>
    <div id="sensitivity-modal-body" class="help-modal-body"></div>
  </div>
</div>

<!-- v3.0.41: print-rapport. Verborgen op scherm; wordt zichtbaar bij window.print(). -->
<div id="print-report" aria-hidden="true"></div>

<!-- v3.0.108: dynamic @page bottom-right (versie + print-timestamp). Wordt
     gevuld door triggerPrint() in ui.print.ts vlak voor window.print(). -->
<style id="print-footer-dynamic"></style>

<script>
(function() {
  function showError(label, msg) {
    var d = document.getElementById('js-error-display');
    if (d) {
      d.style.display = 'block';
      d.textContent = label + ': ' + msg;
    }
  }
  window.addEventListener('error', function(e) {
    showError('JS-fout', (e.message || 'onbekend') + (e.filename ? ' @ ' + e.filename + ':' + e.lineno : ''));
  });
  window.addEventListener('unhandledrejection', function(e) {
    showError('Promise-fout', (e.reason && e.reason.message) || String(e.reason));
  });
  // Fallback: als #app na 5s nog leeg is, toon waarschuwing.
  // v3.0.120: 2s → 5s. iPad Safari first-load triggerde false-positive op
  // 2s bij grote inline-blobs (524 KB PDF-base64 + 82 KB AG2024 + 142 KB
  // bundle); parsing was nog bezig terwijl detector al vuurde. Cached
  // refreshes en andere browsers (Firefox/DuckDuckGo op iOS) hadden geen
  // last. 5s geeft Safari ruimte zonder echte init-fouten te verbergen.
  setTimeout(function() {
    var app = document.getElementById('app');
    if (app && app.innerHTML.trim() === '') {
      showError('Init', 'JS-bundle uitgevoerd maar #app bleef leeg na 5s. Browser ondersteunt mogelijk een gebruikt feature niet. UA: ' + navigator.userAgent);
    }
  }, 5000);
})();
</script>

<script>window.__AG2024__ = ${ag2024};</script>
<script>window.__MODELSPEC_PDF__ = "${pdfBase64}";</script>
<script>${bundle}</script>

</body>
</html>`

  // 4. Schrijf
  console.log('[4/4] Schrijf output...')
  fs.mkdirSync(path.dirname(OUT_HTML), { recursive: true })
  fs.writeFileSync(OUT_HTML, html)
  const totalSize = html.length
  console.log(`\n✓ Geschreven: ${OUT_HTML}`)
  console.log(`  Totale omvang: ${(totalSize / 1024).toFixed(1)} KB`)
  console.log(`  Verdeling: bundle ${(bundle.length / 1024).toFixed(1)} KB + AG2024 ${(ag2024.length / 1024).toFixed(1)} KB + PDF-base64 ${(pdfBase64.length / 1024).toFixed(1)} KB + HTML/CSS ~${((totalSize - bundle.length - ag2024.length - pdfBase64.length) / 1024).toFixed(1)} KB`)
}

build().catch((err) => {
  console.error('Build failed:', err)
  process.exit(1)
})
