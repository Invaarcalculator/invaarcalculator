# ARCHITECTUUR v1 — Vier-modules-model van de WTP-pensioencalculator

Datum: 22-04-2026 22:49
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Status: **normatief** — vastlegging van de beoogde architectuur, niet van de huidige code
Licentie: CC BY-NC 4.0

Dit document legt het conceptuele model vast waarop de calculator vanaf Fase B wordt gebouwd. Het is het resultaat van de werksessie op 22-04-2026 waarin drie documenten samenkwamen: `calculator_specificatie.docx` (ontvangen als engine-spec, behandelt één module), `DESIGN_engine_v0.md` (reverse-engineering van wat de huidige code feitelijk doet, drie modules), en de strategische richting uit `STRATEGY_R9.30.md`.

De uitkomst van dat gesprek: de engine is conceptueel **vier modules**, elk met een eigen vraag, eigen input, eigen output en eigen intellectueel profiel. Ze vormen geen monoliet maar een architectuur met keten (1→2→3) en parallelle module (4).

---

## 1. Het vier-modules-model

```
  ┌──────────────────────────────────┐
  │ Module 1 — Huidige waarde        │  "Wat is uw pensioen nu waard?"
  │ → KV, levensverwachting          │
  └──────────────┬───────────────────┘
                 │
                 ▼
  ┌──────────────────────────────────┐
  │ Module 2 — Potje                 │  "Wat krijgt u mee uit de pot?"
  │ → potje, buffer-aandeel          │
  └──────────────┬───────────────────┘
                 │
                 ▼
  ┌──────────────────────────────────┐                  ┌──────────────────────────────────┐
  │ Module 3 — Uitkeringsbenadering  │                  │ Module 4 — Waardevergelijking    │
  │ → U_t banden, buffer-statistiek  │                  │ → V_DB, V_Wtp, K_x, Δ            │
  └──────────────────────────────────┘                  └──────────────────────────────────┘
                                                         "Hoe verhoudt uw aanspraak zich
                                                          pre versus post transitie?"
```

Modules 1, 2 en 3 vormen een **keten**: elke module gebruikt de output van de voorgaande als input. Module 4 staat **parallel**: hij beantwoordt een eigen vraag, gebruikt geen output van 1-3, en levert zijn eigen getal. De vier modules leveren samen vier complementaire antwoorden die naast elkaar gepresenteerd worden in de UI.

---

## 2. Module 1 — Huidige waarde

**Vraag die beantwoord wordt:** *Wat is mijn huidige pensioenaanspraak waard, gegeven mijn leeftijd en een gekozen rekenrente?*

**Input:**
- Deelnemer: leeftijd, bruto jaarpensioen
- Parameter: rekenrente (gebruiker of dataset-default)
- Fondsparameterset: sterftetafel (AG2022 baseline), eventueel ervaringssterftefactor en geslacht

**Output:**
- KV (kapitaalwaarde van de aanspraak): KV = pen · ä(age, r)
- Levensverwachting (verwachte sterfleeftijd onder AG2022)

**Relatie tot huidige code:**
- Grotendeels gerealiseerd in `renderStart` (regel 3028) en de helpers `annuityTo` / `lifeExp` (regel 2925, 2943)
- Module 1 is het meest volwassen van de vier

**Mogelijke verrijking in spec-v1:**
- Geslacht toevoegen (vereist Q_M en Q_V tafels)
- Generatietafel q_{x,t} met kalenderjaar-dimensie
- Ervaringssterftefactor f(x, g) uit de fondsparameterset
- Kostenopslag ρ op de KV

**Wat module 1 *niet* doet:**
- Geen regelingsverschil (KV is regime-agnostisch)
- Geen partnerpensioen (partner heeft eigen aanspraak, komt eventueel als aparte KV-regel)
- Geen indexatieprojectie — dat is module 4's domein

---

## 3. Module 2 — Potje

**Vraag die beantwoord wordt:** *Wat krijg ik uit het fondsvermogen meegeleverd bij invaren, gegeven mijn eigen KV en de fondsbalans?*

**Input:**
- Van module 1: KV, leeftijd
- Fondsparameterset: fondsvermogen, dekkingsgraad, compensatiedepot, operationele reserve, bijstort, demografie, DNB-spreidings-N, buffer-reservering, compensatie-curve (μ, σ)

**Output:**
- Potje = ppkBase + ppkSurplus + ppkComp
- Buffer-aandeel (naar module 3)
- Cohort-uitkomsten (voor deepdive-weergave)

**Relatie tot huidige code:**
- Volledig gerealiseerd in `ppkCalculate` (regel 3643) met bijbehorende helpers (`dnbShareFactor`, `dnbNormFactor`, `ppkBell`, `ppkCurveSum`, `computeCohortOutcomes`, `kvProfile`)
- Ontwerp-principe: **gebruikersconsistentie** (R9.21-keuze), Σ individuele toedelingen ≠ fondsvermogen

**Mogelijke verrijking in spec-v1:**
- Expliciet maken dat φ (toedelingsfactor uit spec docx) hier impliciet zit als `(kv/vpvTotal) × surplus × sFactor × nFactor`
- Mogelijkheid om φ als dataset-veld expliciet te ontvangen (alternatief rekenpad)
- Leeftijdsafhankelijke φ(x) toestaan

**Wat module 2 *niet* doet:**
- Geen regelingsverschil in de berekening zelf (DNB-spreiding is fonds-toedelings-mechaniek, niet Wtp-regeling-specifiek)
- Maar: sommige parameters (compensatiedepot, bijstort) hangen wel samen met de gekozen regeling en het transitieplan van het fonds

---

## 4. Module 3 — Uitkeringsbenadering

**Vraag die beantwoord wordt:** *Hoe ontwikkelt mijn uitkering zich na transitie onder de gekozen Wtp-regeling, met welke onzekerheidsmarge?*

**Input:**
- Van module 2: potje, buffer-aandeel
- Van module 1: leeftijd, levensverwachting (voor horizon)
- Parameters: projectierendement, verwacht rendement, volatiliteit, inflatie, dempingjaren
- Regeling: FPR / SPR-clean / SPR-hybride (Fase B — in R9.30 alleen FPR)

**Output:**
- Percentielbanden U_t voor t = 0..years (p10/p50/p90)
- Benchmark (rode lijn: oude situatie met volledige indexatie)
- Buffer-statistieken (eindbuffer, tekortjaren, dekking-categorieën)
- Startuitkering U₀

**Relatie tot huidige code:**
- Volledig gerealiseerd in `verwSimulate` (regel 5477) met MC (2000 paden, seed 20260418)
- Log-normaal rendement (GBM) met arithmetisch-naar-log conversie
- FPR U-update: U_{t+1} = U_t · (1 + effR) / (1 + proj)
- Buffer-mechaniek met effR < inf trigger (gemarkeerd als heroverwegingspunt)

**Mogelijke verrijking in spec-v1:**
- Regeling-dimensie expliciet maken: SPR-clean en SPR-hybride inner loops specificeren naast de bestaande FPR-variant
- Correlatie rente-inflatie (huidig: onafhankelijk)
- Lifecycle-profiel (huidig: één μ en σ voor alle leeftijden)
- Mortality pooling expliciet (huidig: impliciet via startuitkering-annuïteit)

**Wat module 3 *niet* doet:**
- Geen waardering — levert uitkeringsbanen, geen contante waardes
- Geen Δ-vergelijking met een pre-transitie-scenario
- Geen keuze-effecten (hoog/laag, uitruil, profielwijziging binnen FPR)

---

## 5. Module 4 — Waardevergelijking

**Vraag die beantwoord wordt:** *Wat is de contante waarde van mijn aanspraak onder voortgezet DB-regime vergeleken met onder Wtp-regime, onder dezelfde grondslagen?*

**Input:**
- Deelnemer: leeftijd, geslacht, jaarpensioen (OP), partnerpensioen (PP) en partnergegevens (leeftijd, geslacht) indien van toepassing, transitiejaar t₀
- Fondsparameterset: toedelingsfactor φ, rentetermijnstructuur RTS (of vlakke rente), generatietafel q_{x,t}, ervaringssterftefactor f, indexatiescenario's π_DB en π_Wtp, kostenopslagen ρ_DB en ρ_Wtp, betalingsfrequentie m, eindleeftijd ω

**Output:**
- V_x^DB (pre-transitie waardering)
- V_x^Wtp (post-transitie waardering onder projectie-aanname π_Wtp)
- K_x = φ(x₀) · V_x^Wtp (toegedeeld individueel vermogen)
- Δ = V_x^Wtp − V_x^DB onder meerdere indexatie-scenariopaar-combinaties

**Relatie tot spec docx:**
- Dit is onverkort `calculator_specificatie.docx` §§1-13, exact zoals daarin beschreven
- Het document is bewust deterministisch (puntwaardering op transitiedatum)
- De scope-voorbehouden van §12 blijven onverminderd van toepassing:
  - V_Wtp is een waarde-equivalent, geen gegarandeerde waarde
  - π_Wtp-afleiding is buiten de engine
  - Joint-life onafhankelijkheidsaanname
  - Geen SPR/FPR-differentiatie in de engine, wel via parametersets
  - Geen risicodeling gewaardeerd

**Relatie tot huidige code:**
- Module 4 bestaat **niet** in R9.30
- Wordt een nieuw scherm (scherm 4) of alternatieve view
- Alle actuariële infrastructuur moet nieuw gebouwd: generatietafel als 2D-object, f-factor, joint-life annuïteiten, twee-pass V-berekening, indexatiescenario-combinaties

**Wat module 4 *niet* doet:**
- Geen onzekerheidsmarge (deterministisch, niet stochastisch)
- Geen uitkeringsbaan in de tijd (alleen puntwaardering op transitiedatum)
- Geen fondsbrede toedelingsmechaniek (φ wordt aangeleverd, niet afgeleid)

---

## 6. Koppelingen en afhankelijkheden

### Keten 1→2→3

| Van | Naar | Via wat |
|---|---|---|
| Module 1 | Module 2 | KV (persoonlijke kapitaalwaarde), leeftijd |
| Module 2 | Module 3 | Potje, buffer-aandeel, indirect: KV en VPV (voor buffer-toedeling proportioneel aan KV-aandeel) |
| Module 1 | Module 3 | Levensverwachting (voor horizon-keuze), leeftijd |

### Module 4 parallel

Module 4 gebruikt **geen** output van modules 1, 2 of 3. Hij leest rechtstreeks uit deelnemersinvoer en fondsparameterset. Dit is een bewuste architecturale keuze: de waarderings­grondslagen van module 4 (generatietafel, RTS, indexatiescenario's) zijn typisch anders dan de vereenvoudigde grondslagen van modules 1-3 (leeftijdstafel, vlakke rente, slider-inflatie). Als module 4 zou proberen hergebruik te maken van module 1's KV, zou hij onzuivere grondslagen importeren en de consistentievoorwaarde uit spec §8 schenden.

### Gedeelde bronnen

Alle vier modules delen:
- De deelnemersinvoer (leeftijd, pensioenbedrag, eventueel geslacht/partner)
- De `FONDS_DATASET` als parameter-bron

Maar ze gebruiken **verschillende deelverzamelingen** van de dataset. Module 1 gebruikt de sterftetafel. Module 2 gebruikt fondsbalans + compensatie + demografie + DNB-N. Module 3 gebruikt defaults-rate (projectie/rendement/volatiliteit/inflatie) + buffer. Module 4 gebruikt RTS + generatietafel + f + π_DB/π_Wtp + ρ + φ.

---

## 7. Parameterset-overlap

Huidig SCHEMA v1 dekt modules 1-3 vrijwel volledig (pragmatisch, met AG2022 leeftijdstafel als benadering). Module 4 vereist uitbreiding:

| Spec-veld module 4 | Status in SCHEMA v1 | Actie voor SCHEMA v2 |
|---|---|---|
| φ toedelingsfactor | Niet expliciet; impliciet via DG × overschot | Nieuw veld of berekend uit bestaande |
| RTS rentetermijnstructuur | `reserveringenFaseB.rtsCurve` = null | Invullen als vector[decimal] |
| q_{x,t} generatietafel | `actuarieel.sterftekansTabelId` verwijst naar 1D tafel | Uitbreiden naar 2D of aparte sterftetabel-resource |
| f(x, g) ervaringssterftefactor | Niet aanwezig | Nieuw veld in `actuarieel` |
| π_DB, π_Wtp scenario's | Niet aanwezig (`inflatieVerwacht` is één waarde) | Nieuwe sectie `scenarios` met indexatiecombinaties |
| ρ_DB, ρ_Wtp kostenopslagen | Niet aanwezig | Nieuwe velden in `beleid` of `actuarieel` |
| m betalingsfrequentie | Niet aanwezig | Nieuw veld in `actuarieel` |
| ω eindleeftijd | Hardcoded `MAX_AGE = 100` | Nieuw veld in `actuarieel` |
| geslacht (deelnemersinvoer) | n.v.t. (deelnemersinvoer, niet fondsdata) | Nieuwe deelnemersinvoer, Q_M en Q_V tafels nodig |

Het schema wordt de **som** van de vier module-behoeftes, niet de max. Geen conflicten, wel substantiële uitbreiding.

---

## 8. Regeling-dimensie per module

Het begrip "regeling" werkt verschillend in verschillende modules:

| Module | Regelingsdimensie | Opties | Reden |
|---|---|---|---|
| 1 — Huidige waarde | n.v.t. | — | KV is regime-agnostisch |
| 2 — Potje | Indirect via parameters | — | Compensatiedepot en bijstort hangen samen met transitieplan, maar de berekeningslogica is gelijk |
| 3 — Uitkeringsbenadering | **drie** opties | FPR / SPR-clean / SPR-hybride | Inner loop verschilt: FPR-update-formule, SPR met RTS en AG-herziening, SPR-hybride met rente-afdekking |
| 4 — Waardevergelijking | **twee** opties | SPR / FPR | Volgens spec §13: differentiatie via parametersets (verschillende φ, π_Wtp, ρ_Wtp, reserveringen), niet via engine |

Dit creëert een UI-vraag: kunnen de regeling-keuzes op module 3 en module 4 gekoppeld worden, of zijn het aparte selectors? Clean/hybride onderscheid bestaat niet in module 4 — dat betekent dat als de gebruiker op module 3 "SPR-clean" kiest, module 4 die automatisch naar "SPR" (generiek) vertaalt.

Voorgestelde resolutie: **één regeling-selector op top-niveau** die twee waarden heeft (SPR, FPR); binnen SPR kiest module 3 tussen clean en hybride via een sub-selector op scherm 3. Module 4 ziet alleen de top-niveau keuze. Dit is een sub-beslispunt voor later.

---

## 9. Consistentie-eisen

**Binnen module 4:** `calculator_specificatie.docx` §8 formuleert het expliciet — V_x^DB en V_x^Wtp moeten onder identieke grondslagen berekend worden (zelfde RTS, generatietafel, f, m, ω). Alleen π_DB/π_Wtp en ρ_DB/ρ_Wtp verschillen. Dit is een wiskundige hygiëne-eis die de module intern bewaakt via een shared-grondslagen-structuur.

**Binnen modules 1-3:** geen formele eis, maar de huidige code gebruikt consistent dezelfde Q-tafel en dezelfde rente-slider voor alle drie modules. Dat hoeft niet zo te blijven — module 3 zou bijvoorbeeld een andere projectierente kunnen gebruiken dan module 1. Wel aanbevolen voor interpretatie-zuiverheid.

**Tussen modules:** **geen** consistentie-eis. Module 1's KV en module 4's V_DB zijn in principe verschillende grootheden (andere grondslagen) en hoeven niet overeen te komen. Dit is architecturaal verdedigbaar maar **communicatie-gevoelig**:
- De gebruiker ziet op scherm 1 "KV = €130k" en op scherm 4 "V_DB = €125k" en vraagt: welke klopt?
- Antwoord: allebei, onder hun eigen aannames. De UI moet dit duidelijk maken — niet door te verbergen, maar door uit te leggen dat de modules verschillende vragen beantwoorden.

---

## 10. Relatie tot bestaande documenten

| Document | Wat het dekt | Relatie tot dit document |
|---|---|---|
| `calculator_specificatie.docx` | Module 4 volledig | Wordt sectie 4 in nieuwe `ENGINE_SPECIFICATIE_v1.md` |
| `DESIGN_engine_v0.md` | Huidige code modules 1-3 (impliciet) | Basis voor secties 1-3 in nieuwe spec |
| `SCHEMA_v1.md` | Dataset-schema voor modules 1-3 | Wordt uitgebreid naar `SCHEMA_v2.md` voor module 4 |
| `HANDOFF_R9.30.md` | Technische stand R9.30 | Ongewijzigd; beschrijft wat er *nu* is, niet waar we heen gaan |
| `STRATEGY_R9.30.md` | Strategische richting, Fase-roadmap | Vraagt aanvulling: Fase B wordt nu geïdentificeerd als spec-v1-schrijven, niet alleen SPR-implementatie |
| Dit document | Conceptuele architectuur | Normatief referentiekader voor alle vervolgwerk |

---

## 11. Vervolgstappen

De eerstvolgende substantiële sessie schrijft `ENGINE_SPECIFICATIE_v1.md`. Verder werk daarna:

### Sessie 1 (volgende): ENGINE_SPECIFICATIE_v1.md schrijven

- Vier modules in gelijke diepgang beschrijven
- Voor elke module: vraag, input, output, formules, fallbacks, validaties, scope-voorbehouden, reviewpunten
- Modules 1-3 tillen van `DESIGN_engine_v0.md` (impliciete beschrijving) naar spec-niveau (normatief)
- Module 4 overnemen uit `calculator_specificatie.docx` met redactionele aanpassingen voor consistentie
- Consistentie-eisen, parameterset-overlap, regeling-dimensie als eigen secties
- Resultaat: één document dat de hele engine vastlegt

### Sessie 2: SCHEMA_v2.md schrijven

- Uitbreiden van SCHEMA v1 met module-4-velden
- Validator uitbreiden
- Dataset-herkomst-strategie voor nieuwe velden (generatietafel is typisch `publiek` via AG; f is `afgeleid`; etc.)
- Geen code-wijziging in deze sessie, alleen schema-ontwerp

### Sessie 3+: implementatie

- `FONDS_DATASET` uitbreiden naar SCHEMA v2
- Engine-code voor module 4 bouwen (scherm 4, actuariële infrastructuur)
- Eventuele module-1-verrijkingen (geslacht, generatietafel) parallel

### Parallel spoor (optioneel)

- SSPF-publiek-v1 data-curatie: echte SSPF-cijfers als placeholder-vervanging voor modules 1-3
- SPR-clean / SPR-hybride inner loops in module 3

---

## 12. Voor de volgende Claude-sessie die spec-v1 schrijft

**Sessiedoel:** `ENGINE_SPECIFICATIE_v1.md` opleveren die in gelijke diepgang de vier modules beschrijft.

**Werkbestanden voor die sessie (alle uploaden):**
1. `21-04-2026_2216.html` (werkbestand R9.30; referentie voor modules 1-3)
2. `calculator_specificatie.docx` (wordt module 4 in de nieuwe spec)
3. `DESIGN_engine_v0.md` (basis voor modules 1-3 in de nieuwe spec)
4. `SCHEMA_v1.md` (huidige dataset-schema, voor parameterset-referentie)
5. `HANDOFF_R9.30.md` (technische stand)
6. `STRATEGY_R9.30.md` (strategische richting)
7. `ARCHITECTUUR_v1.md` (dit document, **leidend** voor de sessie)

**Eerste handeling:** lees `ARCHITECTUUR_v1.md` in zijn geheel. Deze sessie implementeert wat daar staat, voegt geen nieuwe architecturale concepten toe. Als er architecturale onzekerheid ontstaat tijdens het schrijven, beleg die expliciet en wacht op beslissing — niet zelf invullen.

**Werkmethode:**
- Nederlandse taal, technisch maar toegankelijk (zoals Hans schrijft)
- Markdown met tabellen en formules (LaTeX-notatie in code blocks waar dat leesbaar is)
- Per module vaste structuur: *vraag* / *input* / *output* / *formules* / *impliciete aannames* / *fallbacks* / *validaties* / *scope-voorbehouden* / *reviewpunten*
- Gebruik `calculator_specificatie.docx` als stilistisch model — zelfde niveau van zelfreflectie in §12-achtige secties per module
- Geen implementatiedetails (geen code, geen regel-referenties behalve in zeldzame reality-checks) — dit is specificatie, niet documentatie

**Scope-grenzen:**
- Alleen specificatie-schrijven; geen code-wijziging
- Alleen wat modules 1-4 doen zoals conceptueel vastgelegd; geen nieuwe modules
- Sub-beslispunten die uit het schrijfwerk oprijzen (bijv. regeling-selector-structuur, precieze geslacht-handling) expliciet benoemen in een `OPEN_VRAGEN`-sectie aan het eind, niet zelf beslissen

**Verwacht omvang:** 800-1200 regels. Dit wordt een substantieel document — het is de spec van de hele engine.

**Succescriterium:** Hans leest het, herkent alle vier modules correct beschreven, en kan op basis van dit document aan SCHEMA_v2 beginnen (sessie 2) zonder terug te moeten naar code of reverse-engineering.

---

## 13. Werkafspraken (onveranderd, voor de volledigheid)

- Nederlandse communicatie, technisch maar toegankelijk
- Release-nummering: deze spec is geen code-release; gebruikt eigen v1-nummer
- Tijdstamp via `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`
- File-output naar `/mnt/user-data/outputs/`
- Bij beslissingen met impact: korte analyse + opties + aanbeveling, wachten op Hans' akkoord
- Eerst lezen, dan denken, dan voorstellen
