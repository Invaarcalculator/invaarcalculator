# Reconstructie-log v3.0.92 → v3.0.106
Sessie-datum: 2026-05-11

## Aanpak
Optie A uit §7.11 HANDOFF_v3.0.106.md: werkdir-source v3.0.92 stap-voor-stap
uitbouwen naar v3.0.106 met behoud van traceerbare per-versie-bumps.

## Belangrijke ontdekking
De v3.0.92-zip-source bevatte feitelijk al een groot deel van v3.0.93..v3.0.95
mutaties (alle `v3.0.93`/`v3.0.94`/`v3.0.95`-comment-stempels aanwezig),
maar de `RELEASE_VERSION`-constant stond achter op `'3.0.89'`. De §8-
regressie was dus geen rollback van source-code maar een **versie-constant-
regressie**: source evolveerde door, alleen het zichtbare versielabel stond
stil. Werkafspraak 16 ("elke source-rakende turn bumpt RELEASE_VERSION +1")
voorkomt deze klasse drift in de toekomst.

## Per-versie reconstructie-werk
- **v3.0.93** (M1 UI-herorganisatie): swap geslacht ↔ leeftijd-caption
  deelnemer + partner, lifeexp-caption met data-lifeexp-for-attribuut, kpi-foot
  strook uit M1 weg, divider-soft tussen persoonsgegevens en hoog-laag,
  mid-markers op in-pen / in-y0 / in-pen-laag. + CSS .lifeexp-caption +
  .divider-soft. + live-update in updateOutputsInPlace.
- **v3.0.94** (vpvTotal-anker): grotendeels al in zip. Mijn werk: DG mid-
  marker 135% → 136%.
- **v3.0.95** (scherm-opruim): volledig al in zip (alle helpIcon-cleanup,
  default-state heeftPartner=false, buildFondsHelp+cascade-block in
  ui.audit-report.ts, test_fonds_modal/test_cascade verwijderd).
- **v3.0.96 t/m v3.0.106** (alles na "regressie-rand"): in één
  reconstructie-turn samengeperst:
  - v3.0.96-99: dropdowns + dropdown-pill CSS — bleek al in zip
  - v3.0.100: slider-bereiken in-pen 0..200k mid 100k, in-r 0..5 mid 2,5%
    — al in zip
  - v3.0.101: reset-knop in pane-header — al in zip
  - v3.0.102: topline-fondsnaam, FONDS.label injection — al in zip
  - v3.0.103: shortLabel-veld, modal-padding 18×20, line-height 1.45,
    :first-of-type → :first-child, "huidige aanspraak" → "huidige
    pensioenaanspraak", uitleg-modal herschreven (4 secties, eerste zonder
    heading, fondsShort-substitutie, UPO uitgeschreven, hoog-laag-uitleg,
    Reset-knop-uitleg), modal-renderer skip lege heading
  - v3.0.104: pane-actions flex row+wrap, padding-override weg
  - v3.0.105: .m2-controls border-top weg
  - v3.0.106: .m2-controls margin-top + padding-top weg
  - inhoudelijke tweaks: DG ?-icoon uit cascade-tabel, rapport-knop labels
    "Mijn rapport" → "Persoonlijk overzicht" / "Audit-rapport" →
    "Actuarieel overzicht", sub-action-notes weg, h1 padding 0 4px weg,
    spreidingstermijn ?-tekst uitgebreid met WAT DOET-sectie

## Test-updates
- test_browser_calc Test 2/3/4/5: ankers naar v3.0.95+ no-partner-default
  - M1-anker € 1.298.341 (was € 1.679.814 — met partner)
  - M2-anker € 1.611.130 (was € 2.174.362 — met partner)
  - DG-default 1.361 (was 1.35) — uit vpvTotal-anker v3.0.94
- test_print_report Test 3: assertions naar no-partner-default
- test_print_report Test 7: omgekeerd — schakel partner AAN ipv UIT
  (default is nu UIT); heeftPartner via select ipv checkbox; btn na re-render
  opnieuw acquireren

## Test-status na reconstructie
- test_aftrek_komma         ✓ 3/3
- test_browser_calc         ✓ 8/8
- test_cwstar_smoke         ✓ 4/4
- test_print_report         ✓ 7/7
- test_ui_spreidingN        ✓
- test_v3_cascade           ✓ 4/4 ankers
- test_hans_replication     7/10 (pre-existing, niet v3.0.96+ gerelateerd)
- test_browser              kapot — legacy multi-bestand pre-single-binary;
                            niet in §7-reconstructie-eis; staat in werkdir
                            maar wordt niet gerepareerd

## Binary-diff
Reconstructed v3.0.106:  290.089 bytes
Reference v3.0.106:      293.018 bytes
Δ:                            2.929 bytes (1.0%)

Geen inhoudelijke marker-verschillen. Δ vermoedelijk: RELEASE_DATE-string,
minor verschil in tussenliggende v3.0.93-95-comment-tekst die in reference
opgeschoond is, en in reconstructie nog cumulatief aanwezig.
