import * as fs from 'fs'
import { JSDOM } from 'jsdom'
const html = fs.readFileSync('/mnt/user-data/outputs/calculator.html', 'utf-8')
const dom = new JSDOM(html, { runScripts: 'dangerously' })
setTimeout(() => {
  const doc = dom.window.document
  const m1 = doc.querySelector('.kpi-card:not(.kpi-m2) .kpi-value')?.textContent?.trim()
  const m2_inf = doc.querySelector('.kpi-card.kpi-m2 .kpi-value')?.textContent?.trim()
  console.log(`KV M1: ${m1}`)
  console.log(`PPV M2 bij Oneindig (default 70-jarige bij DG=1.35, aftrek=6%): ${m2_inf}`)
  const r10 = doc.querySelector('input[value="10"]') as any
  r10.checked = true
  r10.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
  setTimeout(() => {
    const m2_10 = doc.querySelector('.kpi-card.kpi-m2 .kpi-value')?.textContent?.trim()
    console.log(`PPV M2 bij 10 jaar: ${m2_10}`)
    process.exit(0)
  }, 2000)
}, 5000)
