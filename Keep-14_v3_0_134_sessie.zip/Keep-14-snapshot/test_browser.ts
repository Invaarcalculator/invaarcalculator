import { JSDOM, VirtualConsole } from 'jsdom'
import * as fs from 'fs'

const HTML_PATH = '/mnt/user-data/outputs/scherm1.html'
const html = fs.readFileSync(HTML_PATH, 'utf-8')

async function main() {
  console.log('=== Browser-simulatie scherm1.html ===\n')

  const virtualConsole = new VirtualConsole()
  const errors: string[] = []
  virtualConsole.on('jsdomError', (err: Error) => {
    errors.push(`jsdomError: ${err.message}`)
  })
  virtualConsole.on('error', (msg: string) => {
    errors.push(`console.error: ${msg}`)
  })

  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    url: 'file:///scherm1.html',
    virtualConsole,
  })

  await new Promise((r) => setTimeout(r, 200))
  const doc = dom.window.document

  console.log('Test 1: script-execution schoon')
  console.log(`  Errors: ${errors.length === 0 ? 'geen ✓' : errors.join('; ')}`)
  console.log()

  console.log('Test 2: #app is gevuld')
  const app = doc.getElementById('app')
  console.log(`  app bestaat: ${app ? '✓' : '✗'}; content-grootte: ${app?.innerHTML.length}`)
  console.log()

  console.log('Test 3: view-toggle aanwezig')
  const toggles = doc.querySelectorAll('[data-view]')
  console.log(`  Toggle-knoppen: ${toggles.length} ${toggles.length === 2 ? '✓' : '✗'}`)
  console.log()

  console.log('Test 4: Casual KV wordt getoond')
  const kpi = doc.querySelector('.kpi-value')
  console.log(`  KPI: ${kpi ? `"${kpi.textContent?.trim()}" ✓` : '✗'}`)
  console.log()

  console.log('Test 5: Deelnemer-velden')
  const fields = doc.querySelectorAll('[data-field]')
  console.log(`  ${fields.length} velden; namen: ${Array.from(fields).map((f) => (f as HTMLElement).dataset.field).join(', ')}`)
  console.log()

  console.log('Test 6: Audit-view')
  const auditBtn = doc.querySelector('[data-view="audit"]') as HTMLElement | null
  auditBtn?.click()
  await new Promise((r) => setTimeout(r, 50))

  const auditHeader = doc.querySelector('.pane.audit h2')
  console.log(`  Header: ${auditHeader ? `"${auditHeader.textContent?.trim()}" ✓` : '✗'}`)
  const tables = doc.querySelectorAll('.pane.audit table')
  console.log(`  Tabellen: ${tables.length}`)
  const disclosures = doc.querySelectorAll('.disclosure-list li')
  console.log(`  Disclosures: ${disclosures.length} (verwacht 7)`)
  console.log()

  console.log('Test 7: Casual terug + wijzig leeftijd (debounce 150ms)')
  const casualBtn = doc.querySelector('[data-view="casual"]') as HTMLElement | null
  casualBtn?.click()
  await new Promise((r) => setTimeout(r, 50))

  const x0Input = doc.querySelector('[data-field="x0"]') as HTMLInputElement | null
  if (x0Input) {
    const initialKPI = doc.querySelector('.kpi-value')?.textContent?.trim()
    x0Input.value = '75'
    x0Input.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    // Direct na input: KPI moet NOG steeds oude waarde tonen (debounce)
    const immediateKPI = doc.querySelector('.kpi-value')?.textContent?.trim()
    console.log(`  Direct na input (moet nog oude waarde zijn): ${immediateKPI}`)

    // Wacht op debounce
    await new Promise((r) => setTimeout(r, 250))
    const debouncedKPI = doc.querySelector('.kpi-value')?.textContent?.trim()
    console.log(`  Na 250ms (post-debounce): ${debouncedKPI}`)
    console.log(`  KV @67: ${initialKPI} → KV @75: ${debouncedKPI}  ${initialKPI !== debouncedKPI ? '✓' : '✗'}`)
  }
  console.log()

  console.log('Test 7b: Performance — 10 leeftijd-wijzigingen in rap tempo')
  if (x0Input) {
    const start = Date.now()
    for (let age = 65; age <= 74; age++) {
      x0Input.value = String(age)
      x0Input.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    }
    const elapsed = Date.now() - start
    console.log(`  10 input-events: ${elapsed}ms (debounce voorkomt 10× recompute)`)
    await new Promise((r) => setTimeout(r, 250))
    const finalKPI = doc.querySelector('.kpi-value')?.textContent?.trim()
    console.log(`  Eind-KPI (x₀=74): ${finalKPI}`)
  }
  console.log()

  console.log('Test 7c: Enter doorbreekt debounce + KV-flash')
  if (x0Input) {
    // Zet een nieuwe waarde; verstuur input (start debounce); druk meteen Enter
    x0Input.value = '70'
    x0Input.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    // Binnen 50ms (ruim binnen debounce-window)
    await new Promise((r) => setTimeout(r, 10))
    const preEnterKPI = doc.querySelector('.kpi-value')?.textContent?.trim()
    console.log(`  Voor Enter (10ms na input, debounce pending): ${preEnterKPI}`)

    // Druk Enter
    const enterEvent = new dom.window.KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true })
    x0Input.dispatchEvent(enterEvent)
    await new Promise((r) => setTimeout(r, 10))

    const postEnterKPI = doc.querySelector('.kpi-value')?.textContent?.trim()
    const flashClass = doc.querySelector('.kpi-card')?.classList.contains('flash')
    console.log(`  Na Enter (10ms later): ${postEnterKPI}`)
    console.log(`  KV direct gewijzigd: ${preEnterKPI !== postEnterKPI ? '✓' : '✗'}`)
    console.log(`  Flash-class gezet: ${flashClass ? '✓' : '✗'}`)
  }
  console.log()

  console.log('Test 8: Partner uitschakelen')
  const partnerCheckbox = doc.querySelector('[data-field="heeftPartner"]') as HTMLInputElement | null
  if (partnerCheckbox) {
    partnerCheckbox.checked = false
    partnerCheckbox.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    await new Promise((r) => setTimeout(r, 50))
    const y0Row = doc.querySelector('[data-field-row="y0"]') as HTMLElement | null
    console.log(`  y0-rij verborgen: ${y0Row?.style.display === 'none' ? '✓' : '✗'}`)
    const kpiNoPartner = doc.querySelector('.kpi-value')?.textContent?.trim()
    console.log(`  KV zonder partner: ${kpiNoPartner}`)
  }
  console.log()

  if (errors.length > 0) {
    console.log('⚠ ERRORS:')
    errors.forEach((e) => console.log(`  - ${e}`))
    process.exit(1)
  }

  console.log('=== Alle browser-simulatie tests groen ✓ ===')
}

main().catch((e) => { console.error(e); process.exit(1) })
