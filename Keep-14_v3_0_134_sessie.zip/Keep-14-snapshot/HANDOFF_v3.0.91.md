# HANDOFF v3.0.91 — Invaarcalculator® release-klaar (ervaringssterfte CBS-onderbouwd, font-tokens, mid-markers)

**Datum:** Zo 10 mei 2026
**Versie:** v3.0.91
**Status:** Release-klaar, alle 6 testsuites groen
**Werkdir:** `/home/claude/Keep-14/`

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip:
  unzip /mnt/user-data/outputs/Keep-14_v3.0.91_complete.zip -d /home/claude/

Dependencies (na verse restore):
  cd /home/claude/Keep-14 && npm install --silent

Build calculator naar /mnt/user-data/outputs/calculator.html (default fonds=sspf):
  cd /home/claude/Keep-14 && npx tsx build.calc.ts

Build met expliciete fonds-keuze:
  cd /home/claude/Keep-14 && npx tsx build.calc.ts --fonds=sspf

Volledige regression-suite (6 test-files, alle groen verwacht):
  npx tsx test_browser_calc.ts        # M1/M2/cascade smoke + ankers
  npx tsx test_fonds_modal.ts         # Fonds-?-modal cascade-render
  npx tsx test_aftrek_komma.ts        # NL-decimaalkomma in cascade
  npx tsx test_cascade.ts             # Cascade-tabel + fonds_fonds2 absent
  npx tsx test_print_report.ts        # PDF-rapport-generator
  npx tsx test_v3_cascade.ts          # Engine-only cascade-ankers (regressie-anchor)
```

**Werkafspraken:**
- Stap-voor-stap, één wijziging per turn (Werkafspraak 12)
- Alle fonds-parameter-wijzigingen voorzien van bron-citaat in `fondsen/sspf/fonds.config.ts`
- "Persoonlijk pensioenvermogen" canonical in UI; geen "potje"
- Géén em-dashes (—) in user-facing tekst
- NL-decimaalkomma overal
- Sidebar-preview niet geschikt voor print/popup-tests (gebruik visuele review op vol scherm)
- **HANDOFF altijd in werkdir én zip** (Werkafspraak 13, 06-05-2026):
  Schrijf HANDOFF_vX.Y.Z.md ALTIJD eerst naar `/home/claude/Keep-14/HANDOFF_vX.Y.Z.md`,
  daarna kopiëren naar `/mnt/user-data/outputs/`. Bij het zippen wordt de werkdir
  ingepakt — als HANDOFF alleen in /outputs/ staat zit hij NIET in de zip-restore.

---

## 2. Architectuur — fonds-agnostisch via build-time-injectie (v3.0.76+)

**De codebase werkt voor één fonds per build.** Voor een tweede fonds maak je een tweede build vanaf dezelfde codebase:

```
/src/                          ← fonds-onafhankelijk (engine, UI, schema, types)
/fondsen/sspf/fonds.config.ts  ← SSPF-data: M1, M2, AanwendingsCascade
/fondsen/<id>/fonds.config.ts  ← (later) ABN of ander fonds
```

Esbuild path-alias `~fonds` → `/fondsen/<id>/fonds.config.ts`. Build-script accepteert `--fonds=<id>`, default `sspf`. Tsconfig.json heeft path-alias zodat tsx + type-check werken.

Voor een tweede fonds (later, bv. ABN):
1. `mkdir fondsen/abn`
2. Maak `fondsen/abn/fonds.config.ts` met ABN-data
3. `npx tsx build.calc.ts --fonds=abn`
4. Twee fondsen tegelijk in één HTML wordt **expliciet niet meer ondersteund**

---

## 3. Numerieke ankers (canoniek voor v3.0.91)

### UI-default scenario
Bij default-state (x0=70, pen=€100k, NP=€70k, DG=135%, fondsvermogen=€26.000m, bijstort=€500m, wettelijk=2%, RDR=€500m, compdepot=€400m, spreiding=∞, **f=0,90**):

- **KV M1** = € 1.679.814 (was € 1.633.637 in v3.0.89; stijging 2,83% door ervaringssterfte 1,0 → 0,90)
- **PPV M2** = € 2.174.362 (was € 2.112.708 in v3.0.89; stijging 2,92%)
- **Verdeelbaar overschot** = € 5.956 mln (cascade-eindrij; ongewijzigd want vpvTotal hangt af van fondsvermogen/DG, niet van f)
- **Verwachte sterfleeftijd (lifeExp_x0)** = 86,02 (was 85,31; +0,71 jaar)

### Cascade-test (test_v3_cascade.ts) — eigen inline params, **stabiele regressie-anchor**:
- KV M1 = € 543.096
- ppkTotal v3.0 N=10 = € 569.457 (Δ 4,85%)
- ppkTotal v3.0 N=∞ = € 569.889 (Δ 4,93%)
- ppkTotal R9.30 LEG = € 572.166 (Δ 5,35%)

Deze ankers zijn **engine-only** met `ervaringsSterfte: 1.0` in de testfile zelf, en bewegen niet mee met fonds.config-wijzigingen.

---

## 4. Versie-overzicht v3.0.89 → v3.0.91

### v3.0.90 — Ervaringssterfte CBS-onderbouwd [DECISION]
**Wijziging:** `ervaringsSterfte` van 1,0 (placeholder) naar **0,90** in beide M1+M2 blokken van `fondsen/sspf/fonds.config.ts`.

**Onderbouwing:** Conservatieve schatting voor SSPF-populatie (hoog-opgeleid wit-boord, top-inkomensquintiel). Bron CBS levensverwachting naar inkomen (vzinfo.nl, peildata 2019/2022): 65-jarige mannen hoogste inkomensquintiel 20,5j vs laagste 16,4j (verschil 4,1j); CBS welvaartsstudie verschil hoogste vs laagste welvaartsgroep ruim 4j op 65-jarige leeftijd. f=0,90 is conservatief midpoint t.o.v. industrie-benchmark hoog-opgeleide witte-boorden-fondsen (typisch 0,85-0,95).

**Files:** `fondsen/sspf/fonds.config.ts` (SSPF_M1 + SSPF_M2 met volledige bron-comment), `src/schema.v2.ts` (.describe-tekst v1.4 → v1.5), `test_browser_calc.ts` (anker-literals 1.633.637 → 1.679.814 en 2.112.708 → 2.174.362).

**Beperking gedocumenteerd:** vlak (geen leeftijds-/gender-differentiatie); v2-uitbreidingspad in §11.13 voor leeftijdsafhankelijke vorm. Echt SSPF-fondsspecifiek getal vraagt niet-publieke ABTN-data. Disclaimer-update **bewust uitgesteld** per user-keuze.

### v3.0.91-a — Font-size tokens (uniforme schaal voor getallen) [DECISION]
**Probleem:** UI rendeerde getallen op 9 verschillende sizes (10/11/12/13/15/18/22/26-mobile/32 px). M1 KV-anker (32px) en M2 ppkTotal-anker (22px) waren visueel ongelijk → suggereerde dat M1 belangrijker was dan M2. Detail-laag (10/11/12 px) was verspreid zonder semantische reden.

**Oplossing:** drie CSS-tokens in `:root` van `build.calc.ts`:
```css
--num-l: 28px;   /* anker-waarden (M1 KV, M2 ppkTotal) — gelijk-prominent */
--num-m: 16px;   /* sub-aggregaten (formule-componenten, KV-decompositie, cascade-totaal) */
--num-s: 12px;   /* detail (cascade-rijen, tabel-cellen, footer, mod-tags, slider-markers) */
```
Type-ratio 28/16/12 = 1,75× / 1,33× — ritmische schaal. **Ankers nu gelijkwaardig** (allebei `--num-l`); M2-formule-decompositie (formule-rijen + sub-totaal) op `--num-m`; alle detail op `--num-s`.

**12 selectoren herwezen:** `.kpi-value`, `.kpi-formula-row .kpi-formula-val`, `.kpi-formula-total .kpi-formula-val`, `.kpi-formula-foot`, `.kpi-sub-value`, `.kpi-foot`, `.kpi-delta`, `.cascade-row .cascade-val`, `.cascade-row .cascade-markers`, `.cascade-total .cascade-val strong`, `.cohort-table`, `.modtag`. Mobile-override op `.kpi-value` (was 26px) verwijderd: 28px werkt cross-device.

### v3.0.91-b — Mid-markers op cascade-sliders
**Probleem:** 6 cascade-sliders toonden alleen min/max-marker (bv. "€ 20.000 mln" / "€ 32.000 mln"); geen midden-referentie. Bestaande conventie (rente-slider 0% / 2% / 4%) was nog niet doorgetrokken.

**Oplossing:** `<span class="marker-mid">` toegevoegd aan elke cascade-slider in `src/ui.app.ts`. CSS bestond al (`.slider-markers .marker-mid { text-align: center; flex: 1; }` in build.calc.ts), geen CSS-wijziging nodig.

**Mid-waarden (geometrisch midden van range):**

| Slider | Min | **Mid** | Max | SSPF-default |
|---|---|---|---|---|
| Fondsvermogen | € 20.000 mln | **€ 26.000 mln** | € 32.000 mln | € 26.000 mln ⚓ |
| Dekkingsgraad | 100% | **135%** | 170% | 135% ⚓ |
| Bijstort | € 0 | **€ 1.250 mln** | € 2.500 mln | € 500 mln |
| Wettelijke reserves | 0% | **2,5%** | 5% | 2% |
| Risicodelingsreserve | € 0 | **€ 750 mln** | € 1.500 mln | € 500 mln |
| Compensatiedepot | € 0 | **€ 500 mln** | € 1.000 mln | € 400 mln |

⚓ = mid valt samen met SSPF-default (visuele bevestiging "halverwege = SSPF").

---

## 5. Tests-status v3.0.91

Alle 6 test-suites groen:

| Test | Wat het dekt |
|------|---|
| test_browser_calc | UI smoke, **nieuwe KV/PPV-ankers** (1.679.814 / 2.174.362), cascade-sliders aanwezig + defaults |
| test_fonds_modal | Fonds-?-modal opent, cascade-tabel render, fonds-naam zichtbaar |
| test_aftrek_komma | NL-decimaalkomma in cascade-tabel + fonds-modal |
| test_cascade | Cascade-tabel verschijnt na klik, fonds_fonds2 afwezig |
| test_print_report | PDF-rapport bevat KV, PPV, cascade-data |
| test_v3_cascade | **Engine-only ankers** (stabiele regressie-anchor, ongewijzigd) |

**Geen test-selector-wijzigingen** in v3.0.90/v3.0.91 — alleen anker-literals in `test_browser_calc.ts` bijgewerkt.

---

## 6. Architecturele aandachtspunten genoteerd

- **DG-afhankelijke bijstort** (€500m/€650m/€850m staffels in fondsdata-comment) niet gemodelleerd; gebruiker kan inconsistente combinaties verkennen via slider zonder waarschuwing
- **Engine modelleert standaardregel** (Bijlage 2a Pw); vba-fondsen niet correct (in disclaimer benoemd)
- **Cascade in fonds-?-modal en M1/2-pane tonen dezelfde getallen**: M1/2-pane is interactief, fonds-modal toont read-only-versie via `buildAanwendingsCascadeBlock`
- **vpvAftrekPct in m2-state is afgeleide**; bron-of-waarheid zijn cascadeOverrides + fondsvermogen + DG + bijstort. UI synchroniseert in recompute()-start
- **ageFromDob snap-to-integer** regelt 365.25-edge rond verjaardagen
- **Alle aanrakingspunten cascade-componenten triggeren full render()** (niet `updateOutputsInPlace`), want afwijking-markers en banner moeten verspringen + cascade-tabel-getallen mee-bewegen
- **Verdeelbaar overschot — uw aandeel** hangt af van zes parameters: uw KV (M1-deelnemer-data) + spreidingstermijn + rekenrente + fondsdemografie (verborgen) + sterftekansentabel (AG2024) + de cascade-componenten. Engine-formule: `ppk(i) = KV(i) + x_fonds × CW_star(i)` met `x_fonds = (M − CW_voor_fonds) / CW_star_fonds`
- **Ervaringssterfte 0,90 is vlak** (geen leeftijds-/gender-differentiatie); raakt KV via q_fonds = f · q_AG2024; vpvTotal blijft via DG-anker ongewijzigd dus cascade-balans verandert niet, alleen individuele KV

---

## 7. PENDING action items

### Actuaris-bevindingen — actief binnen scope (gepensioneerden + publieke informatie)

Vier punten resterend uit de v3.0.91 deep-dive:

1. **C1 — Compensatiedepot-routing transparantie** (HOOG)
   €400 mln wordt uit cascade geknipt zonder zichtbare toekenning aan een groep. Voor gepensioneerden onduidelijk waar geld heen gaat. Voorstel: help-icon-tooltip op cascade-rij "Compensatiedepot" met tekst "toegekend aan actieven, niet aan gepensioneerden". Gebruikt bestaand `helpIcon()`-patroon.

2. **D2 — RDR labelen als bestemd voor pensioengerechtigden** (MIDDEL)
   €500 mln RDR komt later via solidariteits-/risicodelingsmechanisme deels terug naar gepensioneerden. Tool toont alleen "weg uit cascade". Voorstel: vergelijkbare help-icon-tooltip; kan in dezelfde turn als C1.

3. **D5 — DG-afhankelijke bijstort-staffel** (HOOG)
   Bijstort vast op €500m, beweegt niet mee met DG-slider. Bij DG-tegenvaller stijgt werkgeversbijstort juist (publieke staffel: ≥135% €500m, 130-135% €650m, 125-130% €850m). Voor gepensioneerden misleidend. DG<125% staffel-waarde uit publieke bron nog te verifiëren. Twee opties: visuele waarschuwing onder slider, óf functioneel meebeweeg-mechanisme.

4. **A3 — Broken-heart factoren uit AG-2018-publicatie** (MIDDEL)
   Huidige placeholders (`bh₀(M)=1,50`, `bh₀(V)=1,25`, lineair 5j) in `engine.m1.ts` regel 489-500 zijn bron-comment "todo AG-2018". Echte waarden uit AG-werkgroep "Sterfte na overlijden partner" (2018) opzoeken. Effect: 1-3% op KV_NP, dus ~0,3-1% op KV-totaal.

### Buiten scope (forward-projectie + nieuw pensioen-omrekening; uitgesteld per user)
- **D3** — Variabele uitkering-projectie post-invaren (M3 Monte Carlo)
- **D4** — Partner-na-overlijden-uitkering-per-maand-projectie
- **PPV → maandbedrag onder SPR** — omrekening naar nieuw pensioen

### Buiten scope (geaccepteerd voor educatieve scope, met disclaimer)
- **A1** — Vlakke r=2,5% vs UFR-curve (voor gepensioneerden duratie 8-12 → effect <1%)
- **A4** — π=0 (geen voorwaardelijke indexatie)
- **A5** — Pensioenleeftijd 65 hardcoded in cohort-proxy (effect <0,5% via ratio-cancellatie)
- **B1** — 67%-toets art. 150n lid 4 Pw (bestuurs-verantwoordelijkheid, niet gepensioneerde-vraag)
- **B3** — Geen vba-pad
- **B4** — N=1000 als ∞-proxy (engineering-correct via ratio-cancellatie)
- **C2** — SSPF-genderweging hardcoded in engine.m2 (pas relevant bij ABN-build)
- **C3** — NP-proxy (70%, partner −3j, allen gehuwd) — <0,5% effect via ratio-cancellatie

### Strategisch (eerder geïdentificeerd, nog steeds open)
5. **Fondsdemografie zichtbaar/aanpasbaar maken** — preset 'gesloten' nu verborgen; beïnvloedt PPV-uitkomst sterk via `x_fonds`
6. **M1 KV-fix actieve deelnemer**
7. **M3 Monte Carlo** (overlapt met D3)
8. **M4 DB-vs-WTP**

### Operationeel
9. **Hosting-deployment** naar invaarcalculator.nl
10. **iPad-issue** (HTML opent niet) — niet gediagnosticeerd
11. **Visuele review v3.0.91** in echte browser door user (font-tokens + mid-markers)

### Code-opruim (latere refactor)
12. **Backward-compat-symbols opruimen**: `SSPF_M1_PLACEHOLDER`, `SSPF_M2_PLACEHOLDER`, `FONDSEN`, `FondsId` nog gebruikt in `src/test_engine.ts`, `src/test_engine.m2.ts`, `src/ui.m1.ts`. Allen kunnen na verificatie weg ten gunste van directe `FONDS`-import

---

## 8. Source-files-overzicht (canoniek voor v3.0.91)

```
/home/claude/Keep-14/
├── src/
│   ├── ui.app.ts              # main, ~1885 regels (M1/2-pane + cascade-sliders gegenereerd hier)
│   ├── ui.m2.ts               # M2-render (KPI als formule-card + spreiding-radio)
│   ├── ui.m1.ts               # M1-render
│   ├── ui.print.ts            # PDF-rapport
│   ├── ui.shared.ts           # gedeelde helpers
│   ├── engine.m1.ts           # KV-berekening (broken-heart placeholders regel 489-500)
│   ├── engine.m2.ts           # PPV-berekening (standaardregel)
│   ├── schema.v2.ts           # types + zod-validatie (ervaringsSterfte v1.5)
│   ├── fondsdataset.ts        # bridge: importeert FONDS van ~fonds
│   └── fondsdataset.types.ts  # fonds-onafhankelijke types
├── ag2024.json                # AG-prognosetafels (geinjecteerd in HTML-template)
├── fondsen/
│   └── sspf/
│       └── fonds.config.ts    # SSPF-bron-van-waarheid (ervaringsSterfte 0,90)
├── build.calc.ts              # build-script (--fonds=<id>-flag, font-tokens in :root)
├── tsconfig.json              # paths-alias '~fonds'
├── package.json               # tsx + jsdom + esbuild + zod
├── test_browser_calc.ts       # ankers 1.679.814 / 2.174.362
├── test_fonds_modal.ts
├── test_aftrek_komma.ts
├── test_cascade.ts
├── test_print_report.ts
├── test_v3_cascade.ts         # engine-only stabiele regressie (ongewijzigd)
└── HANDOFF_v3.0.91.md         # ← deze file
```
