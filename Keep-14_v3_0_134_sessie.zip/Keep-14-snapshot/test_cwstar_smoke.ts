/**
 * Smoke-test voor cw_star-uitbreiding (Stap 1 v3.0)
 *
 * Doel: bevestig dat
 *   1. computeM1 zonder m2Context → cw_star_op/np = undefined
 *   2. computeM1 mét m2Context → cw_star_op/np gevuld, beide ≤ KV_op/np
 *   3. cw_star bij N=10 < cw_star bij N=1000 (langere spreiding → lager q-gewogen)
 *      Wacht: het is precies andersom. q(h, N) = min(floor(h)/N, 1).
 *      Bij N=1000 is q veel kleiner → cw_star kleiner. Bij N=10 sneller naar 1.
 *      Dus cw_star(N=10) > cw_star(N=1000). ✓
 *   4. Lineariteit-check: ppk = KV + x · CW_star sluit OP+NP = totaal.
 */
import * as fs from 'fs'
import { computeM1 } from './src/engine.m1'
const ag = JSON.parse(fs.readFileSync('/home/claude/Keep-14/ag2024.json', 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag }

const deelnemer = {
  x0: 67, g: 'M' as const,
  heeftPartner: true,
  x_partner: 65, g_y: 'V' as const,
  pen: 30000, y0: 21000,
}

const params = {
  r: 0.02, sterftekansTabelId: 'AG2024' as const,
  t0: 2026, ervaringsSterfte: 1.0, m: 12,
  annuiteitsconventie: 'arrears' as const, pi: 0,
  fondsvermogen: 27202e6, omega: 110,
  uitvoeringskostenJaarlijks: null, kostenOpslagPct: null,
}

console.log('=== Smoke-test cw_star-uitbreiding (Stap 1 v3.0) ===\n')

// Test 1: zonder m2Context
const r1 = computeM1(deelnemer, params)
console.log(`[1] Zonder m2Context: cw_star_op=${r1.cw_star_op ?? 'undefined'}, cw_star_np=${r1.cw_star_np ?? 'undefined'}`)
console.log(`    KV_OP=${r1.KV_OP.toFixed(0)}, KV_NP=${r1.KV_NP.toFixed(0)}, KV=${r1.KV.toFixed(0)}`)
const ok1 = r1.cw_star_op === undefined && r1.cw_star_np === undefined
console.log(`    ${ok1 ? '✓' : '✗'} cw_star velden ontbreken zonder m2Context\n`)

// Test 2: met N=10
const r2 = computeM1(deelnemer, params, { spreidingN: 10 })
console.log(`[2] Met N=10: cw_star_op=${r2.cw_star_op?.toFixed(0)}, cw_star_np=${r2.cw_star_np?.toFixed(0)}`)
console.log(`    Ratio cw_star_op/KV_OP = ${((r2.cw_star_op ?? 0) / r2.KV_OP).toFixed(4)}`)
console.log(`    Ratio cw_star_np/KV_NP = ${((r2.cw_star_np ?? 0) / r2.KV_NP).toFixed(4)}`)
const ok2a = (r2.cw_star_op ?? -1) >= 0 && (r2.cw_star_op ?? Infinity) <= r2.KV_OP
const ok2b = (r2.cw_star_np ?? -1) >= 0 && (r2.cw_star_np ?? Infinity) <= r2.KV_NP
console.log(`    ${ok2a ? '✓' : '✗'} 0 ≤ cw_star_op ≤ KV_OP`)
console.log(`    ${ok2b ? '✓' : '✗'} 0 ≤ cw_star_np ≤ KV_NP\n`)

// Test 3: vergelijking N=10 vs N=1000
const r3 = computeM1(deelnemer, params, { spreidingN: 1000 })
console.log(`[3] Met N=1000: cw_star_op=${r3.cw_star_op?.toFixed(0)}, cw_star_np=${r3.cw_star_np?.toFixed(0)}`)
console.log(`    Ratio cw_star_op/KV_OP = ${((r3.cw_star_op ?? 0) / r3.KV_OP).toFixed(4)}`)
const ok3 = (r3.cw_star_op ?? Infinity) < (r2.cw_star_op ?? 0)
console.log(`    ${ok3 ? '✓' : '✗'} cw_star_op(N=1000) < cw_star_op(N=10) — lange spreiding ⇒ kleinere q-weging\n`)

// Test 4: lineariteit-check met fictief x_fonds
const x_fonds = 0.10  // bijv. 10% fondsoverschot na schaling
const ppk_op  = r2.KV_OP + x_fonds * (r2.cw_star_op ?? 0)
const ppk_np  = r2.KV_NP + x_fonds * (r2.cw_star_np ?? 0)
const ppk_tot = r2.KV    + x_fonds * ((r2.cw_star_op ?? 0) + (r2.cw_star_np ?? 0))
const sluiting = Math.abs((ppk_op + ppk_np) - ppk_tot)
console.log(`[4] Lineariteit-sluitingscontrole bij x*=0.10:`)
console.log(`    ppk_OP=${ppk_op.toFixed(2)} + ppk_NP=${ppk_np.toFixed(2)} = ${(ppk_op+ppk_np).toFixed(2)}`)
console.log(`    ppk_totaal direct      = ${ppk_tot.toFixed(2)}`)
console.log(`    Verschil               = ${sluiting.toExponential(2)}`)
console.log(`    ${sluiting < 1e-6 ? '✓' : '✗'} Sluiting binnen 1e-6\n`)

const allPassed = ok1 && ok2a && ok2b && ok3 && sluiting < 1e-6
console.log(allPassed ? '=== Alle 4 smoke-tests GROEN ===' : '=== TESTS FAALDEN ===')
process.exit(allPassed ? 0 : 1)
