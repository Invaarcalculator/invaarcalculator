#!/usr/bin/env node
/**
 * Build scherm1.html — single-file artefact.
 *
 * 1. Bundel src/ui.m1.ts (+ dependencies: schema.v2, engine.m1, fondsdataset, zod)
 *    via esbuild naar één IIFE-blob
 * 2. Lees ag2024.json
 * 3. Lees template.html
 * 4. Substitueer: __AG2024__ data, __BUNDLE__ js
 * 5. Schrijf output
 */

import * as esbuild from 'esbuild'
import * as fs from 'fs'
import * as path from 'path'

const BUILD_DIR = '/home/claude/m1_build'
const OUT_HTML = '/mnt/user-data/outputs/scherm1.html'

async function build(): Promise<void> {
  console.log('=== Build scherm1.html ===\n')

  // 1. Bundel
  console.log('[1/4] Bundel TypeScript via esbuild...')
  const result = await esbuild.build({
    entryPoints: [path.join(BUILD_DIR, 'src/ui.m1.ts')],
    bundle: true,
    format: 'iife',
    platform: 'browser',
    target: 'es2020',
    minify: true,
    write: false,
    logLevel: 'warning',
  })
  const bundle = result.outputFiles[0].text
  console.log(`  Bundle: ${(bundle.length / 1024).toFixed(1)} KB (minified)`)

  // 2. AG2024 JSON
  console.log('[2/4] Lees AG2024 data...')
  const ag2024 = fs.readFileSync(path.join(BUILD_DIR, 'ag2024.json'), 'utf-8')
  console.log(`  AG2024: ${(ag2024.length / 1024).toFixed(1)} KB`)

  // 3. Template
  console.log('[3/4] Wrap in HTML-template...')
  const html = `<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WTP-pensioencalculator — scherm 1 (M1-engine v2.0)</title>
<style>
  * { box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    max-width: 960px;
    margin: 1.5rem auto;
    padding: 0 1rem;
    color: #222;
    line-height: 1.5;
    background: #f8f8f8;
  }
  h1 {
    font-size: 1.3rem;
    margin: 0 0 0.3rem;
    color: #004488;
  }
  h2 { font-size: 1.15rem; margin-top: 0; }
  h3 { font-size: 1rem; color: #555; margin-top: 1.2rem; margin-bottom: 0.5rem; }
  .subtitle { font-size: 0.9rem; color: #666; margin-bottom: 1rem; }
  .view-toggle {
    display: flex;
    gap: 0.5rem;
    margin: 1rem 0;
  }
  .view-toggle button {
    flex: 1;
    padding: 0.6rem 1rem;
    border: 1px solid #ccc;
    background: #fff;
    cursor: pointer;
    border-radius: 4px;
    font-size: 0.95rem;
  }
  .view-toggle button.active {
    background: #004488;
    color: white;
    border-color: #004488;
  }
  .pane {
    border: 1px solid #ccc;
    padding: 1.3rem 1.5rem;
    background: #fff;
    border-radius: 4px;
    margin-bottom: 1rem;
  }
  .pane.casual { border-left: 4px solid #4a7bc8; }
  .pane.audit { border-left: 4px solid #c8994a; background: #fff8ed; }
  .intro { color: #555; font-size: 0.95rem; margin: 0.5rem 0 1rem; }
  .form { margin: 1rem 0; }
  .field {
    display: grid;
    grid-template-columns: 260px 1fr;
    gap: 0.7rem;
    align-items: center;
    margin-bottom: 0.7rem;
  }
  .field label { font-size: 0.92rem; }
  .field input, .field select {
    padding: 0.4rem 0.6rem;
    font-size: 0.95rem;
    border: 1px solid #aaa;
    border-radius: 3px;
    width: 100%;
    max-width: 260px;
  }
  .field input[type="checkbox"] {
    justify-self: start;
    width: auto;
  }
  .disclosure {
    grid-column: 2;
    font-size: 0.8rem;
    color: #886600;
    background: #fff8e0;
    padding: 0.3rem 0.5rem;
    border-left: 3px solid #c8994a;
    margin-top: 0.2rem;
  }
  .disclosure-inline {
    font-size: 0.82rem;
    color: #886600;
    background: #fff8e0;
    padding: 0.3rem 0.5rem;
    border-left: 3px solid #c8994a;
    margin-top: 0.3rem;
  }
  .rente-control {
    margin-top: 1rem;
    padding: 0.8rem;
    background: #f0f6ff;
    border-radius: 4px;
  }
  .rente-control label {
    display: block;
    margin-bottom: 0.4rem;
    font-size: 0.9rem;
  }
  .rente-control input[type="range"] { width: 100%; }
  .output { margin-top: 1.3rem; }
  .kpi-card {
    background: #f0f6ff;
    padding: 1.2rem;
    border-radius: 4px;
    text-align: center;
    transition: background 0.3s ease;
  }
  .kpi-card.flash {
    animation: kpi-flash 0.45s ease-out;
  }
  @keyframes kpi-flash {
    0%   { background: #f0f6ff; box-shadow: 0 0 0 0 rgba(0, 68, 136, 0); }
    25%  { background: #d6e7ff; box-shadow: 0 0 0 4px rgba(0, 68, 136, 0.15); }
    100% { background: #f0f6ff; box-shadow: 0 0 0 0 rgba(0, 68, 136, 0); }
  }
  .kpi-label { font-size: 0.9rem; color: #555; }
  .kpi-value {
    font-size: 2.2rem;
    font-weight: 600;
    color: #004488;
    margin: 0.4rem 0;
  }
  .kpi-breakdown { font-size: 0.85rem; color: #555; margin-top: 0.6rem; }
  .error { background: #fee; color: #a00; padding: 0.7rem; border-radius: 3px; }
  .meta-note {
    font-size: 0.82rem;
    color: #666;
    margin-top: 0.8rem;
    padding-top: 0.6rem;
    border-top: 1px dashed #ddd;
  }
  table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 0.4rem;
    font-size: 0.9rem;
  }
  th, td {
    border: 1px solid #ddd;
    padding: 0.45rem 0.7rem;
    text-align: left;
    vertical-align: top;
  }
  th { background: #eee; font-weight: 600; }
  td.num {
    text-align: right;
    font-variant-numeric: tabular-nums;
    font-family: 'SF Mono', Consolas, monospace;
  }
  tr.display-decompositie td { background: #fafafa; }
  tr.display-deepdive td { background: #f2f2f2; color: #555; }
  tr.display-diagnose td { background: #fff0f0; color: #884444; }
  .specref {
    font-family: monospace;
    font-size: 0.8rem;
    color: #666;
  }
  code {
    font-family: monospace;
    background: #eee;
    padding: 1px 4px;
    border-radius: 2px;
    font-size: 0.88rem;
  }
  .info { cursor: help; color: #c8994a; font-size: 0.9rem; }
  .disclosure-list {
    font-size: 0.85rem;
    padding-left: 1.3rem;
    line-height: 1.55;
  }
  .disclosure-list li { margin-bottom: 0.3rem; }
  .footer {
    font-size: 0.78rem;
    color: #888;
    text-align: center;
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid #ddd;
  }
</style>
</head>
<body>

<h1>WTP-pensioencalculator — scherm 1</h1>
<p class="subtitle">Module 1 — Huidige waarde van uw aanspraak. Gebouwd op SCHEMA v2.0 + ENGINE SPEC v2.2.9.</p>

<div id="app"></div>

<div class="footer">
  Demo-calculator. Waarden zijn placeholders (SSPF-defaults uit R9.30), niet officiële SSPF-publicatie. CC BY-NC 4.0.
</div>

<script>window.__AG2024__ = ${ag2024};</script>
<script>${bundle}</script>

</body>
</html>`

  // 4. Write
  console.log('[4/4] Schrijf output...')
  fs.mkdirSync(path.dirname(OUT_HTML), { recursive: true })
  fs.writeFileSync(OUT_HTML, html)
  const totalSize = html.length
  console.log(`\n✓ Geschreven: ${OUT_HTML}`)
  console.log(`  Totale omvang: ${(totalSize / 1024).toFixed(1)} KB`)
  console.log(`  Verdeling: bundle ${(bundle.length / 1024).toFixed(1)} KB + AG2024 ${(ag2024.length / 1024).toFixed(1)} KB + HTML/CSS ~${((totalSize - bundle.length - ag2024.length) / 1024).toFixed(1)} KB`)
}

build().catch((err) => {
  console.error('Build failed:', err)
  process.exit(1)
})
