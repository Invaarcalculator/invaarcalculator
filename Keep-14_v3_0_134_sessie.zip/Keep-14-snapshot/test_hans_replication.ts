/**
 * test_hans_replication.ts
 *
 * Reproduceert Hans-Haringa-notitie 2-mei-2026 Bijlage 1 tabel:
 * Effect levenslange spreiding (N=1000) versus 10 jaar default,
 * uitgedrukt als verschil in opslag (procentpunten) per leeftijd, bij DG=135%.
 *
 * Hans-tabel verwacht (uniform demografie, Gompertz):
 *   30j: +40,5pp / 40j: +27,0pp / 50j: +12,0pp / 60j: -1,7pp /
 *   65j: -4,5pp  / 70j: -5,3pp  / 75j: -6,0pp  / 80j: -6,2pp /
 *   85j: -5,9pp  / 90j: -5,2pp
 *
 * Onze engine gebruikt AG2024 (geen Gompertz) en SSPF-genderweging,
 * dus afwijking van enkele procentpunten is geaccepteerd. De TEST-CRITERIUM
 * is RICHTING: pensioengerechtigden ≥65 moeten NEGATIEF effect zien
 * van langere spreiding (consistent met Hans-model). Pre-fix faalt deze test;
 * post-fix moet hij slagen.
 */

import { computeM1 } from './src/engine.m1'
import { computeM2 } from './src/engine.m2'
import { SSPF_M1_PLACEHOLDER, SSPF_M2_PLACEHOLDER } from './src/fondsdataset'
import * as fs from 'fs'

const ag = JSON.parse(fs.readFileSync('./ag2024.json', 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag }

interface ResultRow {
  age: number
  opslagN10: number
  opslagN1000: number
  diff: number
  hansVerwacht: number
  richtingOk: boolean
  ordeOk: boolean
}

const hansVerwacht: Record<number, number> = {
  30: +40.5,
  40: +27.0,
  50: +12.0,
  60: -1.7,
  65: -4.5,
  70: -5.3,
  75: -6.0,
  80: -6.2,
  85: -5.9,
  90: -5.2,
}

function run(): { rows: ResultRow[]; passed: number; failed: number } {
  const rows: ResultRow[] = []
  let passed = 0
  let failed = 0

  for (const age of Object.keys(hansVerwacht).map(Number)) {
    const dat = {
      x0: age,
      pen: 100000,
      g: 'M' as const,
      heeftPartner: false,
      y0: null,
      x_partner: null,
      g_y: 'M' as const,
    }
    const params10 = {
      ...SSPF_M2_PLACEHOLDER,
      spreidingN: 10,
      vpvAftrekPct: 0.10,
      demografie: { soort: 'preset' as const, preset: 'uniform' as const },
    }
    const params1000 = { ...params10, spreidingN: 1000 }

    const m1_10 = computeM1(dat, SSPF_M1_PLACEHOLDER, { spreidingN: 10 })
    const m1_1000 = computeM1(dat, SSPF_M1_PLACEHOLDER, { spreidingN: 1000 })
    const ppk10 = computeM2(dat, m1_10, params10).ppkTotal
    const ppk1000 = computeM2(dat, m1_1000, params1000).ppkTotal
    const opslag10 = (ppk10 / m1_10.KV - 1) * 100
    const opslag1000 = (ppk1000 / m1_1000.KV - 1) * 100
    const diff = opslag1000 - opslag10
    const verwacht = hansVerwacht[age]

    // Richting check: teken van diff moet matchen met Hans
    const richtingOk = Math.sign(diff) === Math.sign(verwacht) || Math.abs(verwacht) < 0.5
    // Orde check: |diff - verwacht| binnen 5pp ruimte (verschil Gompertz vs AG2024)
    const ordeOk = Math.abs(diff - verwacht) <= 5

    if (richtingOk && ordeOk) passed++
    else failed++

    rows.push({ age, opslagN10: opslag10, opslagN1000: opslag1000, diff, hansVerwacht: verwacht, richtingOk, ordeOk })
  }

  return { rows, passed, failed }
}

const { rows, passed, failed } = run()

console.log('Hans-replicatie test (uniform demografie, DG=1.35, aftrek=0.10)')
console.log('=================================================================')
console.log('Leeftijd | opslag N=10 | opslag N=∞ | verschil | Hans verwacht | richting | orde')
console.log('---------|-------------|------------|----------|---------------|----------|------')
for (const r of rows) {
  const fmt = (x: number) => `${x >= 0 ? '+' : ''}${x.toFixed(1)}pp`
  const richting = r.richtingOk ? '✓' : '✗'
  const orde = r.ordeOk ? '✓' : '✗'
  console.log(
    `${String(r.age).padStart(8)} | ${(r.opslagN10.toFixed(1) + '%').padStart(11)} | ${(r.opslagN1000.toFixed(1) + '%').padStart(10)} | ${fmt(r.diff).padStart(8)} | ${fmt(r.hansVerwacht).padStart(13)} |    ${richting}     |  ${orde}`
  )
}
console.log()
console.log(`Resultaat: ${passed} ✓ / ${failed} ✗ van ${rows.length} cohorten`)
process.exit(failed > 0 ? 1 : 0)
