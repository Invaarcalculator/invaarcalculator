/**
 * UI-test: applyM2SliderInput met spreidingN-radio + verifieer SCHEMA-acceptatie.
 */
import { applyM2SliderInput } from './src/ui.m2'
import { M2 } from './src/schema.v2'

const baseParams = M2.parameterset.parse({
  r: 0.02, sterftekansTabelId: 'AG2024',
  t0: 2026, ervaringsSterfte: 1.0, m: 12,
  annuiteitsconventie: 'arrears', pi: 0,
  fondsvermogen: 27202, omega: 110,
  dekkingsgraad: 1.15, compensatiedepot: 0,
  vpvAftrekPct: 0.10,
  // legacy-velden weglaten: SCHEMA-defaults pakken (v2.2.10 superRefine-regel)
  bijstort: 0, N_deelnemers: 10000, spreidingN: 10,
  compensatieMu: 50, compensatieSigma: 8, buffer: 0,
  demografie: { soort: 'preset', preset: 'gesloten' },
})

console.log('=== UI-test spreidingN-radio + SCHEMA-validatie ===\n')

// Default
console.log(`Start: spreidingN = ${baseParams.spreidingN}`)

// Toggle naar 1000
const after1000 = applyM2SliderInput(baseParams, 'spreidingN', '1000')
console.log(`Na radio "1000": spreidingN = ${after1000.spreidingN} ${after1000.spreidingN === 1000 ? '✓' : '✗'}`)

// Toggle terug naar 10
const after10 = applyM2SliderInput(after1000, 'spreidingN', '10')
console.log(`Na radio "10":   spreidingN = ${after10.spreidingN} ${after10.spreidingN === 10 ? '✓' : '✗'}`)

// SCHEMA-acceptatie van N=1000
try {
  M2.parameterset.parse({ ...baseParams, spreidingN: 1000 })
  console.log(`SCHEMA accepteert spreidingN=1000: ✓`)
} catch (e) {
  console.log(`SCHEMA reject spreidingN=1000: ✗ — ${e instanceof Error ? e.message : e}`)
}

// SCHEMA reject van N=1001 (out of range)
try {
  M2.parameterset.parse({ ...baseParams, spreidingN: 1001 })
  console.log(`SCHEMA accepteert spreidingN=1001: ✗ — zou afgewezen moeten worden`)
} catch {
  console.log(`SCHEMA reject spreidingN=1001 (out of range): ✓`)
}

// SCHEMA-acceptatie tussenwaarde N=15 (langere onderbouwbaar)
try {
  M2.parameterset.parse({ ...baseParams, spreidingN: 15 })
  console.log(`SCHEMA accepteert spreidingN=15: ✓`)
} catch {
  console.log(`SCHEMA reject spreidingN=15: ✗`)
}

// Custom value via applyM2SliderInput
const after15 = applyM2SliderInput(baseParams, 'spreidingN', '15')
console.log(`Na input "15": spreidingN = ${after15.spreidingN} ${after15.spreidingN === 15 ? '✓' : '✗'}`)

// Negatieve waarde rejected door applyM2SliderInput
const afterNeg = applyM2SliderInput(baseParams, 'spreidingN', '-5')
console.log(`Na input "-5": spreidingN = ${afterNeg.spreidingN} ${afterNeg.spreidingN === 10 ? '✓ (afgewezen door applyM2SliderInput, behoudt oud)' : '✗'}`)
