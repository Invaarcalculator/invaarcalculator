/**
 * jsdom-test voor calculator.html (M1+M2 gebundeld). Pendant van test_browser.ts.
 *
 * Verifieert:
 *   1. Script-execution zonder errors
 *   2. M1-anker € 543.096 nog steeds correct (regressie M1)
 *   3. M2-KPI ppkTotal € 574.369 zichtbaar (M2-anker v3.0 wet-canoniek)
 *   4. Slider-aanpassingen muteren state (DG=1.05 → ppkSurplus=0)
 *   5. Audit-toggle werkt en M2-secties verschijnen
 *   6. Alle FIELD_REGISTRY-velden gedekt in audit
 */

import { JSDOM, VirtualConsole } from 'jsdom'
import * as fs from 'fs'

const HTML_PATH = '/mnt/user-data/outputs/calculator.html'
const html = fs.readFileSync(HTML_PATH, 'utf-8')

async function main(): Promise<void> {
  console.log('=== Browser-simulatie calculator.html ===\n')

  const virtualConsole = new VirtualConsole()
  const errors: string[] = []
  virtualConsole.on('jsdomError', (err: Error) => {
    errors.push(`jsdomError: ${err.message}`)
  })
  virtualConsole.on('error', (msg: string) => {
    errors.push(`console.error: ${msg}`)
  })

  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    url: 'file:///calculator.html',
    virtualConsole,
  })
  // v3.0.92: stub window.print zodat triggerAuditReport niet faalt in jsdom
  ;(dom.window as unknown as { print: () => void }).print = () => {}

  await new Promise((r) => setTimeout(r, 200))
  const doc = dom.window.document

  // -------------------------------------------------------------------------
  console.log('Test 1: script-execution schoon')
  console.log(`  Errors: ${errors.length === 0 ? 'geen ✓' : '✗ ' + errors.join('; ')}`)
  console.log()

  // -------------------------------------------------------------------------
  console.log('Test 2: M1-anker via UI-default (70M+65V+€30k OP+€21k NP+SSPF)')
  // v3.0.11: UI-default x0 = 70 (publiek-realistisch). Engine-anker € 543.096
  // bij x0=67 blijft via test_engine.m2.ts; deze browser-test toetst alleen
  // dat de live-calculator een geldig getal oplevert bij de UI-defaults.
  const m1Card = doc.querySelector('.kpi-m1 .kpi-value')
  const m1Text = m1Card?.textContent ?? ''
  console.log(`  M1-KV-card tekst: "${m1Text}"`)
  // Verwacht € 1.298.341 bij default x0=70, pen=100k, r=2.5%, f=0.90, GEEN partner
  // (v3.0.95: default-partner uit, KV_NP=0; v3.0.94: DG=1.361 anker uit vpvTotal=19100)
  const m1Pass = m1Text.includes('1.298.341')
  console.log(`  M1-anker (x0=70): ${m1Pass ? '✓' : '✗'}`)
  console.log()

  // -------------------------------------------------------------------------
  console.log('Test 3: M2-anker via UI-default (v3.0 wet-canoniek bij x0=70, r=2.5%, DG=1.361, spreiding=∞, geen partner)')
  const m2Card = doc.querySelector('.kpi-m2 .kpi-formula-total .kpi-formula-val')
  const m2Text = m2Card?.textContent ?? ''
  console.log(`  M2-ppkTotal-card tekst: "${m2Text}"`)
  // v3.0.95: default geen partner; v3.0.94: DG=1.361 via vpvTotal-anker.
  // PPV-anker per handoff §4: € 1.611.130.
  const m2Pass = m2Text.includes('1.611.130')
  console.log(`  M2-anker: ${m2Pass ? '✓' : '✗'}`)
  console.log()

  // -------------------------------------------------------------------------
  console.log('Test 4: Cascade-sliders aanwezig en hebben juiste defaults')
  // v3.0.79: DG en cascade-componenten zijn nu data-co i.p.v. data-m2field.
  const dgSlider = doc.querySelector('input[data-co="dekkingsgraad"]') as HTMLInputElement | null
  const fondsvermogenSlider = doc.querySelector('input[data-co="fondsvermogen"]') as HTMLInputElement | null
  const rdrSlider = doc.querySelector('input[data-co="rdrBedrag"]') as HTMLInputElement | null
  console.log(`  dekkingsgraad-slider value=${dgSlider?.value} (verwacht 1.361): ${dgSlider?.value === '1.361' ? '✓' : '✗'}`)
  console.log(`  fondsvermogen-slider value=${fondsvermogenSlider?.value} (verwacht 26000): ${fondsvermogenSlider?.value === '26000' ? '✓' : '✗'}`)
  console.log(`  rdrBedrag-slider value=${rdrSlider?.value} (verwacht 500): ${rdrSlider?.value === '500' ? '✓' : '✗'}`)
  console.log()

  // -------------------------------------------------------------------------
  console.log('Test 5: Slider-mutatie — DG=1.05 (lichte onderdekking)')
  if (dgSlider) {
    dgSlider.value = '1.05'
    dgSlider.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    await new Promise((r) => setTimeout(r, 100)) // rAF + recompute
    const m2CardAfter = doc.querySelector('.kpi-m2 .kpi-formula-total .kpi-formula-val')
    const m2TextAfter = m2CardAfter?.textContent ?? ''
    console.log(`  ppkTotal na DG=1.05: "${m2TextAfter}"`)
    // v3.0: bij DG=1.05 wordt ppkTotal lager dan bij DG=1.35 (gespreide korting via x*<0).
    // Detectie: nieuwe waarde verschilt van de pre-mutatie waarde uit Test 3.
    const matchesLower = m2TextAfter !== m2Text && m2TextAfter.match(/€\s*([\d.]+)/)
    console.log(`  Slider-respons: ${matchesLower ? '✓ (waarde veranderd)' : '✗ (geen verandering)'}`)
    // Reset
    dgSlider.value = '1.361'
    dgSlider.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    await new Promise((r) => setTimeout(r, 100))
  } else {
    console.log('  ✗ slider niet gevonden')
  }
  console.log()

  // -------------------------------------------------------------------------
  console.log('Test 6: Audit-rapport-knop genereert rapport met cohort + modtags + verifieerbaarheidshaak')
  // v3.0.92: audit is geen aparte view meer; klik op audit-report-btn vult
  // #print-report met de technische uitvoer (parallel aan Mijn rapport).
  const auditBtn = doc.getElementById('audit-report-btn') as HTMLButtonElement | null
  const printTarget = doc.getElementById('print-report')
  if (!auditBtn) {
    console.log('  ✗ audit-report-btn niet gevonden')
  } else if (!printTarget) {
    console.log('  ✗ #print-report container niet gevonden')
  } else {
    auditBtn.click()
    await new Promise((r) => setTimeout(r, 100))
    const filled = printTarget.innerHTML
    console.log(`  audit-rapport gevuld (${filled.length} chars): ${filled.length > 1000 ? '✓' : '✗'}`)

    // Cohort-tabel met 15 rijen
    const cohortTable = printTarget.querySelector('.cohort-table')
    const cohortRows = cohortTable?.querySelectorAll('tbody tr').length ?? 0
    console.log(`  cohort-table aanwezig met ${cohortRows} rijen (verwacht 15): ${cohortRows === 15 ? '✓' : '✗'}`)

    // Verifieerbaarheidshaak-tekst
    const hasVerif = filled.includes('Verifieerbaarheidshaak')
    console.log(`  Verifieerbaarheidshaak-tekst zichtbaar: ${hasVerif ? '✓' : '✗'}`)

    // Modtags
    const sharedTags = printTarget.querySelectorAll('.modtag-shared').length
    const m1Tags = printTarget.querySelectorAll('.modtag-m1').length
    const m2Tags = printTarget.querySelectorAll('.modtag-m2').length
    console.log(`  shared-modtags: ${sharedTags} (verwacht ≥9): ${sharedTags >= 9 ? '✓' : '✗'}`)
    console.log(`  M1-modtags: ${m1Tags} (verwacht ≥1): ${m1Tags >= 1 ? '✓' : '✗'}`)
    console.log(`  M2-modtags: ${m2Tags} (verwacht ≥11): ${m2Tags >= 11 ? '✓' : '✗'}`)
  }
  console.log()

  // -------------------------------------------------------------------------
  console.log('Test 7: Disclosure-tekst v2.2.10 §11.19 zichtbaar in audit')
  const fullAuditText = doc.body.textContent ?? ''
  const hasV1119 = fullAuditText.includes('§11.19') || fullAuditText.includes('§3.10') || fullAuditText.includes('CRM-2026-34')
  console.log(`  v2.2.10/CRM-disclosure-referentie aanwezig in DOM: ${hasV1119 ? '✓' : '✗'}`)
  console.log()

  // -------------------------------------------------------------------------
  console.log('Test 8: Geen residual JS-errors na alle interactie')
  console.log(`  Errors-totaal: ${errors.length === 0 ? '0 ✓' : '✗ ' + errors.length + ' errors'}`)
  if (errors.length > 0) {
    errors.slice(0, 3).forEach((e) => console.log(`    ${e}`))
  }
  console.log()

  console.log('=== calculator.html browser-test klaar ===')
}

main().catch((err) => {
  console.error('Test crashed:', err)
  process.exit(1)
})
