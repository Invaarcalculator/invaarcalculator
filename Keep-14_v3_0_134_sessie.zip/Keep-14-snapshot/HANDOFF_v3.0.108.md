# HANDOFF v3.0.108 — Invaarcalculator® · Modelspecificatie-PDF + Persoonlijk overzicht vereenvoudigd

**Datum:** Di 12 mei 2026, einde-sessie
**Vorige handoff:** HANDOFF_v3.0.107.md (in werkdir, naast deze)
**Versie in werkdir bij sessie-eind:** **v3.0.108** (`src/ui.app.ts` regel met `RELEASE_VERSION = '3.0.108'`)
**Status werkdir:** v3.0.108-source compleet; geen regressie-tests gedraaid in deze sessie (engine niet aangeraakt)
**Status binary:** `calculator.html` v3.0.108 gebouwd; ankers M1 KV = EUR 1.298.341 en M2 PPV = EUR 1.611.130 zouden bit-identiek moeten zijn want engine-source onaangeraakt

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip:
  # De zip bevat Keep-14/ als top-level dir; uitpakken vanaf /home/claude/
  cd /home/claude
  unzip -q /mnt/user-data/uploads/Keep-14_v3.0.108_sessie.zip
  # → maakt /home/claude/Keep-14/ met alle source en docs

Dependencies (na verse restore):
  cd /home/claude/Keep-14 && npm install --silent

Build calculator (default fonds=sspf):
  cd /home/claude/Keep-14 && npx tsx build.calc.ts
  # → schrijft /mnt/user-data/outputs/calculator.html (≈ 795 KB)
  # NB: vereist modelspecificatie.pdf in werkdir-root, anders FAILS hard

Regressie-suite (engine niet aangeraakt, dus alle 4 hoofdtests zouden groen moeten zijn):
  npx tsx test_browser_calc.ts        # UI smoke, ankers, audit-rapport
  npx tsx test_aftrek_komma.ts        # NL-decimaalkomma + DG 1-decimaal
  npx tsx test_print_report.ts        # ⚠ ZIE §6 — assertions hieronder kunnen breken
  npx tsx test_v3_cascade.ts          # Engine-only cascade-ankers
```

### Werkafspraken (cumulatief, peildatum 12-05-2026)
Identiek aan HANDOFF_v3.0.107 §1. De belangrijkste twee in herhaling:
- **Werkafspraak 12**: één wijziging per turn (uitzondering: expliciet "all-in-one"-modus per gebruikers-instemming)
- **Werkafspraak 16**: elke turn die `src/`, `build.calc.ts` of `fondsen/` raakt verhoogt `RELEASE_VERSION` met +1

### NIEUW deze sessie — Werkafspraak 17 (PDF-sync):
- Elke RELEASE_VERSION-bump die de modelspecificatie ook publiek raakt, vereist:
  1. `BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v{NEW}.tex` versie-strings updaten (6 plekken: regel 2 comment, regel 91 \Large titel, regel 108+121 fancyfoot, regel 134 §1, regel 686 §8 anker-tekst)
  2. Hercompileren met `pdflatex` (3 passes voor `\LastPage`-resolutie)
  3. Resultaat als `modelspecificatie.pdf` in werkdir-root plaatsen
  4. Daarna pas `npx tsx build.calc.ts` draaien — build faalt hard als PDF ontbreekt
- Mismatch is een release-risico (HTML-versie ≠ PDF-versie in gebruikersinterface), vandaar hard fail.

---

## 2. Wat is er gebeurd in deze sessie

Drie functionele uitbreidingen, één per turn-batch, plus modelspec-rebrand:

### Turn 1: Modelspecificatie als markdown-document
- Geen src/-edits. Geen versie-bump.
- Gecreëerd: `BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.106.md` (602 regels, 11 secties)
- Doel: actuariële tegenhanger van Haringa's Bijlage 2 voor het volledige model (M1+M2, AG2024, joint-life broken-heart, cohort-proxy, fondsbalans Model C bundle)

### Turn 2: LaTeX-conversie
- Gecreëerd: `.tex`-variant compileert clean met pdfLaTeX (dutch babel + tabularx + longtable)
- 19 pagina's PDF (na verwijdering Haringa-sectie in turn 3)
- Custom commands: `\ann` (ä), `\annq`, `\anntemp`, `\xfonds`, `\CWvoor`, `\CWstar`, `\vpvTotal`, `\bh`, `\dG`, `\code{...}` etc.

### Turn 3: Rebrand + Haringa-referenties verwijderen
- Titelpagina: "Actuariële Modelspecificatie" / "Invaarcalculator™ v3.0.106" / Author "Innovation Nestor"
- 5 plekken gestript: §1 laatste zin, §8 Stap F-analyse (reframed als losse gevoeligheidsanalyse i.p.v. Haringa-vergelijking), hele §10 Haringa-tabel weg, §11 RDR-item, titel
- Document is nu standalone — geen lezer-afhankelijkheid van Haringa-brief 2 mei 2026

### Turn 4: Header/footer-config voor PDF
- `fancyhdr` + `lastpage` + `datetime` toegevoegd aan preamble
- Linksboven: `Invaarcalculator™ — Actuariële modelspecificatie`
- Rechtsboven: `Innovation Nestor`
- Linksonder: `Pagina X van Y`
- Rechtsonder: `v3.0.106 — {today} {now}` (timestamp vers bij elke compile)

### Turn 5: Calculator v3.0.107 — derde knop "Modelspecificatie" + PDF-injectie
**SRC-edit, versie-bump 3.0.106 → 3.0.107.**

Wijzigingen:
- **`build.calc.ts`**:
  - Nieuwe stap `[2b/4]`: leest `modelspecificatie.pdf` uit werkdir, base64-encodeert, faalt hard bij ontbreken
  - Injectie als `<script>window.__MODELSPEC_PDF__ = "...";</script>` net naast bestaande `window.__AG2024__`
  - Size-rapportage uitgebreid met PDF-base64-regel
- **`src/ui.app.ts`**:
  - `RELEASE_VERSION = '3.0.107'`
  - Derde `<button id="modelspec-btn">Modelspecificatie</button>` in `.pane-actions`
  - Click-handler: `window.__MODELSPEC_PDF__` → `atob` → `Uint8Array` → `Blob({type:'application/pdf'})` → tijdelijk `<a download="Modelspecificatie_Invaarcalculator_v${RELEASE_VERSION}.pdf">` → `setTimeout(URL.revokeObjectURL, 1000)`
  - Foutpaden: visuele knop-feedback ("Modelspecificatie wordt voorbereid…"), `console.error` + `alert` bij ontbrekende globaal

PDF mee gebumpt v3.0.106 → v3.0.107 (alle versie-strings + recompile).

**Build resultaat v3.0.107:**
- Totaal HTML: 794.8 KB (was 290 KB v3.0.106 → +274%)
- Verdeling: bundle 163.4 KB + AG2024 81.8 KB + PDF-base64 511.8 KB + HTML/CSS ~37.9 KB

### Turn 6: Calculator v3.0.108 — Persoonlijk overzicht vereenvoudigd + modelspec-stijl headers/footers
**SRC-edit, versie-bump 3.0.107 → 3.0.108.**

Wijzigingen:
- **`src/ui.print.ts`** (Persoonlijk overzicht):
  - **Sectie 2 vereenvoudigd**: OP/NP-rijen verwijderd voor M1 én M2. Alleen totalen (KV en PPV) plus rekenrente/sliderwaarden blijven.
  - **Sectie 4 (formules-appendix) verwijderd** — disclaimer rangschikt op van sectie 5 → sectie 4
  - H1 hernoemd: "resultatenrapport" → "persoonlijk overzicht" (consistent met knop-label)
  - `triggerPrint`: vult vlak vóór `window.print()` een dynamische `<style id="print-footer-dynamic">` met `@page { @bottom-right { content: "v{version} — {dd-mm-yyyy HH:MM}" } }`
- **`build.calc.ts`** (CSS):
  - Bron-van-waarheid `RELEASE_VERSION` uit `src/ui.app.ts` extraheren (build-time `fs.readFileSync` + regex)
  - `@page` margins 18mm → 22mm boven/onder (ruimte voor margin-boxes)
  - Vier nieuwe margin-boxes in modelspec-stijl: `@top-left`, `@top-right`, `@bottom-left` (alle statisch); `@bottom-right` blijft dynamisch via `#print-footer-dynamic`-placeholder die `triggerPrint` vult
- **HTML-template**:
  - Toegevoegd: `<style id="print-footer-dynamic"></style>` placeholder na `#print-report`

**Build resultaat v3.0.108:**
- Totaal HTML: 794.5 KB
- Verdeling: bundle 161.3 KB + AG2024 81.8 KB + PDF-base64 511.9 KB + HTML/CSS ~39.4 KB
- Bundle 2.1 KB kleiner dan v3.0.107 (formules-appendix-strings weg uit ui.print.ts)

---

## 3. Knop-pad voor de eindgebruiker (v3.0.108)

Drie knoppen in `.pane-actions`:

| Knop | id | Output | Inhoud |
|---|---|---|---|
| Persoonlijk overzicht | `print-report-btn` | print-preview → "Opslaan als PDF" | **Vereenvoudigd in v3.0.108**: M1 KV totaal + M2 PPV totaal, sliderwaarden, fondsparameters, disclaimer. **GEEN OP/NP-decompositie. GEEN formules-appendix.** Headers/footers in modelspec-PDF-stijl (Chromium volledig, Firefox negeert margin-boxes maar body blijft leesbaar). |
| Actuarieel overzicht | `audit-report-btn` | print-preview → "Opslaan als PDF" | Volledige audit, OP/NP-decompositie, alle fondsparameters, cascade-tabel. **Onveranderd in v3.0.108** — bevat OP/NP juist wel. |
| Modelspecificatie | `modelspec-btn` | direct PDF-download | De v3.0.108 modelspec uit base64-injectie. Bestandsnaam `Modelspecificatie_Invaarcalculator_v3.0.108.pdf`. |

---

## 4. Niet-getest in deze sessie

- **Visuele rendering van `@page` margin-boxes in browser-print-preview** — niet zelf gevalideerd; vereist een echte browser. Verwacht:
  - Chromium (Chrome, Edge, Brave, Opera): volledige render van alle vier margin-boxes
  - Safari ≥ 14: partieel (header werkt, footer in praktijk wisselend)
  - Firefox: negeert margin-boxes; body blijft leesbaar
- **Regressie-suite niet gedraaid**. Engine-source niet aangeraakt deze sessie dus ankers (EUR 1.298.341 / EUR 1.611.130) zouden bit-identiek moeten zijn. `test_print_report.ts` kan echter wel breken op de OP/NP-assertions — zie §6.

---

## 5. Bestanden in `/mnt/user-data/outputs/` bij sessie-eind

```
calculator.html                                         794.5 KB  ← actuele build v3.0.108
calculator_v3.0.108.html                                794.5 KB  ← versie-prefix kopie
BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.108.pdf  ~384 KB  ← embedded in HTML én losse share
BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.108.tex  ~57 KB   ← bron, voor Overleaf
BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.108.md   ~46 KB  ← markdown-bron (voorgaand aan tex)
```

**Storage-anomalie (niet kritisch):** Eerder in de sessie ontstond een `calculator_v3.0.107.html` dat na rm-poging in een corrupt state achterbleef (listing toont 815KB, daadwerkelijk lezen geeft I/O-error). Beïnvloedt distributie niet.

---

## 6. ⚠️ Belangrijk voor volgende sessie

### A. `test_print_report.ts` kan breken op v3.0.108
De test in HANDOFF_v3.0.107 baseline test naar verwachting:
- OP/NP-rijen in print-rapport — **WEG in v3.0.108**, dus assertions als `assert(html.includes('KV_OP'))` falen
- Formules-appendix — **WEG in v3.0.108**, dus assertions als `assert(html.includes('Bijlage 2a'))` falen

**Aanbevolen actie**: bekijk `test_print_report.ts` en pas assertions aan op het nieuwe verkorte rapport (sectie 1, 2, 3, 4 — geen OP/NP, geen formules). Versie-bump van test-bestand niet vereist (tests staan buiten src/, build.calc.ts en fondsen/).

### B. PDF-versie-sync is HARD-FAILED
Bij elke nieuwe versie-bump die de calculator-binary publiekelijk uitbrengt: vergeet niet de `BIJLAGE2_MODELSPECIFICATIE_*.tex` te updaten en hercompileren. `build.calc.ts` faalt nu hard als `modelspecificatie.pdf` mismatched is of ontbreekt. Dit is bewuste keuze om mismatches te voorkomen, maar voelt onhandig bij rapid prototyping. Overweeg een `--skip-pdf`-flag toe te voegen voor non-release builds.

### C. Bestand `calculator_v3.0.107.html` in outputs is corrupt
Niet meeleveren in distributie. `rm` geeft I/O-error in deze sandbox. Bij verse restore in nieuwe sessie verdwijnt dit.

---

## 7. Openstaande actuaris-bevindingen (cumulatief, ongewijzigd sinds v3.0.106)

Identiek aan HANDOFF_v3.0.106 §5 + HANDOFF_v3.0.107 §5:
- **C1**: compensatiedepot-routing (al-naar-OP via art. 150f Pw; deels-naar-NP-variant openstaand voor multi-fonds-toepassing)
- **D2**: RDR-labeling in UI/audit-rapport (heeft niet altijd dezelfde benaming als in spec)
- **D5**: DG-staffel bijstort (Shell-bijdrage 500/650/850 mln; nu één scalair bedrag, automatisering openstaand)
- **A3**: broken-heart AG-2018-bron (bh₀(M)=1.50, bh₀(V)=1.25 placeholder-waarden, primaire bron nog niet gelokaliseerd)

Geen van deze is in deze sessie aangeraakt.

---

## 8. Strategische items (niet-gebouwd, vermelding voor planning)

Identiek aan HANDOFF_v3.0.107 §6:
- **M3 Monte Carlo**: stochastische scenario-analyse (goed/mediaan/slechtweer), netto profijt, kortingskansen
- **M4 DB-vs-WTP-projectie**: uitkeringspaden voortzetting DB versus invaren WTP
- **Werkelijke SSPF-cohort-counts**: nu preset "gesloten", customCounts-pad openstaand
- **Leeftijds-afhankelijke f(x, g)**: nu scalar f = 0.90, parametrische uitbreiding openstaand
- **AG2024-cohorttafels**: nu periode-snapshot t₀ = 2026, kolom-mee-evoluerende variant openstaand (effect typisch <1%)

---

## 9. Bestand-fingerprint werkdir bij sessie-eind

```
src/ui.app.ts       71938 bytes  RELEASE_VERSION = '3.0.108'
src/ui.print.ts     12652 bytes  GEEN OP/NP, geen formules-appendix, dynamic footer
build.calc.ts       47289 bytes  PDF-injectie + RELEASE_VERSION-extractie + @page margin-boxes
modelspecificatie.pdf  393161 bytes  v3.0.108 (footer "Pagina X van 19, v3.0.108 — 12 mei 2026 09:30:45")
```

Smoke-test resultaten v3.0.108:
- `__MODELSPEC_PDF__` aanwezig (×2 in HTML)
- PDF base64 decodeert naar `%PDF-1.5` magic-bytes
- `modelspec-btn` aanwezig (×2: declaratie + handler)
- `@page` margin-boxes (4: top-left, top-right, bottom-left, bottom-right dynamic placeholder)
- `Innovation Nestor` (×2: print-CSS én ergens anders)
- `Persoonlijk overzicht` (×2: knop én H1)
- Versie 3.0.108 in bundle (2 hits)
- OP/NP-strings 9× in totaal — allen uit `ui.audit-report.ts`, geen uit `ui.print.ts` (bron-grep bevestigd)

---

*Einde HANDOFF v3.0.108.*
