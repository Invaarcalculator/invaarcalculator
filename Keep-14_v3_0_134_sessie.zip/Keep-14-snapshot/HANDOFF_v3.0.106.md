# HANDOFF v3.0.106 — Invaarcalculator® release-klaar (UI-finishing pre-launch)

**Datum:** Ma 11 mei 2026
**Versie:** v3.0.106
**Status:** Release-klaar; calculator.html in outputs gestempeld 3.0.106
**Werkdir:** `/home/claude/Keep-14/` — momenteel op v3.0.92-source-staat (zie §8)

---

## 1. Quick-start nieuwe chat

```
Werkdir: /home/claude/Keep-14/

Restore vanuit zip (basisset):
  mkdir -p /home/claude/Keep-14
  cd /home/claude/Keep-14
  unzip -q /mnt/user-data/outputs/Keep-14_v3.0.92_complete.zip

Dependencies (na verse restore):
  cd /home/claude/Keep-14 && npm install --silent

Build calculator naar /mnt/user-data/outputs/calculator.html (default fonds=sspf):
  cd /home/claude/Keep-14 && npx tsx build.calc.ts

Volledige regression-suite (4 testsuites, alle groen verwacht na v3.0.95-opruim):
  npx tsx test_browser_calc.ts        # M1/M2/cascade smoke + ankers + audit-rapport
  npx tsx test_aftrek_komma.ts        # NL-decimaalkomma in cascade
  npx tsx test_print_report.ts        # PDF-rapport-generator (Persoonlijk overzicht)
  npx tsx test_v3_cascade.ts          # Engine-only cascade-ankers (regressie-anchor)
```

**Werkafspraken (cumulatief, peildatum 11-05-2026):**

1. Stap-voor-stap, één wijziging per turn (Werkafspraak 12)
2. Alle fonds-parameter-wijzigingen voorzien van bron-citaat in `fondsen/sspf/fonds.config.ts`
3. "Persoonlijk pensioenvermogen" canonical in UI; geen "potje"
4. Geen em-dashes in user-facing tekst
5. NL-decimaalkomma overal
6. Sidebar-preview niet geschikt voor print/popup-tests (gebruik visuele review op vol scherm)
7. HANDOFF altijd in werkdir en zip (Werkafspraak 13, 06-05-2026)
8. ?-helptekst is puur invul-help, geen op- of aanmerkingen, geen parameters tussen haakjes (Werkafspraak 14, 10-05-2026), met uitzondering voor concepten die functie-uitleg verdienen (rekenrente, spreidingstermijn) waar twee secties zijn toegestaan: "WAT DOET ...?" + "WAT KUNT U INSTELLEN?"
9. Audit-uitvoer via een rapport-knop, niet via aparte view of code-bescherming (Werkafspraak 15, 10-05-2026)
10. **Versie-bump per turn**: elke turn die een wijziging in de source of HTML-template doorvoert verhoogt `RELEASE_VERSION` in `src/ui.app.ts` met één patch-versie (Werkafspraak 16, 11-05-2026, zie §3 voor reden)
11. Fonds-agnostische teksten: hardcoded fondsnamen vermijden in source; gebruik `FONDS.label` (volledige naam) of `FONDS.shortLabel` (korte vorm zoals "SSPF") via build-time-substitutie of runtime-templating. Default-fallback respecteren

---

## 2. Architectuur — fonds-agnostisch via build-time-injectie (v3.0.76+)

Codebase werkt voor één fonds per build. Voor een tweede fonds maak je een tweede build vanaf dezelfde codebase:

```
/src/                          ← fonds-onafhankelijk
/fondsen/sspf/fonds.config.ts  ← SSPF-data: label, shortLabel, m1, m2, AanwendingsCascade
/fondsen/<id>/fonds.config.ts  ← (later) ABN of ander fonds
```

Esbuild path-alias `~fonds` naar `/fondsen/<id>/fonds.config.ts`. Build-script accepteert `--fonds=<id>`, default `sspf`. Tsconfig.json heeft path-alias zodat tsx en type-check werken.

v3.0.103+: `Fonds`-type uitgebreid met optioneel `shortLabel`-veld voor compacte UI-context ("Voor wie SSPF-pensioen ontvangt"). Build-script leest dit veld via dynamic `await import(FONDS_CONFIG_PATH)` en substitueert `${fondsShort}` in HTML-template.

---

## 3. Waarom Werkafspraak 16 (versie-bump per turn)

Tussen v3.0.89 en v3.0.106 zijn zeventien substantiële commits gedaan zonder dat `RELEASE_VERSION` werd verhoogd. Effecten:
- Footer toonde lange tijd "Release 3.0.89" terwijl de bundle al veel later was
- Print/audit-rapporten gestempeld met verkeerd versienummer
- HANDOFF v3.0.92 was de enige tussenliggende handoff, maar refereerde naar v3.0.92 in eigen body; ondertussen ging de werkdir door

Werkafspraak 16 maakt dit expliciet:
- Elke turn die `src/`, `build.calc.ts` of `fondsen/` raakt: `RELEASE_VERSION` +1
- Alleen tekst-correctie zonder code-effect (HANDOFF-bijwerking, comments) telt niet
- Bij meerdere refactors in één turn: nog steeds +1 (één turn = één versie-stap, ongeacht aantal sub-wijzigingen)

---

## 4. Numerieke ankers (canoniek voor v3.0.106)

### UI-default scenario
Bij default-state (v3.0.95+: x0=70, pen=€100k, GEEN partner, DG=136,1%, F=26.000 mln, vpvTotal=19.100 mln (anker), bijstort=€500m, wettelijk=2%, RDR=€500m, compdepot=€400m, spreiding=∞, f=0,90):

- KV M1 = € 1.298.341 (alleen OP, KV_NP = 0)
- PPV M2 = € 1.611.130
- Verdeelbaar overschot = € 6.840 mln
- Verwachte sterfleeftijd (lifeExp_x0) = 86,02

### Bij partner aan (heeftPartner toggled to true; hydrate y0=70.000, dob_partner=65j)
- KV M1 = ca. € 1.606.774
- PPV M2 = ca. € 2.071.039

### Cascade-test (test_v3_cascade.ts), stabiele regressie-anchor (ongewijzigd):
- KV M1 = € 543.096
- ppkTotal v3.0 N=10 = € 569.457 (Δ 4,85%)
- ppkTotal v3.0 N=∞ = € 569.889 (Δ 4,93%)
- ppkTotal R9.30 LEG = € 572.166 (Δ 5,35%)

Belangrijk v3.0.94-architectuur: `vpvTotal` is nu fonds-anker (€ 19.100 mln voor SSPF, bron eind feb 2026), niet meer afgeleid uit F/DG. F en DG bewegen in tandem rond deze vaste anker.

---

## 5. Versie-overzicht v3.0.92 naar v3.0.106

### v3.0.93 — UI-herorganisatie M1
- Geslacht-toggle onder geboortedatum (was eronder)
- Verwachte sterfleeftijd-caption toegevoegd onder Leeftijd-caption
- Sterfleeftijd + rekenrente-strook uit M1-resultaatblok verwijderd
- Dunne divider tussen persoonsgegevens en hoog-laag-uitkering toggle
- Mid-markers op pensioen-sliders

### v3.0.94 — F + DG in tandem rond vpvTotal-anker [ARCHITECTUUR]
- `vpvTotal` toegevoegd aan M2ParametersetSchema en aan SSPF-fonds.config (€ 19.100 mln, bron: SSPF stand eind feb 2026)
- `engine.m2.ts`: twee plekken `vpvTotal = fondsvermogen / dekkingsgraad` worden `vpvTotal = params.vpvTotal * 1e6`
- UI-handler: F-slider muteert DG = F/vpvTotal; DG-slider muteert F = DG × vpvTotal
- DG-display met één decimaal (NL-locale: "136,1%")
- test_v3_cascade krijgt expliciete vpvTotal=27202/1.15 voor stabiele ankers

### v3.0.95 — Fonds-modal naar audit-rapport, default geen partner, scherm-opruim
- "Mijn pensioenfonds"-pane volledig weg
- Default `heeftPartner=false`, partner-velden null
- Alle ?-iconen weg uit M1 behalve rekenrente
- Rekenrente ?-tekst uitgebreid met functie-uitleg
- `buildFondsHelp` + `buildAanwendingsCascadeBlock` uit `ui.app.ts` verwijderd; verhuisd naar `ui.audit-report.ts` als sectie 4 "Fondsparameters"
- Tests test_fonds_modal.ts en test_cascade.ts verwijderd; test_aftrek_komma.ts afgeslankt
- Regression-suite van 6 naar 4 testsuites

### v3.0.96 — Radio's vervangen door dropdowns
- Alle 4 radio-paren in M1 worden `<select class="dropdown-pill">` (geslacht-deelnemer, geslacht-partner, hoog-laag-uitkering, heeftPartner)
- `.dropdown-pill`-CSS met identieke styling aan `.dob-input` voor uniforme rechter-kolom-uitlijning
- Partner-hydrate-fix: bij `heeftPartner` naar true worden `y0` en `dob_partner` gehydrateerd vanuit null-defaults
- Boolean-conversie in handler uitgebreid voor HTMLSelectElement

### v3.0.97-99 — Dropdown-styling-iteraties
- Dropdown-pill min-width 10.5em naar 12.6em (te breed) naar 8.4em (20% smaller dan DOB)
- DOB-input min-width matched aan dropdown (8.4em)
- Beide explicit `height: 22px` + `line-height: 22px`
- Zachte focus-ring (`var(--bdr2)`) ipv harde `var(--txt1)`
- 3× SVG-kalender-icoon weggehaald (browser-native datepicker icon volstaat)
- Heeft-partner-toggle naar binnen het partnerBlock verhuisd
- `.partner-fields[hidden]` wrapper voor child-elementen
- `field-inline-radio` margin-top 8px naar 12px; `.partner-fields { margin-top: 12px }`

### v3.0.100 — Slider-bereiken
- Pensioen-slider (deelnemer + pen_laag): min 2.000 naar 0, mid € 101.000 naar € 100.000
- Rekenrente-slider: max 4% naar 5%, mid 2% naar 2,5%

### v3.0.101 — Reset-knop in pane-header
- Reset-knop verhuisd van onder cascade-tabel naar naast Bewerkt-marker in pane-header
- Beide knoppen identiek getuned (padding 2px×10px, font-size 11px, line-height 14px, min-width 6em, uppercase)
- Label "Reset naar fonds-defaults" naar "Reset"

### v3.0.102 — Fondsnaam in topline header
- `build.calc.ts` doet `await import(FONDS_CONFIG_PATH)` voor FONDS.label
- Nieuwe `<p class="topline-fondsnaam">` tussen h1 en subtitle

### v3.0.103 — Uitleg-rewrite + shortLabel + modal-padding
- `Fonds`-type uitgebreid met `shortLabel?: string`; SSPF: `'SSPF'`
- HTML-title + topline-subtitle gebruiken `${fondsShort}`: "Voor wie SSPF-pensioen ontvangt"
- Uitleg-modal "VOOR WIE"-sectie idem
- Uitleg-modal volledig herschreven (4 secties: intro zonder kop + 3 met kop)
- Taal-puristische cleanup: "tool" naar "rekentool", anglicismen weg ("defaults" naar "fonds-uitgangswaarden"), UPO uitgeschreven, "actuele standen" naar "actuele waarden"
- Hoog-laag-uitleg toegevoegd aan "WAT KUNT U HIER DOEN?"
- "Uw huidige aanspraak" naar "Uw huidige pensioenaanspraak" op 7 plaatsen
- Modal-padding 24×28 naar 18×20; section margins compacter; line-height 1.55 naar 1.45
- Empty-heading-sectie: renderer slaat `<h3>` over als heading leeg is
- `:first-of-type` naar `:first-child` om eerste h3 na intro-paragraaf correct spacing te geven

### v3.0.104 — Spreidingstermijn-uitlijning
- `.m2-controls` padding-left/right 18px verwijderd
- `.pane.casual.pane-actions` padding-override 12×16 verwijderd (erft nu `.pane` 18×20)

### v3.0.105 — M2-pane horizontale divider weg
- `.m2-controls` border-top weg

### v3.0.106 — M2-spacing match M1 + version-bump
- `.m2-controls` margin-top 16px + padding-top 14px weg
- RELEASE_VERSION bumped 3.0.89 naar 3.0.106
- Werkafspraak 16 vastgelegd

### Inhoudelijke tweaks (verspreid over turns)
- Rapport-knop-labels: "Mijn rapport" naar "Persoonlijk overzicht"; "Audit-rapport" naar "Actuarieel overzicht"; beide naast elkaar zonder sub-teksten
- Dekkingsgraad ?-icoon weg uit cascade-tabel
- Spreidingstermijn ?-tekst uitgebreid met functie-uitleg
- h1 padding 0 4px verwijderd (uitlijn-bug met fondsnaam en subtitle)
- "jaarlijkse uitkering" toegevoegd in Uitleg-intro
- "Wilt u verder kijken?" vervangen door declaratieve aanhef

---

## 6. Tests-status v3.0.106

Alle 4 test-suites groen na v3.0.95-opruim:

| Test | Wat het dekt | Status |
|------|---|---|
| test_browser_calc | UI smoke, KV/PPV-ankers (no-partner: 1.298.341 / 1.611.130), cascade-sliders, audit-rapport-knop, Fondsparameters-sectie | ✓ |
| test_aftrek_komma | NL-decimaalkomma in cascade-tabel + DG "136,1%" (1 decimaal) | ✓ |
| test_print_report | Persoonlijk-overzicht-rapport bevat invoer + KPI's; partner-toggle hydrate werkt | ✓ |
| test_v3_cascade | Engine-only ankers met expliciete vpvTotal=27202/1.15 | ✓ |

Verwijderde tests v3.0.95: test_fonds_modal.ts, test_cascade.ts.

---

## 7. PENDING action items

### Actuaris-bevindingen — actief binnen scope (ongewijzigd t.o.v. v3.0.91/92)
1. C1 — Compensatiedepot-routing transparantie (HOOG)
2. D2 — RDR labelen als bestemd voor pensioengerechtigden (MIDDEL)
3. D5 — DG-afhankelijke bijstort-staffel (HOOG)
4. A3 — Broken-heart factoren uit AG-2018-publicatie (MIDDEL)

### Buiten scope (uitgesteld per user)
- D3 (M3 Monte Carlo), D4 (partner-overlijden-uitkering), PPV naar maandbedrag onder SPR

### Buiten scope (geaccepteerd educatief, met disclaimer)
- A1, A4, A5, B1, B3, B4, C2, C3 (zie v3.0.91 handoff)

### Strategisch (open)
5. Fondsdemografie zichtbaar/aanpasbaar maken
6. M1 KV-fix actieve deelnemer
7. M3 Monte Carlo
8. M4 DB-vs-WTP

### Operationeel
9. Hosting-deployment naar invaarcalculator.nl
10. iPad-issue (HTML opent niet)
11. **Werkdir-source v3.0.93..v3.0.106 reconstrueren** (zie §8)

### Code-opruim
12. Backward-compat-symbols opruimen, oude src/ui.m1.ts en renderM2Audit dead-code

---

## 8. ⚠️ Werkdir-source-staat — KRITISCH

Deze handoff is geschreven op een moment dat de werkdir-source een **regressie naar v3.0.92** had ondergaan. De `calculator.html` in `/mnt/user-data/outputs/` is wel v3.0.106 (gebouwd in eerdere sessies), maar de bijbehorende source-files zijn niet meer aanwezig op v3.0.106-niveau.

**Wat wel beschikbaar is:**
- `/home/claude/Keep-14/` herstelt vanuit `Keep-14_v3.0.92_complete.zip` in outputs
- `/mnt/user-data/outputs/calculator.html` is werkende v3.0.106 binary
- Deze HANDOFF met §5-overzicht van alle wijzigingen sinds v3.0.92

**Pad terug naar volledige v3.0.106-source in volgende sessie:**

Optie A — handmatige migratie (aanbevolen):
1. Restore v3.0.92 werkdir
2. Herapply de turn-stappen uit §5 in volgorde, met verificatie tegen v3.0.106-`calculator.html`
3. Test na elke 2-3 stappen

Optie B — reverse-engineering (sneller, brozer):
1. Restore v3.0.92 werkdir
2. Lees `calculator.html` (~285 KB) terug
3. Diff gerenderde structuur tegen v3.0.92-build, leid wijzigingen af

Optie C — fresh start vanaf v3.0.106-binary:
1. Behoud `calculator.html` als productie-deliverable
2. Begin nieuwe source-tak in v3.0.107 met deze handoff als specificatie

**Aanbeveling: Optie A, in een volgende sessie.** Werkafspraak 16 voorkomt herhaling.

---

## 9. Source-files-overzicht (canoniek voor v3.0.106, gewenste eindstaat)

```
/home/claude/Keep-14/
├── src/
│   ├── ui.app.ts              # main, verwacht ~1620 regels na opruim
│   ├── ui.m2.ts               # M2-render (renderM2Audit dead-code)
│   ├── ui.m1.ts               # dead-code
│   ├── ui.print.ts            # Persoonlijk overzicht (was: Mijn rapport)
│   ├── ui.audit-report.ts     # Actuarieel overzicht; sectie 4 Fondsparameters
│   ├── ui.shared.ts
│   ├── engine.m1.ts
│   ├── engine.m2.ts           # vpvTotal uit params, niet F/DG
│   ├── schema.v2.ts           # met v3.0.94 vpvTotal-veld in M2Parameterset
│   ├── fondsdataset.ts
│   └── fondsdataset.types.ts  # Fonds type met v3.0.103 shortLabel?: string
├── ag2024.json
├── fondsen/
│   └── sspf/
│       └── fonds.config.ts    # label, shortLabel='SSPF', vpvTotal=19100, dekkingsgraad=1.361
├── build.calc.ts              # met fondsShort substitutie
├── tsconfig.json, package.json
├── test_browser_calc.ts       # M1+M2-ankers (no-partner), audit-rapport-flow
├── test_aftrek_komma.ts       # DG "136,1%" 1-decimal
├── test_print_report.ts       # Persoonlijk overzicht + partner-toggle via dropdown
├── test_v3_cascade.ts         # Engine-only met expliciete vpvTotal
├── HANDOFF_v3.0.92.md
└── HANDOFF_v3.0.106.md        # ← deze file
```
