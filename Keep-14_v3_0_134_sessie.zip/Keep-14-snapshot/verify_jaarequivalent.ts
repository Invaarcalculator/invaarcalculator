/**
 * Verify jaarpensioen-equivalent met app-defaults.
 *
 * Berekening (uit src/ui.m2.ts v3.0.127):
 *   aandeel           = m2Out.ppkTotal - m1Out.KV
 *   annuiteitFactor   = m1Out.KV / pen
 *   jaarEquivalent    = aandeel / annuiteitFactor = aandeel * pen / KV
 *
 * Defaults uit src/ui.app.ts (state) + fondsen/sspf/fonds.config.ts (FONDS):
 *   x0=70, g='M', pen=100000, heeftPartner=false (zonder-partner-case)
 *   y0=70000, x_partner=65, g_y='V'             (met-partner-case, hydrate)
 *   r=2,5%, t0=2026, f=0,90, m=12, ervaringsSterfte=0,90, omega=120
 *   dekkingsgraad=1.361, bijstort=500 mln, spreidingN=1000, etc.
 */
import { FONDS } from './fondsen/sspf/fonds.config'
import * as fs from 'fs'
import * as path from 'path'

// Inject AG2024 in globalThis.window (engine.m1.ts leest window.__AG2024__)
const ag2024Data = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'ag2024.json'), 'utf-8'))
;(globalThis as any).window = { __AG2024__: ag2024Data }

import { computeM1 } from './src/engine.m1'
import { computeM2 } from './src/engine.m2'
import { M1, M2 } from './src/schema.v2'

function dobForExactAge(years: number, peildatum: string): string {
  const peil = new Date(peildatum)
  const dob = new Date(peil)
  dob.setFullYear(peil.getFullYear() - years)
  return dob.toISOString().slice(0, 10)
}

const PEILDATUM = new Date().toISOString().slice(0, 10)

function run(label: string, heeftPartner: boolean) {
  const deelnemer = {
    x0: 70,
    pen: 100000,
    g: 'M' as const,
    heeftPartner,
    y0: heeftPartner ? 70000 : null,
    x_partner: heeftPartner ? 65 : null,
    g_y: 'V' as const,
    dob: dobForExactAge(70, PEILDATUM),
    dob_partner: heeftPartner ? dobForExactAge(65, PEILDATUM) : null,
    hooglaagActief: false,
    pen_laag: null,
    x_knip: null,
    dob_knip: null,
  }

  const p1 = M1.parameterset.parse({ ...FONDS.m1 })
  const m2Raw = { ...FONDS.m2 }
  // v3.0.79 cascade-aggregatie zoals ui.app.ts:287:
  //   vpvAftrekPct = wettelijkReservesPct + (rdrBedrag + compdepotBedrag) / vpvTotal
  // FONDS.m2.vpvAftrekPct=0,06 is een statische default; de UI overschrijft die.
  const cascade = FONDS.aanwendingsCascade
  const vpvForCascade = m2Raw.vpvTotal > 0 ? m2Raw.vpvTotal : m2Raw.fondsvermogen / m2Raw.dekkingsgraad
  m2Raw.vpvAftrekPct = cascade.wettelijkeReservesPct + (cascade.rdrBedrag + cascade.compensatiedepotBedrag) / vpvForCascade
  const p2 = M2.parameterset.parse(m2Raw)
  const d = M1.deelnemer.parse(deelnemer)

  const m1Out = computeM1(d, p1, { spreidingN: p2.spreidingN })
  const k = M2.ketenInput.parse({
    KV: m1Out.KV,
    KV_OP: m1Out.KV_OP,
    KV_NP: m1Out.KV_NP,
    cw_star_op: m1Out.cw_star_op ?? 0,
    cw_star_np: m1Out.cw_star_np ?? 0,
  })
  const m2Out = computeM2(d, k, p2)

  const pen = 100000
  const aandeel = m2Out.ppkTotal - m1Out.KV
  const annuiteitFactor = m1Out.KV / pen
  const jaarEquivalent = aandeel / annuiteitFactor

  const eur = (x: number) => '€ ' + Math.round(x).toLocaleString('nl-NL')
  const eurExact = (x: number) => '€ ' + x.toFixed(2).replace('.', ',')

  console.log(`\n=== ${label} ===`)
  console.log(`  vpvAftrekPct (eff) = ${(p2.vpvAftrekPct * 100).toFixed(4)}%`)
  console.log(`  KV          = ${eur(m1Out.KV)}  (KV_OP=${eur(m1Out.KV_OP)}, KV_NP=${eur(m1Out.KV_NP)})`)
  console.log(`  ppkTotal    = ${eur(m2Out.ppkTotal)}`)
  console.log(`  aandeel     = ${eurExact(aandeel)}`)
  console.log(`  KV/pen      = ${annuiteitFactor.toFixed(4)}`)
  console.log(`  jaar-equiv  = ${eur(jaarEquivalent)}  (exact: ${eurExact(jaarEquivalent)})`)

  // Reconstrueer UI-string zoals in renderM2KPI
  const jaarSign = jaarEquivalent >= 0 ? '+' : '−'
  const jaarEur = '€ ' + Math.round(Math.abs(jaarEquivalent)).toLocaleString('nl-NL')
  const penEur = '€ ' + Math.round(pen).toLocaleString('nl-NL')
  const extraOrMinder = jaarEquivalent >= 0 ? 'extra' : 'minder'
  console.log(`  UI-tekst    : ≈ ${jaarSign} ${jaarEur} ${extraOrMinder} (boven uw huidige ${penEur}) per jaar pensioen levenslang`)
}

run('Zonder partner (app-defaults)', false)
run('Met partner (app-defaults + hydrate y0=70k, partner V 65j)', true)
