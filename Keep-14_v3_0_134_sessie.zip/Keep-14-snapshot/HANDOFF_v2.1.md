# WTP-PENSIOENCALCULATOR — HANDOFF ENGINE SPEC v2.1

Datum: 23-04-2026 13:40
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Licentie: CC BY-NC 4.0

Dit document markeert de afronding van de **scherm-1-spec-sessie** (23-04-2026) en geeft de volgende sessie een schone start. Het vervangt niet `HANDOFF_R9.30.md` (Fase A code-status), maar vormt een parallelle spec-track-handoff.

---

## KERN IN ÉÉN ALINEA

Op 22-04-2026 is de sessie gestart met het schrijven van `ENGINE_SPECIFICATIE_v1.md` — de normatieve spec voor de engine in vier modules. Na basis-v1 zijn zeven hoofdpunten voor scherm 1 (module 1 — huidige waarde) stap-voor-stap beslist, plus drie cross-screen doorwerkingen. Dit heeft geleid tot 13 besluiten en elf patches (v1.1 → v2.1). De spec is daarmee voor scherm 1 volledig af en klaar voor uitbreiding naar scherm 2.

---

## STAND VAN ZAKEN — SPEC v2.1

**Hoofdbestand:** `ENGINE_SPECIFICATIE_v1.md` (1674 regels).

**Voltooide besluiten (met datum en kern):**

| § | Besluit | Datum | Kern |
|---|---|---|---|
| 11.1 | φ afgeleid zichtbaar | 09:24 | Optie 2: `phiDerived = ppkTotal / V_x^Wtp`; decoratief output M2 |
| 11.2 | Regeling-selector | 09:24 | Optie 1: top-level SPR/FPR + M3-sub-selector |
| 11.3 | Rente-parameters | 09:24 + 13:40 | Drie velden structureel (Optie 2) + UI-koppeling via slider met ontkoppel-toggle (v2.1) |
| 11.4 | Annuïteitsconventie | 09:53 | **Arrears m=12 uniform cross-module** (afwijking van R9.30-baseline) |
| 11.5 | Partneruitbreiding M1 | 09:59 | Optie 2: aparte KV_OP en KV_NP in output |
| 11.10 | Sterftetafel-structuur | 09:24 + 11:58 | Operationeel via §11.16 (AG2024) |
| 11.13 | Ervaringssterftefactor f | 10:05 | Structurele scalar, v1-placeholder 1,0 tot SSPF-bron |
| 11.14 | Kostenopslag ρ | 10:24 | Afleidingsformule `ρ = c_jaar × ä(x, r)` met ultieme default 0,02 (bewuste afwijking §12.5) |
| 11.15 | Indexatie π M1 | 11:32 | Structurele scalar, waarde 0 als bewust anker (§1.1 narratief) |
| 11.16 | Sterftetafel-migratie | 11:58 | **AG2024 vervangt R9.30 Q-tabel + gender-activering** |
| 11.17 | SSPF-gender-weging | 13:21 | Placeholder 95/5 deelnemer, 5/95 partner-gegeven-M |
| 11.18 | NP-integratie | 13:35 | **Optie 4: één potje, geoormerkte OP/NP-componenten (major v2.0)** |

**Sub-defaults bevestigd v1.8:**
- Partner-sterftetafel = AG2024 per `g_y`
- Correlatie tussen levens = 0 (joint-life is v2)
- NP-fallback bij onbekende `y₀` = 70% OP
- Rekenrente-default `r` = 2%

**Scherm 1 + directe cross-screen doorwerkingen zijn afgerond.** Scherm 2, 3, 4 zijn nog te doen.

---

## ACTIEVE WERKAFSPRAKEN

Tijdens de sessie ontwikkeld en te behouden:

1. **Narratief kompas (§1.1)** — drie momenten (nu → invaren → straks) × vier schermen, met scherm 4 als regime-split van moment 1. Sturend principe: "bij identieke aannames mag hetzelfde getal op meerdere schermen staan — dat is geen redundantie maar ankerfunctie". Elke toekomstige beslissing wordt aan dit kompas getoetst.

2. **Educatieve leidraad** — de tool moet verborgen dimensies zichtbaar maken (gender-verschil op annuïteit, NP als substantieel deel van aanspraak, kostenopslag-impact), niet alleen een getal uitrekenen. Bevestigd moment: Hans' eigen UPO-observatie (partnerpensioen staat apart) leidde tot Optie 4 voor NP-integratie.

3. **Spec-met-reserveringen-principe (§12.5)** — v1-defaults reproduceren R9.30-gedrag waar mogelijk. Eén bewuste afwijking: ρ=0,02 (zou "rijk rekenen" zijn bij ρ=0; publieke calculator moet het kostenverschil zichtbaar maken).

4. **Stap-voor-stap-methode** — elk open punt wordt met probleem/opties/aanbeveling voorgelegd, Hans beslist, Claude patcht direct in spec, dan naar volgend punt. Geen bulk-beslissingen.

5. **SSPF-prior voor fallbacks** — gender-weging voor "gemengd" = 95% M / 5% V (deelnemer), geen CBS-neutrale weging.

6. **Timestamp-conventie** — `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"` voor alle patches.

7. **Bronhoudbaarheid boven snelheid** — waar placeholders gekozen zijn (f=1, ρ-fallback, SSPF-weging 95/5), expliciet gedocumenteerd dat SSPF-jaarverslag/Implementatieplan de waardes later kan vervangen zonder spec-revisie.

---

## KRITIEKE ARCHITECTUUR — STRUCTUREEL VASTGELEGD

Deze keuzes moeten bij elke volgende sessie paraat zijn:

### Module-structuur

- **M1** = huidige waarde: levert `KV_OP`, `KV_NP`, `KV` totaal + annuïteitsfactoren per leven + levensverwachtingen
- **M2** = potje: levert `ppkBase + ppkSurplus + ppkComp = ppkTotal`, met **geoormerkte subcomponenten `ppk_OP` en `ppk_NP`** (v2.0)
- **M3** = uitkeringsbenadering: levert pad + onzekerheidsbanden, gebruikt `ppkTotal` en heeft interne NP-schakel bij overlijden deelnemer (detailimplementatie openstaand)
- **M4** = waardevergelijking: docx-spec overgenomen, V_DB vs V_Wtp cohort-correct op AG2024

### Sterftetafel

- **AG2024** is de normatieve bron per geslacht (bestand: `AG2024.xlsx`, sheets `qx mannen 2024` en `qx vrouwen 2024`)
- **M1-3 gebruikt periode-snapshot** (één kolom `t_0=2026`)
- **M4 gebruikt cohort** (diagonaal `q_{x+t, t_0+t, g}`)
- **Gender verplicht invullen in UI**, `gemengd` is fallback met SSPF-weging 95/5

### Rente

- **Eén UI-slider** voor discontering (default 2%), gekoppeld doorwerken naar `r` (M1), `proj` (M3), `i` (M4-fallback)
- **Ontkoppelings-toggle** voor power-user
- **`μ` (M3 GBM verwachtingswaarde rendement)** is apart — niet hetzelfde als discontering

### Annuïteitsconventie

- **Uniform arrears m=12** in alle modules

### NP-regime

- NP wordt **mee-ingevaren** in persoonlijk pensioenvermogen
- **Geoormerkt** binnen één kapitaal (niet apart depot)
- Collectief belegd, levenslang

---

## OPEN BESLISPUNTEN VOOR SCHERM 2

Tijdens v2.0 doorwerking zijn detailvragen geïdentificeerd die in scherm-2-sessie moeten worden beslist:

1. **Exacte ppkSurplus-OP/NP-splitsingsformule.** De lineaire splitsing (via KV-ratio) werkt voor ppkBase; voor ppkSurplus gelden levensspecifieke spreidingsfactoren. Keuze: zuivere actuariële splitsing (ongelijke totalen t.o.v. geaggregeerde formule) of correctiefactor. Zie §3.5 "Notatie-noot" in spec.

2. **ppkComp dubbeling-check.** v2.0 stelt vast dat compensatiedepot volledig aan OP gaat (deelnemer-compensatie, geen NP). Te bevestigen: is dit consistent met SSPF-transitieplan, of krijgt de NP-aanspraak ook compensatie bij invaren?

3. **`phiDerived` referentie bij OP/NP-splitsing (§11.12).** Wordt `phiDerived` berekend op totaal (`ppkTotal / V_x^Wtp_totaal`), per component, of beide? Reservering uit v1.1 nog open.

4. **Lifecycle-rente in M2/M3 (§11.8).** Nog niet besloten. Past eerder bij M3 dan M2, maar raakt potje-berekening indirect.

5. **BufferTrigger-default (§11.6).** Nog niet besloten. Past bij M3 maar beïnvloedt `buffer`-aandeel uit M2.

6. **Correlatie rente-inflatie (§11.7).** M3-parameter, niet eerder beslist.

---

## OPEN BESLISPUNTEN VOOR SCHERM 3

- **Cross-punt 3**: gender in `ä(x, proj)` voor U₀. Triviale doorwerking van v1.7-besluit, maar formeel in spec vastleggen.
- **NP-schakel mechaniek**: hoe wordt de latent-NP-dekking uit ppk_NP geactiveerd bij overlijden deelnemer in projectie? Eén kapitaal, twee uitkeringspaden die conditioneel wisselen op overlijdensevent.
- **§11.9 Plot-horizon** — niet scherm-1 afhandelbaar, past bij scherm 3/UI.

---

## OPEN BESLISPUNTEN VOOR SCHERM 4

- **Cross-punt 5**: cohort-correct M4 versus periode-snapshot M1 — levert bewust <1% verschil; toe te lichten in UI of opgeheven?
- M4-specifieke reviewpunten uit §5.12 docx-spec overgenomen, nog niet individueel beslist.

---

## DATA-TODO'S VOOR HANS (NIET-BLOKKEREND)

Deze moeten ergens in implementatiefase worden aangeleverd, niet spec-blokkerend:

1. **SSPF-specifieke `f`-waarde** (Implementatieplan of jaarverslag) — vervangt placeholder 1,0.
2. **SSPF uitvoeringskosten per jaar** (jaarverslag, `financieel.uitvoeringskostenJaarlijks`) — activeert Variant-A-afleiding voor ρ, vervangt 0,02-placeholder.
3. **SSPF M/V-verdeling per cohort** (jaarverslag demografie) — vervangt 95/5 placeholder in `demografie.genderWegingSSPF`.
4. **AG2024 populatie-data voor gemengde tafel** — voor NL-neutrale weging als alternatief naast SSPF-prior (CBS Statline bevolkingsopbouw).
5. **Q-tafel herkomst documentatie** — bevestigd als fout (zie v1.7 onderbouwing); R9.30-waardes gedeprecieerd.

---

## VOLGENDE-SESSIE-AANPAK (VOORSTEL)

1. **Start**: lees `ENGINE_SPECIFICATIE_v1.md` v2.1 volledig door, met focus op §1.1 (narratief kompas), §3 (module 2), §11 (alle genomen besluiten).
2. **Eerste inventarisatie**: welke scherm-2-punten open staan (zie "OPEN BESLISPUNTEN VOOR SCHERM 2" hierboven).
3. **Werkwijze**: zelfde stap-voor-stap als scherm 1 — probleem / opties / aanbeveling / beslissing / direct patchen / volgende punt.
4. **Versiebump-regel**: patch-niveau (v2.1.1, v2.1.2...) voor kleine beslissingen; minor (v2.2, v2.3) voor structuurveranderingen binnen scherm 2; major (v3.0) alleen bij fundamentele herordening zoals NP-integratie was.
5. **Breekpunt**: na scherm-2-voltooiing handoff maken (zelfde stijl als dit document) voordat scherm 3 of SCHEMA v2 wordt begonnen.

---

## BRONBESTANDEN — COMPLETE INVENTARIS

Volgende sessie heeft deze bestanden nodig:

**Van deze sessie nieuw:**
- `ENGINE_SPECIFICATIE_v1.md` (v2.1, 1674 regels) — normatieve spec
- `HANDOFF_v2.1.md` (dit document) — handoff voor volgende sessie

**Eerder opgeleverd (onveranderd):**
- `ARCHITECTUUR_v1.md` — leidend architectuur-document, basis voor spec §12-opdracht
- `DESIGN_engine_v0.md` — reverse-engineering R9.30 engine, basis voor spec modules 1-3
- `calculator_specificatie.docx` — M4-docx-spec, overgenomen in spec §5
- `SCHEMA_v1.md` — huidige SCHEMA (wordt v2 op basis van deze spec)
- `STRATEGY_R9.30.md` — strategische context
- `HANDOFF_R9.30.md` — technische handoff code (ander track)
- `21-04-2026_2216.html` — R9.30 werkbestand (code baseline)

**Externe data:**
- `AG2024.xlsx` — AG2024 gemodelleerde prognose-sterftekansen per geslacht (KAG 12-09-2024)
- `51490-Data_AG2024.xlsx` — AG2024 brondata (Deaths/Exposures, 1970-2019)

---

## AFSLUITENDE NOTITIE

Deze sessie heeft de engine-spec voor scherm 1 van 0 naar volwassen gebracht. Het proces was stap-voor-stap, elke beslissing werd aan het narratief kompas getoetst, en externe bronnen (AG2024, SSPF-transitieplan, CBS) zijn daadwerkelijk geconsulteerd voordat keuzes werden geforceerd. Volgende sessie vervolgt met scherm 2; de methodiek staat, de spec is de bronwaarheid, en de openstaande punten zijn concreet gelabeld.

*Einde HANDOFF_v2.1.md*
