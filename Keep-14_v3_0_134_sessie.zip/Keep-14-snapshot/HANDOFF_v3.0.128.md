# HANDOFF v3.0.128 — Drie gevoeligheidsgrafieken + versie in filename

**Datum**: 2026-05-14
**Versie**: 3.0.128 (was v3.0.119 bij start sessie)
**Werkdir**: `/home/claude/Keep-14/`
**Voorganger**: `HANDOFF_v3.0.119.md` (eerdere sessie, integreert volledige historie)

Deze handoff dekt de wijzigingen tussen v3.0.119 → v3.0.128: de iPad-Safari-fix, de tweede gevoeligheidsgrafiek (bijstort), de jaarpensioen-equivalent-regel in M2-KPI, de derde gevoeligheidsgrafiek (verhoging vs. indexatie), de annuïteit-factor-correctie voor partnerpensioenverplichting, en versienummer in output-filename.

---

## 1. Wat is er gebouwd deze sessie

### v3.0.120 — iPad-Safari false-positive fix
- `build.calc.ts`: detector-timeout 2000 → 5000 ms
- Probleem: hosted v3.0.119 op iPad Safari 26.2 toonde "JS-bundle uitgevoerd maar #app bleef leeg na 2s" bij eerste-load, terwijl de calculator wél werkte. Root cause: 2s timeout vuurde af terwijl parsing van 524 KB PDF-base64 + 82 KB AG2024 + 142 KB bundle nog bezig was.
- Optie A (minimale ingreep): timeout verlengd, geen andere wijzigingen.

### v3.0.121 — Bijstort-gevoeligheidsgrafiek (tweede grafiek)
Iteratief prototype-ontwikkeld in `prototypes/` over ~7 iteraties:
1. Aanvankelijk X-as 0-1500 mln, Y-as % van KV (absoluut), één lijn met €500/€650/€850 verticale referentielijnen
2. Switch naar "% extra aandeel" delta
3. Tussenstap met drie parallelle DG-lijnen (125/130/135%) — wiskundig gemeten als exact parallel, helling 0,3938 %-punt per €100 mln
4. Drie-lijnen-versie verwijderd ("alle DG gelul") — terug naar één lijn
5. Eindversie: één lijn, X-as 0-2500 mln (slider-max), Y-as delta-euro t.o.v. huidige slider-stand (kan +/−), tweede Y-as rechts voor jaarpensioen-equivalent (k€/jaar)
6. Interactieve hover/tap-tooltip met crosshair + 3-regel value-label, snap op €10 mln

Geïntegreerd in `src/ui.sensitivity.ts` (~250 nieuwe regels):
- `runBijstortSweep(deelnemer, m1Out, m2Params)` — 251 M2-runs, DG vast, bijstort sweep
- `renderBijstortHTML(sweep)` + private `renderBijstortSVG(sweep)`
- `attachBijstortTooltip(container, sweep)` — wordt ná innerHTML-injectie aangeroepen
- Types: `BijstortPoint`, `BijstortSweep`

UI-wijzigingen (`src/ui.app.ts`):
- "Gevoeligheidsgrafiek"-knop hernoemd → "Effect dekkingsgraad"
- Nieuwe knop "Effect werkgevers-bijdrage"
- Eén modal-container hergebruikt — titel en body switchen per grafiek
- `openBijstortModal` parallel aan `openSensitivityModal`

CSS-class hernoemd `svg.dg-chart` → `svg.sens-chart` voor gedeelde styling.

### v3.0.122 — Jaarpensioen-equivalent in M2-KPI
- `renderM2KPI` signature uitgebreid met `pen` parameter (twee call-sites bijgewerkt in `ui.app.ts`)
- Nieuwe regel onder bestaande %-regel: `≈ + € 24.091 per jaar pensioen levenslang ?`
- Wiskunde: `jaarequivalent = aandeel / (KV_OP / pen)` ≈ €24k voor 70j M met app-defaults
- Edge case: regel verschijnt alleen als `pen > 0 && KV_OP > 0`
- `HELP_CONTENT.jaarequivalent` toegevoegd met drie secties (wat betekent dit / levenslang / geen rechten)
- CSS: nieuwe class `.kpi-formula-foot-secondary` (kleinere top-marge, geen border)

### v3.0.123 — Jaarpensioen-tekst verduidelijkt
Hans wees op verwarring (€24k klinkt als nieuw totaal, maar is verhoging):
- Tekst: `≈ + € 24.091 per jaar pensioen levenslang` → `≈ + € 24.091 extra (boven uw huidige € 100.000) per jaar pensioen levenslang`
- Bij negatief aandeel: "extra" wordt automatisch "minder" (grammatica wat krakkemikkig bij tekort-scenario — niet opgelost, zie §6)

### v3.0.124 — Tekstfix: "uitkeringskeuzes" weg
SSPF heeft geen uitkeringskeuzes (geen hoog-laag-keuze achteraf, geen vaste/variabele uitkering). De disclaimer-tekst die op vier plekken stond was feitelijk fout voor SSPF.
Volledige scan + correctie: "uitkeringskeuzes" → "fondsbeleidsbeslissingen" in:
- `HELP_CONTENT.jaarequivalent` (M2-KPI helpicon)
- Bijstort-grafiek meta-note in tool
- Beide prototypes

Volledige grep-scan na fix bevestigt 0 voorkomens in user-facing tekst.

### v3.0.125 — Derde grafiek: Verhoging vs. indexatie over de tijd
Volledig nieuwe grafiek. Prototype iteratief ontwikkeld:
1. Eerste interpretatie: beide lijnen geïndexeerd (huidig vs. verhoogd) — was fout
2. Hans corrigeerde: vlak vs. geïndexeerd → kruispunt-verhaal
3. Kleuren: rood (M2-pane-kleur) voor vlak, groen (M1-pane-kleur) voor geïndexeerd
4. Tekst herformuleerd van stellig ("uw nieuwe pensioen na invaren") naar scenario-framing ("rode lijn toont een vlak verloop... aanname: geen indexatie")
5. Meta-note uitgebreid: vetgedrukte tussenzin "veel meer factoren die niet zijn gemodelleerd", lijst (o.a. beleggingsbeleid en lifecycle per cohort, solidariteitsreserves, risicodelingsmechanismes, etc.)

Wiskunde:
- **Rode lijn**: vlak op `pen + jaarequivalent` (€124.091 voor app-defaults)
- **Groene lijn**: `pen × (1 + r)^t` met r = rekenrente uit M1-parameters (2,5% voor SSPF, DNB UFR-curve eind 2025)
- **Verwachte sterfleeftijd**: `lifeExpectancy(x, t0, g, opts)` uit `src/engine.m1.ts` (export al beschikbaar, gebruikt AG2024 + ervaringsSterfte f + omega)
- **Kruispunt**: `t = ln(verhoogd / pen) / ln(1 + r)`, leeftijd = `x0 + t`. Voor app-defaults ~78,75 jaar
- Geen sweep nodig — twee analytische functies

Code in `src/ui.sensitivity.ts` (~150 nieuwe regels):
- `runIndexedSweep(deelnemer, m1Out, m2Out, m1Params)` → `IndexedSweep`-data-object
- `renderIndexedHTML(sweep)` + private `renderIndexedSVG(sweep)`
- Geen tooltip-handlers (grafiek is statisch)
- Type `IndexedSweep`

UI:
- Vierde knop in pane-actions: "Verhoging vs. indexatie"
- `openIndexedModal` parallel aan `openSensitivityModal` / `openBijstortModal`

### v3.0.126 — Knopvolgorde
Volgorde van links naar rechts:
1. **Verhoging vs. indexatie** (nieuwste, prominent vooraan)
2. **Effect dekkingsgraad**
3. **Effect werkgevers-bijdrage**
4. **Modelspecificatie**

### v3.0.127 — Annuïteit-factor gecorrigeerd voor partnerpensioen
Hans wees op een fout in de jaarpensioen-equivalent-regel: bij partneraanwezigheid bevat het aandeel verdeelbaar overschot óók een NP-deel, wat onrealistisch hoge "verhoging per jaar" gaf. Wiskundig:

```
Persoonlijk pensioenvermogen = OP × ä꜀ + PP × ä꜀|ₚ
                            = pen × ä꜀ + y0 × ä꜀|ₚ
→ KV / pen = ä꜀ + (y0/pen) × ä꜀|ₚ   ← gewogen factor
   KV_OP / pen = ä꜀                  ← alleen eigen leven
```

Hetzelfde vermogen moet zowel uw OP-uitkering dragen zolang u leeft als de PP-uitkering aan partner ná uw overlijden. De juiste annuïteit-factor is dus `KV / pen` (gewogen), niet `KV_OP / pen` (alleen eigen leven).

Fix op drie plekken:
- `renderM2KPI` in `src/ui.m2.ts`
- `runBijstortSweep` in `src/ui.sensitivity.ts`
- `runIndexedSweep` in `src/ui.sensitivity.ts`

Plus edge-case-check `pen > 0 && KV > 0` (KV ≥ KV_OP altijd, dus geen extra risico).

Tekst-updates:
- `HELP_CONTENT.jaarequivalent` krijgt nieuwe sectie "EN ALS U EEN PARTNER HEEFT?" met uitleg over de gewogen pot
- Bijstort meta-note: "...AG2024-sterftekansen, huidige rekenrente en — indien van toepassing — de reservering voor partnerpensioen"
- Indexed meta-note: extra zin "De omrekening van kapitaal naar jaarpensioen houdt — indien van toepassing — rekening met de reservering voor partnerpensioen"

Validatie via verify-script:
- **Zonder partner** (default): KV_NP=0 → KV=KV_OP → factor identiek (12,983), jaarequivalent ongewijzigd €24.608. Geen regressie.
- **Met partner** (y0=70k, vrouw 68j): factor 12,98 → **16,06**, jaarequivalent €36.239 → **€29.305** (~€6.900 realistisch lager).

De factor 16,06 = 12,98 + (70/100) × 4,4, met ä꜀|ₚ ≈ 4,4 (lager dan typisch literatuur-getal ~5,5 vanwege rekenrente 2,5% in plaats van 2%, plus AG2024-conditional survival voor vrouw 68).

### v3.0.128 — Versienummer in output-filename
Hans wilde dat de "download all"-bundel in de chat-interface herkenbaar is per versie. De handoff-zip en helpicon-PDF hadden het versienummer al; alleen `calculator.html` had een generieke naam.

Fix: `OUT_HTML` in `build.calc.ts` aangepast van vaste `/mnt/user-data/outputs/calculator.html` naar dynamisch `calculator_v${releaseVersion}.html`. Definitie verplaatst naar binnen `build()` omdat het versienummer pas beschikbaar is ná extractie uit `src/ui.app.ts` (regel ~46).

Resultaat: build genereert nu `calculator_v3.0.128.html`. Bij hosting kan een symlink of redirect een stabiele URL bieden indien gewenst.

---

## 2. Gewijzigde bestanden

### Source-files (in `src/`)
- **`src/ui.app.ts`** (1752 regels, +52 t.o.v. v3.0.119):
  - Imports uitgebreid met `runBijstortSweep, renderBijstortHTML, attachBijstortTooltip, runIndexedSweep, renderIndexedHTML`
  - Vier knoppen in pane-actions (was 2)
  - `openBijstortModal`, `openIndexedModal` toegevoegd; bestaande `openSensitivityModal` aangepast om titel dynamisch te zetten
  - Click-handlers voor `bijstort-btn`, `indexed-btn` in document-listener
  - `renderM2KPI` call-sites (2×) updaten met `state.deelnemer.pen`
  - `HELP_CONTENT.jaarequivalent` entry met drie secties
  - Versie bump 119 → 126

- **`src/ui.m2.ts`** (456 regels):
  - `renderM2KPI` signature: `(m1Out, m2Out)` → `(m1Out, m2Out, pen)`
  - Nieuwe `kpi-formula-foot-secondary` regel met jaarequivalent
  - Tekst v3.0.123: `extra (boven uw huidige € X)`

- **`src/ui.sensitivity.ts`** (778 regels, +~400 t.o.v. v3.0.119):
  - Import `lifeExpectancy, getAG2024` uit `engine.m1.ts`
  - Bijstort-blok: `BijstortPoint`, `BijstortSweep`, `runBijstortSweep`, `renderBijstortSVG`, `renderBijstortHTML`, `attachBijstortTooltip`
  - Indexed-blok: `IndexedSweep`, `runIndexedSweep`, `renderIndexedSVG`, `renderIndexedHTML`
  - Tekstfix v3.0.124: "uitkeringskeuzes" → "fondsbeleidsbeslissingen" in bijstort meta-note
  - CSS-class in DG-renderer: `dg-chart` → `sens-chart`

### Build-file
- **`build.calc.ts`** (1728 regels):
  - Detector-timeout 2000 → 5000 ms (v3.0.120 fix)
  - CSS-selector `svg.dg-chart` → `svg.sens-chart`
  - Nieuwe CSS-class `.kpi-formula-foot-secondary`

### Prototype-files (in `prototypes/`)
- **`prototypes/sweep_bijstort.ts`**: laatste versie X 0-2500, app-defaults pen=100k, anker=slider-stand, annuiteitFactor=KV_OP/pen
- **`prototypes/sweep_bijstort.json`**: 251 punten gegenereerd output
- **`prototypes/bijstort_grafiek_template.html`**: laatste versie met interactieve tooltip + dubbele Y-as. "Verandering bij andere bijdrage" / "Uw huidige instelling" als legend
- **`prototypes/indexed_pension_grafiek_prototype.html`**: nieuw, derde grafiek prototype (vlak vs. geïndexeerd)

---

## 3. Werkafspraken (cumulatief, ongewijzigd)

Bevestigd uit eerdere sessies:
- **W12**: Eén wijziging per turn
- **W13**: HANDOFF in werkdir + zip
- **W14**: ?-helptekst is puur invul-help (concreet over slider/veld, geen modelspec-tutorials)
- **W15**: Audit via rapport-knop
- **W16**: `RELEASE_VERSION + 1` bij elke wijziging in `src/`, `build.calc.ts`, of `fondsen/`-bestanden
- **W17**: PDF-sync bij wijzigingen die ook de modelspec raken (deze sessie BEWUST overgeslagen, PDF blijft v3.0.108 — zie §6)

---

## 4. Architectuur — vier knoppen, één modal-container

Pattern verfijnd deze sessie: in plaats van per-grafiek-eigen modal, gebruiken we **één gedeelde modal-container** (`sensitivity-modal-overlay` in `build.calc.ts`) met dynamische titel + body.

```
[knop X]
  → handler in document-listener
  → run sweep-functie (geeft type-X-specifiek sweep-object)
  → openXModal(sweep)
    → modal-titel zetten
    → bodyEl.innerHTML = renderXHTML(sweep)
    → display: flex
    → (optioneel) attachXTooltip(bodyEl, sweep)
```

De drie grafieken (DG, bijstort, indexed) volgen exact dit patroon. Modelspec-knop (vierde knop) heeft eigen flow (PDF-download), maakt geen gebruik van de modal.

---

## 5. Edge cases en validaties

**Bijstort-grafiek**: 
- Aanker = huidige slider-stand → blauwe stip altijd op delta=0
- Voor jaarpensioen-rechter-as: `annuiteitFactor = KV_OP / pen`; bij `pen=0` of `KV_OP=0` valt rechter-as weg (alleen linker-as getoond)
- Snap op €10 mln (sweep-resolutie); tooltip toont alleen sweep-punten
- Tap-elsewhere op mobile: tooltip sluit

**M2-KPI jaarequivalent-regel**:
- Verschijnt alleen als `pen > 0 && KV_OP > 0`
- Negatief aandeel: "extra" → "minder" automatisch, met "−" teken
- Edge case "minder boven uw huidige € Y": grammaticaal niet soepel, niet opgelost (zie §6)

**Indexed-grafiek**:
- Kruispunt-stip + label alleen getoond als `ageCross` binnen X-range [x0, xMax]
- Bij `verhoogd <= pen` (negatief aandeel scenario): geen kruispunt mogelijk, `ageCross = null`
- Bij `r = 0`: geen kruispunt mogelijk (lijn loopt vlak)
- Y-bereik: dynamisch, afgerond op stappen van 20 k€
- Verwachte sterfleeftijd via M1-engine, deelnemer-specifiek (M/V, ervaringsSterfte, omega)

---

## 6. Pending / openstaand

### A. M2-tekort-scenario tekst-tweaks
Bij negatief aandeel toont jaarpensioen-regel: `≈ − € X minder (boven uw huidige € Y) per jaar pensioen levenslang`. De zin "minder boven uw huidige" is grammaticaal niet soepel. Mogelijke oplossingen voor later: bij negatief aandeel "boven" → "ten opzichte van" of een aparte tekst-vorm.

### B. Werkafspraak 17 (PDF-sync) — uitgesteld
UI is v3.0.126, embedded PDF is nog v3.0.108. Hans expliciet akkoord met mismatch deze sessie. Voor publicatie: PDF moet hercompileerd worden.

### C. Cleanup-roadmap (uit `HANDOFF_v3.0.119.md` §6) — niet uitgevoerd
Onbereikbare files (`ui.print.ts`, `ui.audit-report.ts`, `build.ts`, etc.), 14 ongebruikte CSS-klassen, etc. Detail in voorganger-handoff.

### D. Transitiebijdrage als DG-functie — niet gemodelleerd
Hans heeft expliciet besloten dit "te laten zitten" — alleen helpicon toegevoegd in eerdere sessie. Status onveranderd.

### E. Visuele tests
De drie grafieken zijn alleen JSDOM-getest. Visuele controles nog open:
- Bijstort-grafiek: tooltip-positionering bij modal-rand, label-fit op mobile, label-positie-switching links/rechts
- Indexed-grafiek: Y-range schaalvermogen bij verschillende deelnemers (jonge vs. oude, M vs. V), modal-wissel zonder rest-artifacts
- M2-KPI: weergave van de tweede regel bij brede vs. smalle viewports

---

## 7. Bundle-evolutie deze sessie

| Versie | Bundle | Delta | Reden |
|---|---|---|---|
| v3.0.119 | 141.8 KB | — | startpunt |
| v3.0.120 | 141.8 KB | +0 KB | timeout-constante |
| v3.0.121 | 151.3 KB | +9.5 KB | bijstort-functies |
| v3.0.122 | 152.5 KB | +1.2 KB | jaarequivalent + helpicon-tekst |
| v3.0.123 | 152.6 KB | +0.1 KB | tekstverduidelijking |
| v3.0.124 | 152.7 KB | +0.1 KB | tekstfix "fondsbeleidsbeslissingen" |
| v3.0.125 | 158.4 KB | +5.7 KB | indexed-grafiek-functies |
| v3.0.126 | 158.4 KB | +0 KB | knopvolgorde |
| v3.0.127 | 159.0 KB | +0.6 KB | annuïteit-fix KV/pen + tekst-updates |
| v3.0.128 | 159.0 KB | +0 KB | versienummer in output-filename |

Totaal: +17.2 KB voor twee nieuwe grafieken + jaarequivalent-regel. Calculator-output: 796.4 KB (was 786 KB bij v3.0.119), bestandsnaam nu `calculator_v3.0.128.html`.

---

## 8. Inventarisatie van bestanden

```
src/ui.app.ts             1752 regels  (was 1700)
src/ui.sensitivity.ts      778 regels  (was 247)
src/ui.m2.ts               456 regels  (was ~430)
build.calc.ts             1728 regels  (was ~1700)
prototypes/sweep_bijstort.ts            nieuw (~100 regels)
prototypes/bijstort_grafiek_template.html  nieuw
prototypes/indexed_pension_grafiek_prototype.html  nieuw
```

Geen tests gefaald (alleen pre-bestaande test-bestanden buiten `src/` hebben hun gebruikelijke compile-warnings).

---

## 9. Voor de volgende sessie

Korte status: v3.0.128 is een complete release. Output heet nu `calculator_v3.0.128.html` voor herkenbare downloads. De jaarpensioen-equivalent-regel rekent correct met de gewogen annuïteit-factor (KV/pen) die de PP-verplichting meeneemt.

Volgende prioritaire items in volgorde van urgentie:
1. **Visuele tests** van de drie grafieken op echte devices (desktop, iPad, mobiel)
2. **PDF-modelspec hercompileren** naar v3.0.128 (W17-afhandeling)
3. **Tekortscenario tekst-tweak** bij jaarequivalent-regel (§6.A)
4. **Cleanup** van onbereikbare files + CSS (§6.C)
