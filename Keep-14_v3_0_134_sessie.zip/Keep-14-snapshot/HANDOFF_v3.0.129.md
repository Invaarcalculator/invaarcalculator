# HANDOFF v3.0.129 — Help-uitbreiding OP/PP-proportionaliteit + modelspec-update

**Datum**: 2026-05-14
**Versie**: 3.0.129 (was v3.0.128 bij start)
**Werkdir**: `/home/claude/Keep-14/`
**Voorganger**: `HANDOFF_v3.0.128.md`

Deze handoff dekt één semantische wijziging in twee samenhangende artefacten: (1) uitbreiding van `HELP_CONTENT.jaarequivalent` met een sectie die expliciet maakt dat de jaarpensioen-equivalent-regel een proportionele OP/PP-stijging impliceert, en (2) een nieuwe versie van de modelspec (`BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.129.md`) met een aanvullende §9-bullet die de OP/PP-proportionaliteit als gevolg van SSPF's keuze voor levenslange spreiding wettelijk verankert (Bijlage 2a Regeling Pw, art. 21 Reg Pw, DNB-factsheet), met verwijzing naar WTW (Pensioen Update februari 2025) over de kasstroom-afhankelijke aanpassing onder spreidingstermijn > 1.

---

## 1. Wat is er gebouwd deze sessie

### v3.0.129 — Help-tekst + modelspec OP/PP-proportionaliteit
Aanleiding: deep-dive op web (Bijlage 2a Reg Pw, DNB-factsheet *Omrekenmethoden bij invaren*, Pensioenfederatie servicedocument, WTW Pensioen Update februari 2025, en fonds-praktijk PMT/SPMS/PFZW/bpfBOUW) bevestigde dat de huidige jaarpensioen-equivalent-formule `ΔOP = aandeel / (KV/pen)` voor SSPF wiskundig consistent is met een proportionele OP/PP-stijging na invaren. Cruciaal: dat is een rechtstreeks gevolg van SSPF's `spreidingN = 1000`-keuze (impl.plan §5.6). Bij de wettelijke default-spreiding van 10 jaar zou de proportionaliteit niet exact gelden, omdat de standaardregel op kasstroom-niveau per individu i en horizon h werkt en OP/PP-kasstromen verschillende horizon-distributies hebben.

Twee aanpassingen, samen één wijziging:

**Help-tekst** (`src/ui.app.ts`):
- Nieuwe sectie toegevoegd aan `HELP_CONTENT.jaarequivalent`, na "EN ALS U EEN PARTNER HEEFT?" en vóór "WAT BETEKENT 'LEVENSLANG'?":
  - Heading: "WAT GEBEURT ER MET HET PARTNERPENSIOEN BIJ INVAREN?"
  - Body: legt uit dat de standaardregel (Bijlage 2a Reg Pw) plus SSPF's keuze voor levenslange spreiding leidt tot proportionele OP/PP-doorwerking; concretiseert "+30% verhoging" voor zowel OP als PP-aanspraak partner; benoemt dat onder de default 10-jaars spreiding deze proportionaliteit niet exact zou gelden.

**Modelspec** (`BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.129.md`):
- Nieuwe file (kopie van v3.0.108-versie met versie-string updates en één aanvullende bullet).
- §9 ("Aannames en hun rechtvaardiging") — nieuwe bullet direct na de bestaande `N = 1000`-bullet:
  - **OP/PP-proportionaliteit bij eerbiediging via levenslange spreiding** — formele uitleg dat `q(h, 1000) ≈ vlak`, dat de M2-KPI-formule `ΔOP = aandeel / (KV/pen)` met `KV/pen = ä꜀ + (y₀/pen)·ä꜀|ₚ` impliciet uitgaat van proportionele OP/PP-groei, met WTW-citaat over kasstroom-afhankelijke aanpassing onder spreidingstermijn > 1, en verwijzing naar art. 21 Reg Pw + DNB-factsheet.
- Versie-strings (3 plekken): titel §0, intro §1, vergelijkingstabel §10 — allemaal `v3.0.108` → `v3.0.129`.
- Filename-referentie `calculator_v3.0.108.html` → `calculator_v3.0.129.html`.
- Peildatum-noot 11 mei 2026 → 14 mei 2026.
- Regressie-anker in §8 (`v3.0.108` in test-naamverwijzing) bewust NIET aangepast — dat verwijst naar het moment van eerste vastlegging van de waarde EUR 1.611.130, niet naar de huidige versie. Engine-getal blijft hetzelfde.

Geen wijzigingen aan engine-code, schema's of fondsdata. Engine-output bit-identiek aan v3.0.128 (verify-script bevestigt €24.091 zonder partner / €30.496 met partner, ongewijzigd).

---

## 2. Gewijzigde bestanden

### Source-files (in `src/`)
- **`src/ui.app.ts`**: één toegevoegde HELP_CONTENT-sectie (~7 regels object), versie 3.0.128 → 3.0.129. Geen andere wijzigingen.

### Modelspec (in werkdir-root)
- **`BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.129.md`** (nieuw, kopie van .108 met aanpassingen):
  - 4 versie-string-updates
  - 1 nieuwe §9-bullet (~10 regels prozas, met WTW-citaat in directe rede)
  - Totaal +~14 regels t.o.v. v3.0.108-versie

### Build-file
- **`build.calc.ts`**: ongewijzigd. Build pakt automatisch nieuwe RELEASE_VERSION op.

### Niet aangepast (bewust)
- `BIJLAGE2_MODELSPECIFICATIE_Invaarcalculator_v3.0.108.tex`: PDF-hercompilatie hoort bij W17-afhandeling (uitgesteld per handoff v3.0.128 §6.B). Embedded PDF in calculator is nog v3.0.108. Voor v3.0.129 betekent dit: gehoste UI verwijst naar Modelspecificatie_Invaarcalculator_v3.0.129.pdf via download-link, maar de bytes daarin zijn nog v3.0.108-inhoud. Hercompilatie .tex → .pdf is een aparte handeling die Hans orkestreert.
- Engine, schema, fondsdata, tests, prototypes: ongewijzigd.

---

## 3. Werkafspraken (cumulatief)

Geen wijzigingen. W12 ("één wijziging per turn") is hier strikt genomen niet gevolgd omdat help-tekst en modelspec in één turn zijn aangepakt; rechtvaardiging: één semantische wijziging in twee artefacten (UI + documentatie van dezelfde aanname), expliciet door gebruiker gevraagd ("Implementeer 1 en 2"). Eén versie-bump.

W16 (versie-bump): gedaan, 128 → 129.

W17 (PDF-sync): nogmaals bewust overgeslagen voor PDF-bytes. .md-bron-of-waarheid is wel bijgewerkt naar v3.0.129; .tex en .pdf blijven v3.0.108. Voor publicatie van v3.0.129 als release: PDF moet hercompileerd worden uit een nog te genereren v3.0.129.tex.

---

## 4. Inhoudelijke achtergrond (samenvatting deep-dive)

De deep-dive vond drie ankers die de proportionele OP/PP-aanname onderbouwen:

Eerste anker: de wettelijke standaardregel (Bijlage 2a Reg Pw, art. 1) werkt op kasstroom-niveau per individu i en horizon h, en gebruikt een spreidings-multiplier `q(h, N) = min(⌊h⌋/N, 1)`. Bij N = 1000 reduceert dit voor alle praktisch relevante looptijden (h ≤ 95) tot een effectief vlakke verdeling: het verdeelbare overschot wordt proportioneel aan de aanspraakwaarde toegekend, ongeacht horizon. Het gevolg is dat OP-aanspraken en PP-aanspraken na pensioendatum, beide deel van dezelfde individuele aanspraakwaarde, dezelfde procentuele aanpassing krijgen.

Tweede anker: WTW analyseert dit punt expliciet in *Uiteenlopende invullingen van de eerbiediging van partnerpensioen* (Pensioen Update, februari 2025): "Die verhoging (of in voorkomende gevallen verlaging) van de aanspraak op partnerpensioen zal — uitgaande van een spreidingstermijn groter dan één — leeftijdsafhankelijk zijn en afwijken van de aanpassing van de aanspraak op ouderdomspensioen. Dat is het gevolg van de te volgen rekenmethodiek waarbij de kasstroom per aanspraak bepalend is voor de hoogte van de aanpassing." Met andere woorden: onder de wettelijke default N = 10 wijken OP- en PP-aanpassingen af; onder N = ∞ vallen ze samen. WTW merkt ook op dat "voor gepensioneerden de eerbiediging minder vragen oproept" omdat het PP-vóór-pensioendatum vervallen is.

Derde anker: fonds-praktijk. PMT en SPMS hanteren een doorlopende OP/PP-percentage-koppeling (resp. 50% en 70%): als OP fluctueert beweegt PP automatisch mee. Voor SSPF betekent dit conceptueel hetzelfde: het persoonlijk pensioenvermogen draagt zowel OP als PP-na, en bij invaren-overschot beweegt de hele aanspraak in dezelfde verhouding op.

Aanvullende ankers benoemd in modelspec maar buiten scope van implementatie: DNB's notitie dat art. 220g Pw géén toegezegde garantie inhoudt (eerbiediging in waardetermen, niet in nominale aanspraak); de mogelijkheid van "egalisatie-correctie" binnen cohort gepensioneerden ná de standaardregel (Ortec — SSPF lijkt dit blijkens spreidingN = levenslang niet toe te passen); art. 150o lid 2 Pw (95%-rekenregel-grens).

---

## 5. Bundle-evolutie

| Versie | Bundle | Delta | Reden |
|---|---|---|---|
| v3.0.128 | 159.0 KB | — | startpunt |
| v3.0.129 | 159.8 KB | +0.8 KB | nieuwe HELP_CONTENT-sectie OP/PP-proportionaliteit |

Calculator-output: `calculator_v3.0.129.html`, 797.2 KB (was 796.4 KB).

---

## 6. Validatie

Verify-script `verify_jaarequivalent.ts` (sessie-artifact, niet in build-pad): bevestigt engine-output ongewijzigd.

```
Zonder partner: KV=€1.298.341, ppkTotal=€1.611.130, aandeel=€312.790, KV/pen=12,9834 → jaar-equiv €24.091
Met partner:    KV=€1.679.814, ppkTotal=€2.192.088, aandeel=€512.274, KV/pen=16,7981 → jaar-equiv €30.496
```

Beide identiek aan v3.0.128, zoals verwacht — engine is niet aangeraakt.

---

## 7. Pending / openstaand

### A. PDF-hercompilatie v3.0.108 → v3.0.129 (W17-afhandeling)
.tex-bestand moet bijgewerkt worden (vergelijkbare wijzigingen als .md), waarna LaTeX-compilatie de nieuwe `Modelspecificatie_Invaarcalculator_v3.0.129.pdf` levert die in de `build.calc.ts` PDF-base64-stream wordt opgenomen. Tot dan: gehoste UI download-link toont versie 3.0.129 in bestandsnaam maar PDF-bytes zijn v3.0.108. Hans expliciet akkoord met mismatch sinds v3.0.108 (handoff §6.B).

### B. Visuele test van nieuwe help-sectie
JSDOM-test niet uitgevoerd voor de toegevoegde sectie; klikbaar `?`-icoon achter de jaarequivalent-regel moet de help-modal tonen met vier secties in plaats van drie. Modal-hoogte kan op mobiele viewport mogelijk een scroll vereisen — visueel checken op iPad/mobiel.

### C. Overige pending uit v3.0.128
Onveranderd:
- Tekortscenario tekst-tweak bij jaarequivalent-regel (handoff v3.0.128 §6.A)
- Cleanup onbereikbare files + CSS (handoff v3.0.119 §6)
- Transitiebijdrage als DG-functie (D-actuaris-item, Hans-besluit "laten zitten")
- Visuele tests drie grafieken op echte devices

---

## 8. Voor de volgende sessie

Status: v3.0.129 is een minimale documentatie-update zonder engine-impact. De wiskundige aanname die de calculator al sinds v3.0.127 maakt (proportionele OP/PP-stijging bij invaren) is nu expliciet onderbouwd in zowel UI-help als modelspec, met verwijzing naar wettelijk kader en WTW-analyse. De jaarpensioen-equivalent-regel blijft mathematisch en numeriek identiek.

Volgende prioritaire items in volgorde van urgentie:
1. PDF-modelspec hercompileren naar v3.0.129 (W17-afhandeling) — nu hoger geprioritiseerd omdat de .md-bron en de .pdf-bytes verder uit elkaar gaan lopen
2. Visuele test van uitgebreide help-modal (nieuwe sectie tussen "EN ALS U EEN PARTNER HEEFT?" en "WAT BETEKENT 'LEVENSLANG'?")
3. Tekortscenario tekst-tweak (§7.C uit v3.0.128)
4. Cleanup-roadmap
