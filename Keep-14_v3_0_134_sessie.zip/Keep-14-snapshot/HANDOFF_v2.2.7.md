# WTP-PENSIOENCALCULATOR — HANDOFF ENGINE SPEC v2.2.7

Datum: 23-04-2026 20:00
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Licentie: CC BY-NC 4.0

Dit document markeert de afronding van de **scherm-4-spec-sessie** (23-04-2026, avond) en sluit daarmee de vier-sessie spec-track van `ENGINE_SPECIFICATIE_v1.md` volledig af. Het bouwt voort op `HANDOFF_v2.1.md` (scherm 1), `HANDOFF_v2.1.3.md` (scherm 2) en `HANDOFF_v2.1.9.md` (scherm 3); alle vier handoffs samen beschrijven de stand van zaken voor schermen 1–4.

---

## KERN IN ÉÉN ALINEA

Op 23-04-2026 zijn in deze vierde spec-sessie acht scherm-4-besluiten stap-voor-stap genomen en geïmplementeerd via acht patches (v2.2.0 t/m v2.2.7). Zeven daarvan zijn snel-formaliseringen die de docx-reviewpunten §5.12 en het cross-punt 5 uit HANDOFF_v2.1 als besloten aannames met UI-disclosure-eisen of v2-reserveringen markeren; één (v2.2.7) sluit het §11.12-heropen-punt conservatief af zonder major-bump. Een terugkerend patroon in deze sessie: **parameterset-discipline als architecturale laag** — §5.12.2 (π^Wtp-afleiding), §5.12.5 (φ-effectiviteit) en §5.12.6 (π^DB-scenario-keuze) leggen gezamenlijk bronverantwoordelijkheid bij de samensteller, niet bij de engine. Eén expliciet erkend ankerfunctie-risico (§5.12.5 M2↔M4-reserveringen-asymmetrie) als v2-heropenpunt procedureel ondervangen via documentatie-eis. Spec-omvang gegroeid van 1849 naar 1966 regels (+117). Geen numerieke wijziging op enige berekening. Scherm 4 is daarmee volledig af en de spec is normatief compleet voor alle vier modules. **De volgende stap is SCHEMA v2 schrijven als directe afgeleide, gevolgd door TEST_FIXTURES v1 en implementatie per module, te beginnen bij M1 (scherm-1-build).**

---

## STAND VAN ZAKEN — SPEC v2.2.7

**Hoofdbestand:** `ENGINE_SPECIFICATIE_v1.md` (1966 regels).

**Voltooide scherm-4-besluiten (acht, chronologisch):**

| Patch | Punt | Datum | Kern |
|---|---|---|---|
| v2.2.0 | Cross-punt 5 (uit HANDOFF_v2.1) — cohort M4 vs periode-snapshot M1-3 | 19:03 | Optie 1: UI-disclosure, methodische asymmetrie behouden. Nieuw §5.12.7; §10.1/§11.16 kruisverwijzingen. <1% verschil als informatief conform §1.1. |
| v2.2.1 | §5.12.1 — V_x^Wtp als waarde-equivalent | 19:09 | Optie 1: geformaliseerd als v1-aanname met harde UI-disclosure-eis. Terminologie-anker ("waarde-equivalent", "verwachte-waardeverschil"). M1-spiegel §11.15. |
| v2.2.2 | §5.12.2 — Afleiding π^Wtp buiten rekenmodule | 19:20 | Optie 1: scope-grens met drie engine-niet-verantwoordelijkheden. Parameterset-documentatie-eis. Gekoppelde discipline met §5.12.1. |
| v2.2.3 | §5.12.3 — Onafhankelijkheid x⊥y (broken-heart-effect) | 19:24 | Optie 1: onafhankelijkheid als v1-aanname; joint-life als gekoppeld v2-pad M1/M3/M4 (§2.10, §4.9, §5.12.3 parallel). |
| v2.2.4 | §5.12.4 — Geen SPR/FPR-differentiatie in kern-module | 19:30 | Optie 1: accommodatie via parametersets bevestigd; §5.13 formeel als v1-uitwerking gestempeld; spiegel §11.2 regeling-selector. |
| v2.2.5 | §5.12.5 — Toedeelbaar vermogen vs totaal (φ_effectief vs φ-as-supplied) | 19:42 | Optie 1: v1-aanname φ=φ_effectief aangeleverd; eerlijk erkend ankerfunctie-risico M2↔M4; v2-heropenpunt (Optie 2 of 3) indien praktijk onvoldoende brondiscipline toont. |
| v2.2.6 | §5.12.6 — π^DB als vereenvoudiging van toeslagmechaniek | 19:46 | Optie 1: v1-vereenvoudiging formaliseren; §5.6 scenario-set als operationele compensatie verankerd; DG-afhankelijke toeslagprojectie als v2-reservering in §5.11. |
| v2.2.7 | §11.12 — OP/NP-breakdown M4 promoveren | 19:53 | Optie A: conservatieve bevestiging; presentatie-laag in v1; drie expliciete v2-heropenings-voorwaarden (gebruikerstest, reviewer-feedback, SSPF-communicatiebehoefte). Afsluitings-patch. |

**Totaal gesloten besluiten over vier sessies:** 29 (12 scherm-1, 3 scherm-2, 6 scherm-3, 8 scherm-4).

**Bewust geparkeerd in scherm-4-sessie:**
- **Cross-module ankerfunctie-risico M2↔M4 reserveringen** (v2.2.5, §5.12.5). Procedureel ondervangen via parameterset-documentatie-eis; structurele oplossing (Optie 2 φ-metadata-veld of Optie 3 M4-formule-herschrijving op netto-basis) expliciet als v2-heropenpunt gemarkeerd. Heropent indien eerste SSPF-parametersets blijkens praktijk onvoldoende brondiscipline tonen.
- **OP/NP-breakdown M4 als berekeningslaag** (v2.2.7, §11.12). Optie 4 blijft v2/v3-pad onder drie expliciete voorwaarden (gebruikerstest, actuariële reviewer-feedback, SSPF-communicatiebehoefte).
- **DG-afhankelijke toeslagprojectie** (v2.2.6, §5.11). V2-uitbreiding naast bestaande stochastische-indexatiescenario's-bullet.

---

## ACTIEVE WERKAFSPRAKEN

Behouden uit eerdere sessies, bevestigd werkend in scherm-4-sessie:

1. **Narratief kompas (§1.1)** — drie momenten × vier schermen, ankerfunctie bij identieke aannames. Elk scherm-4-besluit is hieraan getoetst: v2.2.0 verankert periode/cohort-asymmetrie als informatief verschil; v2.2.1/v2.2.2 maken projectie-aannames cross-module expliciet (M1 π=0 anker ↔ M4 π^Wtp verwachte ontwikkeling); v2.2.5 erkent eerlijk dat ankerfunctie `ppkTotal ≈ V_x^Wtp_totaal` afhangt van samensteller-discipline (niet weggepoetst).

2. **Educatieve leidraad** — verborgen dimensies zichtbaar maken. v2.2.0 UI-disclosure-voorstel voor scherm-4; v2.2.1 "waarde-equivalent onder projectie-aanname"-terminologie is zelf een educatieve onthulling (π^Wtp = verwachting, niet toeslag); v2.2.6 §5.6-scenario-vergelijking als "laat gebruiker zien hoe gevoelig Δ is voor toeslag-aannames".

3. **Spec-met-reserveringen-principe (§12.5)** — v1-defaults reproduceren docx-gedrag; afwijkingen expliciet gemotiveerd. Alle acht scherm-4-patches respecteren dit principe; geen nieuwe afwijkingen naast de enkele uit v1.5 (ρ=0,02).

4. **Stap-voor-stap-methode** — elk open punt apart, probleem/opties/aanbeveling/besluit/patch, geen bulk. Gewerkt; tempo lag op één besluit per ~5–10 minuten; scherm 4 in één sessie-blok doorlopen mogelijk door hoge homogeniteit (zeven snel-formaliseringen + één afsluitings-patch).

5. **SSPF-prior voor fallbacks** — behouden uit eerdere sessies; geen scherm-4-specifieke nieuwe SSPF-priors (scherm 4 is fondsagnostisch in design, samensteller verzorgt realisme).

6. **Timestamp-conventie** — `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`. Consequent gehanteerd in alle acht patches.

7. **Bronhoudbaarheid boven snelheid** — parameterset-discipline als expliciete verantwoordelijkheids-architectuur (§5.12.2, §5.12.5, §5.12.6). Documentatie-eis aan samensteller vervangt engine-interne validatie. Upgrade-pad open zonder spec-revisie.

8. **Bronnenonderzoek voor normatieve kwesties** — niet actief gebruikt in scherm-4-sessie (alle punten waren scope/architectuur, niet juridisch-normatief). Patroon blijft beschikbaar voor toekomstige sessies.

9. **Geen code-wijzigingen aan R9.30-productiebestand vanuit spec-sessie** — gerespecteerd; M4 is als enige module überhaupt niet geïmplementeerd in R9.30, dus spec-wijzigingen zijn per definitie vooruitlopend op implementatie.

10. **Patch-administratie-hygiëne (werkafspraak uit scherm 3)** — bij opeenvolgende patches: nooit str_replace op voorgaande changelog-entry; gebruik stabiele anker-zin (spec-met-reserveringen-alinea onder de metadata) om eronder in te voegen, met anker-zin letterlijk identiek in `old_str` en `new_str`. In scherm 4 consequent toegepast, geen herhaling van v2.1.5-anker-afkap-fout.

11. **Parameterset-discipline als architecturale laag (nieuw expliciet scherm 4)** — drie §5.12-sub-paragrafen (§5.12.2, §5.12.5, §5.12.6) leggen gezamenlijk bronverantwoordelijkheid voor projectie- en toedelings-grootheden bij de samensteller, niet bij de engine. Dit is een uitbreiding van het "gekoppelde v2-pad"-patroon uit scherm 3 (v2.1.7/v2.1.8) van *gereserveerde velden* naar *verantwoordelijkheids-architectuur*. Houdbaar patroon voor toekomstige cross-module audit-vragen.

12. **Eerlijke boekhouding bij gekozen vereenvoudiging (nieuw expliciet v2.2.5)** — bij aannames die een risico niet oplossen maar procedureel ondervangen: het risico wordt in de besluit-notitie *niet weggepoetst*, maar expliciet benoemd met v2-heropenings-voorwaarde. V2.2.5 cross-module ankerrisico M2↔M4 en v2.2.7 OP/NP-heropenings-voorwaarden zijn beide voorbeelden. Behoudt intellectuele integriteit van spec bij conservatieve keuzes.

---

## KRITIEKE ARCHITECTUUR — STRUCTUREEL VASTGELEGD

Deze keuzes moeten bij elke volgende sessie paraat zijn. Scherm-4-aanvullingen op de v2.1.9-handoff-lijst zijn **vetgedrukt**.

### Module-structuur

- **M1** = huidige waarde: levert `KV_OP`, `KV_NP`, `KV` totaal + annuïteitsfactoren per leven + levensverwachtingen
- **M2** = potje: levert `ppkBase + ppkSurplus + ppkComp = ppkTotal`, met geoormerkte subcomponenten `ppk_OP` en `ppk_NP` (v2.0)
- **M3** = uitkeringsbenadering: levert pad + onzekerheidsbanden, gebruikt `ppkTotal` (decompositie via `ppk_OP`/`ppk_NP` sinds v2.1.4)
- **M4** = waardevergelijking: docx-spec overgenomen, V_DB vs V_Wtp cohort-correct op AG2024
  - **OP/NP-breakdown blijft presentatie-laag in v1 (v2.2.7 conservatief bevestigd)**; drie v2-heropenings-voorwaarden expliciet vastgelegd
  - **V_x^Wtp als waarde-equivalent onder projectie-aanname formeel (v2.2.1)**; M1-spiegel §11.15 π=0 anker
  - **π^Wtp-afleiding valt buiten engine-scope (v2.2.2)**; parameterset-samensteller-verantwoordelijkheid, drie engine-niet-verantwoordelijkheden expliciet
  - **φ=φ_effectief aangeleverd als v1-aanname (v2.2.5)**; cross-module ankerrisico M2↔M4 eerlijk erkend als v2-heropenpunt (Optie 2 of 3)
  - **π^DB als scalar/vector-vereenvoudiging formeel (v2.2.6)**; §5.6 scenario-set als operationele compensatie verankerd; DG-afhankelijke toeslagprojectie als v2-reservering §5.11
  - **SPR/FPR-differentiatie via §5.13-parametersets formeel (v2.2.4)**; regeling-architectuur compleet: §11.2 (gebruikers-selector) → §5.12.2 (bronverantwoordelijkheid) → §5.12.4 (regime-verschillen in parameterset) → §5.13 (welke parameters)
  - **Onafhankelijkheid x⊥y als v1-aanname (v2.2.3)**; joint-life als gekoppeld v2-pad M1/M3/M4; coherentie-eis bij activering expliciet
  - **Periode-snapshot M1-3 vs cohort M4 als bewuste methodische asymmetrie (v2.2.0)**; <1% numeriek verschil informatief conform §1.1; UI-disclosure-eis

### Sterftetafel

Ongewijzigd: AG2024 per geslacht, M1-3 periode-snapshot t₀=2026, M4 cohort, gender verplicht in UI met SSPF-weging 95/5 als fallback. **Scherm-4-bevestiging: periode/cohort-asymmetrie geformaliseerd als informatief verschil (§5.12.7, v2.2.0).**

### Rente

Ongewijzigd: één UI-slider (default 2%) voor discontering; ontkoppelings-toggle voor power-user; `μ` apart. `μ=0,045`/`σ=0,08` indicatief SSPF 60/40 (v2.1.8).

### Annuïteitsconventie

Ongewijzigd: uniform arrears m=12 in alle modules.

### NP-regime

Ongewijzigd: NP mee-ingevaren, geoormerkt binnen één persoonlijk pensioenvermogen. M3 decompositief U₀_OP/U₀_NP (v2.1.4). **Scherm-4-bevestiging: M4 OP/NP blijft presentatie-laag (v2.2.7); joint-life als gekoppeld v2-pad M1/M3/M4 (v2.2.3).**

### Compensatie-regime

Ongewijzigd: ppkComp volledig naar OP, wettelijk verankerd (v2.1.2).

### Brug M2↔M4

- `phiDerived = ppkTotal / V_x^Wtp_totaal` als één decoratief anker (v2.1.3)
- Geen `phiDerived_OP`/`phiDerived_NP` in v1; v2-heropenbaar onder drie expliciete voorwaarden (v2.2.7)
- **Cross-module ankerfunctie-risico M2↔M4 reserveringen eerlijk erkend (v2.2.5)**; procedureel ondervangen via parameterset-documentatie-eis; structurele oplossing v2-heropenpunt

### Buffer (RDR) en demping

Ongewijzigd uit v2.1.6: `buffer-aandeel` = SSPF-RDR-buffer; `bufferTrigger='koopkracht'` default; `dempJaren=5` SSPF-design. RDR-uitputtingsmechaniek geparkeerd.

### Architecturaal patroon "gekoppelde v2-paden" (uitgebreid v2.2.3)

Nu vier keer toegepast in spec als reservering-discipline: velden die conceptueel onlosmakelijk samen geactiveerd moeten worden krijgen explicit-koppelings-noten:
- `correlatieRenteInflatie` ↔ `inflatieStochastiek` (v2.1.7)
- `lifecycle-profiel` ↔ `rtsCurve` (v2.1.8)
- `RTS` ↔ `agHerzienPeriode` ↔ `renteAfdekkingFactor` (SPR-Fase B, §4.9)
- **Joint-life-activering M1 ↔ M3 ↔ M4 (v2.2.3, §2.10/§4.9/§5.12.3)** — drie modules die tegelijk op broken-heart-factor moeten overgaan

Dit patroon uitbreidbaar naar SCHEMA v2 metadata-velden (bijv. hypothetische `φ_is_effectief`-koppeling bij v2-heropening §5.12.5).

### Architecturaal patroon "parameterset-discipline als verantwoordelijkheidsgrens" (nieuw expliciet scherm 4)

Drie keer toegepast in §5.12 als scope-architectuur:
- **§5.12.2** (π^Wtp-afleiding) — bronverantwoordelijkheid samensteller, drie engine-niet-verantwoordelijkheden
- **§5.12.5** (φ-effectiviteit) — v1-aanname φ=φ_effectief aangeleverd, documentatie-eis
- **§5.12.6** (π^DB-scenario-keuze) — scenario-set §5.6 als operationele compensatie, motiveringseis aan samensteller

Dit is een bredere discipline dan "gekoppelde v2-paden" — parameterset-discipline legt verantwoordelijkheid buiten de engine, gekoppelde v2-paden leggen coherentie-eisen binnen gereserveerde velden. Beide patronen houdbaar voor toekomstige spec-uitbreidingen.

### Plot-horizon-architectuur

Ongewijzigd uit v2.1.9: engine berekent tot ω, UI-cap via `plotHorizonRule`-enum (vier waardes, default `'lifeExpPlus10'`).

---

## OPEN BESLISPUNTEN — NA SCHERM 4

**Scherm 4 is volledig afgesloten; geen open punten binnen de spec zelf.**

**Volgende fases:**

1. **SCHEMA v2** — directe afgeleide van spec v2.2.7 (geen nieuwe inhoudelijke beslissingen nodig; alle velden staan in de spec met status `actief (vX.X)` of `gereserveerd`).
2. **TEST_FIXTURES v1** — vaste numerieke assertions per module (x=67, x=75, x=85 met vaste parameters). Nodig voor implementatie-validatie; dekt M1/M2/M3 (M4 krijgt eigen fixtures zodra implementatie-track start).
3. **UI-design voor OP/NP-breakdown op schermen 2/3/4** — §11.18 follow-up bullet 3, thematisch eigen sessie. Niet-blokkerend voor M1-build.
4. **Implementatie-track** — separate sessie(s):
   - **M1/scherm-1-build** als eerste (volledig gespecificeerd sinds v1.8)
   - **M2/scherm-2-build** daarna (volledig gespecificeerd sinds v2.1.3)
   - **M3/scherm-3-build** daarna (volledig gespecificeerd sinds v2.1.9)
   - **M4/scherm-4-build** als laatste (volledig gespecificeerd sinds v2.2.7; als enige module niet in R9.30 aanwezig, dus greenfield)

**Potentieel later heropen (niet blokkerend):**
- V2.2.5 cross-module ankerfunctie-risico (M2↔M4 reserveringen) — alleen bij praktijk-bewijs van onvoldoende samensteller-brondiscipline
- V2.2.7 OP/NP-breakdown M4 promotie — onder drie expliciete voorwaarden (gebruikerstest, reviewer-feedback, SSPF-communicatiebehoefte)
- V2.1.6 RDR-uitputtingsmechaniek — bij vondst SSPF-reglement
- V2.1.7 correlatie rendement-inflatie — bij DNB-FTK/AG-kalibratie
- V2.1.8 lifecycle-bundel — voor niet-SSPF-Wtp-fondsen met individuele FPR

---

## DATA-TODO'S VOOR HANS (NIET-BLOKKEREND)

Behouden uit eerdere handoffs; scherm-4-sessie heeft geen nieuwe data-todo's toegevoegd.

1. SSPF-specifieke `f`-waarde (Implementatieplan/jaarverslag) → vervangt placeholder 1,0.
2. SSPF uitvoeringskosten per jaar → activeert Variant-A-afleiding voor ρ, vervangt 0,02-placeholder.
3. SSPF M/V-verdeling per cohort → vervangt 95/5-placeholder.
4. AG2024 populatie-data voor NL-neutrale weging.
5. Q-tafel herkomst documentatie (bevestigd als fout).
6. SSPF-RDR-uitputtingsregels (v2.1.6, geparkeerd).
7. SSPF-officiële μ/σ-bron voor 60/40-portfolio (v2.1.8).
8. DNB-FTK/AG-stochastische-set-parameters voor correlatie rendement-inflatie (v2.1.7).

**Nieuw bij M4-implementatie-track (niet blokkerend voor M1):**
9. Parameterset-samenstellings-discipline voor SSPF — documenteer hoe π^Wtp wordt afgeleid (§5.12.2), of φ voor reserveringen gecorrigeerd is (§5.12.5), welke π^DB-waardes in scenario-set (§5.12.6). Relevant zodra SSPF de eerste fondsparameterset voor M4 aanlevert; bron voor validatie of v2.2.5-heropenpunt geactiveerd moet worden.

---

## COHERENTIE-CHECK UITGEVOERD BIJ AFRONDING

Conform werkafspraak 10 en 11 zijn tijdens scherm-4-sessie continu drie controles uitgevoerd:

1. **Patch-volgorde en changelog-integriteit.** Bij elke patch (v2.2.0 t/m v2.2.7) gecheckt: alle voorgaande changelog-entries staan compleet en op volgorde. Eindstand v2.2.7: tien v2.x-entries scherm 3 (v2.1 t/m v2.1.9) + acht v2.2.x-entries scherm 4 (v2.2.0 t/m v2.2.7) = 18 entries in één doorlopende blok tussen "Major release v2.0" en de spec-met-reserveringen-anker-zin. Anker-zin-positie verschoven van regel 50 (v2.1.9) naar regel 66 (v2.2.7), alle acht scherm-4-patches ingevoegd zonder één overschrijving.

2. **Anker-zin-integriteit.** In alle acht scherm-4-patches correct toegepast: anker-zin letterlijk identiek in `old_str` en `new_str`. Geen herhaling van v2.1.5-anker-afkap-fout.

3. **Doorwerkings-consistentie tussen modules.** Scherm-4-sessie heeft drie structurele cross-module-patterns geïntroduceerd of bevestigd: (a) parameterset-discipline §5.12.2/§5.12.5/§5.12.6; (b) joint-life gekoppeld v2-pad §2.10/§4.9/§5.12.3 (v2.2.3); (c) regeling-architectuur keten §11.2 → §5.12.2 → §5.12.4 → §5.13 (v2.2.4). Elke is bij relevante patch gecheckt op interne consistentie.

**Extra coherentie-check uniek voor scherm 4: eerlijke boekhouding bij conservatieve keuzes.** V2.2.5 en v2.2.7 zijn conservatieve keuzes die een risico niet oplossen maar procedureel ondervangen. In beide besluit-notities is het risico *niet weggepoetst* maar als v2-heropenpunt met expliciete voorwaarden vastgelegd. Dit voorkomt dat toekomstige implementatoren of reviewers de conservatieve keuze als "afgedaan" lezen waar het in feite "geparkeerd onder voorwaarden" is.

---

## VOLGENDE-SESSIE-AANPAK (VOORSTEL)

**Primair voorgesteld: SCHEMA v2 schrijven.**

1. **Start**: lees `ENGINE_SPECIFICATIE_v1.md` v2.2.7 volledig door, met focus op alle §X.3 "Invoerschema — fondsparameterset"-tabellen (M1 §2.3, M2 §3.3, M3 §4.3, M4 §5.4) en de statussen `actief (vX.X)` / `gereserveerd` per veld.
2. **Context-injectie**: lees alle vier handoffs: `HANDOFF_v2.1.md` (scherm 1), `HANDOFF_v2.1.3.md` (scherm 2), `HANDOFF_v2.1.9.md` (scherm 3), `HANDOFF_v2.2.7.md` (dit document, scherm 4).
3. **Werkwijze**: SCHEMA v2 is géén beslissings-sessie; alle inhoudelijke beslissingen zijn in de vier spec-sessies al genomen. SCHEMA v2 is een *vertaling* van de spec naar een machine-leesbaar contract (JSON Schema, TypeScript types, of een gelijkwaardig formaat). Geen nieuwe werkafspraken-variaties; wel coherentie-check tegen de spec bij elke veld-definitie.
4. **Versiebump-regel**: SCHEMA v2 is een apart document; spec-versie blijft v2.2.7 tenzij tijdens SCHEMA-vertaling een tegenstrijdigheid of omissie in de spec ontdekt wordt. In dat geval patch v2.2.8+ met expliciete motivering.
5. **Breekpunt**: na SCHEMA v2-voltooiing HANDOFF maken (HANDOFF_SCHEMA_v2.md, variant-stijl) voordat TEST_FIXTURES of implementatie begint.

**Alternatief: TEST_FIXTURES v1 voor M1 schrijven.** Als Hans prefereert directe bouw-voorbereiding boven SCHEMA-abstractie, kan TEST_FIXTURES v1 eerst. Dit vereist dat SCHEMA v2 dan ofwel impliciet via fixture-voorbeelden wordt gedefinieerd, ofwel achteraf gedestilleerd.

**Alternatief: M1-implementatie-sessie starten.** Scherm 1 is spec-compleet sinds v1.8. Directe bouw is mogelijk onder tijdelijke "SCHEMA v2 wordt parallel aan de implementatie afgeleid"-afspraak, maar vergroot audit-risico.

**Aanbeveling**: SCHEMA v2 eerst, dan TEST_FIXTURES v1, dan M1-implementatie. Dit geeft een complete, gevalideerde spec-tot-implementatie-keten voordat de eerste regel productiecode wordt geschreven.

---

## BRONBESTANDEN — COMPLETE INVENTARIS

Volgende sessie heeft deze bestanden nodig:

**Van deze sessie nieuw:**
- `ENGINE_SPECIFICATIE_v1.md` (v2.2.7, 1966 regels) — normatieve spec, scherm 1–4 compleet
- `HANDOFF_v2.2.7.md` (dit document) — scherm-4-handoff, sessie-slot
- `PROMPT_nieuwe_chat.md` — nieuwe sessie-prompt voor SCHEMA v2

**Van eerdere sessies behouden:**
- `HANDOFF_v2.1.md` — scherm-1-handoff (brede context)
- `HANDOFF_v2.1.3.md` — scherm-2-handoff (cumulatief)
- `HANDOFF_v2.1.9.md` — scherm-3-handoff (cumulatief)

**Eerder opgeleverd (onveranderd):**
- `ARCHITECTUUR_v1.md` — leidend architectuur-document
- `DESIGN_engine_v0.md` — reverse-engineering R9.30 engine
- `calculator_specificatie.docx` — M4-docx-spec
- `SCHEMA_v1.md` — huidige SCHEMA (wordt v2 in volgende sessie)
- `STRATEGY_R9.30.md` — strategische context
- `HANDOFF_R9.30.md` — technische handoff code (ander track)
- `21-04-2026_2216.html` — R9.30 werkbestand (code baseline)

**Externe data:**
- `AG2024.xlsx` — AG2024 gemodelleerde prognose-sterftekansen per geslacht
- `51490-Data_AG2024.xlsx` — AG2024 brondata

---

## AFSLUITENDE NOTITIE

Scherm 4 is systematisch doorgenomen zoals scherm 1, 2 en 3: acht open punten, acht besluiten, acht patches, allen aan het narratief kompas getoetst. Het tempo lag hoger dan scherm 3 (acht patches in één blok versus zes over één dag) doordat zeven van de acht punten pure snel-formaliseringen waren — docx-reviewpunten die al inhoudelijk af waren en alleen formele besluit-status + cross-module verankering nodig hadden. Twee patches (v2.2.5 en v2.2.7) introduceren eerlijke-boekhouding-patroon: risico's die conservatief geparkeerd worden krijgen expliciete v2-heropenings-voorwaarden, zodat de conservatieve keuze niet per abuis als "opgelost" wordt gelezen. Eén nieuwe architecturale laag opgeschreven als patroon voor toekomstige sessies: parameterset-discipline als verantwoordelijkheidsgrens (§5.12.2/§5.12.5/§5.12.6), bredere scope dan het gekoppelde-v2-paden-patroon uit scherm 3.

De spec is hiermee normatief compleet voor alle vier modules. Een externe actuariële, juridische of IT-auditor kan nu per module de gekozen benadering beoordelen zonder terug te hoeven grijpen naar de onderliggende docx, HTML of R9.30-code. Een implementator kan per module de benodigde inputs, outputs, formules, aannames en validaties rechtstreeks afleiden. SCHEMA v2 is een mechanische vertaling waarvoor geen nieuwe inhoudelijke beslissingen meer nodig zijn; TEST_FIXTURES v1 volgt daaruit; M1-implementatie kan daarna beginnen.

De vier-sessie spec-track is afgerond.

*Einde HANDOFF_v2.2.7.md*
