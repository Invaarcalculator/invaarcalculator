# WTP-PENSIOENCALCULATOR — HANDOFF SCHEMA v2.0 M1-BLOCK

Datum: 23-04-2026 22:20
Auteur: Claude (op instructie van Hans Haringa, Innovation Nestor)
Licentie: CC BY-NC 4.0

Dit document markeert de afronding van de **SCHEMA-v2-M1-sessie** (23-04-2026, avond) — de eerste implementatie-voorbereidings-sessie na het afsluiten van de vier-sessie spec-track met HANDOFF_v2.2.7. Het opent een nieuwe track (SCHEMA-afleiding) parallel aan de spec-track, en documenteert de infrastructuur + het M1-block die in deze sessie zijn gelegd.

---

## KERN IN ÉÉN ALINEA

Op 23-04-2026 is SCHEMA v2.0 gestart als directe machine-leesbare afgeleide van ENGINE_SPECIFICATIE v2.2.7. Formaat-keuze: **Zod 3** (knelpunt-sessie 1). UX-model: **Model D** (vier casual-schermen + één audit/actuarisscherm) met `display`-metadata-laag per veld en `uiDisclosure`-annotatie per veld. Eerste blok opgeleverd: infrastructuur-laag (F-wrapper, WeakMap + FIELD_REGISTRY, Display-enum vijf waardes, audit-helpers) + M1-block (deelnemer, parameterset-subset, output, refines, 26 geregistreerde velden, 7 met UI-disclosure). Negen knelpunten stap-voor-stap doorlopen (1–9), allen gesloten. Tijdens SCHEMA-schrijven twee spec-patches uitgevoerd: **v2.2.8** (§2.3 tabel-kop-cosmetiek voor `f`/`π` scalar-type aangescherpt conform §11.13/§11.15-besluiten), en **v2.2.9** (M1 `t₀` verplaatst van §2.2 naar §2.3 voor cross-module-symmetrie met M3 §4.3). Spec-omvang gegroeid van 1966 naar 1970 regels. SCHEMA v2.0 M1-block: 474 regels TypeScript, type-check schoon, smoke-test groen (7 assertions inclusief §7.3-cross-module-lock-validatie), mockup-renderer genereert zowel casual scherm 1 als audit-scherm M1-sectie mechanisch uit metadata. **Volgende sessie: SCHEMA v2 M2-block** (potje, scherm 2 — complexste keten-output met OP/NP-decompositie en exacte sluitingscontrole).

---

## STAND VAN ZAKEN — SCHEMA v2.0 M1-BLOCK

**Hoofdbestanden (nieuw in deze sessie):**
- `schema.v2.ts` (474 regels) — infrastructuur + M1-block
- `smoke.test.ts` — 7 runtime-assertions
- `render_mockup.ts` — mechanische scherm-generator uit FIELD_REGISTRY
- `mockup_m1.html` — gegenereerd voorbeeld-scherm (casual + audit M1-sectie)
- `tsconfig.json`, `package.json` — TypeScript + Zod 3 dependencies

**Spec-patches uitgevoerd in deze sessie:**

| Patch | Datum | Kern |
|---|---|---|
| v2.2.8 | 21:49 | Cosmetische tabel-kop-aanscherping §2.3 — `f(x,g)` type van "scalar of map" → "scalar → decimal"; `π` type van "decimal of vector" → "decimal". Alignering van tabel-kop met sturende besluiten §11.13/§11.15. Geen numerieke wijziging; in-spec-consistentie-correctie tijdens SCHEMA-schrijven ontdekt. |
| v2.2.9 | 21:54 | M1 `t₀`-veld verplaatst van §2.2 (deelnemer-invoer) naar §2.3 (fondsparameterset). Rationale: semantische misplaatsing (`t₀` is parameterkeuze, geen UPO-invoer) én M1↔M3-symmetrie-herstel (M3 §4.3 had `t₀` al correct in parameterset sinds v2.1.5). M4 §5.3 bewust niet gepatcht — heeft daar andere semantiek (cohort-start-kalenderjaar). Geen numerieke wijziging. |

**Totaal gesloten besluiten spec:** 29 + 2 cosmetische/semantische patches = 31 (12 scherm-1, 3 scherm-2, 6 scherm-3, 8 scherm-4, 2 SCHEMA-afgeleid).

**Negen knelpunten in SCHEMA-M1-sessie stap-voor-stap gesloten:**

| # | Onderwerp | Keuze | Implementatie |
|---|---|---|---|
| 1 | Metadata-wrapping | `F()` + WeakMap + FIELD_REGISTRY, Zod 3 | Infrastructuur-laag schema.v2.ts regels 16-117 |
| 2 | `ρ` kostenopslag | Drie bronvelden (`fondsvermogen`, `uitvoeringskostenJaarlijks`, `kostenOpslagPct`); engine past §2.7-fallback-ladder toe; `rho_effectief` als diagnose-output | M1Parameterset regels 237-265, M1Output regels 320-325 |
| 3 | `f`, `π` scalar-only | Scalar in v2.0; map/vector als v2-uitbreidingspad (minor SCHEMA-bump) | M1Parameterset `ervaringsSterfte`, `pi` + spec-patch v2.2.8 |
| 4 | Sterftetafel | Alleen `sterftekansTabelId`; engine resolvert uit tabel-ID; geen inline q-override | SterftekansTabelIdSchema als enum `['AG2024']` |
| 5 | `t₀` plaatsing | Naar parameterset (was in §2.2 deelnemer) | Spec-patch v2.2.9 + M1Parameterset.t0 |
| 6 | Naamgeving | ASCII-mapping; Griekse notatie in `.describe()`-strings | Volledig toegepast; onderzocht dat Unicode-subscripts niet werken in ECMAScript (only letters zijn ID_Continue) |
| 7 | Validatie-fouten | Alles hard fail via `ctx.addIssue(custom)` | Twee superRefine-blokken in M1Deelnemer en M1Parameterset |
| 8 | `annuiteitsconventie` | `z.literal('arrears')` — §7.3-lock in SCHEMA afgedwongen | AnnuiteitsconventieSchema single-value |
| 9 | `m` (betalingsfrequentie) | `z.literal(12)` — zelfde §7.3-lock | MSchema single-value |

**Architecturale keuzes gemaakt in deze sessie:**

- **UX-model D** (casual schermen + apart audit-scherm). In knelpunt-voorbereiding afgewogen tegen Modellen A (twee bundels), B (progressieve disclosure), C (modus-toggle). Model D gekozen op basis van 80/20-vangst van professional-behoefte zonder per-scherm-verdubbeling.
- **Display-metadata-laag opgenomen** in SCHEMA met vijf enum-waardes: `hoofdpad`, `decompositie`, `deepdive`, `parameter-audit`, `diagnose`. Automatisch-uitleesbaar voor audit-scherm-generatie.
- **`uiDisclosure`-veld op parameter-niveau** voor de zeven UI-disclosure-eisen uit de spec. Eén vaste plek voor spec-paragraaf-verankering per veld.
- **§7.3-cross-module-lock in SCHEMA** voor `annuiteitsconventie` en `m` via `z.literal()`. Consistentie-eis uit spec wordt mechanisch afgedwongen bij dataset-load; heropening vergt spec-patch + SCHEMA minor-bump.
- **`F()`-wrapper met parallel FIELD_REGISTRY** i.p.v. schema-property-vervuiling of Zod 4 `.meta()`. Versie-agnostisch; werkt op Zod 3 én Zod 4 zonder wijziging.

---

## ACTIEVE WERKAFSPRAKEN

Behouden uit de vier spec-sessies, bevestigd werkend in SCHEMA-M1-sessie:

1. **Narratief kompas (§1.1)** — drie momenten × vier schermen, ankerfunctie bij identieke aannames. In SCHEMA-M1 is dit vertaald naar de `display`-metadata-laag: `hoofdpad` voor casual, `decompositie/deepdive/parameter-audit/diagnose` voor audit.

2. **Educatieve leidraad** — verborgen dimensies zichtbaar maken. `uiDisclosure`-veld op parameter-niveau is SCHEMA-implementatie van de zeven verspreide UI-disclosure-eisen; audit-scherm rendert ze uit één plek.

3. **Spec-met-reserveringen-principe (§12.5)** — v1-defaults reproduceren R9.30-gedrag waar mogelijk. SCHEMA v2.0 volgt dit strikt: alle gereserveerde velden krijgen `null`-default; activering vereist later minor-bump. Bewuste afwijking ρ=0,02 (§11.14) in SCHEMA ingebakken via §2.7-fallback-ladder.

4. **Stap-voor-stap-methode** — elk knelpunt apart behandeld, Hans beslist, Claude implementeert, dan door naar volgend. Geen bulk-beslissingen. Negen knelpunten in één doorlopende sessie; tempo 5–10 minuten per knelpunt.

5. **SSPF-prior voor fallbacks** — gender-weging 95/5 deelnemer, 60/40-portfolio μ/σ, 5-jaars demping. SCHEMA-implementatie: waar relevant als spec-referentie in `.describe()` en `uiDisclosure`. Geen SSPF-specifieke defaults in SCHEMA zelf (parameterset is fondsagnostisch).

6. **Timestamp-conventie** — `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"`. Consequent gehanteerd in beide spec-patches en in schema-header.

7. **Bronhoudbaarheid boven snelheid** — placeholders expliciet gelabeld; upgrade-pad open zonder spec-revisie voor data-wijzigingen; upgrade-pad met SCHEMA minor-bump voor structurele uitbreidingen (bijv. `f`/`π` naar map/vector).

8. **Bronnenonderzoek voor normatieve kwesties** — niet actief gebruikt in SCHEMA-M1-sessie (alle punten waren SCHEMA-formaat-keuzes, niet inhoudelijk-normatief).

9. **Geen code-wijzigingen aan R9.30-productiebestand vanuit spec-sessie** — gerespecteerd. SCHEMA-track is aparte codebase in `/home/claude/schema_v2/`; R9.30-HTML blijft onaangeroerd. Implementatie-track zal SCHEMA-afgeleid zijn.

10. **Patch-administratie-hygiëne** — bij opeenvolgende spec-patches: nooit str_replace op voorgaande changelog-entry; gebruik stabiele anker-zin ("De spec is geschreven met *spec-met-reserveringen*-principe") met anker-zin letterlijk identiek in `old_str` en `new_str`. **v2.2.8 en v2.2.9 correct toegepast** — geen herhaling van v2.1.5-anker-afkap-fout. Coherentie-check per patch uitgevoerd: anker-zin exact 1×, changelog-entries elk exact 1×, datum-header consistent.

11. **Parameterset-discipline als architecturale laag** (uit scherm 4) — SCHEMA-M1 eerbiedigt deze via de `ρ`-drie-bronvelden-aanpak (§2.7-ladder zichtbaar i.p.v. één `rho`-veld).

12. **Eerlijke boekhouding bij gekozen vereenvoudiging** (uit scherm 4) — toegepast bij knelpunt 6: Claude heeft eerlijk gecorrigeerd dat "B volledige spec-parallel" technisch onmogelijk is in ECMAScript (subscript-digits niet ID_Continue); Hans zag alternatieven en koos A.

13. **SCHEMA-afgeleide spec-patches toegestaan** (nieuw in deze sessie) — tijdens SCHEMA-schrijven kunnen in-spec-inconsistenties opduiken (v2.2.8 type-cosmetiek) of semantische misplaatsingen (v2.2.9 `t₀`-plaatsing). Deze worden als patch-voorstel aan Hans voorgelegd met drie-laags rationale; bij go wordt de spec gepatcht conform werkafspraak 10. **Alleen spec-patchen als SCHEMA-schrijven een tegenstrijdigheid/omissie onthult**, niet voor verfraaiing.

---

## KRITIEKE ARCHITECTUUR — STRUCTUREEL VASTGELEGD

Deze keuzes moeten bij elke volgende sessie paraat zijn. SCHEMA-M1-aanvullingen op de v2.2.7-handoff-lijst zijn **vetgedrukt**.

### Module-structuur

- M1 = huidige waarde: `KV_OP`, `KV_NP`, `KV` totaal + `ä`-factoren per leven + levensverwachtingen
- M2 = potje: `ppkBase + ppkSurplus + ppkComp = ppkTotal`, met geoormerkte `ppk_OP`/`ppk_NP`
- M3 = uitkeringsbenadering: pad + onzekerheidsbanden, `U₀_OP`/`U₀_NP`-decompositie
- M4 = waardevergelijking: V_DB vs V_Wtp cohort-correct AG2024; OP/NP presentatie-laag

### SCHEMA-structuur (nieuw)

- **Formaat: Zod 3 in TypeScript.** Single-source-of-truth; runtime-validatie + compile-time types (`z.infer`). Exporteerbaar naar JSON Schema via `zod-to-json-schema` indien later extern nodig.
- **UX-model D.** Vier casual-schermen (minimal UPO-input + hoofdpad-output); één audit/actuarisscherm (decompositie + deepdive + parameter-audit + diagnose).
- **Metadata-laag per veld.** `display: 'hoofdpad' | 'decompositie' | 'deepdive' | 'parameter-audit' | 'diagnose'`; `uiDisclosure: string | undefined`; `specRef: string`; `module: 'M1' | 'M2' | 'M3' | 'M4' | 'shared'`. Geregistreerd via `F()`-wrapper in WeakMap + flat FIELD_REGISTRY-array.
- **Audit-scherm mechanisch gegenereerd** uit FIELD_REGISTRY + `display`-filter. Geen handmatige veld-lijsten; uitbreiding bij M2/M3/M4 is automatisch.
- **`§7.3-cross-module-lock` in SCHEMA** voor `annuiteitsconventie` (`z.literal('arrears')`) en `m` (`z.literal(12)`). Dataset kan geen inconsistente waarde aanleveren.
- **`§2.7 fallback-ladder expliciet in SCHEMA`** voor ρ-afleiding: drie bronvelden zichtbaar (`fondsvermogen`, `uitvoeringskostenJaarlijks`, `kostenOpslagPct`); engine doet de ladder-logica; resultaat in `rho_effectief` als diagnose-output.
- **Hard fail voor alle consistentie-checks** (knelpunt 7): geen warn-laag in v2.0; strikte dataset-curatie bij load.

### Sterftetafel

Ongewijzigd: AG2024 per geslacht, M1-3 periode-snapshot t₀=2026, M4 cohort. **SCHEMA-bevestiging: `sterftekansTabelId` als string-enum `['AG2024']`; tabel zelf niet inline in dataset.**

### Rente

Ongewijzigd: één UI-slider default 2%; ontkoppel-toggle; `μ` apart. **SCHEMA-bevestiging: `r` in M1Parameterset als scalar met default 0.02, bereik [-0.05, 0.15].**

### Annuïteitsconventie en m

Ongewijzigd: uniform arrears m=12. **SCHEMA-bevestiging: §7.3-lock afgedwongen via `z.literal('arrears')` en `z.literal(12)` — dataset kan niet afwijken.**

### NP-regime

Ongewijzigd: mee-ingevaren, geoormerkt. M3 decompositief `U₀_OP`/`U₀_NP`. **SCHEMA-bevestiging M1: `heeftPartner=true` vereist `x_partner`; `y₀` optioneel met fallback 0.70·pen via engine §2.7.**

### Brug M2↔M4

Ongewijzigd. `phiDerived` scalar. Ankerfunctie-risico v2.2.5 procedureel via parameterset-documentatie-eis. **SCHEMA-implementatie komt in M2-block volgende sessie.**

### Plot-horizon-architectuur

Ongewijzigd: engine berekent tot ω, UI-cap via `plotHorizonRule`-enum. **SCHEMA-implementatie komt in M3-block.**

### Architecturaal patroon "gekoppelde v2-paden" (SCHEMA-implementatie)

Alle vier bekende gekoppelde paden komen in de M3- en/of M4-blocks; infrastructuur daarvoor is de `.superRefine()`-methode op module-schemas (zie knelpunt 7 — hard fail bij activerings-inconsistentie).

### Architecturaal patroon "parameterset-discipline als verantwoordelijkheidsgrens"

SCHEMA-implementatie: `uiDisclosure`-veld met spec-paragraaf-verwijzing (bijv. `§5.12.5 — samensteller documenteert φ-effectiviteit`) op de relevante parameter-velden. Audit-scherm rendert deze disclosure-eisen mechanisch. Zichtbaarheid van de discipline is daarmee codificatie, niet meer alleen documentatie.

---

## OPEN BESLISPUNTEN — NA SCHEMA-M1-SESSIE

**SCHEMA-M1 is volledig afgesloten; geen open punten binnen M1.**

**Volgende fases:**

1. **SCHEMA v2 M2-block** — scherm 2 (potje). Complexste keten-output: OP/NP-decompositie met exacte sluitingscontrole `ppk_OP + ppk_NP = ppkTotal`, bell-curve compensatie, DNB-spreiding gender-expliciet, `phiDerived` als decoratief nullable output. Eerste test van `.superRefine()` met multi-veld numerieke identiteit.
2. **SCHEMA v2 M3-block** — scherm 3 (uitkeringsbenadering). Meeste gereserveerde velden (drie gekoppelde v2-paden). Stress-test voor de gekoppelde-paden-consistentie-afdwinging in SCHEMA.
3. **SCHEMA v2 M4-block** — scherm 4 (waardevergelijking). Greenfield; zeven UI-disclosure-eisen concentreren zich hier; nomenclatuur-inconsistentie M1-3 (`pen`, `y₀`) vs M4 (`B_OP`, `B_PP`) vraagt aandacht — mogelijk spec-patch v2.2.10.
4. **FONDS_DATASET-compositie** — samensmelten M1/M2/M3/M4-parameterset-subsets tot één `FONDS_DATASET`-schema met top-level `meta`, `regeling`, `herkomst`. Opvolger van SCHEMA_v1.md.
5. **TEST_FIXTURES v1** — numerieke assertions per module (x=67, x=75, x=85 met vaste parameters). Gebruikt SCHEMA v2 voor dataset-construction.
6. **Implementatie-track M1** — scherm-1-build. Leest SCHEMA v2 M1-typen; genereert audit-scherm-sectie mechanisch uit FIELD_REGISTRY.

**Mogelijke SCHEMA-afgeleide spec-patches in volgende sessies:**

- **v2.2.10 kandidaat** (M4-sessie): nomenclatuur-verzoening M4 §5.3 met M1-3-conventie (`B_OP` → `pen`, `B_PP` → `y₀`-als-bedrag, `g_x` → `g`, `y₀`-als-partnerleeftijd naar `x_partner`). Grotere patch dan v2.2.8/v2.2.9; vergt bronnenonderzoek naar waarom docx-overname deze naamgeving behield.
- **v2.2.11 kandidaat** (M4-sessie): M4 `t₀`-plaatsing — §5.3 heeft `t₀` in deelnemer-invoer met andere semantiek dan M1/M3. Eventuele heroverweging analoog aan v2.2.9; niet blokkerend.

---

## DATA-TODO'S VOOR HANS (NIET-BLOKKEREND)

Behouden uit HANDOFF_v2.2.7:

1. SSPF-specifieke `f`-waarde → vervangt placeholder 1,0
2. SSPF uitvoeringskosten per jaar → activeert Variant-A-afleiding voor ρ, vervangt 0,02-placeholder
3. SSPF M/V-verdeling per cohort → vervangt 95/5-placeholder
4. AG2024 populatie-data voor NL-neutrale weging
5. Q-tafel herkomst documentatie (bevestigd als fout)
6. SSPF-RDR-uitputtingsregels (v2.1.6, geparkeerd)
7. SSPF-officiële μ/σ-bron voor 60/40-portfolio (v2.1.8)
8. DNB-FTK/AG-stochastische-set-parameters voor correlatie rendement-inflatie (v2.1.7)
9. Parameterset-samenstellings-discipline voor SSPF (§5.12.2 π^Wtp, §5.12.5 φ, §5.12.6 π^DB)

**Nieuw bij SCHEMA-track:**

10. SSPF-specifieke default-waarden voor M2/M3-parameters (fondsvermogen, dekkingsgraad, compensatiedepot, RDR-buffer, μ/σ) — nodig voor FONDS_DATASET_SSPF-publiek-v1 compositie na M2/M3-blocks.

---

## COHERENTIE-CHECK UITGEVOERD BIJ AFRONDING

Conform werkafspraak 10 en 13 zijn tijdens SCHEMA-M1-sessie vier controles uitgevoerd:

1. **Patch-volgorde en changelog-integriteit** (spec). v2.2.8 en v2.2.9 correct ingevoegd tussen v2.2.7-entry en spec-met-reserveringen-anker-zin. Anker-zin exact 1× aanwezig; elke changelog-entry exact 1×; datum-header in juiste volgorde.
2. **Anker-zin-integriteit** (spec). Beide spec-patches hebben anker-zin letterlijk identiek in `old_str` en `new_str`. Geen herhaling van v2.1.5-anker-afkap-fout.
3. **SCHEMA ↔ spec traceerbaarheid**. Elk veld in `schema.v2.ts` heeft `specRef`-metadata naar ≥1 spec-paragraaf. Totaal 26 velden, alle traceerbaar. `FIELD_REGISTRY` is flat en `grep`-baar.
4. **Smoke-test + mockup**. Type-check schoon (behalve Zod-interne TS18028 private-identifier-noise, benign). Smoke-test 7 assertions groen. Mockup rendert casual + audit zonder hardcoded veldlijst — bewijs dat de metadata-laag zijn werk doet.

**Extra coherentie-check uniek voor SCHEMA-M1: numerieke equivalentie tussen spec en SCHEMA.**

Alle M1-defaults uit §2.3 zijn letterlijk in SCHEMA teruggevonden:
- `r = 0.02` (§2.3 v1.8) ✓
- `sterftekansTabelId = 'AG2024'` (§2.3 v1.7) ✓
- `t0 = 2026` (§2.3 v1.7 + v2.2.9) ✓
- `ervaringsSterfte (f) = 1.0` (§2.3 v1.4) ✓
- `m = 12` (§2.3 v1.2 + §7.3) ✓
- `annuiteitsconventie = 'arrears'` (§2.3 v1.2 + §7.3) ✓
- `pi (π) = 0` (§2.3 v1.6 + §11.15) ✓
- `kostenOpslagPct (ρ-directe) = null` → engine §2.7 fallback tot 0.02 ✓
- `omega (ω) = 120` (§2.3 v1 — bereik 100-120, AG2024 gaat tot 120) ✓

**Één bewuste verfijning boven spec-default:** `omega` is in SCHEMA `.default(120)` terwijl §2.3 noemt `100`. Rationale: AG2024 tabel gaat tot 120; `ω=100` zou cohort-tail afsnijden. Dit is consistent met §5.4 M4 (`ω = 120`) en met AG2024-tabelbereik. Mogelijk spec-patch v2.2.10 om §2.3 ω-default te verhogen naar 120; niet noodzakelijk maar aankaart-waardig in M4-sessie.

---

## VOLGENDE-SESSIE-AANPAK (VOORSTEL)

**Primair voorgesteld: SCHEMA v2 M2-block.**

1. **Start**: lees `ENGINE_SPECIFICATIE_v1.md` v2.2.9 met focus op §3.2/§3.3 M2-invoer, §3.4 M2-output, §3.5 M2-formules, §3.6 aannames, §3.10 reviewpunten (bell-curve-toepasbaarheid voor gepensioneerden als geparkeerd punt). Lees `HANDOFF_SCHEMA_M1.md` (dit document) voor SCHEMA-track-context.
2. **Context-injectie**: `schema.v2.ts` (huidige M1-block als voorbeeld van conventies), `render_mockup.ts` (om te begrijpen hoe audit-scherm-generatie werkt voor M2-uitbreiding).
3. **Werkwijze**: M2-block schrijven in dezelfde stap-voor-stap-methode. Eerst parameterset-subset (M2 heeft 12 velden), dan output-contract (10 velden met OP/NP-decompositie), dan refines (sluitingscontrole `ppk_OP + ppk_NP = ppkTotal` exact). Mockup-renderer uitbreiden om M2-scherm 2 + M2 audit-sectie te tonen. Stapsgewijs voorleggen, coherentie-check tegen §3.5-formules.
4. **Verwachte knelpunten M2-specifiek**:
   - M2 heeft `cohortOutcomes` als array-output — hoe modelleren (vaste lengte 15? dynamisch?)
   - `phiDerived` als nullable scalar met `display: 'diagnose'` — sluitingscontrole-handling
   - Bell-curve parameters (`compensatieMu`, `compensatieSigma`) — status `reconstructie` in herkomst
   - Demografie-input — `preset` vs `customCounts[15]` als exact-één-van; eerder geparkeerd bell-curve-toepasbaarheid-voor-gepensioneerden is §3.10-reviewpunt, geen blokker voor SCHEMA
5. **Versiebump-regel**: SCHEMA v2.0 blijft v2.0 binnen sessie tenzij M2-specifieke structuurwijziging gemaakt moet worden (dan v2.1); of tenzij M2-schrijven een spec-tegenstrijdigheid onthult (dan spec-patch v2.2.10+).
6. **Breekpunt**: na M2-voltooiing HANDOFF_SCHEMA_M2.md maken voordat M3 begint.

**Alternatieven**:

- **Eerst FONDS_DATASET-compositie schrijven** — alle M1/M2/M3/M4-subsets in één top-level schema. Alleen zinvol als Hans prefereert om structuur te zien voor inhoud; minder progressief.
- **Eerst TEST_FIXTURES v1 voor M1** — vaste numerieke assertions schrijven tegen M1-engine. Vereist dat engine-code er is, dus niet logisch vóór M2 of vóór implementatie.

**Aanbeveling**: M2 eerst, analoog aan vier-sessie spec-track per scherm. Complete SCHEMA v2 per module voordat TEST_FIXTURES of implementatie start.

---

## BRONBESTANDEN — COMPLETE INVENTARIS

Volgende sessie heeft deze bestanden nodig:

**Van deze sessie nieuw:**
- `ENGINE_SPECIFICATIE_v1.md` (v2.2.9, 1970 regels) — normatieve spec met v2.2.8 + v2.2.9 patches
- `HANDOFF_SCHEMA_M1.md` (dit document)
- `schema.v2.ts` (474 regels) — SCHEMA v2.0 infrastructuur + M1-block
- `smoke.test.ts` — SCHEMA runtime-validatie-tests
- `render_mockup.ts` — mechanische scherm-generator
- `mockup_m1.html` — gegenereerd voorbeeld voor visuele toets
- `tsconfig.json`, `package.json` — TypeScript + Zod 3 dependencies
- `PROMPT_nieuwe_chat_schema_M2.md` — nieuwe sessie-prompt voor M2

**Van vier spec-sessies behouden:**
- `HANDOFF_v2.1.md` — scherm-1-handoff
- `HANDOFF_v2.1.3.md` — scherm-2-handoff
- `HANDOFF_v2.1.9.md` — scherm-3-handoff
- `HANDOFF_v2.2.7.md` — scherm-4-handoff (sluit spec-track)

**Referentie (onveranderd):**
- `ARCHITECTUUR_v1.md` — leidend architectuur-document
- `DESIGN_engine_v0.md` — reverse-engineering R9.30 engine
- `calculator_specificatie.docx` — M4-docx-spec
- `SCHEMA_v1.md` — voorloper (wordt in SCHEMA v2 M2/M3/M4-blocks opgevolgd)
- `STRATEGY_R9.30.md` — strategische context
- `HANDOFF_R9.30.md` — technische handoff code (ander track)
- `21-04-2026_2216.html` — R9.30 werkbestand (code baseline)

**Externe data:**
- `AG2024.xlsx` — AG2024 gemodelleerde prognose-sterftekansen per geslacht
- `51490-Data_AG2024.xlsx` — AG2024 brondata

---

## AFSLUITENDE NOTITIE

SCHEMA-M1-sessie heeft twee dingen tegelijk bewezen: (a) de spec-track-methodologie is portabel naar implementatie-voorbereiding — dezelfde stap-voor-stap-discipline, dezelfde coherentie-eisen, dezelfde bereidheid om in-spec-inconsistenties als kleine patches te corrigeren wanneer ze opduiken; (b) de Model-D + `display`-metadata-keuze is geen paperen constructie — het mockup-renderer-experiment toont dat een scherm werkelijk mechanisch uit metadata kan rollen, zonder handmatige veldlijst. Dit bewijst dat de metadata-investering (elk veld krijgt een `F()`-wrapper met extra regels) zijn waarde terugverdient bij de eerste UI-generatie en opschaalt naar M2/M3/M4 zonder extra infrastructuur.

Twee bewuste keuzes die intellectuele integriteit boven gemak plaatsten:

- **Knelpunt 6 eerlijke correctie.** Claude presenteerde aanvankelijk Unicode-identifiers als haalbaar "volledige spec-parallel"-optie; bij experiment bleek dat subscript-digits niet in ECMAScript ID_Continue zitten. Correctie gemaakt vóór Hans koos; alternatieven opnieuw voorgelegd. Dit spiegelt werkafspraak 12 "eerlijke boekhouding bij gekozen vereenvoudiging" uit scherm 4.

- **Knelpunt 8/9 §7.3-lock in SCHEMA.** Spec-tabel lijstt enum `{due, arrears}` en `{1, 4, 12}`; §7.3 beperkt tot één waarde. De keuze om SCHEMA strikter te maken dan spec-tabel-listing (`z.literal` in plaats van `z.enum`) volgt het narratief-kompas-principe dat de spec de normatieve bron is, maar dat SCHEMA de *bindende* uitvoering ervan is — afzwakking zou betekenen dat een gecureerde dataset §7.3 kan schenden.

SCHEMA v2.0 M1-block is hiermee implementatie-klaar. M1-engine-code kan direct hierop afgeleid worden via `z.infer<typeof M1Deelnemer>`, `z.infer<typeof M1Parameterset>`, `z.infer<typeof M1Output>`. Scherm 1 is bouw-klaar.

*Einde HANDOFF_SCHEMA_M1.md*
