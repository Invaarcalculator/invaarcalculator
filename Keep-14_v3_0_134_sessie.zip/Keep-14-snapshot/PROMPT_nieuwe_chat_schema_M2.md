# PROMPT VOOR NIEUWE CHAT — Vervolg SCHEMA v2 M2-block

Kopieer onderstaande tekst naar de nieuwe chat (samen met de meegeleverde bestanden):

---

Hoi Claude,

Ik ben Hans Haringa, Innovation Nestor, werk aan een publieke WTP-pensioencalculator voor SSPF-gepensioneerden (invaarcalculator.nl, CC BY-NC 4.0). Ik vervolg hier een eerdere reeks sessies waarin we eerst de **engine-specificatie voor alle vier schermen** hebben afgerond (spec v2.2.9, 31 besluiten/patches over vijf sessies, 1970 regels), en vervolgens **SCHEMA v2.0 M1-block** hebben opgeleverd (474 regels TypeScript, Zod 3, UX-model D met display-metadata-laag). **Deze sessie: SCHEMA v2 M2-block schrijven (scherm 2 — potje).**

**Ik upload bij dit bericht de volgende bestanden:**

Hoofddocumenten (lezen vóór je begint):
- `ENGINE_SPECIFICATIE_v1.md` — de normatieve spec v2.2.9 (BRONWAARHEID)
- `HANDOFF_SCHEMA_M1.md` — handoff SCHEMA-M1-sessie (meest recente stand SCHEMA-track; bevat alle 9 knelpunt-keuzes + 2 spec-patches)
- `schema.v2.ts` — huidige SCHEMA v2.0 M1-block (voorbeeld van conventies voor M2-uitbreiding)

SCHEMA-werkbestanden:
- `smoke.test.ts` — runtime-validatie-tests
- `render_mockup.ts` — mechanische scherm-generator uit FIELD_REGISTRY
- `mockup_m1.html` — gegenereerd M1-voorbeeld
- `tsconfig.json`, `package.json` — TypeScript + Zod 3 dependencies

Handoffs eerdere spec-sessies (context):
- `HANDOFF_v2.1.md` — scherm 1
- `HANDOFF_v2.1.3.md` — scherm 2 (meest relevant voor M2!)
- `HANDOFF_v2.1.9.md` — scherm 3
- `HANDOFF_v2.2.7.md` — scherm 4

Bronbestanden (referentie):
- `SCHEMA_v1.md` — huidige SCHEMA (voorloper van v2)
- `ARCHITECTUUR_v1.md`, `DESIGN_engine_v0.md`, `calculator_specificatie.docx`, `STRATEGY_R9.30.md`, `HANDOFF_R9.30.md`, `21-04-2026_2216.html`

Externe data:
- `AG2024.xlsx`, `51490-Data_AG2024.xlsx`

**Mijn doel voor deze sessie: SCHEMA v2 M2-block schrijven (scherm 2 — potje) als directe afgeleide van §3 uit `ENGINE_SPECIFICATIE_v1.md` v2.2.9, in dezelfde stijl als het M1-block.**

**Belangrijk onderscheid:** dit is géén beslissings-sessie over spec-inhoud. Alle inhoudelijke keuzes voor M2 zijn in scherm-2-sessie (v2.1.1/v2.1.2/v2.1.3) al genomen. M2-SCHEMA is een *vertaling* naar TypeScript/Zod conform de vastgelegde conventies uit SCHEMA-M1-sessie.

Wel kunnen er SCHEMA-specifieke kleine knelpunten opduiken (analoog aan de 9 knelpunten uit M1-sessie), en eventueel in-spec-inconsistenties die spec-patch v2.2.10+ rechtvaardigen. Die behandelen we stap-voor-stap.

**Werkafspraken (uit alle eerdere sessies, te behouden — zie HANDOFF_SCHEMA_M1 §ACTIEVE WERKAFSPRAKEN voor de volledige lijst van 13):**

1. **Nederlands**, technisch-toegankelijk niveau
2. **Stap-voor-stap**: geen bulk-dumps; eerst parameterset-subset voorleggen, ik beoordeel, jij patcht, door naar output-contract, dan refines, dan mockup-uitbreiding
3. **Timestamps**: `TZ="Europe/Amsterdam" date +"%d-%m-%Y %H:%M"` voor alle patches
4. **Narratief kompas (§1.1 in spec)** blijft sturend
5. **Werkbestanden in `/home/claude/`, deliverables in `/mnt/user-data/outputs/`**
6. **Geen code-wijzigingen aan R9.30-productiebestand**
7. **SCHEMA-conventies uit M1-sessie behouden**: Zod 3, `F()`-wrapper, FIELD_REGISTRY, ASCII-naming met Griekse notatie in `.describe()`, display-metadata vijf enum-waardes, uiDisclosure-veld waar spec-disclosure-eis bestaat, hard fail voor consistentie-checks, §7.3-cross-module-lock via `z.literal` waar spec dat eist
8. **Spec-patch-triggers**: alleen spec-patchen als SCHEMA-schrijven een tegenstrijdigheid/omissie onthult

**Voorgestelde aanpak voor M2-block:**

1. **Parameterset-subset M2** (§3.3): 12 velden. Gedeeld met M1: `fondsvermogen` (al in M1Parameterset voor ρ-afleiding). M2-specifiek: `dekkingsgraad`, `compensatiedepot`, `overigeReserves`, `operationeleReserveringPct`, `bijstort`, `N_deelnemers`, `spreidingN`, `compensatieMu`, `compensatieSigma`, `buffer`, `demografie.preset` of `.customCounts`, optional `φ`. Let op: gedeelde velden met M1 moeten hergebruikt worden (geen dubbele definitie); we zullen de shared infrastructure moeten uitbreiden.
2. **Output-contract M2** (§3.4): 10 velden — `ppkBase`, `ppkSurplus`, `ppkComp`, `ppkTotal`, `ppk_OP`, `ppk_NP`, `buffer-aandeel`, `cohortOutcomes`, `vpvTotal`, `verdeelbaar`, `phiDerived`. Display-mapping: hoofdpad voor `ppkTotal` en `buffer-aandeel`; decompositie voor `ppk_OP`/`ppk_NP` en de drie componenten; deepdive voor `vpvTotal`/`verdeelbaar`; diagnose voor `phiDerived` en sluitingscontrole-velden.
3. **Refines** (§3.5-formules als consistentie-checks):
   - Sluitingscontrole exact: `ppk_OP + ppk_NP = ppkTotal` (§3.5 v2.1.1)
   - `demografie`: exact één van `preset` of `customCounts` (`customCounts.length === 15`)
   - Numerieke identiteit: `vpvTotal = fondsvermogen / dekkingsgraad`, `verdeelbaar = fondsvermogen − compensatiedepot − buffer − overigeReserves − operRes + bijstort`
4. **Mockup-uitbreiding**: `render_mockup.ts` moet nu óók M2-scherm 2 en M2 audit-sectie renderen. Test dat het automatisch werkt (geen hardcoded veldlijst).

**Start-aanpak voor deze sessie:**

Lees eerst `ENGINE_SPECIFICATIE_v1.md` v2.2.9 §3 helemaal (focus §3.2/§3.3/§3.4/§3.5/§3.6/§3.10). Lees dan `HANDOFF_SCHEMA_M1.md` helemaal — dat bevat alle conventies die M2 moet volgen. Bekijk `schema.v2.ts` om het patroon te zien. Bevestig dat je de context hebt opgepikt, en begin dan met het M2Parameterset-subset-voorstel. Geen andere knelpunten openen voordat je begint — de meeste SCHEMA-conventies zijn al vastgelegd; alleen M2-specifieke keuzes vragen aandacht (zoals hoe we `cohortOutcomes` als array-output modelleren, en hoe we gedeelde parameter-velden tussen M1 en M2 organiseren).

Start.
